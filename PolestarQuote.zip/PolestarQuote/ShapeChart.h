#pragma once
class TKLineControl;
class TShapeChart
{
public:
	TShapeChart();
	~TShapeChart();
public:
	void SetKLineControl(TKLineControl* pKLine) { m_pKLine = pKLine; }
	void SelectDrawTool(SHAPE_TYPE type,TKLineChart* pChart, TKLineAxisX* pAxisX);
	void DrawChart(HDC mdc);
	bool OnMouseMove(POINTS& pts);
	bool OnLButtonDown(POINTS& pts);
	bool OnRButtonDown(POINTS& pts);
	void ResetShape();
	void DeleteAlleShape();
	void DeleteSingleShape();
	void GetShapeArray(std::vector<TShape*>& arr);
	void SetArrShape(std::vector<TShape*>& arrShape);
	int  GetShapeSize() { return m_arrShape.size(); }
	void DeleteShapePen();
private:
	void AfterShapePenClick();   //���ʱ������һ���Ժ�Ĵ���
private:
	std::vector<TShape*> m_arrShape;
	ShapePen*            m_pCurShapePen;
	TKLineControl*       m_pKLine;
	int                  m_penWid;
	COLORREF             m_clrPen;
	TShape*              m_pCurShape; //��ǰ��ý������״
	int                  m_nSelShap;
};


#include "PreInclude.h"
int TPanelControl::TICK_ROW_HEIGHT = 22;
int TPanelControl::LEVEL_ONE_HEIGHT = 22;
int TPanelControl::LEVEL_OTHER_HEIGHT = 22;
int TPanelControl::QTY_WIDTH = 70;
int TPanelControl::SELL_HEIGHT = CONTRACT_HEIGHT;
int TPanelControl::BUY_HEIGHT = CONTRACT_HEIGHT;
TPanelControl::TPanelControl(TDuiWindow& window) : TDuiControl(window), m_Contract(NULL), m_Level(PANEL_LEVEL_ONE), m_UpDown(0), m_ShowAllBuySell(false),m_bIsSpread(false)
, m_all_buy_vol(0), m_all_sell_vol(0), m_LastAskPrice(0), m_LastBidPrice(0), m_AskColor(COLOR_FUTURE_EQUAL), m_BidColor(COLOR_FUTURE_EQUAL),m_bSmallModel(false),m_bInitWidth(false),m_bLeftBid(true),m_nSelectField(-1)
, m_bAccumulate(true)
{
	m_Chg[0] = true;
	m_Chg[1] = true;
	m_Chg[2] = true;
	G_QuoteCenter.Add_PanelControl(this);
	m_SpreadContractNo[0] = '\0';
}

TPanelControl::~TPanelControl()
{
	if (NULL != m_Contract)
		G_QuoteCenter.Unsub_Quote(m_Contract->ContractNo);

	G_QuoteCenter.Del_PanelControl(this);
}

bool TPanelControl::SetContract(SContract* contract)
{
	if (contract == m_Contract)
		return false;

	if (NULL != m_Contract)
	{
		G_QuoteCenter.Unsub_Quote(m_Contract->ContractNo);
		G_QuoteCenter.Unsub_HisQuote(m_Contract->ContractNo, this);
	}
	else if (strlen(m_SpreadContractNo) > 0)
	{
		G_QuoteCenter.Unsub_Quote(m_SpreadContractNo);
		m_SpreadContractNo[0] = '\0';
	}

	m_Contract = contract;

	if (NULL != m_Contract)
	{
		G_QuoteCenter.Sub_Quote(m_Contract->ContractNo);
		G_QuoteCenter.Sub_HisQuote(m_Contract->ContractNo, S_KLINE_TICK, 0, 50, this);
	}
	m_bIsSpread = false;
	m_nSelectField = -1;
	//�����Ƿ��� ��������
	m_ShowAllBuySell = (NULL != m_Contract 
		&& 'Z' == m_Contract->ContractNo[0] && 'C' == m_Contract->ContractNo[1]
		&& 'E' == m_Contract->ContractNo[2] && '|' == m_Contract->ContractNo[3]);

	ChgAll();
	if (m_bSmallModel)
	{
		int nWidth = PreColSmallPanelWidth();
		((TQuoteFrame*)GetWindow())->SetPanelWidth(nWidth);
	}
	else
	{
		((TQuoteFrame*)GetWindow())->ApplyColorSetting();
	}
	return true;
}

bool TPanelControl::SetSpreadContractNo(SContractNoType cno)
{
	if (strcmp(cno, m_SpreadContractNo) == 0)
		return false;
	if (NULL != m_Contract)
	{
		G_QuoteCenter.Unsub_Quote(m_Contract->ContractNo);
		G_QuoteCenter.Unsub_HisQuote(m_Contract->ContractNo, this);
		m_Contract = NULL;
	}
	else if (strlen(m_SpreadContractNo) > 0)
	{
		G_QuoteCenter.Unsub_Quote(m_SpreadContractNo);
	}
	strcpy_s(m_SpreadContractNo, cno); 
	G_QuoteCenter.Sub_Quote(m_SpreadContractNo);
	G_QuoteUtils.GetSpreadContract(m_SpreadContractNo, m_SpreadContract);
	m_bIsSpread = true;
	//�����Ƿ��� ��������
	m_ShowAllBuySell = (NULL != m_Contract
		&& 'Z' == m_Contract->ContractNo[0] && 'C' == m_Contract->ContractNo[1]
		&& 'E' == m_Contract->ContractNo[2] && '|' == m_Contract->ContractNo[3]);

	ChgAll();

	return true;
}

void TPanelControl::GetSpreadContractNo(SContractNoType& cno)
{
	strcpy_s(cno, sizeof(SContractNoType),m_SpreadContractNo);
}

void TPanelControl::SetLevel(TQuotePanelLevelType level)
{
	m_Level = level;
}

void TPanelControl::ChgAll()
{
	TCriticalSection::Lock lock(m_Crit);
	m_Chg[0] = true;
	m_Chg[1] = true;
	m_Chg[2] = true;
}

void TPanelControl::ChgQuote()
{
	TCriticalSection::Lock lock(m_Crit);
	m_Chg[0] = true;
	m_Chg[1] = true;
}

void TPanelControl::ChgSpreadQuote(const SSpreadContract* scont)
{
	TCriticalSection::Lock lock(m_Crit);
	m_SpreadContract.SnapShot = scont->SnapShot;
	m_Chg[1] = true;
}

void TPanelControl::ChgTick()
{
	TCriticalSection::Lock lock(m_Crit);
	m_Chg[2] = true;
}
void TPanelControl::SetUpDownRefType(UpDownRefType type)
{
	m_updwonType = type;
	ChgQuote();
	Redraw(NULL);
}
void TPanelControl::SetIsLeftBid(bool bLeftBid)
{
	m_bLeftBid = bLeftBid;
	ChgQuote();
	Redraw(NULL);
}
void TPanelControl::SetIsBidRedAskGreen(bool bBuyR)
{
	m_bBidRAskG = bBuyR;
	ChgQuote();
	Redraw(NULL);
}
void TPanelControl::SetIsShowAccumulate(bool bShow)
{
	m_bAccumulate = bShow;
	ChgQuote();
	Redraw(NULL);
}
void TPanelControl::CancalSelectField()
{
	m_nSelectField = -1;
	m_Chg[1] = true;
	Redraw(NULL);
}
bool TPanelControl::OnDraw(HDC hdc, HDC mdc, RECT& cr, RECT& ur, bool follow)
{
	if (m_bSmallModel)
	{
		//�����ǵ�
		CalUpDown();
		DrawSmallPanel(mdc, cr);
		return true;
	}
	//�����з�
	PrepareRects(cr);
	if (follow)
		ChgAll();

	{
		TCriticalSection::Lock lock(m_Crit);
		m_DrawChg[0] = m_Chg[0];

		m_DrawChg[1] = m_Chg[1];
		m_DrawChg[2] = m_Chg[2];
		m_Chg[0] = false;
		m_Chg[1] = false;
		m_Chg[2] = false;
	}

	//������ �� �ָ���
	Draw_Background(mdc, cr);

	//�����ǵ�
	CalUpDown();
	
	//����������۸�
	Draw_Price(mdc, cr);

	//��tick�仯
	Draw_Tick(mdc, cr);

	return true;
}

void TPanelControl::OnMouseMove(WORD btn, POINTS& pts)
{
	//���ο��ȵ������� 2016-08-11
	//�ް���
	if (0 == btn)
	{
		if (pts.x >= 0 && pts.x < 3)
		{
			if (CURSOR_WE != GetCursor())
				SetCursor(CURSOR_WE);
		}
	}
	else if (HasMouse())	//���µ�������
	{
		if (CURSOR_WE != GetCursor())
			SetCursor(CURSOR_WE);

		POINT p;
		GetCursorPos(&p);

		RECT r;
		GetRect(r);
		r.right -= r.left;

		if (m_bSmallModel&&r.right + m_BeginMoveX - p.x >= MIN_WIDTH)
		{
			m_bSmallModel = false;
			((TQuoteFrame*)GetWindow())->SetPanelWidth(MID_WIDTH);
			if (HasMouse())
				ReleaseMouse();
		}
		else  if ((r.right + m_BeginMoveX - p.x >= MIN_WIDTH && r.right + m_BeginMoveX - p.x <= MAX_WIDTH)|| m_bSmallModel&&r.right + m_BeginMoveX - p.x >= 20)
		{
			((TQuoteFrame*)GetWindow())->SetPanelWidth(r.right + m_BeginMoveX - p.x);
			m_BeginMoveX = p.x;
		}
		else if (!m_bSmallModel&&r.right + m_BeginMoveX - p.x < MIN_WIDTH)
		{
			SetSmallModle(true);
			((TQuoteFrame*)GetWindow())->SetPanelWidth(SMALL_MODEL_WIDTH);
			if (HasMouse())
				ReleaseMouse();
		}
		
	}
}

void TPanelControl::OnLButtonDown(WORD btn, POINTS& pts)
{
	ClickPanelLinkage("LButtonDown", pts);

	//���ο��ȵ������� 2016-08-11
	if (pts.x >= 0 && pts.x < 3)
	{
		CatchMouse();
		POINT p;
		GetCursorPos(&p);
		m_BeginMoveX = p.x;
		return;
	}

	
	RECT wr;
	GetRect(wr);

	RECT r(wr);
	r.right -= r.left;
	r.bottom -= r.top;

	r.bottom = r.top + CONTRACT_HEIGHT;
	r.left = r.right - (r.bottom - r.top);

	RECT BigRc(r);
	InflateRect(&BigRc, -7, -7);
	if (m_bSmallModel&&pts.x >= BigRc.left && pts.x < BigRc.right && pts.y >= BigRc.top && pts.y < BigRc.bottom)
	{
		m_bSmallModel = false;
		((TQuoteFrame*)GetWindow())->SetPanelWidth(MID_WIDTH);
		return;
	}
	if (!m_bSmallModel&&pts.x >= r.left && pts.x < r.right && pts.y >= r.top && pts.y < r.bottom)
	{
		TDuiPopMenuWindow pop;
	
		TDuiPopMenuItem item;
		memset(&item, 0, sizeof(TDuiPopMenuItem));

		item.Index = 1;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_PANEL_QUOTE1), sizeof(item.Text)/sizeof(wchar_t) - 1);
		pop.AddItem(item);

		item.Index = 2;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_PANEL_QUOTE5), sizeof(item.Text)/sizeof(wchar_t) - 1);
		pop.AddItem(item);

		item.Index = 3;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_PANEL_QUOTE10), sizeof(item.Text)/sizeof(wchar_t) - 1);
		pop.AddItem(item);

		item.Index = 4;
		wcsncpy_s(item.Text,G_LANG->LangText(TLI_SMALLPANEL), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddItem(item);

		pop.SetSpi(this);

		//POINT p;
		//GetCursorPos(&p);
		//pop.ShowPop(p.x, p.y);
		POINT p;
		p.x = wr.right - wr.left;
		p.y = CONTRACT_HEIGHT - 1;
		ClientToScreen(p);
		pop.ShowPop(p.x - TDuiPopMenuControl::POPMENU_WIDTH, p.y,false,NULL);
	}
	
}


void TPanelControl::OnRButtonDown(WORD btn, POINTS& pts)
{

}

void TPanelControl::OnLButtonUp(WORD btn, POINTS& pts)
{
	//���ο��ȵ������� 2016-08-11
	if (HasMouse())
		ReleaseMouse();
}

void TPanelControl::OnLButtonDbClk(WORD btn, POINTS& pts)
{
	ClickPanelLinkage("LButtonDbClk", pts);
}

void TPanelControl::OnKeyDown(WPARAM vk, LPARAM lParam)
{

}

void TPanelControl::OnMouseWheel(short rot, WORD btn, POINTS& pts)
{

}

void TPanelControl::OnPopMenuClick(TDuiPopMenuItem* obj)
{
	int nWidth = 0;
	switch (obj->Index)
	{
	case 2:
		m_Level = PANEL_LEVEL_FIVE;
		break;
	case 3:
		m_Level = PANEL_LEVEL_TEN;
		break;
	case 4:
		m_bSmallModel = true;
		nWidth = PreColSmallPanelWidth();
		((TQuoteFrame*)GetWindow())->SetPanelWidth(nWidth);
		return;
	default:
		m_Level = PANEL_LEVEL_ONE;
		break;
	}

	((TQuoteFrame*)GetWindow())->SaveCfg();

	ChgAll();
	Redraw(NULL);
}
void TPanelControl::PrepareRects(RECT& cr)
{
	//�����Լ��ʾ����
	RECT& con_r(m_Rects[CONTRACT]);
	con_r = cr;
	con_r.bottom = con_r.top + CONTRACT_HEIGHT;
	RECT& con_name_r(m_Rects[CONTRACT_NAME]);
	con_name_r = con_r;
	con_name_r.left = LINE_PADDING;
	RECT& con_sel_r(m_Rects[CONTRACT_SEL]);
	con_sel_r = con_r;
	con_sel_r.bottom -= 1;
	con_sel_r.left = con_sel_r.right - (con_sel_r.bottom - con_sel_r.top);
	con_name_r.right = con_sel_r.left;
	//����۸���ʾ����
	//����߶�
	LONG quote_height = (PANEL_LEVEL_ONE == m_Level ? (SELL_HEIGHT + BUY_HEIGHT + 6 * ROW_HEIGHT) : (2 * LEVEL_ONE_HEIGHT +2*(m_Level-1)* LEVEL_OTHER_HEIGHT));
	if (m_ShowAllBuySell)
		quote_height += ROW_HEIGHT;
	RECT& price_r(m_Rects[PRICE]);
	price_r = cr;
	price_r.top += CONTRACT_HEIGHT;
	price_r.bottom = price_r.top + quote_height;
	//������ϸ��ʾ����
	//if (CONTRACT_HEIGHT + quote_height < cr.bottom - cr.top)
	{
		RECT& tick_r(m_Rects[TICK]);
		tick_r = cr;
		tick_r.top = CONTRACT_HEIGHT + quote_height;
		tick_r.bottom = cr.bottom;

	}
}
void TPanelControl::CalUpDown()
{
	m_UpDown = 0;
	m_UpDownRate = 0;
	m_UpDownColor = COLOR_FUTURE_EQUAL;
	SQuoteSnapShot* q(NULL);
	if (m_bIsSpread)
	{
		//���������ǵ�
		if (strlen(m_SpreadContractNo) <= 0 || m_SpreadContract.SnapShot == NULL)
			return;
		q = m_SpreadContract.SnapShot;
		SQuoteField* field1 = &q->Data[S_FID_LASTPRICE];
		SQuoteField* field2 = &q->Data[S_FID_PRESETTLEPRICE];
		if (S_FIDTYPE_NONE != field1->FidAttr&&S_FIDTYPE_NONE != field2->FidAttr)
			m_UpDown = field1->Price - field2->Price;
	}
	else
	{
		if (NULL == m_Contract || NULL == m_Contract->SnapShot)
			return;
		q = m_Contract->SnapShot;
		SQuoteField* field = &q->Data[S_FID_UPDOWN];
		if (S_FIDTYPE_NONE != field->FidAttr)
			m_UpDown = field->Price;
	}

	SQuoteField* field = &q->Data[S_FID_GROWTH];
	if (S_FIDTYPE_NONE != field->FidAttr)
		m_UpDownRate = field->Price;
	if (m_UpDown > 0)
		m_UpDownColor = COLOR_FUTURE_UP;
	else if (m_UpDown < 0)
		m_UpDownColor = COLOR_FUTURE_DOWN;

	SPriceType askPrice = 0, bidPrice = 0;
	if (m_updwonType == TYPE_LASTPRICE)
	{  
		SQuoteField field1 = q->Data[S_FID_BESTASKPRICE];
		if (!m_bIsSpread)
		{
			SQuoteField Im_field;
			bool ret = G_StarApi->GetImpliedField(m_Contract, S_FID_BESTASKPRICE, &Im_field);
			if (ret)
				field1 = Im_field;
		}
		if (S_FIDTYPE_NONE != field1.FidAttr)
		{
			askPrice = field1.Price;
			if (m_LastAskPrice != 0 && m_LastAskPrice != askPrice)
			{
				if (askPrice - m_LastAskPrice >0)
					m_AskColor = COLOR_FUTURE_UP;
				else
					m_AskColor = COLOR_FUTURE_DOWN;
			}
		}
		field1 = q->Data[S_FID_BESTBIDPRICE];
		if (!m_bIsSpread)
		{
			SQuoteField Im_field;
			bool ret = G_StarApi->GetImpliedField(m_Contract, S_FID_BESTBIDPRICE, &Im_field);
			if (ret)
				field1 = Im_field;
		}
		if (S_FIDTYPE_NONE != field1.FidAttr)
		{
			bidPrice = field1.Price;
			if (m_LastBidPrice != 0 && m_LastBidPrice != bidPrice)
			{
				if (bidPrice - m_LastBidPrice >0)
					m_BidColor = COLOR_FUTURE_UP;
				else
					m_BidColor = COLOR_FUTURE_DOWN;
			}
		}
	}
	m_LastAskPrice = askPrice;
	m_LastBidPrice = bidPrice;
}

void TPanelControl::Draw_Background(HDC hdc, RECT& cr)
{
	//��Լ�仯
	if (m_DrawChg[0])
	{
		//����
		RECT zr(m_Rects[CONTRACT]);
		FillRect(hdc, &zr, BRUSH_PANEL_BACKGROUND);

		//�ױ�
		SelectObject(hdc, PEN_PANEL_LINE);
		MoveToEx(hdc, LINE_PADDING, zr.bottom - 1, 0);
		LineTo(hdc, zr.right - LINE_PADDING, zr.bottom - 1);

		//��Լ
		SelectObject(hdc, FONT_PANEL_CONTRACT);
		SetTextColor(hdc, COLOR_PANEL_STR);

		RECT r = m_Rects[CONTRACT_NAME];
		wchar_t text[101];
		if (NULL != m_Contract&&!m_bIsSpread)
		{		
			if (GetContractName(G_StarApi, m_Contract->ContractNo, text))
			{
				wcsncat_s(text, L"  ", 2);
				GetContractCode(G_StarApi, m_Contract->ContractNo, &text[wcslen(text)]);
			}
			else 
			{
				MultiByteToWideChar(1252, 0, m_Contract->ContractNo, -1, text, sizeof(text) / sizeof(wchar_t));
			}
			DrawText(hdc, text, wcslen(text), &r, DT_NOPREFIX | DT_LEFT | DT_SINGLELINE | DT_VCENTER);
		}
		else if (m_bIsSpread)
		{
			if (GetContractName(G_StarApi, m_SpreadContractNo, text))
			{
				wcsncat_s(text, L"  ", 2);
				GetContractCode(G_StarApi, m_SpreadContractNo, &text[wcslen(text)]);
			}
			else
			{
				MultiByteToWideChar(1252, 0, m_SpreadContractNo, -1, text, sizeof(text) / sizeof(wchar_t));
			}
			DrawText(hdc, text, wcslen(text), &r, DT_NOPREFIX | DT_LEFT | DT_SINGLELINE | DT_VCENTER);
		}
		//�˵�ѡ���־
		SelectObject(hdc, PEN_KLINE_CYCLE);
		r = m_Rects[CONTRACT_SEL];
		Draw_Arraw(hdc, r, D_DOWN);
	}

	//����仯 
	if (m_DrawChg[1])
	{
		//����
		RECT zr(m_Rects[PRICE]);
		FillRect(hdc, &zr, BRUSH_PANEL_BACKGROUND);

		zr.left += LINE_PADDING;
		//�ָ����� �� ��̬����	
		SelectObject(hdc, PEN_PANEL_DOT_LINE);
		SelectObject(hdc, FONT_PANEL_TEXT);
		SetTextColor(hdc, COLOR_PANEL_PRICE_TEXT);

		if (PANEL_LEVEL_ONE == m_Level)
		{
			//��������
			RECT r(zr);
			r.bottom = r.top + SELL_HEIGHT;
			DrawText(hdc, G_LANG->LangText(TLI_SELL_TEXT), wcslen(G_LANG->LangText(TLI_SELL_TEXT)), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);

			r.top = r.bottom;
			r.bottom = r.top + BUY_HEIGHT;
			DrawText(hdc, G_LANG->LangText(TLI_BUY_TEXT), wcslen(G_LANG->LangText(TLI_BUY_TEXT)), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);

			//�����ױ���
			MoveToEx(hdc, zr.left, zr.top + SELL_HEIGHT + BUY_HEIGHT, 0);
			LineTo(hdc, zr.right, zr.top + SELL_HEIGHT + BUY_HEIGHT);

			//���ҷָ���
			MoveToEx(hdc, (zr.left + zr.right) / 2, zr.top + SELL_HEIGHT + BUY_HEIGHT, 0);
			LineTo(hdc, (zr.left + zr.right) / 2, zr.bottom);

			//��������
			if (m_ShowAllBuySell)
			{
				r.top = r.bottom;
				r.bottom = r.top + ROW_HEIGHT;

				r.left = zr.left;
				DrawText(hdc, G_LANG->LangText(TLI_PANEL_TOTALBID), wcslen(G_LANG->LangText(TLI_PANEL_TOTALBID)), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);

				r.left = zr.left + (zr.right - zr.left) / 2 + LINE_PADDING;
				DrawText(hdc, G_LANG->LangText(TLI_PANEL_TOTALASK), wcslen(G_LANG->LangText(TLI_PANEL_TOTALASK)), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);

			}

			//���������ֶ�����
			for (int i = 0; i < 6; i++)
			{
				r.top = r.bottom;
				r.bottom = r.top + ROW_HEIGHT;

				r.left = zr.left;
				DrawText(hdc, G_LANG->LangText(TLI_NEW_TEXT+i), wcslen(G_LANG->LangText(TLI_NEW_TEXT+i)), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);

				r.left = zr.left + (zr.right - zr.left) / 2 + LINE_PADDING;
				DrawText(hdc, G_LANG->LangText(TLI_UPDOWN_TEXT+i), wcslen(G_LANG->LangText(TLI_UPDOWN_TEXT+i)), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
			}



		}
		else
		{
			RECT r(zr);
			r.bottom = r.top;

			//��������
			if (m_ShowAllBuySell)
			{
				//���� �� ����
				r.bottom = r.top + ROW_HEIGHT;
				DrawText(hdc, G_LANG->LangText(TLI_PANEL_TOTALBID), wcslen(G_LANG->LangText(TLI_PANEL_TOTALBID)), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);

				r.left = zr.left + (zr.right - zr.left) / 2 + LINE_PADDING;
				DrawText(hdc, G_LANG->LangText(TLI_PANEL_TOTALASK), wcslen(G_LANG->LangText(TLI_PANEL_TOTALASK)), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);

				MoveToEx(hdc, zr.left, zr.top + ROW_HEIGHT, 0);
				LineTo(hdc, zr.right, zr.top + ROW_HEIGHT);
			}

			//�м�ָ���
			MoveToEx(hdc, zr.left + LINE_PADDING, zr.bottom - LEVEL_ONE_HEIGHT - (m_Level - 1) * LEVEL_OTHER_HEIGHT, 0);
			LineTo(hdc, zr.right - LINE_PADDING, zr.bottom - LEVEL_ONE_HEIGHT - (m_Level - 1) * LEVEL_OTHER_HEIGHT);

			r.left = zr.left;

			//����
			for (int i = 0; i < m_Level; i++)
			{
				r.top = r.bottom;
				r.bottom = r.top + (i == m_Level - 1 ? LEVEL_ONE_HEIGHT : LEVEL_OTHER_HEIGHT);
				if (i == m_Level-1)
					r.bottom -= 2;
				DrawText(hdc, G_LANG->LangText(TLI_SELL1_TEXT+m_Level-1-i), wcslen(G_LANG->LangText(TLI_SELL1_TEXT+m_Level-1-i)), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
			}
			r.bottom += 4;
			//����
			for (int i = 0; i < m_Level; i++)
			{
				r.top = r.bottom;
				r.bottom = r.top + (i == 0 ? LEVEL_ONE_HEIGHT : LEVEL_OTHER_HEIGHT);
				DrawText(hdc, G_LANG->LangText(TLI_BUY1_TEXT+i), wcslen(G_LANG->LangText(TLI_BUY1_TEXT+i)), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
			}
		}
	}

	//Tick�仯
	RECT zr(m_Rects[TICK]);
	if (m_DrawChg[2] && zr.bottom-zr.top>0)
	{
		SelectObject(hdc, FONT_PANEL_TEXT);
		SetTextColor(hdc, COLOR_PANEL_TICK_TEXT);
		FillRect(hdc, &zr, BRUSH_PANEL_BACKGROUND);

		//����
		SelectObject(hdc, PEN_PANEL_LINE);
		MoveToEx(hdc, LINE_PADDING, zr.top, 0);
		LineTo(hdc, zr.right - LINE_PADDING, zr.top);

		RECT r(zr);
		r.bottom = r.top + ROW_HEIGHT;
		r.right = r.left + TICK_TIME_WIDTH;
		DrawText(hdc, G_LANG->LangText(TLI_TICK_TIME), wcslen(G_LANG->LangText(TLI_TICK_TIME)), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

		r.left = r.right;
		if (cr.right - TICK_TIME_WIDTH - 3 * TICK_OTHER_WIDTH > 0)
			r.right += cr.right - TICK_TIME_WIDTH - 3 * TICK_OTHER_WIDTH;
		DrawText(hdc, G_LANG->LangText(TLI_TICK_PRICE), wcslen(G_LANG->LangText(TLI_TICK_PRICE)), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

		r.left = cr.right - 3 * TICK_OTHER_WIDTH;
		r.right = r.left + TICK_OTHER_WIDTH;
		DrawText(hdc, G_LANG->LangText(TLI_NEWVOL_TEXT), wcslen(G_LANG->LangText(TLI_NEWVOL_TEXT)), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

		if (m_Contract&&m_Contract->Commodity&&IsDomesticExchange(m_Contract->Commodity->Exchange->ExchangeNo))
		{
			r.left = r.right;
			r.right += TICK_OTHER_WIDTH;
			DrawText(hdc, G_LANG->LangText(TLI_TICK_HOLDCHG), wcslen(G_LANG->LangText(TLI_TICK_HOLDCHG)), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
		}

		r.left = r.right;
		r.right += TICK_OTHER_WIDTH;
		DrawText(hdc, G_LANG->LangText(TLI_TICK_OFFSET), wcslen(G_LANG->LangText(TLI_TICK_OFFSET)), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
	}

	//����ߣ��ᴩ����
	SelectObject(hdc, PEN_PANEL_LINE);
	MoveToEx(hdc, cr.left, cr.top, 0);
	LineTo(hdc, cr.left, cr.bottom);
}
void TPanelControl::Draw_SpreadPrice(HDC hdc, RECT& cr)
{
	if (!m_bIsSpread || m_SpreadContract.SnapShot==NULL)
		return;
	SQuoteSnapShot* q(m_SpreadContract.SnapShot);
	wchar_t text[101];
	wchar_t text2[101];

	SQuoteField* field(NULL);

	SCommodityPrecType Prec = m_SpreadContract.PricePrec;
	//����߶�
	LONG quote_height = (PANEL_LEVEL_ONE == m_Level ? (SELL_HEIGHT + BUY_HEIGHT + 6 * ROW_HEIGHT) : (2 * m_Level * ROW_HEIGHT));
	if (m_ShowAllBuySell)
		quote_height += ROW_HEIGHT;

	RECT zr(cr);
	zr.top = CONTRACT_HEIGHT;
	zr.bottom = zr.top + quote_height;

	//һ��
	if (PANEL_LEVEL_ONE == m_Level)
	{
		//���� �� ����------------------------------------------------------------------------
		SelectObject(hdc, FONT_PANEL_BIG_PRICE);

		text[0] = L'\0';
		field = &q->Data[S_FID_BESTASKPRICE];
		if (S_FIDTYPE_NONE != field->FidAttr)
		{
			FormatPrice(G_StarApi, field->Price, Prec, 1, text, true);
		}
		text2[0] = L'\0';
		field = &q->Data[S_FID_BESTBIDPRICE];
		if (S_FIDTYPE_NONE != field->FidAttr)
		{
			FormatPrice(G_StarApi, field->Price, Prec, 1, text2, true);
		}
		int price_width(TITLE_TEXT_WIDTH);
		SIZE size;
		GetTextExtentPoint(hdc, text, wcslen(text), &size);
		if (size.cx > price_width)
			price_width = size.cx;
		GetTextExtentPoint(hdc, text2, wcslen(text2), &size);
		if (size.cx > price_width)
			price_width = size.cx;

		//������� �� ���
		if (m_updwonType == TYPE_LASTSETTLE)
			SetTextColor(hdc, m_UpDownColor);
		else
			SetTextColor(hdc, m_AskColor);
		RECT r(zr);
		r.left += TITLE_TEXT_WIDTH;
		r.right = r.left + price_width + LINE_PADDING;
		r.bottom = r.top + SELL_HEIGHT;
		DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

		if (m_updwonType == TYPE_LASTSETTLE)
			SetTextColor(hdc, m_UpDownColor);
		else
			SetTextColor(hdc, m_BidColor);
		r.top = r.bottom;
		r.bottom = r.top + BUY_HEIGHT;
		DrawText(hdc, text2, wcslen(text2), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

		//�������
		SetTextColor(hdc, COLOR_PANEL_STR);

		r.top = zr.top;
		r.bottom = r.top + SELL_HEIGHT;
		r.left = r.right + 3 * LINE_PADDING;
		r.right = zr.right;

		text[0] = '\0';
		field = &q->Data[S_FID_BESTASKQTY];
		if (S_FIDATTR_NONE != field->FidAttr)
		{
			_itow_s((int)field->Qty, text, 10);
		}
		DrawText(hdc, text, wcslen(text), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
		if (S_FIDATTR_NONE != field->FidAttr)
			m_all_sell_vol = field->Qty;

		//�������
		r.top = r.bottom;
		r.bottom = r.top + BUY_HEIGHT;

		text[0] = '\0';
		field = &q->Data[S_FID_BESTBIDQTY];
		if (S_FIDATTR_NONE != field->FidAttr)
		{
			_itow_s((int)field->Qty, text, 10);
		}
		DrawText(hdc, text, wcslen(text), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
		if (S_FIDATTR_NONE != field->FidAttr)
			m_all_buy_vol = field->Qty;


		//����------------------------------------------------------------------------
		SelectObject(hdc, FONT_PANEL_SMALL_PRICE);
		SPriceType price(0);

		r.left = zr.left;

		//���� ����
		if (m_ShowAllBuySell)
		{
			SetTextColor(hdc, COLOR_PANEL_STR);
			r.top = r.bottom;
			r.bottom = r.top + ROW_HEIGHT;
			r.right = cr.right / 2 - LINE_PADDING;

			field = &q->Data[S_FID_TOTALBIDQTY];
			if (S_FIDATTR_NONE != field->FidAttr)
			{
				_itow_s((int)field->Qty, text, sizeof(text) / sizeof(wchar_t) / 2, 10);
				DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
			}

			r.right = cr.right - LINE_PADDING;

			field = &q->Data[S_FID_TOTALASKQTY];
			if (S_FIDATTR_NONE != field->FidAttr)
			{
				_itow_s((int)field->Qty, text, sizeof(text) / sizeof(wchar_t) / 2, 10);
				DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
			}
		}

		//����
		SetTextColor(hdc, m_UpDownColor);
		r.top = r.bottom;
		r.bottom = r.top + ROW_HEIGHT;
		r.right = cr.right / 2 - LINE_PADDING;

		field = &q->Data[S_FID_LASTPRICE];
		if (S_FIDATTR_NONE != field->FidAttr && FormatPrice(G_StarApi, field->Price , Prec, 1, text, false))
		{
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
		}

		//�ǵ�
		SetTextColor(hdc, m_UpDownColor);
		r.right = cr.right - LINE_PADDING;
		if (FormatPrice(G_StarApi, m_UpDown , Prec, 1, text, true))
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

		//����
		SetTextColor(hdc, COLOR_PANEL_STR);
		r.top = r.bottom;
		r.bottom = r.top + ROW_HEIGHT;
		r.right = cr.right / 2 - LINE_PADDING;

		field = &q->Data[S_FID_LASTQTY];
		if (S_FIDATTR_NONE != field->FidAttr)
		{
			_itow_s((int)field->Qty, text, 10);
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
		}

		//�Ƿ�
		SetTextColor(hdc, m_UpDownColor);
		r.right = cr.right - LINE_PADDING;
		if (FormatPrice(G_StarApi, m_UpDownRate, 2, 1, text, false))
		{
			wcsncat_s(text, L"%", 1);
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
		}

		//����
		SetTextColor(hdc, COLOR_PANEL_STR);
		r.top = r.bottom;
		r.bottom = r.top + ROW_HEIGHT;
		r.right = cr.right / 2 - LINE_PADDING;

		field = &q->Data[S_FID_TOTALQTY];
		if (S_FIDATTR_NONE != field->FidAttr)
		{
			_itow_s((int)field->Qty, text, 10);
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
		}

		//���
		SetTextColor(hdc, m_UpDownColor);
		r.right = cr.right - LINE_PADDING;
		field = &q->Data[S_FID_HIGHPRICE];
		if (S_FIDATTR_NONE != field->FidAttr && FormatPrice(G_StarApi, field->Price , Prec, 1, text, false))
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

		//�ֲ�
		SetTextColor(hdc, COLOR_PANEL_STR);
		r.top = r.bottom;
		r.bottom = r.top + ROW_HEIGHT;
		r.right = cr.right / 2 - LINE_PADDING;
		field = &q->Data[S_FID_POSITIONQTY];
		if (S_FIDATTR_NONE != field->FidAttr)
		{
			_itow_s((int)field->Qty, text, 10);
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
		}

		//���
		SetTextColor(hdc, m_UpDownColor);
		r.right = cr.right - LINE_PADDING;
		field = &q->Data[S_FID_LOWPRICE];
		if (S_FIDATTR_NONE != field->FidAttr && FormatPrice(G_StarApi, field->Price, Prec, 1, text, false))
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

		//����
		SetTextColor(hdc, m_UpDownColor);
		r.top = r.bottom;
		r.bottom = r.top + ROW_HEIGHT;
		r.right = cr.right / 2 - LINE_PADDING;

		field = &q->Data[S_FID_OPENINGPRICE];
		if (S_FIDATTR_NONE != field->FidAttr && FormatPrice(G_StarApi, field->Price, Prec, 1, text, false))
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

		//��ͣ
		SetTextColor(hdc, COLOR_FUTURE_UP);
		r.right = cr.right - LINE_PADDING;
		field = &q->Data[S_FID_LIMITUPPRICE];
		if (S_FIDATTR_NONE != field->FidAttr && FormatPrice(G_StarApi, field->Price, Prec, 1, text, false))
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

		//�����
		SetTextColor(hdc, COLOR_FUTURE_EQUAL);
		r.top = r.bottom;
		r.bottom = r.top + ROW_HEIGHT;
		r.right = cr.right / 2 - LINE_PADDING;

		field = &q->Data[S_FID_PRESETTLEPRICE];
		if (S_FIDATTR_NONE != field->FidAttr && FormatPrice(G_StarApi, field->Price, Prec, 1, text, false))
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

		//��ͣ
		SetTextColor(hdc, COLOR_FUTURE_DOWN);
		r.right = cr.right - LINE_PADDING;
		field = &q->Data[S_FID_LIMITDOWNPRICE];
		if (S_FIDATTR_NONE != field->FidAttr && FormatPrice(G_StarApi, field->Price, Prec, 1, text, false))
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
	}
	Draw_RedGreenBar(hdc, cr);
}

void TPanelControl::Draw_Price(HDC hdc, RECT& cr)
{
	//�ޱ仯
	if (!m_DrawChg[1])
		return;
	m_all_buy_vol = 0;
	m_all_sell_vol = 0;

	//if (m_bIsSpread)
	//{
	//	Draw_SpreadPrice(hdc, cr);
	//	return;
	//}
	//�޺�Լ ������
	//if (NULL == m_Contract || NULL == m_Contract->SnapShot)
	//	return;
	//һ��
	if (PANEL_LEVEL_ONE == m_Level)
	{
		Draw_Level_One(hdc, cr);
	}

	//�嵵 ʮ��
	if (PANEL_LEVEL_FIVE == m_Level || PANEL_LEVEL_TEN == m_Level)
	{
		Draw_Level_Multiply(hdc, cr);
	}

	Draw_RedGreenBar(hdc, cr);

}
void TPanelControl::Draw_Level_One(HDC hdc, RECT& cr)
{
	if (PANEL_LEVEL_ONE != m_Level)
		return;
	SQuoteSnapShot* q = NULL;
	if (m_bIsSpread&&m_SpreadContract.SnapShot)
	{
		q = m_SpreadContract.SnapShot;
	}
	else
	{
		if (!m_Contract)
			return;
		q = m_Contract->SnapShot;
	}
	if (!q)
		return;

	wchar_t text[101];
	wchar_t text2[101];

	SQuoteField field;

	SCommodityPrecType Prec;
	SCommodityDenoType Deno;
	if (m_bIsSpread)
	{
		Prec = m_SpreadContract.PricePrec;
		Deno = 1;
	}
	else
	{
		Prec = m_Contract->Commodity->PricePrec;
		Deno = m_Contract->Commodity->PriceDeno;
	}

	RECT zr(m_Rects[PRICE]);
	//���� �� ����------------------------------------------------------------------------
	SelectObject(hdc, FONT_PANEL_BIG_PRICE);
	text[0] = L'\0';
	field = q->Data[S_FID_BESTASKPRICE];
	if (!m_bIsSpread)
	{
		SQuoteField Im_field;
		bool ret = G_StarApi->GetImpliedField(m_Contract, S_FID_BESTASKPRICE, &Im_field);
		if (ret)
			field = Im_field;
	}
	switch (field.FidAttr)
	{
	case S_FIDATTR_VALID:
		FormatPrice(G_StarApi, field.Price, Prec, Deno, text, true);
		break;
	case S_FIDATTR_IMPLIED:
		text[0] = '*';
		FormatPrice(G_StarApi, field.Price, Prec, Deno, &text[1], true);
		break;
	default:
		break;
	}
	text2[0] = L'\0';
	field = q->Data[S_FID_BESTBIDPRICE];
	if (!m_bIsSpread)
	{
		SQuoteField Im_field;
		bool ret = G_StarApi->GetImpliedField(m_Contract, S_FID_BESTBIDPRICE, &Im_field);
		if (ret)
			field = Im_field;
	}
	switch (field.FidAttr)
	{
	case S_FIDATTR_VALID:
		FormatPrice(G_StarApi, field.Price, Prec, Deno, text2, true);
		break;
	case S_FIDATTR_IMPLIED:
		text2[0] = '*';
		FormatPrice(G_StarApi, field.Price, Prec, Deno, &text2[1], true);
		break;
	default:
		break;
	}

	int price_width(TITLE_TEXT_WIDTH);
	SIZE size;
	GetTextExtentPoint(hdc, text, wcslen(text), &size);
	if (size.cx > price_width)
		price_width = size.cx;
	GetTextExtentPoint(hdc, text2, wcslen(text2), &size);
	if (size.cx > price_width)
		price_width = size.cx;

	//������� �� ���
	if (m_updwonType == TYPE_LASTSETTLE)
		SetTextColor(hdc, m_UpDownColor);
	else
		SetTextColor(hdc, m_AskColor);
	RECT r(zr);
	r.left += TITLE_TEXT_WIDTH;
	r.right = r.left + price_width + LINE_PADDING;
	r.bottom = r.top + SELL_HEIGHT;
	DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
	if (m_updwonType == TYPE_LASTSETTLE)
		SetTextColor(hdc, m_UpDownColor);
	else
		SetTextColor(hdc, m_BidColor);
	r.top = r.bottom;
	r.bottom = r.top + BUY_HEIGHT;
	DrawText(hdc, text2, wcslen(text2), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

	//�������
	SetTextColor(hdc, COLOR_PANEL_STR);

	r.top = zr.top;
	r.bottom = r.top + SELL_HEIGHT;
	r.left = r.right + 3 * LINE_PADDING;
	r.right = zr.right;

	text[0] = '\0';
	field = q->Data[S_FID_BESTASKQTY];
	if (!m_bIsSpread)
	{
		SQuoteField Im_field;
		bool ret = G_StarApi->GetImpliedField(m_Contract, S_FID_BESTASKQTY, &Im_field);
		if (ret)
			field = Im_field;
	}
	switch (field.FidAttr)
	{
	case S_FIDATTR_VALID:
		_itow_s((int)field.Qty, text, 10);
		break;
	case S_FIDATTR_IMPLIED:
		text[0] = L'*';
		_itow_s((int)field.Qty, &text[1], sizeof(text) / sizeof(wchar_t) - 1, 10);
		break;
	default:
		break;
	}
	DrawText(hdc, text, wcslen(text), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	if (S_FIDTYPE_NONE != field.FidAttr)
		m_all_sell_vol = field.Qty;

	//�������
	r.top = r.bottom;
	r.bottom = r.top + BUY_HEIGHT;

	text[0] = '\0';
	field = q->Data[S_FID_BESTBIDQTY];
	if (!m_bIsSpread)
	{
		SQuoteField Im_field;
		bool ret = G_StarApi->GetImpliedField(m_Contract, S_FID_BESTBIDQTY, &Im_field);
		if (ret)
			field = Im_field;
	}
	switch (field.FidAttr)
	{
	case S_FIDATTR_VALID:
		_itow_s((int)field.Qty, text, 10);
		break;
	case S_FIDATTR_IMPLIED:
		text[0] = L'*';
		_itow_s((int)field.Qty, &text[1], sizeof(text) / sizeof(wchar_t) - 1, 10);
		break;
	default:
		break;
	}
	DrawText(hdc, text, wcslen(text), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	if (S_FIDTYPE_NONE != field.FidAttr)
		m_all_buy_vol = field.Qty;


	//����------------------------------------------------------------------------
	SelectObject(hdc, FONT_PANEL_SMALL_PRICE);
	SPriceType price(0);

	r.left = zr.left;

	//���� ����
	if (m_ShowAllBuySell)
	{
		SetTextColor(hdc, COLOR_PANEL_STR);
		r.top = r.bottom;
		r.bottom = r.top + ROW_HEIGHT;
		r.right = cr.right / 2 - LINE_PADDING;

		field = q->Data[S_FID_TOTALBIDQTY];
		if (S_FIDTYPE_NONE != field.FidAttr)
		{
			_itow_s((int)field.Qty, text, sizeof(text) / sizeof(wchar_t) / 2, 10);
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
		}

		r.right = cr.right - LINE_PADDING;

		field = q->Data[S_FID_TOTALASKQTY];
		if (S_FIDTYPE_NONE != field.FidAttr)
		{
			_itow_s((int)field.Qty, text, sizeof(text) / sizeof(wchar_t) / 2, 10);
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
		}
	}

	//����
	SetTextColor(hdc, m_UpDownColor);
	r.top = r.bottom;
	r.bottom = r.top + ROW_HEIGHT;
	r.right = cr.right / 2 - LINE_PADDING;

	field = q->Data[S_FID_LASTPRICE];
	if (S_FIDTYPE_NONE != field.FidAttr && FormatPrice(G_StarApi, field.Price, Prec, Deno, text, false))
	{
		DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
	}

	//�ǵ�
	SetTextColor(hdc, m_UpDownColor);
	r.right = cr.right - LINE_PADDING;
	if (FormatPrice(G_StarApi, m_UpDown, Prec, Deno, text, true))
		DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

	//����
	SetTextColor(hdc, COLOR_PANEL_STR);
	r.top = r.bottom;
	r.bottom = r.top + ROW_HEIGHT;
	r.right = cr.right / 2 - LINE_PADDING;

	field = q->Data[S_FID_LASTQTY];
	if (S_FIDTYPE_NONE != field.FidAttr)
	{
		_itow_s((int)field.Qty, text, 10);
		DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
	}

	//�Ƿ�
	SetTextColor(hdc, m_UpDownColor);
	r.right = cr.right - LINE_PADDING;
	if (FormatPrice(G_StarApi, m_UpDownRate, 2, 1, text, false))
	{
		wcsncat_s(text, L"%", 1);
		DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
	}

	//����
	SetTextColor(hdc, COLOR_PANEL_STR);
	r.top = r.bottom;
	r.bottom = r.top + ROW_HEIGHT;
	r.right = cr.right / 2 - LINE_PADDING;

	field = q->Data[S_FID_TOTALQTY];
	if (S_FIDTYPE_NONE != field.FidAttr)
	{
		_itow_s((int)field.Qty, text, 10);
		DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
	}

	//���
	SetTextColor(hdc, m_UpDownColor);
	r.right = cr.right - LINE_PADDING;
	field = q->Data[S_FID_HIGHPRICE];
	if (S_FIDTYPE_NONE != field.FidAttr && FormatPrice(G_StarApi, field.Price, Prec, Deno, text, false))
		DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

	//�ֲ�
	SetTextColor(hdc, COLOR_PANEL_STR);
	r.top = r.bottom;
	r.bottom = r.top + ROW_HEIGHT;
	r.right = cr.right / 2 - LINE_PADDING;
	field = q->Data[S_FID_POSITIONQTY];
	if (S_FIDTYPE_NONE != field.FidAttr)
	{
		_itow_s((int)field.Qty, text, 10);
		DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
	}

	//���
	SetTextColor(hdc, m_UpDownColor);
	r.right = cr.right - LINE_PADDING;
	field = q->Data[S_FID_LOWPRICE];
	if (S_FIDTYPE_NONE != field.FidAttr && FormatPrice(G_StarApi, field.Price, Prec, Deno, text, false))
		DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

	//����
	SetTextColor(hdc, m_UpDownColor);
	r.top = r.bottom;
	r.bottom = r.top + ROW_HEIGHT;
	r.right = cr.right / 2 - LINE_PADDING;

	field = q->Data[S_FID_OPENINGPRICE];
	if (S_FIDTYPE_NONE != field.FidAttr && FormatPrice(G_StarApi, field.Price, Prec, Deno, text, false))
		DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

	//��ͣ
	SetTextColor(hdc, COLOR_FUTURE_UP);
	r.right = cr.right - LINE_PADDING;
	field = q->Data[S_FID_LIMITUPPRICE];
	if (S_FIDTYPE_NONE != field.FidAttr && FormatPrice(G_StarApi, field.Price, Prec, Deno, text, false))
		DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

	//�����
	SetTextColor(hdc, COLOR_FUTURE_EQUAL);
	r.top = r.bottom;
	r.bottom = r.top + ROW_HEIGHT;
	r.right = cr.right / 2 - LINE_PADDING;

	field = q->Data[S_FID_PRESETTLEPRICE];
	if (S_FIDTYPE_NONE != field.FidAttr && FormatPrice(G_StarApi, field.Price, Prec, Deno, text, false))
		DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

	//��ͣ
	SetTextColor(hdc, COLOR_FUTURE_DOWN);
	r.right = cr.right - LINE_PADDING;
	field = q->Data[S_FID_LIMITDOWNPRICE];
	if (S_FIDTYPE_NONE != field.FidAttr && FormatPrice(G_StarApi, field.Price, Prec, Deno, text, false))
		DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
}
void TPanelControl::Draw_Level_Multiply(HDC hdc, RECT& cr)
{
	if (!(PANEL_LEVEL_FIVE == m_Level||PANEL_LEVEL_TEN == m_Level))
		return;
	SQuoteSnapShot* q = NULL;
	SQuoteSnapShotL2* q_Buy = NULL;
	SQuoteSnapShotL2* q_Sell = NULL;
	SImpliedDepthL2 im_Dep;
	memset(&im_Dep, 0, sizeof(SImpliedDepthL2));
	if (m_bIsSpread&&m_SpreadContract.SnapShot)
	{
		q = m_SpreadContract.SnapShot;
	}
	else
	{
		if (!m_Contract)
			return;
		q = m_Contract->SnapShot;
		q_Buy = m_Contract->BidL2;
		q_Sell = m_Contract->AskL2;
		//G_StarApi->GetSnapshotL2(m_Contract->ContractNo, q_Buy, c);
		SQuoteSnapShotL2 im_Buy,im_Sell;
		memset(&im_Buy, 0, sizeof(SQuoteSnapShotL2));
		memset(&im_Sell, 0, sizeof(SQuoteSnapShotL2));
		if (G_StarApi->GetImpliedSnapshot(m_Contract, &im_Buy, &im_Sell,im_Dep))
		{
			q_Buy = &im_Buy;
			q_Sell = &im_Sell;
		}
	}
	if (!q)
		return;
	wchar_t text[101];

	SCommodityPrecType Prec;
	SCommodityDenoType Deno;
	if (m_bIsSpread)
	{
		Prec = m_SpreadContract.PricePrec;
		Deno = 1;
	}
	else
	{
		Prec = m_Contract->Commodity->PricePrec;
		Deno = m_Contract->Commodity->PriceDeno;
	}
	SQuoteField* field(NULL);
	SelectObject(hdc, FONT_PANEL_SMALL_PRICE);
	SetTextColor(hdc, COLOR_PANEL_STR);

	RECT r(m_Rects[PRICE]);

	//���� ����
	if (m_ShowAllBuySell)
	{
		SetTextColor(hdc, COLOR_PANEL_STR);
		r.bottom = r.top + ROW_HEIGHT;
		r.right = cr.right / 2 - 2 * LINE_PADDING;

		field = &q->Data[S_FID_TOTALBIDQTY];
		if (S_FIDTYPE_NONE != field->FidAttr)
		{
			_itow_s((int)field->Qty, text, sizeof(text) / sizeof(wchar_t) / 2, 10);
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
		}

		r.right = cr.right - 2 * LINE_PADDING;

		field = &q->Data[S_FID_TOTALASKQTY];
		if (S_FIDTYPE_NONE != field->FidAttr)
		{
			_itow_s((int)field->Qty, text, sizeof(text) / sizeof(wchar_t) / 2, 10);
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
		}


	}

	//���� ���� �ۼ���	
	r.left = cr.left + 2 * LINE_PADDING + TITLE_TEXT_WIDTH;
	r.top = CONTRACT_HEIGHT + (m_ShowAllBuySell ? ROW_HEIGHT : 0) + LEVEL_ONE_HEIGHT + (m_Level - 1) * LEVEL_OTHER_HEIGHT;
	r.bottom = r.top;

	SPriceType price(0);
	SQtyType qty(0);
	SQtyType all_qty(0);
	SQuoteFieldL2* fieldL2(NULL);
	for (int i = 0; i < m_Level; i++)
	{
		r.bottom = r.top;
		r.top = r.bottom - (i==0? LEVEL_ONE_HEIGHT: LEVEL_OTHER_HEIGHT);

		//����					
		r.right = cr.right -2* QTY_WIDTH - 2 * LINE_PADDING;

		qty = 0;
		price = 0;
		if (m_bIsSpread&&m_SpreadContract.SnapShot)
		{
			if (i != 0)
				continue;
			SQuoteField* field1 = &q->Data[S_FID_BESTASKQTY];
			qty = field1->Qty;

			if (qty <= 0)
				break;

			field1 = &q->Data[S_FID_BESTASKPRICE];
			price = field1->Price;
		}
		else if(q_Sell)
		{
			fieldL2 = &q_Sell->Data[i];
			qty = fieldL2->Qty;

			if (qty <= 0)
				break;

			fieldL2 = &q_Sell->Data[i];
			price = fieldL2->Price;
		}
		//����۸�
		SetTextColor(hdc, m_bBidRAskG ? COLOR_FUTURE_DOWN :m_UpDownColor);
		if(i==0)
			SelectObject(hdc, FONT_PANEL_ONE_LEVEL);
		else
			SelectObject(hdc, FONT_PANEL_OTHER_LEVEL);
		if (im_Dep.AskPriceDepth==i+1)
		{
			text[0] = L'*';
			if (FormatPrice(G_StarApi, price, Prec, Deno, &text[1], true))
				DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
		}
		else if (FormatPrice(G_StarApi, price, Prec, Deno, text, true))
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

		//����
		SetTextColor(hdc, COLOR_PANEL_MULTI_ASK);
		if (m_bAccumulate)
		    r.right = cr.right - QTY_WIDTH - 2 * LINE_PADDING;
		else
			r.right = cr.right - 2 * LINE_PADDING;

		//������
		if (im_Dep.AskQtyDepth == i + 1)
		{
			text[0] = L'*';
			_itow_s((int)qty, &text[1], sizeof(text) / sizeof(wchar_t) - 1, 10);
		}
		else
			_itow_s((int)qty, text, 10);
		DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

		//�ۼ���
		if (m_bAccumulate)
		{
			r.right = cr.right - 2 * LINE_PADDING;
			all_qty += qty;

			_itow_s((int)all_qty, text, 10);
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
		}
		if (m_nSelectField == i)
		{
			RECT rr(r);
			rr.left = cr.left+1;
			rr.right = cr.right;
			if (i == 0)
				rr.bottom -= 2;
			FrameRect(hdc, &rr, BRUSH_FUTURE_SEL);
		}
		//����������
		m_all_sell_vol += qty;
	}

	//��� ���� �ۼ���
	all_qty = 0;

	r.top = CONTRACT_HEIGHT + (m_ShowAllBuySell ? ROW_HEIGHT : 0) + LEVEL_ONE_HEIGHT+(m_Level-1) * LEVEL_OTHER_HEIGHT;
	r.bottom = r.top;

	for (int i = 0; i < m_Level; i++)
	{
		r.top = r.bottom;
		r.bottom = r.top + (i == 0 ? LEVEL_ONE_HEIGHT : LEVEL_OTHER_HEIGHT);

		//���					
		r.right = cr.right  -2* QTY_WIDTH- 2 * LINE_PADDING;

		qty = 0;
		price = 0;
		if (m_bIsSpread&&m_SpreadContract.SnapShot)
		{
			if (i != 0)
				continue;
			SQuoteField* field1 = &q->Data[S_FID_BESTBIDQTY];
			qty = field1->Qty;

			if (qty <= 0)
				break;

			field1 = &q->Data[S_FID_BESTBIDPRICE];
			price = field1->Price;
		}
		else if (q_Buy)
		{
			fieldL2 = &q_Buy->Data[i];
			qty = fieldL2->Qty;

			if (qty <= 0)
				break;

			fieldL2 = &q_Buy->Data[i];
			price = fieldL2->Price;
		}
		//����۸�
		SetTextColor(hdc, m_bBidRAskG ? COLOR_FUTURE_UP : m_UpDownColor);
		if (i == 0)
			SelectObject(hdc, FONT_PANEL_ONE_LEVEL);
		else
			SelectObject(hdc, FONT_PANEL_OTHER_LEVEL);
		if (im_Dep.BidPriceDepth == i+1)
		{
			text[0] = L'*';
			if (FormatPrice(G_StarApi, price, Prec, Deno, &text[1], true))
				DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
		}
		else if (FormatPrice(G_StarApi, price, Prec, Deno, text, true))
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

		SetTextColor(hdc, COLOR_PANEL_MULTI_BID);
		if (m_bAccumulate)
			r.right = cr.right - QTY_WIDTH - 2 * LINE_PADDING;
		else
			r.right = cr.right - 2 * LINE_PADDING;

		//������
		if (im_Dep.BidQtyDepth == i+1)
		{
			text[0] = L'*';
			_itow_s((int)qty, &text[1], sizeof(text) / sizeof(wchar_t) - 1, 10);
		}
		else
			_itow_s((int)qty, text, 10);
		DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

		//�ۼ���
		if (m_bAccumulate)
		{
			r.right = cr.right - 2 * LINE_PADDING;
			all_qty += qty;

			_itow_s((int)all_qty, text, 10);
			DrawText(hdc, text, wcslen(text), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
		}

		if (m_nSelectField == BID_BEGIN + i)
		{
			RECT rr(r);
			rr.left = cr.left + 1;
			rr.right = cr.right;
			if (i == 0)
				rr.top += 2;
			FrameRect(hdc, &rr, BRUSH_FUTURE_SEL);
		}
		//����������
		m_all_buy_vol += qty;
	}
}
void TPanelControl::Draw_RedGreenBar(HDC hdc, RECT& cr)
{
	//���ƺ�����
	if (m_all_buy_vol + m_all_sell_vol > 0)
	{
		RECT r(cr);
		r.top = CONTRACT_HEIGHT;
		if (PANEL_LEVEL_ONE == m_Level)
			r.top += SELL_HEIGHT;
		else
			r.top += ((m_ShowAllBuySell ? ROW_HEIGHT : 0) + LEVEL_ONE_HEIGHT + (m_Level - 1) * LEVEL_OTHER_HEIGHT);

		r.top--;
		r.bottom = r.top + 3;
		r.left += LINE_PADDING;
		r.right -= LINE_PADDING;

		RECT rr(r);
		HBRUSH hbr = BRUSH_FUTURE_UP;
		if (m_bLeftBid)
		{
			rr.right = rr.left + (rr.right - rr.left) * (LONG)m_all_buy_vol / (LONG)(m_all_buy_vol + m_all_sell_vol);
			hbr = BRUSH_FUTURE_UP;
		}
		else
		{
			rr.right = rr.left + (rr.right - rr.left) * (LONG)m_all_sell_vol / (LONG)(m_all_buy_vol + m_all_sell_vol);
			hbr = BRUSH_FUTURE_DOWN;
		}
		if (rr.right > rr.left)
			FillRect(hdc, &rr, hbr);
		if (m_bLeftBid)
			hbr = BRUSH_FUTURE_DOWN;
		else
			hbr = BRUSH_FUTURE_UP;
		rr.left = rr.right;
		rr.right = r.right;
		if (rr.right > rr.left)
			FillRect(hdc, &rr, hbr);
	}
}
void TPanelControl::Draw_Tick(HDC hdc, RECT& cr)
{
	//�ޱ仯
	if (!m_DrawChg[2])
		return;

	//�޺�Լ ������
	if (NULL == m_Contract || NULL == m_Contract->SnapShot)
		return;

	//����߶�
	LONG quote_height = (PANEL_LEVEL_ONE == m_Level ? (SELL_HEIGHT + BUY_HEIGHT + 6 * ROW_HEIGHT) : (2 * LEVEL_ONE_HEIGHT + 2 * (m_Level - 1)* LEVEL_OTHER_HEIGHT));
	if (m_ShowAllBuySell)
		quote_height += ROW_HEIGHT;

	//��ߴ�
	RECT r(cr);
	r.top = CONTRACT_HEIGHT + quote_height + ROW_HEIGHT;

	if (r.top >= cr.bottom)
		return;

	int count = (cr.bottom - r.top) / TICK_ROW_HEIGHT;
	r.bottom = r.top;

	//ȡ����
	SHisQuoteData data[50];
	if (count > sizeof(data) / sizeof(SHisQuoteData))
		count = sizeof(data) / sizeof(SHisQuoteData);
	int len = G_StarApi->GetHisQuote(m_Contract->ContractNo, S_KLINE_TICK, 0, 1, 0, data, count);
	if (len <= 0)
		return;
	//��Y��
	SPriceType dPresettle = 0.0;
	SQuoteSnapShot* q = m_Contract->SnapShot;
	SQuoteField* field1 = &q->Data[S_FID_PRESETTLEPRICE];
	if (S_FIDTYPE_NONE != field1->FidAttr)
		dPresettle = field1->Price;
	SelectObject(hdc, FONT_PANEL_TICK_PRICE);

	wchar_t text[51];
	bool isup(m_UpDown > 0);
	//������
	SDateType tradedate(0);
	for (int i = 0; i < len; i++)		//����������
	{
		r.top = r.bottom;
		r.bottom = r.top + TICK_ROW_HEIGHT;
		if (r.bottom > cr.bottom)		//���Ƹ߶�
			break;

		SHisQuoteData& d = data[i];
		if (0 != tradedate && d.TradeDate != tradedate)
			break;
		SQuoteField& ut = q->Data[S_FID_DATETIME];
		if (ut.DateTime / 1000000000LL <= d.DateTimeStamp / 1000000000LL
			|| ut.DateTime / 1000000000LL <= d.TradeDate)
			tradedate = d.TradeDate;
		else
			break;
		//��������һ�ʼ�ͷ��ʶ
		if (i == 0)
		{
			SelectObject(hdc, PEN_PANEL_ARROW);
			r.left = -5;
			r.right = r.left + 16;
			Draw_Arraw(hdc, r, D_RIGHT);
		}
		//ʱ��
		SetTextColor(hdc, COLOR_PANEL_TICK_TEXT);
		r.left = LINE_PADDING;
		r.right = r.left + TICK_TIME_WIDTH;
		STimeType t(d.DateTimeStamp / 1000 % 1000000);
		swprintf_s(text, L"%02d:%02d:%02d", t / 10000, t / 100 % 100, t % 100);
		DrawText(hdc, text, wcslen(text), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);

		//�۸�
		//�������Ƚ� ���ں� С���� ���ڰ�
		if(d.QLastPrice>dPresettle)
		   SetTextColor(hdc, COLOR_FUTURE_UP);
		else if (d.QLastPrice<dPresettle)
			SetTextColor(hdc, COLOR_FUTURE_DOWN);
		else
			SetTextColor(hdc, COLOR_FUTURE_EQUAL);
		SIZE size;
		GetTextExtentPoint(hdc, text, wcslen(text), &size);
		r.left += size.cx;
		r.right = r.left + (cr.right - size.cx - 3 * TICK_OTHER_WIDTH) - LINE_PADDING;
		if (FormatPrice(G_StarApi, d.QLastPrice, m_Contract->Commodity, text, false))
			DrawText(hdc, text, wcslen(text), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

		//���� ��ɫ�Ǹ�����һ�ʱ仯��������Ϊ�죬��Ϊ��
		SHisQuoteData* next(NULL);
		if (i + 1 < len)
			next = &data[i+1];
		
		//�� �ǵ�
		double oldAverage = (d.QSellPrice + d.QBuyPrice) / 2;
		double nowAverage = (d.QSellPrice + d.QBuyPrice) / 2;
		double oldLast = d.QLastPrice;
		double nowLast = d.QLastPrice;
		if (NULL != next)
		{
			oldLast = next->QLastPrice;
			nowLast = d.QLastPrice;
			oldAverage = (next->QSellPrice + next->QBuyPrice)/2;
			nowAverage = (d.QSellPrice + d.QBuyPrice) / 2;
		}
	
		//�� ��ƽ
		//��ƽ9�� 
		//���֣�����Ϊ0�����¼۴�����һ�� �໻��С����һ�� �ջ������ ����
		//��������Ϊ��������=���� ˫������۳ɽ�Ϊ�գ����۳ɽ�Ϊ��
		//ƽ������Ϊ��������=���� ˫ƽ�����۳ɽ�Ϊ�գ���۳ɽ�Ϊ��
		int offsetindex(0);
		bool bReCal = false;
		if (0 == d.QPositionChg)
		{
			if (nowLast > oldLast)
			{
				offsetindex = 1; //�໻
			}
			else if (nowLast < oldLast)
			{
				offsetindex = 2; //�ջ�
			}
			else
			{
				offsetindex = 0;
			}
			bReCal = true;
		}
		else if (d.QPositionChg > 0)
		{
			if (d.QLastQty == d.QPositionChg)
			{
				offsetindex = 3;     //˫��
				bReCal = true;
			}
			else
			{
				if (next)
				{
					//if (nowLast >= oldLast)
					{
						if (d.QLastPrice >= next->QSellPrice)
							offsetindex = 4;    //�࿪
						else
							offsetindex = 5; //�տ�
					}
					//else
					//{
					//	if (d.QLastPrice >= next->QSellPrice)
					//		offsetindex = 5;    //�տ�
					//	else
					//		offsetindex = 4; //�տ�
					//}
				}
				else
				{
					if (d.QLastPrice >= d.QSellPrice)
						offsetindex = 4;    //�࿪
					else
						offsetindex = 5; //�տ�
				}

			}
		}
		else
		{
			if (d.QLastQty == (-1) * d.QPositionChg)
			{
				offsetindex = 6;     //˫ƽ
				bReCal = true;
			}
			else
			{
				if (next)
				{
					//if (nowLast >= oldLast)
					{
						if (d.QLastPrice <= next->QBuyPrice)
							offsetindex = 7;    //��ƽ
						else
							offsetindex = 8;    //��ƽ
					}
					//else
					//{
					//	if (d.QLastPrice <= next->QBuyPrice)
					//		offsetindex = 8;    //��ƽ
					//	else
					//		offsetindex = 7;    //��ƽ
					//}
				}
				else
				{
					if (d.QLastPrice <= d.QBuyPrice)
						offsetindex = 7;    //��ƽ
					else
						offsetindex = 8;    //��ƽ
				}
			}
		}

		if (bReCal)
		{
			if (next)
			{
				if (d.QLastPrice >= oldAverage)
						isup = true;
				else
						isup = false;
				
			}
			else
			{
				if (d.QLastPrice >= nowAverage)
					isup = true;
				else
					isup = false;
			}
		}

		switch (offsetindex)
		{
		case 4:
		case 8:
			SetTextColor(hdc, COLOR_FUTURE_UP);
			break;
		case 5:
		case 7:
			SetTextColor(hdc, COLOR_FUTURE_DOWN);
			break;
		case 0:
		case 1:
		case 2:
		case 3:
		case 6:
			if(isup)
				SetTextColor(hdc, COLOR_FUTURE_UP);
			else
				SetTextColor(hdc, COLOR_FUTURE_DOWN);
			break;
		default:
			break;
		}

		r.left = cr.right - 3 * TICK_OTHER_WIDTH;
		r.right = r.left + TICK_OTHER_WIDTH;
		_itow_s(d.QLastQty, text, 10);
		DrawText(hdc, text, wcslen(text), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

		SetTextColor(hdc, COLOR_PANEL_STR);
		//����
		if (IsDomesticExchange(m_Contract->Commodity->Exchange->ExchangeNo))
		{
			r.left = r.right;
			r.right = r.left + TICK_OTHER_WIDTH;
			_itow_s(d.QPositionChg, text, 10);
			DrawText(hdc, text, wcslen(text), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
		}

		r.left = r.right;
		r.right = r.left + TICK_OTHER_WIDTH;
		
		DrawText(hdc, G_LANG->LangText(TLI_PANEL_CHG + offsetindex), wcslen(G_LANG->LangText(TLI_PANEL_CHG + offsetindex)), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
	}
}
void TPanelControl::DrawSmallPanel(HDC hdc, RECT& cr)
{
	//�޺�Լ ������
	if (m_bIsSpread)
	{
		if (m_SpreadContract.SnapShot == NULL)
			return;
	}
	else
	{
		if (NULL == m_Contract || NULL == m_Contract->SnapShot)
			return;
	}
	FillRect(hdc, &cr, BRUSH_PANEL_BACKGROUND);
	FrameRect(hdc, &cr, BRUSH_PANEL_LINE);
	RECT r(cr);
	r.right -= r.left;
	r.bottom -= r.top;

	r.bottom = r.top + CONTRACT_HEIGHT;
	r.left = r.right - (r.bottom - r.top);
	RECT BigRc(r);
	InflateRect(&BigRc, -7, -7);
	FrameRect(hdc, &BigRc, BRUSH_PANEL_LINE);
	SelectObject(hdc, PEN_PANEL_LINE);
	MoveToEx(hdc, BigRc.left, BigRc.top + 1,0);
	LineTo(hdc, BigRc.right, BigRc.top + 1);

	SQuoteSnapShot* q = NULL;
	SCommodityPrecType Prec = 1;
	if (m_bIsSpread)
	{
		q = m_SpreadContract.SnapShot;
		Prec = m_SpreadContract.PricePrec;
	}
	else
	{
		q = m_Contract->SnapShot;
	}
	//������� 
	wchar_t text[101];
	SQuoteField field;
	SelectObject(hdc, FONT_PANEL_SMALL_PRICE);
	wcscpy_s(text, L"0.0");
	field = q->Data[S_FID_BESTASKPRICE];
	if (m_bIsSpread)
	{
		if (S_FIDTYPE_NONE != field.FidAttr)
		{
			FormatPrice(G_StarApi, field.Price, Prec, 1, text, true);
		}
	}
	else
	{
		SQuoteField Im_field;
		bool ret = G_StarApi->GetImpliedField(m_Contract, S_FID_BESTASKPRICE, &Im_field);
		if (ret)
			field = Im_field;
		switch (field.FidAttr)
		{
		case S_FIDATTR_VALID:
			FormatPrice(G_StarApi, field.Price, m_Contract->Commodity, text, true);
			break;
		case S_FIDATTR_IMPLIED:
			text[0] = '*';
			FormatPrice(G_StarApi, field.Price, m_Contract->Commodity, &text[1], true);
			break;
		default:
			break;
		}
	}
	int nRowHigth = 16;
	RECT textrc(cr);
	InflateRect(&textrc, -5, 0);
	textrc.top = BigRc.bottom + 10;
	textrc.bottom = textrc.top + nRowHigth;
	if (m_updwonType == TYPE_LASTSETTLE)
		SetTextColor(hdc, m_UpDownColor);
	else
		SetTextColor(hdc, m_AskColor);
	DrawText(hdc, text, wcslen(text), &textrc, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
	//�������
	wcscpy_s(text, L"0");
	field = q->Data[S_FID_BESTASKQTY];
	if (!m_bIsSpread)
	{
		SQuoteField Im_field;
		bool ret = G_StarApi->GetImpliedField(m_Contract, S_FID_BESTASKQTY, &Im_field);
		if (ret)
			field = Im_field;
	}
	switch (field.FidAttr)
	{
	case S_FIDATTR_VALID:
		_itow_s((int)field.Qty, text, 10);
		break;
	case S_FIDATTR_IMPLIED:
		text[0] = L'*';
		_itow_s((int)field.Qty, &text[1], sizeof(text) / sizeof(wchar_t) - 1, 10);
		break;
	default:
		break;
	}
	textrc.top = textrc.bottom;
	textrc.bottom = textrc.top + nRowHigth;
	SetTextColor(hdc, COLOR_PANEL_STR);
	DrawText(hdc, text, wcslen(text), &textrc, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
	//������
	wcscpy_s(text, L"0.0");
	field = q->Data[S_FID_BESTBIDPRICE];
	if (m_bIsSpread)
	{
		if (S_FIDATTR_NONE != field.FidAttr)
		{
			FormatPrice(G_StarApi, field.Price, Prec, 1, text, true);
		}
	}
	else
	{
		SQuoteField Im_field;
		bool ret = G_StarApi->GetImpliedField(m_Contract, S_FID_BESTBIDPRICE, &Im_field);
		if (ret)
			field = Im_field;
		switch (field.FidAttr)
		{
		case S_FIDATTR_VALID:
			FormatPrice(G_StarApi, field.Price, m_Contract->Commodity, text, true);
			break;
		case S_FIDATTR_IMPLIED:
			text[0] = '*';
			FormatPrice(G_StarApi, field.Price, m_Contract->Commodity, &text[1], true);
			break;
		default:
			break;
		}
	}
	textrc.top = textrc.bottom;
	textrc.bottom = textrc.top + nRowHigth;
	if (m_updwonType == TYPE_LASTSETTLE)
		SetTextColor(hdc, m_UpDownColor);
	else
		SetTextColor(hdc, m_BidColor);
	DrawText(hdc, text, wcslen(text), &textrc, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
	//�������
	wcscpy_s(text, L"0");
	field = q->Data[S_FID_BESTBIDQTY];
	if (!m_bIsSpread)
	{
		SQuoteField Im_field;
		bool ret = G_StarApi->GetImpliedField(m_Contract, S_FID_BESTBIDQTY, &Im_field);
		if (ret)
			field = Im_field;
	}
	switch (field.FidAttr)
	{
	case S_FIDATTR_VALID:
		_itow_s((int)field.Qty, text, 10);
		break;
	case S_FIDATTR_IMPLIED:
		text[0] = L'*';
		_itow_s((int)field.Qty, &text[1], sizeof(text) / sizeof(wchar_t) - 1, 10);
		break;
	default:
		break;
	}
	textrc.top = textrc.bottom;
	textrc.bottom = textrc.top + nRowHigth;
	SetTextColor(hdc, COLOR_PANEL_STR);
	DrawText(hdc, text, wcslen(text), &textrc, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

	//����
	wcscpy_s(text, L"0.0");
	SetTextColor(hdc, m_UpDownColor);
	textrc.top = textrc.bottom + nRowHigth;
	textrc.bottom = textrc.top + nRowHigth;

	field = q->Data[S_FID_LASTPRICE];
	if (S_FIDTYPE_NONE != field.FidAttr)
	{
		if (m_bIsSpread)
			FormatPrice(G_StarApi, field.Price, Prec, 1, text, true);
		else
			FormatPrice(G_StarApi, field.Price, m_Contract->Commodity, text, true);
	}
	DrawText(hdc, text, wcslen(text), &textrc, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
	//����
	wcscpy_s(text, L"0");
	SetTextColor(hdc, COLOR_PANEL_STR);
	textrc.top = textrc.bottom;
	textrc.bottom = textrc.top + nRowHigth;

	field = q->Data[S_FID_LASTQTY];
	if (S_FIDTYPE_NONE != field.FidAttr)
	{
		_itow_s((int)field.Qty, text, 10);
		DrawText(hdc, text, wcslen(text), &textrc, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
	}

	//����
	wcscpy_s(text, L"0");
	textrc.top = textrc.bottom + nRowHigth;
	textrc.bottom = textrc.top + nRowHigth;

	field = q->Data[S_FID_TOTALQTY];
	if (S_FIDTYPE_NONE != field.FidAttr)
	{
		_itow_s((int)field.Qty, text, 10);
		DrawText(hdc, text, wcslen(text), &textrc, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
	}

	//�ǵ�
	wcscpy_s(text, L"0");
	SetTextColor(hdc, m_UpDownColor);
	textrc.top = textrc.bottom + nRowHigth;
	textrc.bottom = textrc.top + nRowHigth;
	if (m_bIsSpread)
		FormatPrice(G_StarApi, m_UpDown, Prec, 1, text, true);
	else
		FormatPrice(G_StarApi, m_UpDown, m_Contract->Commodity, text, false);
	DrawText(hdc, text, wcslen(text), &textrc, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

	//�Ƿ�
	wcscpy_s(text, L"0.0%");;
	textrc.top = textrc.bottom;
	textrc.bottom = textrc.top + nRowHigth;
	if (FormatPrice(G_StarApi, m_UpDownRate, 2, 1, text, false))
	{
		wcsncat_s(text, L"%", 1);
		DrawText(hdc, text, wcslen(text), &textrc, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
	}
	if (m_bIsSpread)
		return;
	//ȡ����
	SHisQuoteData data[50];
	int len = G_StarApi->GetHisQuote(m_Contract->ContractNo, S_KLINE_TICK, 0, 1, 0, data, sizeof(data) / sizeof(SHisQuoteData));
	if (len <= 0)
		return;
	bool isup(m_UpDown > 0);
	bool isequal(false);
	SHisQuoteData& d = data[0];
	//���� ��ɫ�Ǹ�����һ�ʱ仯��������Ϊ�죬��Ϊ��
	SHisQuoteData* next(NULL);
	if (1 < len)
		next = &data[1];
	//�� �ǵ�
	isequal = true;
	if (NULL != next)
	{
		if (abs(d.QLastPrice - next->QLastPrice) > m_Contract->Commodity->PriceTick / 2)
		{
			isequal = false;

			if (d.QLastPrice > next->QLastPrice)
			{
				isup = true;
			}
			else if (d.QLastPrice < next->QLastPrice)
			{
				isup = false;
			}
		}
	}

	//�� ��ƽ
	//��ƽ9�� 
	//���֣�����Ϊ0�����¼۴�����һ�� �໻��С����һ�� �ջ������ ����
	//��������Ϊ��������=���� ˫������۳ɽ�Ϊ�գ����۳ɽ�Ϊ��
	//ƽ������Ϊ��������=���� ˫ƽ�����۳ɽ�Ϊ�գ���۳ɽ�Ϊ��
	int offsetindex(0);
	if (0 == d.QPositionChg)
	{
		if (isequal)
			offsetindex = 0;
		else
			offsetindex = isup ? 1 : 2;
	}
	else if (d.QPositionChg > 0)
	{
		if (d.QLastQty == d.QPositionChg)
			offsetindex = 3;
		else
		{
			if (abs(d.QLastPrice - d.QSellPrice) < m_Contract->Commodity->PriceTick / 2)
				offsetindex = 4;
			else
				offsetindex = 5;
		}
	}
	else
	{
		if (d.QLastQty == (-1) * d.QPositionChg)
			offsetindex = 6;
		else
		{
			if (abs(d.QLastPrice - d.QBuyPrice) < m_Contract->Commodity->PriceTick / 2)
				offsetindex = 7;
			else
				offsetindex = 8;
		}
	}

	switch (offsetindex)
	{
	case 1:
	case 4:
	case 7:
		SetTextColor(hdc, COLOR_FUTURE_UP);
		break;
	case 2:
	case 5:
	case 8:
		SetTextColor(hdc, COLOR_FUTURE_DOWN);
		break;
	default:
		break;
	}
	//����
	SetTextColor(hdc, COLOR_PANEL_STR);
	textrc.top = textrc.bottom + nRowHigth;
	textrc.bottom = textrc.top + nRowHigth;
	if (IsDomesticExchange(m_Contract->Commodity->Exchange->ExchangeNo))
	{
		_itow_s(d.QPositionChg, text, 10);
		DrawText(hdc, text, wcslen(text), &textrc, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
	}

    //��ƽ
	textrc.top = textrc.bottom;
	textrc.bottom = textrc.top + nRowHigth;
	DrawText(hdc, G_LANG->LangText(TLI_PANEL_CHG + offsetindex), wcslen(G_LANG->LangText(TLI_PANEL_CHG + offsetindex)), &textrc, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
}
bool TPanelControl::IsDomesticExchange(SExchangeNoType	exchangeNo)
{
	if (strcmp(exchangeNo, "ZCE") == 0 || strcmp(exchangeNo, "DCE") == 0 || strcmp(exchangeNo, "SHFE") == 0 || strcmp(exchangeNo, "INE") == 0 || strcmp(exchangeNo, "CFFEX") == 0)
		return true;
	return false;
}
int TPanelControl::PreColSmallPanelWidth()
{
	int nWidth = SMALL_MODEL_WIDTH;
	if (!m_bSmallModel)
		return nWidth;
	// �޺�Լ ������
	if (m_bIsSpread)
	{
		if (m_SpreadContract.SnapShot == NULL)
			return nWidth;
	}
	else
	{
		if (NULL == m_Contract || NULL == m_Contract->SnapShot)
			return nWidth;
	}
	SQuoteSnapShot* q = NULL;
	SCommodityPrecType Prec = 1;
	if (m_bIsSpread)
	{
		q = m_SpreadContract.SnapShot;
		Prec = m_SpreadContract.PricePrec;
	}
	else
	{
		q = m_Contract->SnapShot;
	}
	SQuoteField* field(NULL);
	HDC hdc = GetDC(NULL);
	SelectObject(hdc, FONT_PANEL_SMALL_PRICE);
	field = &q->Data[S_FID_SETTLEPRICE];
	wchar_t text[101];
	wcscpy_s(text, L"0.0%");;
	if (S_FIDTYPE_NONE != field->FidAttr)
	{
		if (m_bIsSpread)
			FormatPrice(G_StarApi, field->Price, Prec, 1, text, true);
		else
			FormatPrice(G_StarApi, field->Price, m_Contract->Commodity, text, true);
	}
	SIZE sz;
	GetTextExtentPoint(hdc, text, wcslen(text), &sz);
	nWidth = max(nWidth, sz.cx);
	
	field = &q->Data[S_FID_TOTALQTY];
	if (S_FIDTYPE_NONE != field->FidAttr)
	{
		_itow_s((int)field->Qty, text, 10);
	}
	nWidth = max(nWidth, sz.cx);
	m_bInitWidth = true;
	return nWidth+10;
}
void TPanelControl::ClickPanelLinkage(const char* action, POINTS& pts)
{
	RECT cr;
	GetRect(cr);
	cr.right -= cr.left;
	cr.bottom -= cr.top;

	int field(-1);
	m_nSelectField = -1;
	int nLevel = -1;
	if (PANEL_LEVEL_ONE == m_Level)
	{
		int base_height = CONTRACT_HEIGHT + SELL_HEIGHT + BUY_HEIGHT;
		if (m_ShowAllBuySell)
			base_height += ROW_HEIGHT;

		if (pts.y >= CONTRACT_HEIGHT && pts.y < CONTRACT_HEIGHT + SELL_HEIGHT)
		{
			field = S_FID_BESTASKPRICE;
		}
		else if (pts.y >= CONTRACT_HEIGHT + SELL_HEIGHT && pts.y < CONTRACT_HEIGHT + SELL_HEIGHT + BUY_HEIGHT)
		{
			field = S_FID_BESTBIDPRICE;
		}
		else if (pts.y >= base_height && pts.y < base_height + ROW_HEIGHT
			&& pts.x >= 0 && pts.x < cr.right / 2)
		{
			field = S_FID_LASTPRICE;
		}
		nLevel = 0;
	}

	if (PANEL_LEVEL_FIVE == m_Level || PANEL_LEVEL_TEN == m_Level)
	{
		int base_height = CONTRACT_HEIGHT;
		if (m_ShowAllBuySell)
			base_height += ROW_HEIGHT;

		if (pts.y >= base_height && pts.y < base_height + LEVEL_ONE_HEIGHT + (m_Level - 1) * LEVEL_OTHER_HEIGHT)
		{
			if (pts.y < base_height + (m_Level - 1) * LEVEL_OTHER_HEIGHT)
				nLevel =  m_Level-1 - (pts.y - base_height) / LEVEL_OTHER_HEIGHT;
			else
				nLevel = 0;
			field = S_FID_BESTASKPRICE;
		}
		else if (pts.y >= base_height + LEVEL_ONE_HEIGHT + (m_Level - 1) * LEVEL_OTHER_HEIGHT && pts.y < base_height + 2 * (LEVEL_ONE_HEIGHT + (m_Level - 1) * LEVEL_OTHER_HEIGHT))
		{
			if (pts.y < base_height + 2 * LEVEL_ONE_HEIGHT + (m_Level - 1) * LEVEL_OTHER_HEIGHT)
				nLevel = 0;
			else
				nLevel = (pts.y - base_height - LEVEL_ONE_HEIGHT- (m_Level - 1) * LEVEL_OTHER_HEIGHT) / LEVEL_OTHER_HEIGHT;
			field = S_FID_BESTBIDPRICE;
		}
		if(field == S_FID_BESTASKPRICE)
		    m_nSelectField = nLevel;
		else
			m_nSelectField =BID_BEGIN+ nLevel ;
	}

	if (field >= 0&& nLevel>=0)
	{
		char content[128];
		if (m_bIsSpread || m_Contract == NULL)
			sprintf_s(content, "contractid=%s;field=%d;src=panel;level=%d", m_SpreadContractNo, field, nLevel);
		else
			sprintf_s(content, "contractid=%s;field=%d;src=panel;level=%d", m_Contract->ContractNo, field, nLevel);

		PolestarQuoteLinkage(GetWindow()->GetHwnd(), action, content);
	}
	m_Chg[1] = true;
	Redraw(NULL);
}
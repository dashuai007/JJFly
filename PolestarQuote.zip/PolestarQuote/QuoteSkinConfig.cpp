﻿#include "PreInclude.h"


QuoteSkinConfig::QuoteSkinConfig()
{
	m_bShowKLine = false;
}


QuoteSkinConfig::~QuoteSkinConfig()
{
}
bool QuoteSkinConfig::Create(HWND hparent)
{
	CreateFrm(_T("TSkinWnd"), hparent, WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN);
	SetWindowPos(m_Hwnd, 0, 0, 0, 520, 400, SWP_NOZORDER);
	InitData();
	PrepareRects();
	CreateSubCtrls();
	return true;
}
void QuoteSkinConfig::RegistQuoteFrame(TQuoteFrame* pFrame)
{
	m_vpQuoteFrame.push_back(pFrame);
	InitData();
	if(LoadCfg())
	   ApplySetting();
}
void QuoteSkinConfig::UnRegistQuoteFrame(TQuoteFrame* pFrame)
{
	auto it = m_vpQuoteFrame.begin();
	while (it != m_vpQuoteFrame.end())
	{
		if (*it == pFrame)
			it = m_vpQuoteFrame.erase(it);
		else
			++it;
	}
}
void QuoteSkinConfig::CreateSubCtrls()
{

	RECT& rc_t_q = m_tab[0].rc;
	rc_t_q = m_Rects[TOP_RECT];
	rc_t_q.top = m_Rects[TOP_STYLE_SETTING].bottom;
	rc_t_q.right = rc_t_q.left + 100;
	wcscpy_s(m_tab[0].text, G_LANG->LangText(TLI_QUOTE_GRIDE));
	m_tab[0].bChecked = true;

	RECT& rc_t_k = m_tab[1].rc;
	rc_t_k = m_Rects[TOP_RECT];
	rc_t_k.top = m_Rects[TOP_STYLE_SETTING].bottom;
	rc_t_k.left = rc_t_q.right ;
	rc_t_k.right = rc_t_k.left + 100;
	wcscpy_s(m_tab[1].text, G_LANG->LangText(TLI_KLINE_GRAPH));
	m_tab[1].bChecked = false;

	m_CmbItems.Create(m_Hwnd, ID_COMBOX_ITEMS, false);
	m_CmbItems.SetFont(FONT_CONTRL_QUOTE);
	m_CmbItems.Clear();
	m_CmbItems.AddString(G_LANG->LangText(TLI_ITEMSALL));
	m_CmbItems.AddString(G_LANG->LangText(TLI_ITEMHEAD));
	m_CmbItems.AddString(G_LANG->LangText(TLI_ITEMBODY));
	m_CmbItems.AddString(G_LANG->LangText(TLI_ITEMSELECTED));
	m_CmbItems.AddString(G_LANG->LangText(TLI_OPEN_PANEL));
	m_CmbItems.ResizeData();
	m_CmbItems.SetSelect(0);

	m_BtBgColor.Create(m_Hwnd, ID_BUTTON_BACKGROUND_COLOR);
	m_BtBgColor.SetButtonText(G_LANG->LangText(TLI_BACKCOLOR));

	m_BtTextColor.Create(m_Hwnd, ID_BUTTON_TEXT_COLOR);
	m_BtTextColor.SetButtonText(G_LANG->LangText(TLI_TEXTCOLOR));

	m_EtRowHigh.Create(m_Hwnd, 0, ID_EDIT_ROW_HIGHT, 1);
	m_SpRowHigh.Create(m_Hwnd, ID_SPIN_ROW_HIGHT);
	wchar_t temp[21];
	swprintf_s(temp, L"%d", m_nRowHigth);
	m_EtRowHigh.SetWindowText(temp);
	/*m_ChangeTextHL.Create(m_Hwnd, ID_CHECKBOX_CHANGE_TEXT);
	m_ChangeTextHL.SetText(G_LANG->LangText(TLI_CHANGETEXTHL));
	m_ChangeTextHL.SetCheck(m_bChangedTextHL);

	m_ChangeBottemHL.Create(m_Hwnd, ID_CHECKBOX_CHANGE_BACKGROUND);
	m_ChangeBottemHL.SetText(G_LANG->LangText(TLI_CHANGEBACKGROUNDHL));
	m_ChangeBottemHL.SetCheck(m_bChangedBkHL);

	m_BuySellVolHL.Create(m_Hwnd, ID_CHECKBOX_BUYSELL_QUILITY);
	m_BuySellVolHL.SetText(G_LANG->LangText(TLI_BUYSELLVOLHL));
	m_BuySellVolHL.SetCheck(m_bBSQtyHL);*/

	m_BtApply.Create(m_Hwnd, ID_BUTTON_APPLY);
	m_BtApply.SetButtonText(G_LANG->LangText(TLI_APPLY));

	m_BtCancel.Create(m_Hwnd, ID_BUTTON_CANCEL);
	m_BtCancel.SetButtonText(G_LANG->LangText(TLI_CANCLE));

	m_BtBlack.Create(m_Hwnd, ID_BUTTON_BLACK);
	m_BtBlack.SetButtonText(G_LANG->LangText(TLI_BLACK_STYLE));

	m_BtGray.Create(m_Hwnd, ID_BUTTON_GRAY);
	m_BtGray.SetButtonText(G_LANG->LangText(TLI_GRAY_STYLE));

	RECT rc = m_Rects[ITEM_SET_RECT];
	RECT rc_Item = rc;
	rc_Item.top = rc_Item.top + 5;
	rc_Item.bottom = rc_Item.top + 20;
	rc_Item.left = rc_Item.left + (rc.right - rc.left) / 2;
	m_CmbItems.MoveWindow(rc_Item.left, rc_Item.top, rc_Item.right - rc_Item.left, rc_Item.bottom - rc_Item.top);
	
	rc_Item.top = rc_Item.bottom + 10;
	rc_Item.bottom = rc_Item.top + 20;
	rc_Item.left = rc.left;
	rc_Item.right = rc.left +(rc.right - rc.left) / 2-3;
	m_BtBgColor.MoveWindow(rc_Item.left, rc_Item.top, rc_Item.right - rc_Item.left, rc_Item.bottom - rc_Item.top);
	
	rc_Item.left = rc_Item.right+6;
	rc_Item.right = rc.right;
	m_BtTextColor.MoveWindow(rc_Item.left, rc_Item.top, rc_Item.right - rc_Item.left, rc_Item.bottom - rc_Item.top);

	rc = m_Rects[HEIGHT_SET_RECT];
	RECT rc_high = rc;
	rc_high.top = rc_high.top + 5;
	rc_high.bottom = rc_high.top + 20;
	rc_high.left = rc_high.left + (rc.right - rc.left) / 2;
	rc_high.right = rc.right - 10;
	m_EtRowHigh.MoveWindow(rc_high.left, rc_high.top, rc_high.right - rc_high.left, rc_high.bottom - rc_high.top);
	rc_high.left = rc_high.right;
	rc_high.right = rc.right;
	m_SpRowHigh.MoveWindow(rc_high.left, rc_high.top, rc_high.right - rc_high.left, rc_high.bottom - rc_high.top);

	rc = m_Rects[OTHER_SET_RECT];
	//rc.top = rc.top + 5;
	//rc.bottom = rc.top + 20;
	//m_ChangeTextHL.MoveWindow(rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top);

	//rc.top = rc.bottom + 5;
	//rc.bottom = rc.top + 20;
	//m_ChangeBottemHL.MoveWindow(rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top);

	//rc.top = rc.bottom + 5;
	//rc.bottom = rc.top + 20;
	//m_BuySellVolHL.MoveWindow(rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top);

	rc.top = rc.top + 134;
	rc.bottom = rc.top + 20;
	m_BtApply.MoveWindow(rc.left, rc.top,70,20);
	m_BtCancel.MoveWindow(rc.right - 70, rc.top, 70, 20);

	rc = m_Rects[TOP_BLACK_STYLE];
	m_BtBlack.MoveWindow(rc.left, rc.top+10, 80, 20);
	rc = m_Rects[TOP_GRAY_STYLE];
	m_BtGray.MoveWindow(rc.left, rc.top+10, 80, 20);
	if (m_Style == BLACK_STYLE)
	{
		m_BtBlack.EnableButton(false);
		m_BtGray.EnableButton(true);
	}
	else
	{
		m_BtBlack.EnableButton(true);
		m_BtGray.EnableButton(false);
	}
	if (m_bShowKLine)
	{
		m_tab[0].bChecked = false;
		m_tab[1].bChecked = true;
	}
	RefeshCtrlVisiable(!m_bShowKLine);
}
LRESULT QuoteSkinConfig::WndProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_PAINT:
		OnPaint();
		break;
	case WM_DESTROY:
		OnDestory();
		break;
	//case SSWM_CHECKBOX_CHECK_CHANAGE:
	//	OnCheckBoxChanged(wParam);
	//	break;
	case WM_NOTIFY:
		OnNotify(wParam, lParam);
		break;
	case WM_MOUSEWHEEL:
		OnMouseWheel(wParam, lParam);
		break;
	case WM_LBUTTONDOWN:
		OnLButtonDown(wParam, lParam);
		break;
	case SSWM_STATIC_BUTTON_CLICKDOWN:
		OnStaticButtonClicked(wParam, lParam);
		break;
	default:
		return NOT_PROCESSED;
	}
	return PROCESSED;
}
void QuoteSkinConfig::OnPaint()
{
	TMemDC memdc(m_Hwnd);
	RECT rect;
	GetClientRect(m_Hwnd, &rect);
	FillRect(memdc.GetHdc(), &rect, BRUSH_BG_QUOTE);

	RECT down_rc = rect;
	down_rc.top = m_Rects[TOP_RECT].bottom;
	HBRUSH hBrusk = CreateSolidBrush(RGB(217, 217, 217));
	FrameRect(memdc.GetHdc(), &down_rc, hBrusk);
	DeleteObject(hBrusk);

	DrawTopRect(memdc.GetHdc(), rect);

	DrawPreviewRect(memdc.GetHdc(), rect);

	DrawControlsRect(memdc.GetHdc(), rect);
}
void QuoteSkinConfig::OnDestory()
{
	m_CmbItems.ReleaseComboxList();
	SaveCfg();
}
void QuoteSkinConfig::InitData()
{
	m_rgbBk = COLOR_FUTURE_BACKGROUND;
	m_rgbHeaderBk = COLOR_FUTURE_HEAD_BACKGROUND;
	m_rgbGrideBk = COLOR_FUTURE_ROW_BACKGROUND;
	m_rgbSelectedBk = COLOR_FUTURE_SEL_BACKGROUND;
	m_rgbHeaderText = COLOR_FUTURE_TITLE;
	m_rgbGrideText = COLOR_FUTURE_STR;
	m_rgbSelectedText = COLOR_FUTURE_SEL_TEXT;
	m_rgbUpText = COLOR_FUTURE_UP;
	m_rgbDownText = COLOR_FUTURE_DOWN;
	m_rgbChangedText = COLOR_FUTURE_CHANGED;
	m_rgbEqueText = COLOR_FUTURE_EQUAL;
	m_rgbSelRow = COLOR_FUTURE_SEL;
	m_rgbPanelBK = COLOR_PANEL_BACKGROUND;
	m_rgbPanelStr = COLOR_PANEL_STR;
	m_rgbPanelPriceStr = COLOR_PANEL_PRICE_TEXT;
	m_rgbPanelTickStr = COLOR_PANEL_TICK_TEXT;
	m_rgbInmoneyBk = COLOR_INMONEY_BACKGROUND;
	m_rgbOutmoneyBk = COLOR_OUTMONEY_BACKGROUND;
	m_rgbPlateBK = COLOR_PLATE_BACKGROUND;
	m_rgbPlateFont = COLOR_PLATE_FONT;
	m_rgbPlateFont2 = COLOR_PLATE_FONT2;
	m_rgbPlateFontHot = COLOR_PLATE_FONT_HOT;
	m_rgbPlateFontHot2 = COLOR_PLATE_FONT_HOT2;
	m_rgbKLineBK = COLOR_KLINE_BACKGROUND;
	m_rgbKLineUp = COLOR_KLINE_RED_BAR;
	m_rgbKLineDown = COLOR_KLINE_GREEN_BAR;
	m_rgbKLineEque = COLOR_KLINE_WHITE_BAR;
	m_rgbKLineStr = COLOR_KLINE_MENU_TEXT;
	m_rgbTLinePrice = COLOR_TLINE_PRICE;
	m_rgbTLineAvg = COLOR_TLINE_AVG_PRICE;
	m_rgbLineOrderBuy = COLOR_LINE_ORDER_BUY;
	m_rgbLineOrderSell = COLOR_LINE_ORDER_SELL;
	m_rgbLineOrderCover = COLOR_LINE_ORDER_COVER;
	m_rgbLineOrderBack = COLOR_LINE_ORDER_BACK;
	m_rgbLineOrderLoss = COLOR_LINE_ORDER_LOSS;
	m_rgbLineOrderProfit = COLOR_LINE_ORDER_PROFIT;
	m_rgbLinePositionBuy = COLOR_LINE_POSITION_BUY;
	m_rgbLinePositionSell = COLOR_LINE_POSITION_SELL;
	m_rgbConfigBK = COLOR_CONFIGWINDOW_BACKGROUND;
	m_rgbPanelMutiBid = COLOR_PANEL_MULTI_BID;
	m_rgbPanelMutiAsk = COLOR_PANEL_MULTI_ASK;
	m_rgbKLineCross = COLOR_KLINE_CROSS;
	for (int i = 0; i < TargetLineNum; i++)
	{
		m_rgbSpaceLine[i] = COLOR_SPEC_LINE[i];
	}
	/*m_bChangedBkHL = false;
	m_bChangedTextHL = true;
	m_bBSQtyHL = true;*/
	m_nRowHigth = 28;
	m_Style = G_STYLE;

}
void QuoteSkinConfig::PrepareRects()
{
	RECT rect;
	GetClientRect(m_Hwnd, &rect);
	int nGap = 5;
	RECT& rc_t = m_Rects[TOP_RECT];
	rc_t = rect;
	rc_t.left = rect.left;
	rc_t.bottom = rect.top + TOP_HIGTH;

	RECT& rc_t_ss = m_Rects[TOP_STYLE_SETTING];
	rc_t_ss = rc_t;
	rc_t_ss.left = rc_t.left + nGap;
	rc_t_ss.right = rc_t_ss.left + 80;
	rc_t_ss.bottom = rc_t_ss.top + 40;

	RECT& rc_t_sb = m_Rects[TOP_BLACK_STYLE];
	rc_t_sb = rc_t;
	rc_t_sb.left = rc_t_ss.right + 15;
	rc_t_sb.right = rc_t_sb.left + 80;
	rc_t_sb.bottom = rc_t_sb.top + 40;

	RECT& rc_t_sg = m_Rects[TOP_GRAY_STYLE];
	rc_t_sg = rc_t;
	rc_t_sg.left = rc_t_sb.right + 15;
	rc_t_sg.right = rc_t_sg.left + 80;
	rc_t_sg.bottom = rc_t_sg.top + 40;

	RECT& rc_l = m_Rects[LEFT_RECT];
	rc_l = rect;
	rc_l.left = rect.left + nGap;
	rc_l.top = rc_t.bottom + nGap;
	rc_l.right = rc_l.left + LEFT_WIDTH;
	rc_l.bottom = rc_l.top + LEFT_HIGTH;

	int nLeft_Gap = 20;
	RECT& rc_r = m_Rects[RIGHT_RECT];
	rc_r = rect;
	rc_r.top = rc_t.bottom + nGap;
	rc_r.left = rc_l.right+ nLeft_Gap;
	rc_r.right = rc_r.left + RIGHT_WIDTH;
	rc_r.bottom = rc_r.top + RIGHT_HIGTH;

	int nHigth = 60;
	RECT& rc_item = m_Rects[ITEM_SET_RECT];
	rc_item = rc_r;
	rc_item.bottom = rc_item.top + nHigth;

	nHigth = 30;
	RECT& rc_high = m_Rects[HEIGHT_SET_RECT];
	rc_high = rc_r;
	rc_high.top = rc_item.bottom;
	rc_high.bottom = rc_high.top + nHigth;

	nHigth = 35;
	RECT& rc_color = m_Rects[COLOR_SET_RECT];
	rc_color = rc_r;
	rc_color.top = rc_high.bottom;
	rc_color.bottom = rc_color.top + nHigth;
	RECT& rc_up = m_Rects[COLOR_UP_RECT];
	rc_up = rc_color;
	rc_up.top = rc_color.top + 5;
	rc_up.right = rc_r.left + (rc_r.right - rc_r.left) / 3;
	RECT& rc_down = m_Rects[COLOR_DOWN_RECT];
	rc_down = rc_up;
	rc_down.left = rc_up.right;
	rc_down.right = rc_down.left + (rc_r.right - rc_r.left) / 3;
	RECT& rc_change = m_Rects[COLOR_CHANGED_RECT];
	rc_change = rc_down;
	rc_change.left = rc_down.right;
	rc_change.right = rc_r.right;

	nHigth = 2* nHigth;
	RECT& rc_other = m_Rects[OTHER_SET_RECT];
	rc_other = rc_r;
	rc_other.top = rc_color.bottom;
	rc_other.bottom = rc_other.top+nHigth;

	nHigth = 35;
	RECT& rc_panel = m_Rects[PANEL_INFO_RECT];
	rc_panel = rc_r;
	rc_panel.top = rc_color.bottom;
	rc_panel.bottom = rc_panel.top + nHigth;

	RECT& rc_panelstr = m_Rects[PANEL_TEXT_RECT];
	rc_panelstr = rc_panel;
	rc_panelstr.right = rc_panel.left + (rc_panel.right - rc_panel.left) / 2;

	RECT& rc_panelprice = m_Rects[PANEL_PRICE_RECT];
	rc_panelprice = rc_panel;
	rc_panelprice.top = rc_panel.top + 5;
	rc_panelprice.left = rc_panelstr.right;
	rc_panelprice.right = rc_panelprice.left + (rc_panel.right - rc_panel.left) / 4;

	RECT& rc_paneltick = m_Rects[PANEL_TICK_RECT];
	rc_paneltick = rc_panel;
	rc_paneltick.top = rc_panel.top + 5;
	rc_paneltick.left = rc_panelprice.right;

	RECT& rc_panelmuti = m_Rects[PANEL_MUTI_RECT];
	rc_panelmuti = rc_panel;
	rc_panelmuti.top = rc_panel.bottom;
	rc_panelmuti.bottom = rc_panelmuti.top + nHigth;
	rc_panelmuti.right = rc_r.left + (rc_r.right - rc_r.left) / 2;

	RECT& rc_panelbid = m_Rects[PANEL_BID_RECT];
	rc_panelbid = rc_panelmuti;
	rc_panelbid.top = rc_panelmuti.top + 5;
	rc_panelbid.left = rc_panelmuti.right;
	rc_panelbid.right = rc_panelbid.left + (rc_r.right - rc_r.left) / 4;

	RECT& rc_panelask = m_Rects[PANEL_ASK_RECT];
	rc_panelask = rc_panelmuti;
	rc_panelask.top = rc_panelmuti.top + 5;
	rc_panelask.left = rc_panelbid.right;
	rc_panelask.right = rc_r.right;


	nHigth = 35;
	RECT& rc_option = m_Rects[OPTION_INFO_RECT];
	rc_option = rc_r;
	rc_option.top = rc_panelask.bottom ;
	rc_option.bottom = rc_option.top + nHigth;

	RECT& rc_optionstr = m_Rects[OPTION_TEXT_RECT];
	rc_optionstr = rc_option;
	rc_optionstr.right = rc_option.left + (rc_option.right - rc_option.left) / 2;

	RECT& rc_optionin = m_Rects[OPTION_INMONEY_RECT];
	rc_optionin = rc_option;
	rc_optionin.top = rc_option.top + 5;
	rc_optionin.left = rc_panelstr.right;
	rc_optionin.right = rc_panelprice.left + (rc_option.right - rc_option.left) / 4;

	RECT& rc_optionout = m_Rects[OPTION_OUTMONEY_RECT];
	rc_optionout = rc_option;
	rc_optionout.top = rc_option.top + 5;
	rc_optionout.left = rc_optionin.right;
}
void QuoteSkinConfig::DrawTopRect(HDC mdc, RECT& cr)
{
	RECT rc_t_ss = m_Rects[TOP_STYLE_SETTING];
	SelectFont(mdc, FONT_CONTRL_QUOTE);
	SetTextColor(mdc, COLOR_QUOTE_CONFIG_FONT);
	DrawText(mdc, G_LANG->LangText(TLI_STYLE_SETTING), wcslen(G_LANG->LangText(TLI_STYLE_SETTING)), &rc_t_ss, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	SetBkMode(mdc, TRANSPARENT);
	//绘制Tab
	for (int i = 0; i <= sizeof(m_tab) / sizeof(Tab_BNT); i++)
	{
		Tab_BNT tab = m_tab[i];
		if (tab.bChecked)
		{
			RECT rc = tab.rc;
			rc.top -= 2;
			rc.bottom += 2;
			FillRect(mdc, &rc, BRUSH_BG_QUOTE);
			HPEN pen = CreatePen(PS_SOLID, 1, RGB(217, 217, 217));
			SelectPen(mdc, pen);
			MoveToEx(mdc, rc.left, rc.bottom, 0);
			LineTo(mdc, rc.left, rc.top);
			LineTo(mdc, rc.right, rc.top);
			LineTo(mdc, rc.right, rc.bottom);
			DeleteObject(pen);
			InflateRect(&rc,-5, -1);
			DrawText(mdc, tab.text, wcslen(tab.text), &rc, DT_LEFT | DT_TOP | DT_SINGLELINE);
		}
		else
		{
			RECT rc = tab.rc;
			HBRUSH hBrusk = CreateSolidBrush(RGB(240, 240, 240));
			FillRect(mdc, &rc, hBrusk);
			DeleteObject(hBrusk);
			hBrusk = CreateSolidBrush(RGB(217, 217, 217));
			FrameRect(mdc, &rc, hBrusk);
			DeleteObject(hBrusk);
			InflateRect(&rc, -5, -1);
			DrawText(mdc, tab.text, wcslen(tab.text), &rc, DT_LEFT | DT_BOTTOM | DT_SINGLELINE);
		}
	}
}
void QuoteSkinConfig::DrawPreviewRect(HDC mdc, RECT& cr)
{
	if (m_bShowKLine)
		DrawKLineGraph(mdc,cr);
	else
		DrawQuoteGrid(mdc, cr);
}
void QuoteSkinConfig::DrawQuoteGrid(HDC mdc, RECT& cr)
{
	//是否 1上涨 0正常 -1 下跌
	int ColorType[12][9] =
	{
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		{ -1,1,0,-1,1,0,0,1,-1 },
		{ 0,0,0,0,1,0,0,0,0 },
		{ 0,-1,0,0,0,0,-1,0,0 },
		{ -1,0,0,0,0,1,0,0,0 },
		{ 0,1,0,0,0,-1,0,0,0 },
		{ 0,0,-1,0,0,0,0,0,0 },
		{ 0,0,0,1,0,1,-1,0,0 },
		{ -1,1,0,0,0,0,0,0,0 },
		{ 0,0,0,0,1,0,0,0,1 },
		{ 0,1,1,1,0,0,0,0,0 },
		{ 0,0,0,-1,0,0,-1,0,0 }
	};
	//是否变动背景闪烁
	bool bFlash[12][9] =
	{
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		{ 1,1,0,0,0,0,0,0,0 },
		{ 0,0,0,0,1,0,0,0,0 },
		{ 0,1,0,0,0,0,1,0,0 },
		{ 0,0,0,0,0,1,0,0,0 },
		{ 0,0,0,0,0,0,0,0,0 },
		{ 0,0,1,0,0,0,0,0,0 },
		{ 0,0,0,0,0,0,1,0,0 },
		{ 1,1,0,0,0,0,0,0,0 },
		{ 0,0,0,0,0,0,0,0,1 },
		{ 0,0,1,0,0,0,0,0,0 },
		{ 0,0,0,1,0,0,1,0,0 }
	};
	RECT rc = m_Rects[LEFT_RECT];
	//绘制背景
	FillSolidRect(mdc, &rc, m_rgbBk);
	SIZE sizehead, sizeList;
	SelectFont(mdc, FONT_FUTURE_TITLE);
	GetTextExtentPoint(mdc, G_LANG->LangText(TLI_COLUMN1), wcslen(G_LANG->LangText(TLI_COLUMN1)), &sizehead);
	SelectFont(mdc, FONT_FUTURE_CONTENT);
	GetTextExtentPoint(mdc, L"1001", wcslen(L"1001"), &sizeList);
	int wid = max(sizehead.cx, sizeList.cx) + 20;
	int hid = m_nRowHigth;
	int nRow = LEFT_HIGTH / hid;
	int nCol = LEFT_WIDTH / wid;
	RECT Row_rc = rc;
	int gridSel = 2; //列表选中行
	Row_rc.right = rc.left + wid;
	Row_rc.bottom = rc.top + hid;
	SetBkMode(mdc, TRANSPARENT);
	//绘制行
	for (int i = 0; i < nRow; i++)
	{
		//绘制列
		for (int t = 0; t < nCol; t++)
		{

			if (i == 0)
			{
				//列表头背景
				FillSolidRect(mdc, &Row_rc, m_rgbHeaderBk);
			}
			else if (i == gridSel)
			{
				//列表选中行背景
				FillSolidRect(mdc, &Row_rc, m_rgbSelectedBk);
			}
			else
			{
				//绘制网格背景
				FillSolidRect(mdc, &Row_rc, m_rgbGrideBk);
			}
			//写文字
			if (i == 0)
			{
				SelectFont(mdc, FONT_FUTURE_TITLE);
				SetTextColor(mdc, m_rgbHeaderText);
			}
			else
			{
				SelectFont(mdc, FONT_FUTURE_CONTENT);
				if (-1 == ColorType[i % 12][t % 9])//下跌
				{
					/*if (m_bChangedBkHL&&bFlash[i % 12][t % 9])
					FillSolidRect(mdc, &Row_rc, AlphaColor(m_rgbGrideBk, m_rgbDownText, 80));*/
					SetTextColor(mdc, m_rgbDownText);
				}
				else if (0 == ColorType[i % 12][t % 9])//正常
				{
					if (i == gridSel)
						SetTextColor(mdc, m_rgbSelectedText);
					else
						SetTextColor(mdc, m_rgbGrideText);
				}
				else if (1 == ColorType[i % 12][t % 9])//上涨
				{
					/*if (m_bChangedBkHL&&bFlash[i % 12][t % 9])
					FillSolidRect(mdc, &Row_rc, AlphaColor(m_rgbGrideBk, m_rgbUpText, 80));*/
					SetTextColor(mdc, m_rgbUpText);
				}
				if (/*m_bChangedTextHL&& */bFlash[i % 12][t % 9])
				{
					SetTextColor(mdc, m_rgbChangedText);
				}
			}
			wchar_t txt[21];
			if (i == 0)
				swprintf_s(txt, L"%s%d", G_LANG->LangText(TLI_COLUMN), t + 1);
			else
				swprintf_s(txt, L"%d0%02d", i, t);
			DrawText(mdc, txt, wcslen(txt), &Row_rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
			if (t == nCol - 1)
			{
				Row_rc.left = rc.left;
				Row_rc.right = rc.left + wid;
			}
			else
			{
				Row_rc.left += wid;
				Row_rc.right += wid;
			}
		}
		Row_rc.top += hid;
		Row_rc.bottom += hid;
		//绘制框选行
		if (i == gridSel)
		{
			RECT secRc = rc;
			secRc.top = rc.top + gridSel*hid;
			secRc.bottom = rc.top + (gridSel + 1)*hid;
			secRc.left = rc.left + 1;
			secRc.right = rc.left + nCol*wid;
			HBRUSH hbsh = CreateSolidBrush(m_rgbSelRow);
			FrameRect(mdc, &secRc, hbsh);
			DeleteObject(hbsh);

		}
	}
}
void QuoteSkinConfig::DrawKLineGraph(HDC mdc, RECT& cr)
{
	RECT rc = m_Rects[LEFT_RECT];
	//绘制背景
	FillSolidRect(mdc, &rc, m_rgbKLineBK);
	RECT text_rc = rc;
	text_rc.bottom = rc.top + 22;
	SetBkMode(mdc, TRANSPARENT);
	SelectObject(mdc, FONT_KLINE_TEXT);
	SetTextColor(mdc, m_rgbKLineStr);
	DrawText(mdc, G_LANG->LangText(TLI_ESUNNY_INFORMATION), wcslen(G_LANG->LangText(TLI_ESUNNY_INFORMATION)), &text_rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	//绘制坐标轴
	int marLeft = 20;//左侧留白
	int marButtom = 20;//底部留白
	int marTop = 22; //顶部留白
	SelectPen(mdc, PEN_KLINE_GRID_LINE);
	MoveToEx(mdc, rc.left + marLeft, rc.top + marTop, 0);
	LineTo(mdc, rc.left + marLeft, rc.bottom - marButtom);
	LineTo(mdc, rc.right, rc.bottom - marButtom);
	int size = (rc.bottom - marButtom - rc.top) / 5;
	SelectPen(mdc, PEN_KLINE_GRID_DOTLINE);
	for (int i = 1; i <= 4; i++)
	{
		MoveToEx(mdc, rc.left + marLeft, rc.bottom - marButtom - i*size, 0);
		LineTo(mdc, rc.right, rc.bottom - marButtom - i*size);
	}
	//计算坐标轴数字位置
	wchar_t num[11][5] = { L"0",L"30",L"60",L"90",L"120" };
	SetBkMode(mdc, OPAQUE);
	SelectObject(mdc, FONT_KLINE_NUMBER);
	SIZE ftsize;
	::GetTextExtentPoint32(mdc, num[4], wcslen(num[4]), &ftsize);
	SetTextColor(mdc, COLOR_KLINE_GRID_TEXT);
	int wid = ftsize.cx;
	int hid = ftsize.cy;
	for (int i = 0; i < 5; i++)
	{
		RECT tmp_rc = rc;
		tmp_rc.top = rc.bottom - marButtom - i*size - hid / 2;
		tmp_rc.right = rc.left + wid;
		tmp_rc.bottom = rc.bottom - marButtom - i*size + hid / 2;
		DrawText(mdc, num[i], wcslen(num[i]), &tmp_rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	}
	SetBkMode(mdc, TRANSPARENT);
	//绘制蜡烛线
	marLeft = 35;//第一根蜡烛线左侧留白
	marTop = 75; //第一根蜡烛线顶部留白
	const int width = 10;
	const int high = 21;
	RECT rcUpBar = rc;
	rcUpBar.left = rc.left + marLeft;
	rcUpBar.top = rc.top + marTop;
	rcUpBar.right = rc.left + marLeft + width;
	rcUpBar.bottom = rc.top + marTop + high;
	HPEN hpen = CreatePen(PS_SOLID, 1, m_rgbKLineUp);
	SelectPen(mdc, hpen);
	HBRUSH hbrush = CreateSolidBrush(m_rgbKLineUp);
	for (int i = 0; i < 8; i++)
	{
		//绘制竖线
		MoveToEx(mdc, rcUpBar.left + width / 2, rcUpBar.top - 16, 0);
		LineTo(mdc, rcUpBar.left + width / 2, rcUpBar.top);
		MoveToEx(mdc, rcUpBar.left + width / 2, rcUpBar.bottom + 16, 0);
		LineTo(mdc, rcUpBar.left + width / 2, rcUpBar.bottom);
		FrameRect(mdc, &rcUpBar, hbrush);
		rcUpBar.left += 30;
		rcUpBar.top -= 7;
		rcUpBar.right += 30;
		rcUpBar.bottom -= 7;
	}
	DeleteObject(hbrush);
	DeleteObject(hpen);
	const int low = 16;//下跌线在上涨线下方
	const int right = 15;//下跌线在上涨线右方
						 //绘制下跌蜡烛线
	RECT rcDownBar = rc;
	rcDownBar.left = rc.left + marLeft + right;
	rcDownBar.top = rc.top + marTop + low;
	rcDownBar.right = rc.left + marLeft + width + right;
	rcDownBar.bottom =  rc.top + marTop + high + low;
	hbrush = CreateSolidBrush(m_rgbKLineDown);
	for (int i = 0; i < 7; i++)
	{
		//绘制竖线
		DrawLine(mdc, rcDownBar.left + width / 2, rcDownBar.top - 16, rcDownBar.left + width / 2, rcDownBar.top, m_rgbKLineDown);
		DrawLine(mdc, rcDownBar.left + width / 2, rcDownBar.bottom + 16, rcDownBar.left + width / 2, rcDownBar.bottom, m_rgbKLineDown);
		FillRect(mdc, &rcDownBar, hbrush);
		rcDownBar.left += 30;
		rcDownBar.top -= 7;
		rcDownBar.right += 30;
		rcDownBar.bottom -= 7;
	}
	DeleteObject(hbrush);
	//绘制指标线
	POINT Line1Fir;
	Line1Fir.x = rc.left + 20;
	Line1Fir.y = rc.top+110 + 20;//指标线1的开始位置
	POINT Line1Sec;
	Line1Sec.x = rc.left + 50;
	Line1Sec.y = rc.top + 95 + 20;//指标线1的第二点
	POINT Line1Thr;
	Line1Thr.x = rc.left + 75;
	Line1Thr.y = rc.top + 105 + 20;//指标线1的第三点
	POINT Line1Fou;
	Line1Fou.x = rc.left + 100;
	Line1Fou.y = rc.top + 95 + 20;//指标线1的第四点
	POINT Line1Fiv;
	Line1Fiv.x = rc.left + 125;
	Line1Fiv.y = rc.top + 105 + 20;//指标线1的第五点
	POINT Line1Six;
	Line1Six.x = rc.right - 35;
	Line1Six.y = rc.top + 105 + 20;//指标线1的第6点
	int gap = 6; //两条指标线间距
	for (int i = 0; i < TargetLineNum; i++)
	{
		//绘制指标线
		hpen = CreatePen(PS_SOLID, 1, m_rgbSpaceLine[i]);
		SelectPen(mdc,hpen);
		MoveToEx(mdc, Line1Fir.x, Line1Fir.y + i*gap,0);
		LineTo(mdc, Line1Sec.x, Line1Sec.y + i*gap);
		LineTo(mdc, Line1Thr.x, Line1Thr.y + i*gap);
		LineTo(mdc, Line1Fou.x, Line1Fou.y + i*gap);
		LineTo(mdc, Line1Fiv.x, Line1Fiv.y + i*gap);
		LineTo(mdc, Line1Six.x, Line1Six.y + i*gap);

		DeleteObject(hpen);
	}
	//绘制分时线
	marLeft = 50; //左侧留白
	marButtom = 20;//底部留白
	const int hight = 65;
	//绘制价位线
	DrawLine(mdc, rc.left + 20, rc.bottom - marButtom - 15, rc.right, rc.bottom - marButtom - hight - 10, m_rgbTLinePrice);
	//绘制均价线
	DrawLine(mdc, rc.left + 20, rc.bottom - marButtom - 10, rc.right, rc.bottom - marButtom - hight - 5, m_rgbTLineAvg);
}
void QuoteSkinConfig::DrawControlsRect(HDC mdc, RECT& cr)
{
	if(m_bShowKLine)
		DrawKLineControls(mdc, cr);
	else
		DrawQuoteControls(mdc, cr);
}
void QuoteSkinConfig::DrawQuoteControls(HDC mdc, RECT& cr)
{
	const int nGap = 5;
	const int nDivHigh = 1;
	const int nItemHigh = 20;
	//绘制字体底部分割条
	RECT rc = m_Rects[ITEM_SET_RECT];
	RECT rc_Item = rc;
	rc_Item.top = rc_Item.top + nGap;
	rc_Item.bottom = rc_Item.top + nItemHigh;
	rc_Item.right = rc_Item.left + (rc.right - rc.left) / 2;
	SelectFont(mdc, FONT_CONTRL_QUOTE);
	SetTextColor(mdc, COLOR_QUOTE_CONFIG_FONT);
	DrawText(mdc, G_LANG->LangText(TLI_ITEMSETTING), wcslen(G_LANG->LangText(TLI_ITEMSETTING)), &rc_Item, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
	rc.top = rc.bottom - nDivHigh;
	rc.bottom = rc.bottom;
	FillSolidRect(mdc, &rc, RGB(160, 160, 160));

	rc = m_Rects[HEIGHT_SET_RECT];
	RECT rc_height = rc;
	rc_height.top = rc_height.top + nGap;
	rc_height.bottom = rc_height.top + nItemHigh;
	rc_height.right = rc_height.left + (rc.right - rc.left) / 2;
	DrawText(mdc, G_LANG->LangText(TLI_ROWHEIGHT), wcslen(G_LANG->LangText(TLI_ROWHEIGHT)), &rc_height, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
	rc.top = rc.bottom - nDivHigh;
	rc.bottom = rc.bottom;
	FillSolidRect(mdc, &rc, RGB(160, 160, 160));

	rc = m_Rects[COLOR_SET_RECT];
	rc.top += 5;
	FillSolidRect(mdc, &rc, m_rgbGrideBk);

	rc = m_Rects[COLOR_UP_RECT];
	SetTextColor(mdc, m_rgbUpText);
	DrawText(mdc, G_LANG->LangText(TLI_UPCOLOR), wcslen(G_LANG->LangText(TLI_UPCOLOR)), &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

	rc = m_Rects[COLOR_DOWN_RECT];
	SetTextColor(mdc, m_rgbDownText);
	DrawText(mdc, G_LANG->LangText(TLI_DOWNCOLOR), wcslen(G_LANG->LangText(TLI_DOWNCOLOR)), &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

	rc = m_Rects[COLOR_CHANGED_RECT];
	SetTextColor(mdc, m_rgbChangedText);
	DrawText(mdc, G_LANG->LangText(TLI_CHANGEDCOLOR), wcslen(G_LANG->LangText(TLI_CHANGEDCOLOR)), &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

	rc = m_Rects[PANEL_TEXT_RECT];
	rc.top += 5;
	SetTextColor(mdc, COLOR_QUOTE_CONFIG_FONT);
	DrawText(mdc, G_LANG->LangText(TLI_PANEL_TEXT), wcslen(G_LANG->LangText(TLI_PANEL_TEXT)), &rc, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	rc = m_Rects[PANEL_INFO_RECT];
	rc.top += 5;
	rc.left = m_Rects[PANEL_TEXT_RECT].right;
	FillSolidRect(mdc, &rc, m_rgbPanelBK);

	rc = m_Rects[PANEL_PRICE_RECT];
	SetTextColor(mdc, m_rgbPanelPriceStr);
	DrawText(mdc, G_LANG->LangText(TLI_TLINE_PRICE), wcslen(G_LANG->LangText(TLI_TLINE_PRICE)), &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

	rc = m_Rects[PANEL_TICK_RECT];
	SetTextColor(mdc, m_rgbPanelTickStr);
	DrawText(mdc, G_LANG->LangText(TLI_PANEL_TICK), wcslen(G_LANG->LangText(TLI_PANEL_TICK)), &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

	rc = m_Rects[PANEL_MUTI_RECT];
	rc.top += 5;
	SetTextColor(mdc, COLOR_QUOTE_CONFIG_FONT);
	DrawText(mdc, G_LANG->LangText(TLI_PANEL_MUTIPLY), wcslen(G_LANG->LangText(TLI_PANEL_MUTIPLY)), &rc, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	rc = m_Rects[PANEL_BID_RECT];
	FillSolidRect(mdc, &rc, m_rgbPanelBK);
	SetTextColor(mdc, m_rgbPanelMutiBid);
	DrawText(mdc, G_LANG->LangText(TLI_BID_QTY), wcslen(G_LANG->LangText(TLI_BID_QTY)), &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

	rc = m_Rects[PANEL_ASK_RECT];
	FillSolidRect(mdc, &rc, m_rgbPanelBK);
	SetTextColor(mdc, m_rgbPanelMutiAsk);
	DrawText(mdc, G_LANG->LangText(TLI_ASK_QTY), wcslen(G_LANG->LangText(TLI_ASK_QTY)), &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

	rc = m_Rects[OPTION_TEXT_RECT];
	rc.top += 5;
	SetTextColor(mdc, COLOR_QUOTE_CONFIG_FONT);
	DrawText(mdc, G_LANG->LangText(TLI_OPTION_GRIDE), wcslen(G_LANG->LangText(TLI_OPTION_GRIDE)), &rc, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	SetTextColor(mdc, m_rgbGrideText);
	rc = m_Rects[OPTION_INMONEY_RECT];
	FillSolidRect(mdc, &rc, m_rgbInmoneyBk);
	DrawText(mdc, G_LANG->LangText(TLI_OPTION_INMONEY), wcslen(G_LANG->LangText(TLI_OPTION_INMONEY)), &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

	rc = m_Rects[OPTION_OUTMONEY_RECT];
	FillSolidRect(mdc, &rc, m_rgbOutmoneyBk);
	DrawText(mdc, G_LANG->LangText(TLI_OPTION_OUTMONEY), wcslen(G_LANG->LangText(TLI_OPTION_OUTMONEY)), &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}

void QuoteSkinConfig::DrawColorBnt(HDC mdc, RECT* cr, COLORREF col)
{
	FillSolidRect(mdc, cr, col);
	HPEN hPen = CreatePen(PS_SOLID, 1, RGB(160, 160, 160));
	SelectPen(mdc, hPen);
	MoveToEx(mdc, cr->left, cr->bottom, 0);
	LineTo(mdc, cr->left, cr->top);
	LineTo(mdc, cr->right, cr->top);
	DeletePen(hPen);
	hPen = CreatePen(PS_SOLID, 1, RGB(243, 243, 243));
	SelectPen(mdc, hPen);
	LineTo(mdc, cr->right, cr->bottom);
	LineTo(mdc, cr->left, cr->bottom);
	DeletePen(hPen);
}
void QuoteSkinConfig::DrawKLineControls(HDC mdc, RECT& cr)
{
	const int nGap = 5;
	const int nDivHigh = 1;
	const int nItemHigh = 15;
	const int nWidth = 25;
	const int nmid = 5;
	RECT rc_r = m_Rects[RIGHT_RECT];
	rc_r.left -= 11;
	//第一行
	RECT rc_text = rc_r;
	rc_text.top = rc_r.top + nGap;
	rc_text.right = rc_r.left+(rc_r.right- rc_r.left)/2- nWidth- nmid;
	rc_text.bottom = rc_text.top + nItemHigh;
	SelectObject(mdc, FONT_KLINE_TEXT);
	SetTextColor(mdc, COLOR_QUOTE_CONFIG_FONT);
	DrawText(mdc, G_LANG->LangText(TLI_KLINE_BACKGROUND), wcslen(G_LANG->LangText(TLI_KLINE_BACKGROUND)), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt0 = m_KLineBnts[ID_KLINE_BACKGROUND];
	rc_bnt0 = rc_text;
	rc_bnt0.right = rc_r.left + (rc_r.right - rc_r.left) / 2 - nmid;
	rc_bnt0.left = rc_bnt0.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt0, m_rgbKLineBK);

	rc_text = rc_r;
	rc_text.top = rc_r.top + nGap;
	rc_text.left = rc_r.left + (rc_r.right - rc_r.left) / 2 + nmid;
	rc_text.right = rc_r.right - nWidth;
	rc_text.bottom = rc_text.top + nItemHigh;
	DrawText(mdc, G_LANG->LangText(TLI_KLINE_TEXT), wcslen(G_LANG->LangText(TLI_KLINE_TEXT)), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt1 = m_KLineBnts[ID_KLINE_TEXT];
	rc_bnt1 = rc_text;
	rc_bnt1.right = rc_r.right;
	rc_bnt1.left = rc_bnt1.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt1, m_rgbKLineStr);

	rc_text.top = rc_text.bottom + 2*nGap;
	rc_text.left = rc_r.left;
	rc_text.right = rc_r.left + (rc_r.right - rc_r.left) / 2 - nWidth - nmid;
	rc_text.bottom = rc_text.top + nItemHigh;
	DrawText(mdc, G_LANG->LangText(TLI_KLINE_UP), wcslen(G_LANG->LangText(TLI_KLINE_UP)), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt2 = m_KLineBnts[ID_KLINE_UP];
	rc_bnt2 = rc_text;
	rc_bnt2.right = rc_r.left + (rc_r.right - rc_r.left) / 2 - nmid;
	rc_bnt2.left = rc_bnt2.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt2, m_rgbKLineUp);


	rc_text.left = rc_r.left + (rc_r.right - rc_r.left) / 2 + nmid;
	rc_text.right = rc_r.right - nWidth;
	DrawText(mdc, G_LANG->LangText(TLI_KLINE_DOWN), wcslen(G_LANG->LangText(TLI_KLINE_DOWN)), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt3 = m_KLineBnts[ID_KLINE_DOWN];
	rc_bnt3 = rc_text;
	rc_bnt3.right = rc_r.right;
	rc_bnt3.left = rc_bnt3.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt3, m_rgbKLineDown);

	rc_text.top = rc_text.bottom + 2 * nGap;
	rc_text.left = rc_r.left;
	rc_text.right = rc_r.left + (rc_r.right - rc_r.left) / 2 - nWidth - nmid;
	rc_text.bottom = rc_text.top + nItemHigh;
	DrawText(mdc, G_LANG->LangText(TLI_TLINE_PRICE_LINE), wcslen(G_LANG->LangText(TLI_TLINE_PRICE_LINE)), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt4 = m_KLineBnts[ID_TLINE_PRICE];
	rc_bnt4 = rc_text;
	rc_bnt4.right = rc_r.left + (rc_r.right - rc_r.left) / 2 - nmid;
	rc_bnt4.left = rc_bnt4.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt4, m_rgbTLinePrice);


	rc_text.left = rc_r.left + (rc_r.right - rc_r.left) / 2 + nmid;
	rc_text.right = rc_r.right - nWidth;
	DrawText(mdc, G_LANG->LangText(TLI_TLINE_AVERAGE), wcslen(G_LANG->LangText(TLI_TLINE_AVERAGE)), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt5 = m_KLineBnts[ID_TLINE_AVERAGE];
	rc_bnt5 = rc_text;
	rc_bnt5.right = rc_r.right;
	rc_bnt5.left = rc_bnt5.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt5, m_rgbKLineDown);

	rc_text.top = rc_text.bottom + 2 * nGap;
	rc_text.left = rc_r.left;
	rc_text.right = rc_r.left + (rc_r.right - rc_r.left) / 2 - nWidth - nmid;
	rc_text.bottom = rc_text.top + nItemHigh;
	wchar_t tmp[101]=L"";
	swprintf_s(tmp, L"%s1", G_LANG->LangText(TLI__KLINE_INDEX));
	DrawText(mdc, tmp, wcslen(tmp), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt6 = m_KLineBnts[ID_KLINE_INDEX1];
	rc_bnt6 = rc_text;
	rc_bnt6.right = rc_r.left + (rc_r.right - rc_r.left) / 2 - nmid;
	rc_bnt6.left = rc_bnt6.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt6, m_rgbSpaceLine[0]);


	rc_text.left = rc_r.left + (rc_r.right - rc_r.left) / 2 + nmid;
	rc_text.right = rc_r.right - nWidth;
	swprintf_s(tmp, L"%s2", G_LANG->LangText(TLI__KLINE_INDEX));
	DrawText(mdc, tmp, wcslen(tmp), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt7 = m_KLineBnts[ID_KLINE_INDEX2];
	rc_bnt7 = rc_text;
	rc_bnt7.right = rc_r.right;
	rc_bnt7.left = rc_bnt7.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt7, m_rgbSpaceLine[1]);

	rc_text.top = rc_text.bottom + 2 * nGap;
	rc_text.left = rc_r.left;
	rc_text.right = rc_r.left + (rc_r.right - rc_r.left) / 2 - nWidth - nmid;
	rc_text.bottom = rc_text.top + nItemHigh;
	swprintf_s(tmp, L"%s3", G_LANG->LangText(TLI__KLINE_INDEX));
	DrawText(mdc, tmp, wcslen(tmp), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt8 = m_KLineBnts[ID_KLINE_INDEX3];
	rc_bnt8 = rc_text;
	rc_bnt8.right = rc_r.left + (rc_r.right - rc_r.left) / 2 - nmid;
	rc_bnt8.left = rc_bnt8.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt8, m_rgbSpaceLine[2]);


	rc_text.left = rc_r.left + (rc_r.right - rc_r.left) / 2 + nmid;
	rc_text.right = rc_r.right - nWidth;
	swprintf_s(tmp, L"%s4", G_LANG->LangText(TLI__KLINE_INDEX));
	DrawText(mdc, tmp, wcslen(tmp), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt9 = m_KLineBnts[ID_KLINE_INDEX4];
	rc_bnt9 = rc_text;
	rc_bnt9.right = rc_r.right;
	rc_bnt9.left = rc_bnt9.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt9, m_rgbSpaceLine[3]);

	rc_text.top = rc_text.bottom + 2 * nGap;
	rc_text.left = rc_r.left;
	rc_text.right = rc_r.left + (rc_r.right - rc_r.left) / 2 - nWidth - nmid;
	rc_text.bottom = rc_text.top + nItemHigh;
	swprintf_s(tmp, L"%s5", G_LANG->LangText(TLI__KLINE_INDEX));
	DrawText(mdc, tmp, wcslen(tmp), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt10 = m_KLineBnts[ID_KLINE_INDEX5];
	rc_bnt10 = rc_text;
	rc_bnt10.right = rc_r.left + (rc_r.right - rc_r.left) / 2 - nmid;
	rc_bnt10.left = rc_bnt10.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt10, m_rgbSpaceLine[4]);


	rc_text.left = rc_r.left + (rc_r.right - rc_r.left) / 2 + nmid;
	rc_text.right = rc_r.right - nWidth;
	swprintf_s(tmp, L"%s6", G_LANG->LangText(TLI__KLINE_INDEX));
	DrawText(mdc, tmp, wcslen(tmp), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt11 = m_KLineBnts[ID_KLINE_INDEX6];
	rc_bnt11 = rc_text;
	rc_bnt11.right = rc_r.right;
	rc_bnt11.left = rc_bnt11.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt11, m_rgbSpaceLine[5]);

	rc_text.top = rc_text.bottom + 2 * nGap;
	rc_text.left = rc_r.left;
	rc_text.right = rc_r.left + (rc_r.right - rc_r.left) / 2 - nWidth - nmid;
	rc_text.bottom = rc_text.top + nItemHigh;
	DrawText(mdc, G_LANG->LangText(TLI_BUY_ORDER), wcslen(G_LANG->LangText(TLI_BUY_ORDER)), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt12 = m_KLineBnts[ID_ORDER_BUY];
	rc_bnt12 = rc_text;
	rc_bnt12.right = rc_r.left + (rc_r.right - rc_r.left) / 2 - nmid;
	rc_bnt12.left = rc_bnt12.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt12, m_rgbLineOrderBuy);

	rc_text.left = rc_r.left + (rc_r.right - rc_r.left) / 2 + nmid;
	rc_text.right = rc_r.right - nWidth;
	DrawText(mdc, G_LANG->LangText(TLI_SELL_ORDER), wcslen(G_LANG->LangText(TLI_SELL_ORDER)), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt13 = m_KLineBnts[ID_ORDER_SELL];
	rc_bnt13 = rc_text;
	rc_bnt13.right = rc_r.right;
	rc_bnt13.left = rc_bnt13.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt13, m_rgbLineOrderSell);

	rc_text.top = rc_text.bottom + 2 * nGap;
	rc_text.left = rc_r.left;
	rc_text.right = rc_r.left + (rc_r.right - rc_r.left) / 2 - nWidth - nmid;
	rc_text.bottom = rc_text.top + nItemHigh;
	DrawText(mdc, G_LANG->LangText(TLI_COVER_ORDER), wcslen(G_LANG->LangText(TLI_COVER_ORDER)), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt14 = m_KLineBnts[ID_ORDER_COVER];
	rc_bnt14 = rc_text;
	rc_bnt14.right = rc_r.left + (rc_r.right - rc_r.left) / 2 - nmid;
	rc_bnt14.left = rc_bnt14.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt14, m_rgbLineOrderCover);

	rc_text.left = rc_r.left + (rc_r.right - rc_r.left) / 2 + nmid;
	rc_text.right = rc_r.right - nWidth;
	DrawText(mdc, G_LANG->LangText(TLI_BACKHAND_ORDER), wcslen(G_LANG->LangText(TLI_BACKHAND_ORDER)), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt15 = m_KLineBnts[ID_ORDER_BACK];
	rc_bnt15 = rc_text;
	rc_bnt15.right = rc_r.right;
	rc_bnt15.left = rc_bnt15.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt15, m_rgbLineOrderBack);

	rc_text.top = rc_text.bottom + 2 * nGap;
	rc_text.left = rc_r.left;
	rc_text.right = rc_r.left + (rc_r.right - rc_r.left) / 2 - nWidth - nmid;
	rc_text.bottom = rc_text.top + nItemHigh;
	DrawText(mdc, G_LANG->LangText(TLI_STOP_LOSS), wcslen(G_LANG->LangText(TLI_STOP_LOSS)), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt16 = m_KLineBnts[ID_ORDER_LOSS];
	rc_bnt16 = rc_text;
	rc_bnt16.right = rc_r.left + (rc_r.right - rc_r.left) / 2 - nmid;
	rc_bnt16.left = rc_bnt16.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt16, m_rgbLineOrderLoss);

	rc_text.left = rc_r.left + (rc_r.right - rc_r.left) / 2 + nmid;
	rc_text.right = rc_r.right - nWidth;
	DrawText(mdc, G_LANG->LangText(TLI_STOP_PROFIT), wcslen(G_LANG->LangText(TLI_STOP_PROFIT)), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt17 = m_KLineBnts[ID_ORDER_PROFIT];
	rc_bnt17 = rc_text;
	rc_bnt17.right = rc_r.right;
	rc_bnt17.left = rc_bnt17.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt17, m_rgbLineOrderProfit);

	rc_text.top = rc_text.bottom + 2 * nGap;
	rc_text.left = rc_r.left;
	rc_text.right = rc_r.left + (rc_r.right - rc_r.left) / 2 - nWidth - nmid;
	rc_text.bottom = rc_text.top + nItemHigh;
	DrawText(mdc, G_LANG->LangText(TLI_BUY_POSITION), wcslen(G_LANG->LangText(TLI_BUY_POSITION)), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt18 = m_KLineBnts[ID_POSITION_BUY];
	rc_bnt18 = rc_text;
	rc_bnt18.right = rc_r.left + (rc_r.right - rc_r.left) / 2 - nmid;
	rc_bnt18.left = rc_bnt18.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt18, m_rgbLinePositionBuy);

	rc_text.left = rc_r.left + (rc_r.right - rc_r.left) / 2 + nmid;
	rc_text.right = rc_r.right - nWidth;
	DrawText(mdc, G_LANG->LangText(TLI_SELL_POSITION), wcslen(G_LANG->LangText(TLI_SELL_POSITION)), &rc_text, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

	RECT& rc_bnt19 = m_KLineBnts[ID_POSITION_SELL];
	rc_bnt19 = rc_text;
	rc_bnt19.right = rc_r.right;
	rc_bnt19.left = rc_bnt19.right - nWidth;
	DrawColorBnt(mdc, &rc_bnt19, m_rgbLinePositionSell);
}
//void QuoteSkinConfig::OnCheckBoxChanged(int nIndex)
//{
//	switch (nIndex)
//	{
//	case ID_CHECKBOX_CHANGE_TEXT:
//		m_bChangedTextHL = m_ChangeTextHL.GetCheck();
//		break;
//	case ID_CHECKBOX_CHANGE_BACKGROUND:
//		m_bChangedBkHL = m_ChangeBottemHL.GetCheck();
//		break;
//	case ID_CHECKBOX_BUYSELL_QUILITY:
//		m_bBSQtyHL = m_BuySellVolHL.GetCheck();
//		break;
//	}
//	InvalidateRect(m_Hwnd, 0, TRUE);
//}
void QuoteSkinConfig::OnNotify(WPARAM wParam, LPARAM lParam)
{
	switch (LOWORD(wParam))
	{
	case ID_SPIN_ROW_HIGHT:
		switch (((LPNMHDR)lParam)->code)
		{
		case UDN_DELTAPOS:
			OnSpinDeltaUpDownEx(-((LPNMUPDOWN)lParam)->iDelta);
		}
		break;
	}
}
void QuoteSkinConfig::OnMouseWheel(WPARAM wParam, LPARAM lParam)
{
	int nID = GetWindowLong(GetFocus(), GWL_ID);
	switch (nID)
	{
	case ID_EDIT_ROW_HIGHT:
		OnSpinDeltaUpDownEx(GET_WHEEL_DELTA_WPARAM(wParam));
		break;
	}
}
void QuoteSkinConfig::OnSpinDeltaUpDownEx(int n)
{
	if (n > 0&&m_nRowHigth<100)
	{
		m_nRowHigth++;

	}
	if (n < 0 && m_nRowHigth>19)
	{
		m_nRowHigth--;
	}
	wchar_t temp[21];
	swprintf_s(temp, L"%d", m_nRowHigth);
	m_EtRowHigh.SetWindowText(temp);
	InvalidateRect(m_Hwnd, 0, TRUE);
}
void QuoteSkinConfig::RefeshCtrlVisiable(bool bVisiable)
{
	ShowWindow(m_CmbItems.GetHwnd(), bVisiable);
	ShowWindow(m_BtBgColor.GetHwnd(), bVisiable);
	ShowWindow(m_BtTextColor.GetHwnd(), bVisiable);
	ShowWindow(m_EtRowHigh.GetHwnd(), bVisiable);
	ShowWindow(m_SpRowHigh.GetHwnd(), bVisiable);
}
void QuoteSkinConfig::OnStaticButtonClicked(WPARAM wParam, LPARAM lParam)
{
	int nSel = (int)lParam;
	switch (nSel)
	{
	case ID_BUTTON_BACKGROUND_COLOR:
		SetBackgroundColor();
		break;
	case ID_BUTTON_TEXT_COLOR:
		SetItemTextColor();
		break;
	case ID_BUTTON_APPLY:
		ApplySetting();
		break;
	case ID_BUTTON_CANCEL:
		CancelSetting();
		break;
	case ID_BUTTON_BLACK:
		SetBlackStyle();
		break;
	case ID_BUTTON_GRAY:
		SetGrayStyle();
		break;
	}
}
//nType    0 背景色 1 文字色
COLORREF QuoteSkinConfig::GetItemColor(int nType)
{
	COLORREF retcol=0;
	wchar_t* pTemp = m_CmbItems.GetText();
	if (wcsncmp(pTemp, G_LANG->LangText(TLI_ITEMSALL), sizeof(G_LANG->LangText(TLI_ITEMSALL))) == 0)
	{
		if(nType==0)
		  retcol = m_rgbBk;
		else if(nType == 1)
		  retcol = m_rgbGrideText;
	}
	else if (wcsncmp(pTemp, G_LANG->LangText(TLI_ITEMHEAD), sizeof(G_LANG->LangText(TLI_ITEMHEAD))) == 0)
	{
		if (nType == 0)
			retcol = m_rgbHeaderBk;
		else if (nType == 1)
			retcol = m_rgbHeaderText;
	}
	else if (wcsncmp(pTemp, G_LANG->LangText(TLI_ITEMBODY), sizeof(G_LANG->LangText(TLI_ITEMBODY))) == 0)
	{
		if (nType == 0)
			retcol = m_rgbGrideBk;
		else if (nType == 1)
			retcol = m_rgbGrideText;
	}
	else if (wcsncmp(pTemp, G_LANG->LangText(TLI_ITEMSELECTED), sizeof(G_LANG->LangText(TLI_ITEMSELECTED))) == 0)
	{
		if (nType == 0)
			retcol = m_rgbSelectedBk;
		else if (nType == 1)
			retcol = m_rgbSelectedText;
	}
	return retcol;
}
//nType    0 背景色 1 文字色
void QuoteSkinConfig::SetItemColor(int nType, COLORREF col)
{
	wchar_t* pTemp = m_CmbItems.GetText();
	if (wcsncmp(pTemp, G_LANG->LangText(TLI_ITEMSALL), sizeof(G_LANG->LangText(TLI_ITEMSALL))) == 0)
	{
		if (nType == 0)
		{
			m_rgbBk = col;
			m_rgbHeaderBk = col;
			m_rgbGrideBk = col;
			m_rgbSelectedBk = col;
			m_rgbPanelBK = col;
		}
		else if(nType == 1)
		{
			m_rgbHeaderText = col;
			m_rgbGrideText = col;
			m_rgbSelectedText = col;
			m_rgbPanelStr = col;
		}
	}
	else if (wcsncmp(pTemp, G_LANG->LangText(TLI_ITEMHEAD), sizeof(G_LANG->LangText(TLI_ITEMHEAD))) == 0)
	{
		if (nType == 0)
		    m_rgbHeaderBk = col;
		else if (nType == 1)
			m_rgbHeaderText = col;
	}
	else if (wcsncmp(pTemp, G_LANG->LangText(TLI_ITEMBODY), sizeof(G_LANG->LangText(TLI_ITEMBODY))) == 0)
	{
		if (nType == 0)
		    m_rgbGrideBk = col;
		else if (nType == 1)
			m_rgbGrideText = col;
	}
	else if (wcsncmp(pTemp, G_LANG->LangText(TLI_ITEMSELECTED), sizeof(G_LANG->LangText(TLI_ITEMSELECTED))) == 0)
	{
		if (nType == 0)
		    m_rgbSelectedBk = col;
		else if (nType == 1)
			m_rgbSelectedText = col;
	}
	else if (wcsncmp(pTemp, G_LANG->LangText(TLI_OPEN_PANEL), sizeof(G_LANG->LangText(TLI_OPEN_PANEL))) == 0)
	{
		if (nType == 0)
			m_rgbPanelBK = col;
		else if (nType == 1)
			m_rgbPanelStr = col;
	}
}
void QuoteSkinConfig::SetBackgroundColor()
{
	CHOOSECOLOR cc;
	cc.lStructSize = sizeof(CHOOSECOLOR);
	cc.Flags = CC_RGBINIT| CC_FULLOPEN | CC_ANYCOLOR;
	cc.hwndOwner = m_Hwnd;
	cc.rgbResult = GetItemColor(0);
	COLORREF crCustom[16] = { 0X00000000 };
	cc.lpCustColors = crCustom;

	if (ChooseColor(&cc))
	{
		SetItemColor(0,cc.rgbResult);
		InvalidateRect(m_Hwnd, 0, TRUE);
	}
}
void QuoteSkinConfig::SetItemTextColor()
{
	CHOOSECOLOR cc;
	cc.lStructSize = sizeof(CHOOSECOLOR);
	cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
	cc.hwndOwner = m_Hwnd;
	cc.rgbResult = GetItemColor(1);
	COLORREF crCustom[16] = { 0X00000000 };
	cc.lpCustColors = crCustom;

	if (ChooseColor(&cc))
	{
		SetItemColor(1,cc.rgbResult);
		InvalidateRect(m_Hwnd, 0, TRUE);
	}
}
void QuoteSkinConfig::OnLButtonDown(WPARAM wParam, LPARAM lParam)
{
	POINT pt;	
	pt.x = GET_X_LPARAM(lParam);
	pt.y = GET_Y_LPARAM(lParam);
	//处理tab
	for (int i = 0; i <= sizeof(m_tab) / sizeof(Tab_BNT); i++)
	{
		Tab_BNT& tab = m_tab[i];
		if (PtInRect(&tab.rc, pt))
		{
			if (i == 0)
			{
				tab.bChecked = true;
				m_bShowKLine = false;
				m_tab[1].bChecked = false;
			}
			else
			{
				tab.bChecked = true;
				m_bShowKLine = true;
				m_tab[0].bChecked = false;
			}
			RefeshCtrlVisiable(!m_bShowKLine);
			InvalidateRect(m_Hwnd, 0, TRUE);
			return;
		}
	}

	if (!m_bShowKLine)
	{
		OnQuoteGridClicked(pt);
	}
	else
	{
		OnKLINEClicked(pt);
	}
}
void QuoteSkinConfig::OnQuoteGridClicked(POINT pt)
{
	if (PtInRect(&m_Rects[COLOR_UP_RECT], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbUpText;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbUpText = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_Rects[COLOR_DOWN_RECT], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbDownText;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbDownText = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_Rects[COLOR_CHANGED_RECT], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbChangedText;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbChangedText = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_Rects[PANEL_PRICE_RECT], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbPanelPriceStr;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbPanelPriceStr = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_Rects[PANEL_TICK_RECT], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbPanelTickStr;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbPanelTickStr = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_Rects[OPTION_INMONEY_RECT], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbInmoneyBk;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbInmoneyBk = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_Rects[OPTION_OUTMONEY_RECT], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbOutmoneyBk;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbOutmoneyBk = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_Rects[PANEL_BID_RECT], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbPanelMutiBid;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbPanelMutiBid = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_Rects[PANEL_ASK_RECT], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbPanelMutiAsk;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbPanelMutiAsk = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
}
void QuoteSkinConfig::OnKLINEClicked(POINT pt)
{
	if (PtInRect(&m_KLineBnts[ID_KLINE_BACKGROUND], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbKLineBK;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbKLineBK = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_KLineBnts[ID_KLINE_TEXT], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbKLineStr;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbKLineStr = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_KLineBnts[ID_KLINE_UP], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbKLineUp;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbKLineUp = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_KLineBnts[ID_KLINE_DOWN], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbKLineDown;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbKLineDown = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_KLineBnts[ID_TLINE_PRICE], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbTLinePrice;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbTLinePrice = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_KLineBnts[ID_TLINE_AVERAGE], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbTLineAvg;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbTLineAvg = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_KLineBnts[ID_KLINE_INDEX1], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbSpaceLine[0];
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbSpaceLine[0] = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_KLineBnts[ID_KLINE_INDEX2], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbSpaceLine[1];
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbSpaceLine[1] = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_KLineBnts[ID_KLINE_INDEX3], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbSpaceLine[2];
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbSpaceLine[2] = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_KLineBnts[ID_KLINE_INDEX4], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbSpaceLine[3];
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbSpaceLine[3] = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_KLineBnts[ID_KLINE_INDEX5], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbSpaceLine[4];
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbSpaceLine[4] = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_KLineBnts[ID_KLINE_INDEX6], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbSpaceLine[5];
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbSpaceLine[5] = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_KLineBnts[ID_ORDER_BUY], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbLineOrderBuy;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbLineOrderBuy = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_KLineBnts[ID_ORDER_SELL], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbLineOrderSell;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbLineOrderSell = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_KLineBnts[ID_ORDER_COVER], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbLineOrderCover;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbLineOrderCover = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_KLineBnts[ID_ORDER_BACK], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbLineOrderBack;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbLineOrderBack = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_KLineBnts[ID_ORDER_LOSS], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbLineOrderLoss;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbLineOrderLoss = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_KLineBnts[ID_ORDER_PROFIT], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbLineOrderProfit;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbLineOrderProfit = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_KLineBnts[ID_POSITION_BUY], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbLinePositionBuy;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbLinePositionBuy = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
	else if (PtInRect(&m_KLineBnts[ID_POSITION_SELL], pt))
	{
		CHOOSECOLOR cc;
		cc.lStructSize = sizeof(CHOOSECOLOR);
		cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR;
		cc.hwndOwner = m_Hwnd;
		cc.rgbResult = m_rgbLinePositionSell;
		COLORREF crCustom[16] = { 0X00000000 };
		cc.lpCustColors = crCustom;

		if (ChooseColor(&cc))
		{
			m_rgbLinePositionSell = cc.rgbResult;
			InvalidateRect(m_Hwnd, 0, TRUE);
		}
	}
}
void QuoteSkinConfig::ApplySetting()
{
	//先改变颜色
	COLOR_FUTURE_BACKGROUND = m_rgbBk;
	COLOR_FUTURE_HEAD_BACKGROUND = m_rgbHeaderBk;
	COLOR_FUTURE_ROW_BACKGROUND = m_rgbGrideBk;
	COLOR_FUTURE_SEL_BACKGROUND = m_rgbSelectedBk;
	COLOR_FUTURE_TITLE = m_rgbHeaderText;
	COLOR_FUTURE_STR = m_rgbGrideText;
	COLOR_FUTURE_SEL_TEXT = m_rgbSelectedText;
	COLOR_FUTURE_UP = m_rgbUpText;
	COLOR_FUTURE_DOWN = m_rgbDownText;
	COLOR_FUTURE_CHANGED = m_rgbChangedText;
	COLOR_FUTURE_EQUAL = m_rgbEqueText;
	COLOR_FUTURE_SEL = m_rgbSelRow;
	COLOR_PANEL_BACKGROUND = m_rgbPanelBK;
	COLOR_PANEL_STR = m_rgbPanelStr;
	COLOR_PANEL_PRICE_TEXT = m_rgbPanelPriceStr;
	COLOR_PANEL_TICK_TEXT  = m_rgbPanelTickStr;
	COLOR_INMONEY_BACKGROUND = m_rgbInmoneyBk;
	COLOR_OUTMONEY_BACKGROUND = m_rgbOutmoneyBk;
	COLOR_PLATE_BACKGROUND = m_rgbPlateBK;
	COLOR_SCROLL_FOREGROUND = COLOR_PLATE_BACKGROUND;
	COLOR_PLATE_FONT = m_rgbPlateFont;
	COLOR_PLATE_FONT2 = m_rgbPlateFont2;
	COLOR_PLATE_FONT_HOT = m_rgbPlateFontHot;
	COLOR_PLATE_FONT_HOT2 = m_rgbPlateFontHot2;
	COLOR_KLINE_BACKGROUND = m_rgbKLineBK;
	COLOR_KLINE_RED_BAR = m_rgbKLineUp;
	COLOR_KLINE_GREEN_BAR = m_rgbKLineDown;
	COLOR_KLINE_WHITE_BAR = m_rgbKLineEque;
	COLOR_KLINE_MENU_TEXT = m_rgbKLineStr;
	COLOR_TLINE_PRICE = m_rgbTLinePrice;
	COLOR_TLINE_AVG_PRICE = m_rgbTLineAvg;
	COLOR_LINE_ORDER_BUY = m_rgbLineOrderBuy;
	COLOR_LINE_ORDER_SELL = m_rgbLineOrderSell;
	COLOR_LINE_ORDER_COVER = m_rgbLineOrderCover;
	COLOR_LINE_ORDER_BACK = m_rgbLineOrderBack;
	COLOR_LINE_ORDER_LOSS = m_rgbLineOrderLoss;
	COLOR_LINE_ORDER_PROFIT = m_rgbLineOrderProfit;
	COLOR_LINE_POSITION_BUY = m_rgbLinePositionBuy;
	COLOR_LINE_POSITION_SELL = m_rgbLinePositionSell;
	COLOR_CONFIGWINDOW_BACKGROUND = m_rgbConfigBK;
	COLOR_PANEL_MULTI_BID = m_rgbPanelMutiBid;
	COLOR_PANEL_MULTI_ASK = m_rgbPanelMutiAsk;
	COLOR_KLINE_CROSS = m_rgbKLineCross;
	G_STYLE = m_Style;
	for (int i = 0; i < TargetLineNum; i++)
	{
		COLOR_SPEC_LINE[i] = m_rgbSpaceLine[i];
	}
	//改变画刷
	DeleteObject(BRUSH_FUTURE_BACKGROUND);
	DeleteObject(BRUSH_FUTURE_HEAD_BACKGROUND);
	DeleteObject(BRUSH_FUTURE_ROW_BACKGROUND);
	DeleteObject(BRUSH_FUTURE_SEL_BACKGROUND);
	DeleteObject(BRUSH_FUTURE_SEL);
	DeleteObject(BRUSH_PANEL_BACKGROUND);
	DeleteObject(BRUSH_INMONEY_BACKGROUND);
	DeleteObject(BRUSH_OUTMONEY_BACKGROUND);
	DeleteObject(PEN_OPTION_STRIKE_LINE);
	DeleteObject(BRUSH_PLATE_BACKGROUND);
	DeleteObject(BRUSH_SCROLL_FOREGROUND);
	DeleteObject(BRUSH_KLINE_BACKGROUND);
	DeleteObject(BRUSH_KLINE_RED_BAR);
	DeleteObject(BRUSH_KLINE_GREEN_BAR);
	DeleteObject(PEN_KLINE_RED_BAR);
	DeleteObject(PEN_KLINE_GREEN_BAR);
	DeleteObject(PEN_KLINE_WHITE_BAR);
	DeleteObject(PEN_KLINE_RED_BAR_DOT);
	DeleteObject(PEN_KLINE_GREEN_BAR_DOT);
	DeleteObject(PEN_KLINE_CYCLE);
	DeleteObject(PEN_TLINE_PRICE);
	DeleteObject(PEN_TLINE_AVG_PRICE);
	DeleteObject(PEN_LINE_ORDER_BUY);
	DeleteObject(PEN_LINE_ORDER_SELL);
	DeleteObject(PEN_LINE_ORDER_COVER);
	DeleteObject(PEN_LINE_ORDER_BACK);
	DeleteObject(PEN_LINE_ORDER_LOSS);
	DeleteObject(PEN_LINE_ORDER_PROFIT);
	DeleteObject(PEN_LINE_POSITION_BUY);
	DeleteObject(PEN_LINE_POSITION_SELL);
	DeleteObject(BRUSH_CONFIGWINDOW_BACKGROUND);
	DeleteObject(BRUSH_KLINE_CROSS);
	for (int i = 0; i < TargetLineNum; i++)
	{
		DeleteObject(PEN_SPEC_LINE[i]);
	}
	BRUSH_FUTURE_BACKGROUND = CreateSolidBrush(COLOR_FUTURE_BACKGROUND);
	BRUSH_FUTURE_HEAD_BACKGROUND = CreateSolidBrush(COLOR_FUTURE_HEAD_BACKGROUND);
	BRUSH_FUTURE_ROW_BACKGROUND = CreateSolidBrush(COLOR_FUTURE_ROW_BACKGROUND);
	BRUSH_FUTURE_SEL_BACKGROUND = CreateSolidBrush(COLOR_FUTURE_SEL_BACKGROUND);
	BRUSH_FUTURE_SEL = CreateSolidBrush(COLOR_FUTURE_SEL);
	BRUSH_PANEL_BACKGROUND = CreateSolidBrush(COLOR_PANEL_BACKGROUND);
	BRUSH_INMONEY_BACKGROUND = CreateSolidBrush(COLOR_INMONEY_BACKGROUND);
	BRUSH_OUTMONEY_BACKGROUND = CreateSolidBrush(COLOR_OUTMONEY_BACKGROUND);
	PEN_OPTION_STRIKE_LINE = CreatePen(PS_SOLID, 1, COLOR_FUTURE_STR);
	BRUSH_PLATE_BACKGROUND = CreateSolidBrush(COLOR_PLATE_BACKGROUND);
	BRUSH_SCROLL_FOREGROUND = CreateSolidBrush(COLOR_SCROLL_FOREGROUND);
	BRUSH_KLINE_BACKGROUND = CreateSolidBrush(COLOR_KLINE_BACKGROUND);
	BRUSH_KLINE_RED_BAR = CreateSolidBrush(COLOR_KLINE_RED_BAR);
	BRUSH_KLINE_GREEN_BAR = CreateSolidBrush(COLOR_KLINE_GREEN_BAR);
	PEN_KLINE_RED_BAR = CreatePen(PS_SOLID, 1, COLOR_KLINE_RED_BAR);
	PEN_KLINE_GREEN_BAR = CreatePen(PS_SOLID, 1, COLOR_KLINE_GREEN_BAR);
	PEN_KLINE_WHITE_BAR = CreatePen(PS_SOLID, 1, COLOR_KLINE_WHITE_BAR);
	PEN_KLINE_RED_BAR_DOT = CreatePen(PS_DOT, 1, COLOR_KLINE_RED_BAR);
	PEN_KLINE_GREEN_BAR_DOT = CreatePen(PS_DOT, 1, COLOR_KLINE_GREEN_BAR);
	PEN_KLINE_CYCLE = CreatePen(PS_SOLID, 1, COLOR_KLINE_MENU_TEXT);
	PEN_TLINE_PRICE = CreatePen(PS_SOLID, 1, COLOR_TLINE_PRICE);
	PEN_TLINE_AVG_PRICE = CreatePen(PS_SOLID, 1, COLOR_TLINE_AVG_PRICE);
	PEN_LINE_ORDER_BUY = CreatePen(PS_DOT, 1, COLOR_LINE_ORDER_BUY);
	PEN_LINE_ORDER_SELL = CreatePen(PS_DOT, 1, COLOR_LINE_ORDER_SELL);
	PEN_LINE_ORDER_COVER = CreatePen(PS_DOT, 1, COLOR_LINE_ORDER_COVER);
	PEN_LINE_ORDER_BACK = CreatePen(PS_DOT, 1, COLOR_LINE_ORDER_BACK);
	PEN_LINE_ORDER_LOSS = CreatePen(PS_DOT, 1, COLOR_LINE_ORDER_LOSS);
	PEN_LINE_ORDER_PROFIT = CreatePen(PS_DOT, 1, COLOR_LINE_ORDER_PROFIT);
	PEN_LINE_POSITION_BUY = CreatePen(PS_DOT, 1, COLOR_LINE_POSITION_BUY);
	PEN_LINE_POSITION_SELL = CreatePen(PS_DOT, 1, COLOR_LINE_POSITION_SELL);
	BRUSH_CONFIGWINDOW_BACKGROUND = CreateSolidBrush(COLOR_CONFIGWINDOW_BACKGROUND);
	BRUSH_KLINE_CROSS = CreateSolidBrush(COLOR_KLINE_CROSS);
	for (int i = 0; i < TargetLineNum; i++)
	{
		PEN_SPEC_LINE[i] = CreatePen(PS_SOLID, 1, COLOR_SPEC_LINE[i]);
	}
	TGridControl::ROW_HEIGHT = m_nRowHigth;
	for (auto it = m_vpQuoteFrame.begin(); it != m_vpQuoteFrame.end(); it++)
	{
		TQuoteFrame* pFrame = *it;
		if (pFrame)
		{
			pFrame->ApplyColorSetting();
		}
	}
	SetSkinStyle(m_Style);
}
void QuoteSkinConfig::CancelSetting()
{
	InitData();
	InvalidateRect(m_Hwnd, 0, TRUE);
}
void QuoteSkinConfig::SetBlackStyle()
{
	m_rgbBk = BLACK_COLOR_BACKG_ROUND;
	m_rgbHeaderBk = BLACK_COLOR_BACKG_ROUND;
	m_rgbGrideBk = BLACK_COLOR_BACKG_ROUND;
	m_rgbSelectedBk = BLACK_COLOR_BACKG_ROUND;
	m_rgbHeaderText = BLACK_COLOR_HEADER_TEXT;
	m_rgbGrideText = BLACK_COLOR_FUTURE_STR;
	m_rgbSelectedText = BLACK_COLOR_FUTURE_SEL_TEXT;
	m_rgbUpText = BLACK_COLOR_FUTURE_UP;
	m_rgbDownText = BLACK_COLOR_FUTURE_DOWN;
	m_rgbChangedText = BLACK_COLOR_FUTURE_CHANGED;
	m_rgbEqueText = BLACK_COLOR_FUTURE_EQUAL;
	m_rgbSelRow = BLACK_COLOR_FUTURE_SEL;
	m_rgbPanelBK = BLACK_COLOR_PANEL_BACKGROUND;
	m_rgbPanelStr = BLACK_COLOR_PANEL_STR;
	m_rgbPanelPriceStr = BLACK_COLOR_PANEL_PRICE_TEXT;
	m_rgbPanelTickStr = BLACK_COLOR_PANEL_TICK_TEXT;
	m_rgbInmoneyBk = BLACK_COLOR_INMONEY_BACKGROUND;
	m_rgbOutmoneyBk = BLACK_COLOR_OUTMONEY_BACKGROUND;
	m_rgbPlateBK = BLACK_COLOR_PLATE_BACKGROUND;
	m_rgbPlateFont = BLACK_COLOR_PLATE_FONT;
	m_rgbPlateFont2 = BLACK_COLOR_PLATE_FONT2;
	m_rgbPlateFontHot = BLACK_COLOR_PLATE_FONT_HOT;
	m_rgbPlateFontHot2 = BLACK_COLOR_PLATE_FONT_HOT2;
	m_rgbKLineBK = BLACK_COLOR_BACKGROUND;
	m_rgbKLineUp = BLACK_COLOR_KLINE_RED_BAR;
	m_rgbKLineDown = BLACK_COLOR_KLINE_GREEN_BAR;
	m_rgbKLineEque = BLACK_COLOR_KLINE_WHITE_BAR;
	m_rgbKLineStr = BLACK_COLOR_KLINE_MENU_TEXT;
	m_rgbTLinePrice = BLACK_COLOR_TLINE_PRICE;
	m_rgbTLineAvg = BLACK_COLOR_TLINE_AVG_PRICE;
	m_rgbLineOrderBuy = BLACK_COLOR_LINE_ORDER_BUY;
	m_rgbLineOrderSell = BLACK_COLOR_LINE_ORDER_SELL;
	m_rgbLineOrderCover = BLACK_COLOR_LINE_ORDER_COVER;
	m_rgbLineOrderBack = BLACK_COLOR_LINE_ORDER_BACK;
	m_rgbLineOrderLoss = BLACK_COLOR_LINE_ORDER_LOSS;
	m_rgbLineOrderProfit = BLACK_COLOR_LINE_ORDER_PROFIT;
	m_rgbLinePositionBuy = BLACK_COLOR_LINE_POSITION_BUY;
	m_rgbLinePositionSell = BLACK_COLOR_LINE_POSITION_SELL;
	m_rgbPanelMutiBid = BLACK_COLOR_PANEL_MULTI_BID;
	m_rgbPanelMutiAsk = BLACK_COLOR_PANEL_MULTI_ASK;
	m_rgbKLineCross = BLACK_COLOR_KLINE_CROSS;
	for (int i = 0; i < TargetLineNum; i++)
	{
		m_rgbSpaceLine[i] = BLACK_COLOR_SPEC_LINE[i];
	}
	/*m_bChangedBkHL = false;
	m_bChangedTextHL = true;
	m_bBSQtyHL = true;*/
	m_nRowHigth = 28;
	m_Style = BLACK_STYLE;
	m_rgbConfigBK= BLACK_COLOR_CONFIGWINDOW_BACKGROUND;
	m_BtBlack.EnableButton(false);
	m_BtGray.EnableButton(true);
	InvalidateRect(m_Hwnd,0,false);
}
void QuoteSkinConfig::SetGrayStyle()
{
	m_rgbBk = GRAY_COLOR_BACKG_ROUND;
	m_rgbHeaderBk = GRAY_COLOR_BACKG_ROUND;
	m_rgbGrideBk = GRAY_COLOR_BACKG_ROUND;
	m_rgbSelectedBk = GRAY_COLOR_BACKG_ROUND;
	m_rgbHeaderText = GRAY_COLOR_HEADER_TEXT;
	m_rgbGrideText = GRAY_COLOR_FUTURE_STR;
	m_rgbSelectedText = GRAY_COLOR_FUTURE_SEL_TEXT;
	m_rgbUpText = GRAY_COLOR_FUTURE_UP;
	m_rgbDownText = GRAY_COLOR_FUTURE_DOWN;
	m_rgbChangedText = GRAY_COLOR_FUTURE_CHANGED;
	m_rgbEqueText = GRAY_COLOR_FUTURE_EQUAL;
	m_rgbSelRow = GRAY_COLOR_FUTURE_SEL;
	m_rgbPanelBK = GRAY_COLOR_PANEL_BACKGROUND;
	m_rgbPanelStr = GRAY_COLOR_PANEL_STR;
	m_rgbPanelPriceStr = GRAY_COLOR_PANEL_PRICE_TEXT;
	m_rgbPanelTickStr = GRAY_COLOR_PANEL_TICK_TEXT;
	m_rgbInmoneyBk = GRAY_COLOR_INMONEY_BACKGROUND;
	m_rgbOutmoneyBk = GRAY_COLOR_OUTMONEY_BACKGROUND;
	m_rgbPlateBK = GRAY_COLOR_PLATE_BACKGROUND;
	m_rgbPlateFont = GRAY_COLOR_PLATE_FONT;
	m_rgbPlateFont2 = GRAY_COLOR_PLATE_FONT2;
	m_rgbPlateFontHot = GRAY_COLOR_PLATE_FONT_HOT;
	m_rgbPlateFontHot2 = GRAY_COLOR_PLATE_FONT_HOT2;
	m_rgbKLineBK = GRAY_COLOR_BACKGROUND;
	m_rgbKLineUp = GRAY_COLOR_KLINE_RED_BAR;
	m_rgbKLineDown = GRAY_COLOR_KLINE_GREEN_BAR;
	m_rgbKLineEque = GRAY_COLOR_KLINE_WHITE_BAR;
	m_rgbTLinePrice = GRAY_COLOR_TLINE_PRICE;
	m_rgbTLineAvg = GRAY_COLOR_TLINE_AVG_PRICE;
	m_rgbKLineStr = GRAY_COLOR_KLINE_MENU_TEXT;
	m_rgbLineOrderBuy = GRAY_COLOR_LINE_ORDER_BUY;
	m_rgbLineOrderSell = GRAY_COLOR_LINE_ORDER_SELL;
	m_rgbLineOrderCover = GRAY_COLOR_LINE_ORDER_COVER;
	m_rgbLineOrderBack = GRAY_COLOR_LINE_ORDER_BACK;
	m_rgbLineOrderLoss = GRAY_COLOR_LINE_ORDER_LOSS;
	m_rgbLineOrderProfit = GRAY_COLOR_LINE_ORDER_PROFIT;
	m_rgbLinePositionBuy = GRAY_COLOR_LINE_POSITION_BUY;
	m_rgbLinePositionSell = GRAY_COLOR_LINE_POSITION_SELL;
	m_rgbPanelMutiBid = GRAY_COLOR_PANEL_MULTI_BID;
	m_rgbPanelMutiAsk = GRAY_COLOR_PANEL_MULTI_ASK;
	m_rgbKLineCross = GRAY_COLOR_KLINE_CROSS;
	for (int i = 0; i < TargetLineNum; i++)
	{
		m_rgbSpaceLine[i] = GRAY_COLOR_SPEC_LINE[i];
	}
	/*m_bChangedBkHL = false;
	m_bChangedTextHL = true;
	m_bBSQtyHL = true;*/
	m_nRowHigth = 28;
	m_Style = GRAY_STYLE;
	m_rgbConfigBK = GRAY_COLOR_CONFIGWINDOW_BACKGROUND;
	m_BtGray.EnableButton(false);
	m_BtBlack.EnableButton(true);
	InvalidateRect(m_Hwnd, 0, false);
}
bool QuoteSkinConfig::LoadCfg()
{
	wchar_t currpath[1024];
	CurrPath(currpath, sizeof(currpath) / sizeof(wchar_t));

	wchar_t filename[1024];
	wsprintf(filename, L"%s\\config\\PolestarQuote\\PolestarQuote.QuoteSkinConfig.pri", currpath);
	std::ifstream icin;
	icin.open(filename);
	if (!icin.good())
		return false;
	icin >> m_rgbBk;
	icin >> m_rgbHeaderBk;
	icin >> m_rgbGrideBk;
	icin >> m_rgbSelectedBk;
	icin >> m_rgbHeaderText;
	icin >> m_rgbGrideText;
	icin >> m_rgbSelectedText;
	icin >> m_rgbUpText;
	icin >> m_rgbDownText;
	icin >> m_rgbChangedText;
	icin >> m_rgbEqueText;
	icin >> m_rgbSelRow;
	icin >> m_rgbPanelBK;
	icin >> m_rgbPanelStr;
	icin >> m_rgbPanelPriceStr;
	icin >> m_rgbPanelTickStr;
	icin >> m_rgbInmoneyBk;
	icin >> m_rgbOutmoneyBk;
	icin >> m_rgbPlateBK;
	icin >> m_rgbPlateFont;
	icin >> m_rgbPlateFont2;
	icin >> m_rgbPlateFontHot;
	icin >> m_rgbPlateFontHot2;
	icin >> m_rgbKLineBK;
	icin >> m_rgbKLineUp;
	icin >> m_rgbKLineDown;
	icin >> m_rgbKLineEque;
	icin >> m_rgbTLinePrice;
	icin >> m_rgbTLineAvg;
	icin >> m_rgbKLineStr;
	int nSize = 0;
	icin >> nSize;
	for (int i = 0; i < nSize; i++)
	{
		icin >> m_rgbSpaceLine[i];
	}
	icin >> m_bChangedBkHL;
	icin >> m_bChangedTextHL;
	icin >> m_bBSQtyHL;
	icin >> m_nRowHigth;
	int nStyle = 0;
	icin >> nStyle;
	m_Style = (SKIN_STYLE)nStyle;
	icin >> m_rgbLineOrderBuy;
	icin >> m_rgbConfigBK;
	icin >> m_rgbPanelMutiBid;
	icin >> m_rgbPanelMutiAsk;
	icin >> m_rgbKLineCross;
	icin >> m_rgbLineOrderSell;
	icin >> m_rgbLineOrderCover;
	icin >> m_rgbLineOrderBack;
	icin >> m_rgbLineOrderLoss;
	icin >> m_rgbLineOrderProfit;
	icin >> m_rgbLinePositionBuy;
	icin >> m_rgbLinePositionSell;
	icin.close();
	return true;
}
bool QuoteSkinConfig::SaveCfg()
{
	wchar_t currpath[1024];
	CurrPath(currpath, sizeof(currpath) / sizeof(wchar_t));

	wchar_t filename[1024];
	wsprintf(filename, L"%s\\config\\PolestarQuote\\PolestarQuote.QuoteSkinConfig.pri", currpath);
	std::ofstream ocout;
	ocout.open(filename);
	if (!ocout.good())
		return false;
	ocout << m_rgbBk;
	ocout << " ";
	ocout << m_rgbHeaderBk;
	ocout << " ";
	ocout << m_rgbGrideBk;
	ocout << " ";
	ocout << m_rgbSelectedBk;
	ocout << " ";
	ocout << m_rgbHeaderText;
	ocout << " ";
	ocout << m_rgbGrideText;
	ocout << " ";
	ocout << m_rgbSelectedText;
	ocout << " ";
	ocout << m_rgbUpText;
	ocout << " ";
	ocout << m_rgbDownText;
	ocout << " ";
	ocout << m_rgbChangedText;
	ocout << " ";
	ocout << m_rgbEqueText;
	ocout << " ";
	ocout << m_rgbSelRow;
	ocout << " ";
	ocout << m_rgbPanelBK;
	ocout << " ";
	ocout << m_rgbPanelStr;
	ocout << " ";
	ocout << m_rgbPanelPriceStr;
	ocout << " ";
	ocout << m_rgbPanelTickStr;
	ocout << " ";
	ocout << m_rgbInmoneyBk;
	ocout << " ";
	ocout << m_rgbOutmoneyBk;
	ocout << " ";
	ocout << m_rgbPlateBK;
	ocout << " ";
	ocout << m_rgbPlateFont;
	ocout << " ";
	ocout << m_rgbPlateFont2;
	ocout << " ";
	ocout << m_rgbPlateFontHot;
	ocout << " ";
	ocout << m_rgbPlateFontHot2;
	ocout << " ";
	ocout << m_rgbKLineBK;
	ocout << " ";
	ocout << m_rgbKLineUp;
	ocout << " ";
	ocout << m_rgbKLineDown;
	ocout << " ";
	ocout << m_rgbKLineEque;
	ocout << " ";
	ocout << m_rgbTLinePrice;
	ocout << " ";
	ocout << m_rgbTLineAvg;
	ocout << " ";
	ocout << m_rgbKLineStr;
	ocout << " ";
	ocout << TargetLineNum;
	for (int i = 0; i < TargetLineNum; i++)
	{
		ocout << " ";
		ocout << m_rgbSpaceLine[i];
	}
	ocout << " ";
	ocout << m_bChangedBkHL;
	ocout << " ";
	ocout << m_bChangedTextHL;
	ocout << " ";
	ocout << m_bBSQtyHL;
	ocout << " ";
	ocout << m_nRowHigth;
	ocout << " ";
	ocout << m_Style;
	ocout << " ";
	ocout << m_rgbLineOrderBuy;
	ocout << " ";
	ocout << m_rgbConfigBK;
	ocout << " ";
	ocout << m_rgbPanelMutiBid;
	ocout << " ";
	ocout << m_rgbPanelMutiAsk;
	ocout << " ";
	ocout << m_rgbKLineCross;
	ocout << " ";
	ocout << m_rgbLineOrderSell;
	ocout << " ";
	ocout << m_rgbLineOrderCover;
	ocout << " ";
	ocout << m_rgbLineOrderBack;
	ocout << " ";
	ocout << m_rgbLineOrderLoss;
	ocout << " ";
	ocout << m_rgbLineOrderProfit;
	ocout << " ";
	ocout << m_rgbLinePositionBuy;
	ocout << " ";
	ocout << m_rgbLinePositionSell;
	ocout.close();
	return true;
}
#include "PreInclude.h"
#pragma comment(lib, "MSIMG32.LIB")

TStaticButton::TStaticButton(int nstyle/* = BTN_ROUND*/)
{
	m_btnclick = false;
	m_bmouseover = false;
	m_bmousetrack = false;
	m_benable = true;
	m_clrbk = RGB(255,255,255);
	m_clrover = RGB(183, 44, 25);
	m_font = FONT_CONTRL_QUOTE;
	m_sztext = L"ȷ��";
	m_gradient = NULL;
	_GradientFill = NULL;
	m_bfocus = false;
	m_nstyle = nstyle;
}

TStaticButton::~TStaticButton()
{
	if (m_gradient)
		::FreeLibrary(m_gradient);
	m_gradient = NULL;
}

bool TStaticButton::Create(HWND hparent, int nindex /* = 0 */)
{
	m_nindex = nindex;
	CreateFrm(_T("TStaticButton"), hparent, WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN);
	return true;
}

void TStaticButton::MoveWindow(const int& x, const int& y, const int& cx, const int& cy)
{
	SetWindowPos(m_Hwnd, 0, x, y, cx, cy, SWP_NOZORDER);
	InvalidateRect(m_Hwnd, 0, true);
}

void TStaticButton::EnableButton(bool benable /*= true*/)
{
	m_benable = benable;
	InvalidateRect(m_Hwnd, 0, false);
	EnableWindow(m_Hwnd, m_benable);
	if (m_benable) SetFocus(m_Hwnd);
}

//property
void TStaticButton::SetButtonText(const wchar_t* ptext)
{
	m_sztext = ptext;
	InvalidateRect(m_Hwnd, 0, false);
}

void TStaticButton::SetBkColor(COLORREF clrbk)
{
	m_clrbk = clrbk;
	InvalidateRect(m_Hwnd, 0, false);
}

void TStaticButton::SetFont(HFONT hfont)
{
	m_font = hfont;
	InvalidateRect(m_Hwnd, 0, false);
}
//MSG

void TStaticButton::OnPaint()
{
	TMemDC memdc(m_Hwnd);

	RECT	 rect;
	GetClientRect(m_Hwnd, &rect);
	SetBkMode(memdc.GetHdc(), TRANSPARENT);

	if (m_nstyle == BTN_NORMAL) DrawNormal(&memdc, rect);
	else DrawRound(&memdc, rect);
}

void TStaticButton::DrawBtnBk(TMemDC* pmemdc, const RECT& rect)
{
	int nMove = 8;
	COLORREF clrtop, clrbottom;
	clrtop = RGB(240,244,252);
	clrbottom = RGB(219, 236, 252);
	TRIVERTEX tvert[2];
	tvert[0].x = rect.left;
	tvert[0].y = rect.top;
	tvert[0].Red = GetRValue(clrtop) << nMove;
	tvert[0].Green = GetGValue(clrtop) << nMove;
	tvert[0].Blue = GetBValue(clrtop) << nMove;
	tvert[0].Alpha = 255;


	tvert[1].x = rect.right;
	tvert[1].y = rect.bottom;
	tvert[1].Red = GetRValue(clrbottom) << nMove;
	tvert[1].Green = GetGValue(clrbottom) << nMove;
	tvert[1].Blue = GetBValue(clrbottom) << nMove;
	tvert[1].Alpha = 255;

	GRADIENT_RECT grect;
	grect.UpperLeft = 0;
	grect.LowerRight = 1;
	if (_GradientFill)_GradientFill(pmemdc->GetHdc(), tvert,2/* sizeof(tvert) / sizeof(TRIVERTEX)*/, &grect, 1, GRADIENT_FILL_RECT_V);
}

void TStaticButton::DrawNormal(TMemDC* pmdc, RECT rect)
{
	HBRUSH hbr;
	hbr = CreateSolidBrush(m_clrbk);
	FillRect(pmdc->GetHdc(), &rect, hbr);
	FrameRect(pmdc->GetHdc(), &rect, BRUSH_IMAGE_GRAY);
	DeleteObject(hbr);
	if (m_bmouseover)
	{
		hbr = CreateSolidBrush(RGB(240, 244, 252));
		FillRect(pmdc->GetHdc(), &rect, hbr);
		DeleteObject(hbr);
		hbr = CreateSolidBrush(RGB(126, 180, 234));
		FrameRect(pmdc->GetHdc(), &rect, hbr);
		DeleteObject(hbr);
	}

	if (!m_benable)
	{
		hbr = CreateSolidBrush(RGB(170, 175, 186));
		FillRect(pmdc->GetHdc(), &rect, BRUSH_IMAGE_GRAY);
		DeleteObject(hbr);
		SetTextColor(pmdc->GetHdc(), RGB(255, 255, 255));
	}

	if (m_benable&&m_bfocus)
	{
		InflateRect(&rect, -3, -3);
		pmdc->DotRectangle(rect, RGB(243, 243, 243), 1);
		InflateRect(&rect, 3, 3);
	}

	SIZE sizetext;
	SelectObject(pmdc->GetHdc(), m_font);
	GetTextExtentPoint32(pmdc->GetHdc(), m_sztext.c_str(), m_sztext.length(), &sizetext);
	rect.top += (rect.bottom - rect.top - sizetext.cy) / 2;
	DrawText(pmdc->GetHdc(), m_sztext.c_str(), m_sztext.length(), &rect, DT_CENTER);
}
void TStaticButton::DrawRound(TMemDC* pmdc, RECT rect)
{
	HBRUSH hbr;
	HPEN holdpen;
	if (m_bmouseover&&m_benable) hbr = CreateSolidBrush(RGB(241, 74, 43));
	else if (!m_benable) hbr = CreateSolidBrush(m_clrover);
	else hbr = CreateSolidBrush(m_clrbk);
	SelectObject(pmdc->GetHdc(), hbr);
	holdpen = (HPEN)SelectObject(pmdc->GetHdc(), GetStockObject(NULL_PEN));
	FillRect(pmdc->GetHdc(), &rect, hbr);
	RoundRect(pmdc->GetHdc(), rect.left, rect.top, rect.right, rect.bottom, 2, 2);

	SetTextColor(pmdc->GetHdc(), RGB(255, 255, 255));
	SelectObject(pmdc->GetHdc(), FONT_CONTRL_QUOTE);
	DrawText(pmdc->GetHdc(), m_sztext.c_str(), m_sztext.length(), &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	DeleteObject(hbr);
	SelectObject(pmdc->GetHdc(), holdpen);
}
void TStaticButton::OnLButtonDown()
{
	if (m_benable)
	{
		m_btnclick = true;
		SetFocus(m_Hwnd);
		InvalidateRect(m_Hwnd, 0, false);
	}
}

void TStaticButton::OnLButtonUp()
{
	if (m_benable&&m_btnclick)
	{
		m_btnclick = false;
		InvalidateRect(m_Hwnd, 0, false);
		SendMessage(GetParent(), SSWM_STATIC_BUTTON_CLICKDOWN, 0, m_nindex);
	}
	m_btnclick = false;
}

void TStaticButton::OnMouseMove(WPARAM wParam, LPARAM lParam)
{
	m_bmouseover = true;
	if (!m_bmousetrack)
	{
		TRACKMOUSEEVENT tme;
		tme.cbSize = sizeof(tme);
		tme.dwFlags = TME_LEAVE;
		tme.hwndTrack = m_Hwnd;
		tme.dwHoverTime = 0;
		::TrackMouseEvent(&tme);
	}
	InvalidateRect(m_Hwnd, 0, false);
}

void TStaticButton::OnMouseLeave(WPARAM wParam, LPARAM lParam)
{
	m_bmousetrack = false;
	m_bmouseover = false;
	m_btnclick = false;
	InvalidateRect(m_Hwnd, 0, false);
}

void TStaticButton::OnSetFocus()
{
	m_bfocus = true;
	InvalidateRect(m_Hwnd, 0, false);
}

void TStaticButton::OnKillFocus()
{
	m_bfocus = false;
	InvalidateRect(m_Hwnd, 0, false);
}
LRESULT TStaticButton::WndProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_PAINT:
		OnPaint();
		break;
	case WM_LBUTTONDOWN:
		OnLButtonDown();
		break;
	case WM_LBUTTONUP:
		OnLButtonUp();
		break;
	case WM_MOUSEMOVE:
		OnMouseMove(wParam, lParam);
		break;
	case WM_MOUSELEAVE:
		OnMouseLeave(wParam, lParam);
		break;
	case WM_SETFOCUS:
		OnSetFocus();
		break;
	case WM_KILLFOCUS:
		OnKillFocus();
		break;
	case WM_KEYDOWN:
		SendMessage(GetParent(), SSWM_TAB_SWITCH_FOCUS, 0, (LPARAM)m_Hwnd);
		break;
	default:
		return NOT_PROCESSED;
	}

	return PROCESSED;
}
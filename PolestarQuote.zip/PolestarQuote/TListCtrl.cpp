﻿#include "PreInclude.h"

TListCtrl::TListCtrl()
{
}


TListCtrl::~TListCtrl()
{
}
void TListCtrl::Create(HWND hparent,int nindex)
{
	m_hWnd = CreateWindowEx(0, //扩展风格 
		WC_LISTVIEW, //这是系统定义的宏，WC_LISTVIEW对应 "SysListView32" 
		NULL, //窗口标题 
		WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_BORDER| WS_CLIPCHILDREN
		| LVS_REPORT | LVS_SHOWSELALWAYS | LVS_SINGLESEL, //窗口风格 （普通控件风格在这里设置，扩展风格要单独设置）
		0,
		0, //窗口大小  
		0, //宽度一定要等于所有列宽的和，否则会看起来有空列 
		0,
		hparent, //父窗口句柄 
		(HMENU)nindex, //菜单句柄 
		GetModuleHandle(NULL), //实例句柄 
		NULL //创建参数 
	);
	//SetWindowSubclass(m_hWnd, TListCtrl::ListProc, 0, (DWORD_PTR)this);
}
void TListCtrl::MoveWindow(const int& x, const int& y, const int& cx, const int& cy)
{
	SetWindowPos(m_hWnd, 0, x, y, cx, cy, SWP_NOZORDER);
	InvalidateRect(m_hWnd, 0, true);
}
void TListCtrl::InsertColumn(int nCol, LPCTSTR lpszColumnHeading, int nFormat, int nWidth , int nSubItem)
{
	LV_COLUMN lvc;
	TCHAR strChar[256];
	lvc.pszText = strChar;
	lvc.cchTextMax = 256;
	wcscpy_s(lvc.pszText, lvc.cchTextMax,lpszColumnHeading);
	lvc.fmt = nFormat;
	lvc.mask = LVCF_TEXT | LVCF_WIDTH | LVCF_FMT | LVCF_SUBITEM;
	lvc.cx = nWidth;
	lvc.iSubItem = nSubItem;
	SendMessage(m_hWnd, LVM_INSERTCOLUMN, nCol, (long)&lvc);
}
void TListCtrl::SetExtendedStyle(DWORD dwNewStyle)
{
	::SendMessage(m_hWnd, LVM_SETEXTENDEDLISTVIEWSTYLE, 0, (LPARAM)dwNewStyle);
}
DWORD TListCtrl::GetExtendedStyle()
{
	return (DWORD)::SendMessage(m_hWnd, LVM_GETEXTENDEDLISTVIEWSTYLE, 0, 0);
}
BOOL TListCtrl::SetColumnWidth(int nCol, int cx)
{
	return (BOOL) ::SendMessage(m_hWnd, LVM_SETCOLUMNWIDTH, nCol, MAKELPARAM(cx, 0));
}
BOOL TListCtrl::DeleteAllItems()
{
	return (BOOL) ::SendMessage(m_hWnd, LVM_DELETEALLITEMS, 0, 0L);
}
int TListCtrl::InsertItem(int nItem, LPCTSTR lpszItem)
{
	LVITEM lvi = { 0 };
	lvi.mask = LVIF_TEXT;
	lvi.iItem = nItem;
	lvi.iSubItem = 0;
	TCHAR strChar[256];
	lvi.pszText = strChar;
	lvi.cchTextMax = 256;
	wcscpy_s(lvi.pszText, lvi.cchTextMax, lpszItem);
	::SendMessage(m_hWnd, LVM_INSERTITEM, 0, (LPARAM)&lvi);

	return 1;
}
void TListCtrl::SetItemText(int nItem, int nSubItem, LPCTSTR lpszItem)
{
	LVITEM lvi = { 0 };
	lvi.mask = LVIF_TEXT;
	lvi.iItem = nItem;
	lvi.iSubItem = nSubItem;
	TCHAR strChar[256];
	lvi.pszText = strChar;
	lvi.cchTextMax = 256;
	wcscpy_s(lvi.pszText, lvi.cchTextMax, lpszItem);

	SendMessage(m_hWnd, LVM_SETITEMTEXT, (WPARAM)(nItem), (LPARAM)(LV_ITEM *)&lvi);
}
int TListCtrl::GetNextItem(int nItem, int nFlags)
{
	return (int) ::SendMessage(m_hWnd, LVM_GETNEXTITEM, nItem, MAKELPARAM(nFlags, 0));
}
bool TListCtrl::DeleteItem(int nItem)
{
	 return (bool) ::SendMessage(m_hWnd, LVM_DELETEITEM, nItem, 0L);
}
//LRESULT	CALLBACK TListCtrl::ListProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData)
//{
//	HWND hparent = ::GetParent(hwnd);
//	CxSpin* pSpin = (CxSpin*)dwRefData;
//	if (!pSpin)
//		return DefSubclassProc(hwnd, message, wParam, lParam);
//	switch (message)
//	{
//	}
//	return DefSubclassProc(hwnd, message, wParam, lParam);//默认回调过程
//}
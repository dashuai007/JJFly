#pragma once

class CxSpin 
{
public:
	CxSpin();
	~CxSpin();
	inline HWND     GetHwnd() const { return m_Hwnd; }
	bool			Create(HWND hparent, int nindex = 0);
	void            MoveWindow(const int& x, const int& y, const int& cx, const int& cy);
protected:
	static		LRESULT	CALLBACK SpinProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData);
private:
	bool m_bHover;
	bool m_bFocus;
	bool m_bDown;
	bool m_bTracking;
	POINT m_point;
	HWND m_Hwnd;
	void DrawTriangle(HDC &hdc, int nStartx, int nStarty, int nWidth, bool bNormal=true);
	void DrawItemFrame(bool bHover, bool bFocus, bool bDown = false);
};


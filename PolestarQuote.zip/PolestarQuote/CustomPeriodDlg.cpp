#include "PreInclude.h"



CustomPeriodDlg::CustomPeriodDlg()
{
}


CustomPeriodDlg::~CustomPeriodDlg()
{
}
bool CustomPeriodDlg::ShowDlg(TQuoteFrame* pFrame)
{
	m_pFrame = pFrame;
	m_nResult = DialogBoxParam(GetModuleHandle(L"PolestarQuote"), MAKEINTRESOURCE(IDD_DIALOG1), pFrame->GetHwnd(), CustomPeriodProc,(LPARAM)this);
	return m_nResult == IDOK;
}
void CustomPeriodDlg::SetDlgRect()
{
	RECT r = { 0, 0, 0, 0 };
	if (m_pFrame)
		m_pFrame->GetRect(r);
	r.right -= r.left;
	r.bottom -= r.top;
	RECT rc;
	GetWindowRect(m_hWnd, &rc);
	int nWidth = rc.right - rc.left;
	int nHigth = rc.bottom - rc.top;
	SetWindowPos(m_hWnd, 0, r.left + (r.right - nWidth) / 2, r.top + (r.bottom - nHigth) / 2, nWidth, nHigth, SWP_NOZORDER);
	ShowWindow(m_hWnd, SW_SHOW);
}
void CustomPeriodDlg::OnInitDlg()
{
	SetWindowText(m_hWnd, G_LANG->LangText(TLI_CUSTOM_PERIOD));
	SetDlgItemText(m_hWnd, IDC_STATIC1, G_LANG->LangText(TLI_TYPE));
	SetDlgItemText(m_hWnd, IDC_STATIC2, G_LANG->LangText(TLI_PERIOD_NUM));
	SetDlgItemText(m_hWnd, IDC_BUTTON2, G_LANG->LangText(TLI_ADD));
	SetDlgItemText(m_hWnd, IDC_BUTTON1, G_LANG->LangText(TLI_DELETE));
	SetDlgItemText(m_hWnd, IDOK, G_LANG->LangText(TLI_BTN_OK));
	SetDlgRect();
	m_hCmbType = GetDlgItem(m_hWnd, IDC_COMBO1);
	SendMessage(m_hCmbType, CB_ADDSTRING, 0, (LPARAM)G_LANG->LangText(TLI_SECOND));
	SendMessage(m_hCmbType, CB_ADDSTRING, 0, (LPARAM)G_LANG->LangText(TLI_MINUTE));
	//SendMessage(m_hCmbType, CB_ADDSTRING, 0, (LPARAM)G_LANG->LangText(TLI_HOUR));
	SendMessage(m_hCmbType, CB_ADDSTRING, 0, (LPARAM)G_LANG->LangText(TLI_DAY));
	SendMessage(m_hCmbType, CB_SETCURSEL, 1, 0);
	m_ListCtrl.SetHwnd(GetDlgItem(m_hWnd, IDC_LIST1));
	m_ListCtrl.SetExtendedStyle(m_ListCtrl.GetExtendedStyle() | LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT| LVS_SHOWSELALWAYS);
	m_ListCtrl.InsertColumn(0, G_LANG->LangText(TLI_TYPE), 0, 80);
	m_ListCtrl.InsertColumn(1, G_LANG->LangText(TLI_PERIOD_NUM), 0, 60);
	m_ListCtrl.SetColumnWidth(1, LVSCW_AUTOSIZE_USEHEADER);
	UpdateList();
}
void CustomPeriodDlg::UpdateList()
{
	m_ListCtrl.DeleteAllItems();
	for (size_t i = 0; i < m_arrPeriod.size(); i++)
	{
		TKLinePeriod period = m_arrPeriod[i];
		m_ListCtrl.InsertItem(i, G_LANG->LangText(period.kind + TLI_CUSTOM_END));
		wchar_t cur[26];
		swprintf_s(cur, L"%d",period.multi);
		m_ListCtrl.SetItemText(i, 1, cur);
	}
}
INT_PTR CALLBACK CustomPeriodDlg::CustomPeriodProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	CustomPeriodDlg* dlg(NULL);
	switch (msg)
	{
	case WM_INITDIALOG:
		dlg = (CustomPeriodDlg*)(lParam);
		if (dlg)
		{
			dlg->m_hWnd = hWnd;
			SetWindowLongPtr(hWnd, DWL_USER, (LONG)dlg);
			dlg->OnInitDlg();
		}	
		break;
	default:
		dlg = (CustomPeriodDlg*)GetWindowLongPtr(hWnd, DWL_USER);
		break;
	}
	if (NULL != dlg&&dlg->m_hWnd != 0)
	{
		switch (msg)
		{
		case WM_CLOSE:
			EndDialog(hWnd, IDCLOSE);
			return TRUE;
		case WM_COMMAND:
			dlg->OnCommand(wParam, lParam);
			return TRUE;
		}
	}
	return FALSE; // ��������
}
void CustomPeriodDlg::OnCommand(WPARAM wParam, LPARAM lParam)
{
	int nId = (int)wParam;
	switch (nId)
	{
	case IDC_BUTTON1:
		OnButtonDel();
		break;
	case IDC_BUTTON2:
		OnButtonAdd();
		break;
	case IDOK:
		OnOk();
		break;
	}
}
void CustomPeriodDlg::OnButtonAdd()
{
	wchar_t p_num[21];
	GetDlgItemText(m_hWnd, IDC_EDIT1, p_num, sizeof(p_num) / sizeof(wchar_t));
	int nNum = _wtoi(p_num);
	int nSel = SendMessage(m_hCmbType, CB_GETCURSEL, 0, 0);
	if (nSel == 0&& (nNum < 1 || nNum > 30))
	{
		MessageBox(m_hWnd, G_LANG->LangText(TLI_DAY_PERIOD_NUMBER_ERROR), G_LANG->LangText(TLI_TIPINFO), MB_ICONINFORMATION);
		return;
	}
	else if (nSel == 1 && (nNum < 1 || nNum > 255))
	{
		MessageBox(m_hWnd, G_LANG->LangText(TLI_PERIOD_NUMBER_ERROR), G_LANG->LangText(TLI_TIPINFO), MB_ICONINFORMATION);
		return;
	}
	else if (nSel == 2 && (nNum < 1 || nNum > 30))
	{
		MessageBox(m_hWnd, G_LANG->LangText(TLI_DAY_PERIOD_NUMBER_ERROR), G_LANG->LangText(TLI_TIPINFO), MB_ICONINFORMATION);
		return;
	}
	TKLinePeriod prd;
	if(nSel == 2)
		prd.kind = nSel + 2;
	else
	    prd.kind = nSel+1;
	prd.multi = nNum;
	for (size_t i = 0; i<m_arrPeriod.size(); i++)
	{
		if (m_arrPeriod[i].kind == prd.kind && m_arrPeriod[i].multi == prd.multi)
		{
			MessageBox(m_hWnd, G_LANG->LangText(TLI_ALEADY_EXISTS), G_LANG->LangText(TLI_TIPINFO), MB_ICONINFORMATION);
			return;
		}
	}
	if (m_arrPeriod.size()>99)
	{
		MessageBox(m_hWnd, G_LANG->LangText(TLI_MOST_SUPPER), G_LANG->LangText(TLI_TIPINFO), MB_ICONINFORMATION);
		return;
	}
	m_arrPeriod.push_back(prd);
	UpdateList();
}
void CustomPeriodDlg::OnButtonDel()
{
	int i = m_ListCtrl.GetNextItem(-1, LVIS_SELECTED);
	if (i >= 0)
	{
		m_arrPeriod.erase(m_arrPeriod.begin() + i);
		m_ListCtrl.DeleteItem(i);
	}

}
void CustomPeriodDlg::OnOk()
{
	EndDialog(m_hWnd, IDOK);
}

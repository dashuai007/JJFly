#pragma once        
struct SHAPE_INFO
{
	SHAPE_TYPE  type;
	COLORREF    color;
	int         width;
};
struct SHAPE_ICON
{
	SHAPE_TYPE  type;
	RECT        rect;
};
typedef std::vector<SHAPE_ICON> ShapeVectorType;
class TQuoteFrame;
class DrawToolDlg :public TIxFrm
{
public:
	DrawToolDlg();
	~DrawToolDlg();
	bool         Create(TQuoteFrame* pFrame);
	SHAPE_TYPE   GetSelectedShape(){return m_SelectShape;}
	void         SetSelectedShape(SHAPE_TYPE type) { m_SelectShape = type; }
protected:
	virtual LRESULT WndProc(UINT message, WPARAM wParam, LPARAM lParam);
	void			OnLbuttonDown(WPARAM wParam, LPARAM lParam);
	void			OnLbuttonUp(WPARAM wParam, LPARAM lParam);
	void            OnPaint();
	void            OnDestory();
	void			OnSize();
	void			OnMouseMove();
	void			OnMouseLeave();            
private:
	void            InitShapeIcon();
	void            AddRectTool(int id, RECT rect, LPWSTR szTipText);
protected:
	static const    int         CAPTION_HEIGHT = 25;
	static const    int         WINDOW_WIDTH = 140;
	static const    int         WINDOW_HEIGHT = 140;
	static const    int         ICON_WIDTH = 25;
	static const    int         ICON_HIGTH = 25;
	RECT						m_rctitle;
	RECT						m_rcclose;
	bool						m_bhoverclose;
	bool						m_btrack;
	bool                        m_bButtonDown;
	HIMAGELIST                  m_hImageList;
	ShapeVectorType             m_VShapes;
	HWND						m_hwTip;
	SHAPE_TYPE                  m_SelectShape;
};


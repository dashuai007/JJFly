#include"PreInclude.h"


CIndexMgr          CIndexMgr::m_Instance;
CIndexMgr::CIndexMgr()
{
}


CIndexMgr::~CIndexMgr()
{
}

void CIndexMgr::InitAllIndex()
{
	//����ָ��
	for (size_t i = 0; i < INDEX_SPEC_COUNT; i++)
	{
		CIndex *pIndex = new CIndex();
		pIndex->SetIndexName(G_IndexSpecs[i].SpecName);
		pIndex->SetIsVisiable(G_IndexSpecs[i].Visible);
		pIndex->SetIndexType(G_IndexSpecs[i].Type);
		pIndex->SetCalcIndeCallback(G_IndexSpecs[i].CalcIndi);
		for (size_t j = 0; j < sizeof(G_IndexSpecs[i].Params) / sizeof(TKLineSpecParam); j++)
			pIndex->SetParam(j, G_IndexSpecs[i].Params[j]);
		m_vIndexs.push_back(pIndex);
   }
}
CIndex* CIndexMgr::GetIndex(INDEX_SPEC i)
{
	if (i < 0 || i >= m_vIndexs.size())
		return NULL;
	return m_vIndexs[i];
}
CIndex* CIndexMgr::GetIndexByName(wchar_t* name)
{
	for (size_t i = 0; i < m_vIndexs.size(); i++)
	{
		if (wcscmp(m_vIndexs[i]->GetIndexName(), name) == 0)
			return m_vIndexs[i];
	}
	return NULL;
}
int CIndexMgr::GetMainIndexCount()
{
	int nCount = 0;
	for (size_t i = 0; i < m_vIndexs.size(); i++)
	{
		if (m_vIndexs[i]->GetIndexType() == TREND_TYPE)
			nCount++;
	}
	return nCount;
}
int CIndexMgr::GetSubIndexCount()
{
	return m_vIndexs.size() - GetMainIndexCount();
}
int CIndexMgr::LoadFromFile(char* strFileName)
{
	FILE* file(NULL);
	fopen_s(&file, strFileName, "rb");
	if (NULL == file)
		return 0;
	DATAFILE_HEAD struHeader;
	fread_s(&struHeader.m_nType, sizeof(int), sizeof(int), 1, file);
	fread_s(&struHeader.m_dwVersion, sizeof(DWORD), sizeof(DWORD), 1, file);
	if (struHeader.m_nType == dftFORMULA)
	{
		WORD nType;
		int nCount;
		fread_s(&nCount, sizeof(int), sizeof(int), 1, file);
		CIndex *pIndex;
		int i = 0;
		while (1 > 0)
		{
			WORD nType;
			fread_s(&nType, sizeof(WORD), sizeof(WORD), 1, file);
			if (nType >100)
				break;
			pIndex = new CIndex();
			pIndex->Serialize(file, true, nType);
			m_vIndexs.push_back(pIndex);
			i++;
		}
	}
	fclose(file);
	return 1;
}
int CIndexMgr::Load()
{
	char currpath[1024];
	CurrPath(currpath, sizeof(currpath));
	//ϵͳ��ʽ
	char filename[1024];
	sprintf_s(filename, "%s\\config\\Formula\\Formula.sys", currpath);
	if (LoadFromFile(filename) == 0)
		return 0;
	return 1;
}
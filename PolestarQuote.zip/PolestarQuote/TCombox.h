#ifndef _TCOMBOX_H
#define _TCOMBOX_H

class TCombox : public TIxFrm
{
public:
	TCombox();
	virtual ~TCombox();
public:
	bool			Create(HWND hwnd, int nindex = 0,bool bedit = true);
	void			MoveWindow(const int& x, const int& y, const int& cx, const int& cy);
	void			Clear();
	void			ResizeData();
public:
	void			AddString(const wchar_t* ptext, const wchar_t* pwvalue = NULL, const wchar_t szparam = 'F',const void* pvalue = NULL);
	void			CreateDropList();
	void			ReleaseComboxList();
public:
	void			SetUserComboxList(TPopupWnd* pwnd);
	void			SetFont(HFONT hfont);
	void			SetText(const wchar_t* ptext);
	wchar_t*		GetText();
	wchar_t			GetParam();
	ComboxStruct*	GetComboxStruct();
	void			SetSelect(int nindex);
	int             GetSelect() { return m_nselect; }
	int				GetSize(){return m_stldata.size(); }
protected:
	virtual		LRESULT		WndProc(UINT message, WPARAM wParam, LPARAM lParam);
	virtual		void		DrawDrop(TMemDC* pmemdc, const RECT& rect, HBRUSH framebrush);
protected:
	static		LRESULT	CALLBACK	EditProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData);
protected:
	void				OnPaint();
	void				OnSize();
	void				OnLbuttonDown(WPARAM wParam, LPARAM lParam);
	void				OnMouseMove(WPARAM wParam,LPARAM lParam);
	void				OnMouseLeave(WPARAM wParam, LPARAM lParam);
	void				OnComboxSelect(WPARAM wParam, LPARAM lParam);
private:
	int						m_nindex;
	bool					m_bedit;
	bool					m_bmousetrack;
	bool					m_bmouseover;
	bool					m_blbtndown;
	bool					m_buserdef;
protected:
	HFONT				m_font;
	COLORREF			m_bkclr;
	std::wstring		m_sztext;
	int					m_nselect;
protected:
	std::vector<ComboxStruct>		m_stldata;
	TPopupWnd*						m_pcomboxlist;
	HWND							m_edit;
private:
	const	int		m_nComboxHeight = 25;
	const	int		m_nDropWidth = 14;
	const	int		m_gapsize = 2;
};

#endif
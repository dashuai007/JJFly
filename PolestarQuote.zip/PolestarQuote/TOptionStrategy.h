#pragma once
class TGridControl;
class TOptionStrategy
{
public:
	TOptionStrategy();
	~TOptionStrategy();
	enum RECT_TYPE
	{
		STRATEGY_ITEM_RECT,

		RIGHT_RECT,

		RIGHT_TOP,
		RIGHT_NORMPLOT,
		RIGHT_PROFITLOSE,
		RBOTTOM_RECT,
		RBOTTOM_LEFT,
		RBOTTOM_RIGHT,
		RECT_COUNT
	};
	enum TARGET_OPTION_TYPE
	{
		TARGET_NONE = 0,
		TARGET_ADD_BUY,
		TARGET_ADD_SELL,
		TARGET_DEL,
	};
	static const int MENU_WIDTH = 20;
public:
	void Draw_OptionStrategy(HDC hdc, RECT& wr, HDC mdc, RECT& cr);
	void SetOptionContract(SContract* pCon, SStrikePriceType price);
	void SetOptionSeries(SOptionSeries* pSeries);
	bool IsOptionSeriesNull() { return m_OptionSeries==NULL; }
	void OnLButtonDown(POINT& pt);
	void OnLButtonUp(POINTS& pt);
	void OnMouseMove(POINT& pts);
	void OnMouseLeave();
	bool OnMouseWheel(int nDone);
	void RegistGridContrl(TGridControl* pGrid) { m_pGride = pGrid; }
	void SetTacticType(Tactic& tac);
	void UpdateXuShiValue();
	void HitStrikeRect(int nRow, POINT& pt);
	void CalProfitExpectVariance();
	bool IsCheckedContect(const SContractNoType ConNo);
	void FreshStrategyGraph();
	void OptionOrderPanelSync(const char* Content);
	void FreeListFocused() { m_bListFocused = false; }
	void DelALLRectTool();
private:
	void InitTactic(); //��ʼ����������
	//ͼ�λ���
	void PrepareRects(RECT& cr);									//���������ͼ����
	void DrawTacticTypeSelect(HDC hdc, RECT& wr, HDC mdc, RECT& cr);
	void DrawButtonIcon(TACTICID id, HDC mdc, RECT& cr); //���ư�ťͼ��
	void Draw_MenuBtn(HDC mdc, RECT& cr);
	void DrawStrikePrice(HDC hdc, RECT& wr, HDC mdc, RECT& cr);
	void DrawTopRect(HDC mdc, RECT& cr);
	void DrawNormplot(HDC mdc, RECT& cr);
	void DrawNormBackground(HDC mdc, RECT& cr);
	void DrawProbabilityCurve(HDC mdc, RECT& cr);
	void DrawProbabilityCursorLine(HDC mdc, RECT& cr);
	void DrawBenifitChart(HDC mdc, RECT& cr);
	void DrawBenifitBackground(HDC mdc, RECT& cr);
	void DrawBenifitCurve(HDC mdc, RECT& cr);
	void DrswBenifitCursorLine(HDC mdc, RECT& cr);
	void DrawBottomLeft(HDC mdc, RECT& cr);
	void DrawBottomRight(HDC mdc, RECT& cr);
	void DrawBenifitList(HDC mdc, RECT& cr);
	void ShowPopSubButton(int x, int y);
	//���ݼ���
	bool GetBalancePrice(SPriceType& price);
	bool GetRoyalty(SPriceType& price);
	bool GetTargetNewPrice(SPriceType& price);
	bool GetTargetPreClosePrice(SPriceType& price);
	bool GetTargetPrice(SPriceType& dPrice,bool bBuy);
	bool GetContractLastPrice(SPriceType& price);
	bool GetIntrinsicValue(SPriceType& price);//���ڼ�ֵ
	bool GetPremiumRatio(SPriceType& price);//�����
	bool GetGearing(SPriceType& price);
	void RefreshCheckList();
	void RefreshCheckListEable();
	void ClickNoticeOrderPanel();
	void ClickOptionTacticNotice();
	double GetProbability(double price);
	//����ͼ����
	//����ͼ
	double CountProfitAndLos(double price);
	double CounrCurrentProfitAndLos(double price);
	void   CountKeyPrices();
	void   CalProfitLossData();
	void   ReCalLimitInfo();
	bool   CheckData();
	//�����
	bool   GetListScrollRect(RECT& r);
	void   AddRectTool(int id, RECT rect, LPWSTR szTipText);
private:
	TacticVectorType			m_vTactis;
	TacticVectorType			m_vMenuTactis;
	Tactic                      m_TactisType;                               //��������
	RECT						m_Rects[RECT_COUNT];						//���л�ͼ����
	TCheckList                  m_CheckList;
	SContract*					m_pContract;
	SOptionSeries*				m_OptionSeries;
	SStrikePriceType			m_StrikePrice;
	HINSTANCE					m_gradient;
	TCriticalSection            m_HisData;
	HIMAGELIST                  m_hImageList;
	TGridControl*               m_pGride;
	int                         m_nXueEndRow;
	bool                        m_bInitCheck;
	//����ͼ
	NormlGraphData              m_NormalData;
	//����ͼ
	ProfitLossData              m_ProfitData;
	CheckedContract             m_CheckedCont;
	KeyPrices                   m_KeyPrices;
	TARGET_OPTION_TYPE          m_TargetOpt;
	POINT m_point;
	double m_CurrentPrice;
	double m_CurrentPayoff;
	//�����
	int m_nRowBegin;
	int m_nShowRows;
	bool m_bCheckScroll;
	POINT m_VScrollBegin;
	int m_nSelectedRow;
	bool m_bListFocused;
	const int ListRows = 11;
	bool m_bRegToolTip;
private:
	double                      m_fPrice;
	double                      m_fDelta;
	double                      m_fGamma;
	double                      m_fTheta;
	double                      m_fVega;
	double                      m_fRho;
	double                      m_fIV;
	HWND						m_hwTip;
};


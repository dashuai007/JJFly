#ifndef _PANEL_CONTROL_
#define _PANEL_CONTROL_

//�����̿����ؼ�
typedef unsigned char TQuotePanelLevelType;
const TQuotePanelLevelType PANEL_LEVEL_ONE = 1;
const TQuotePanelLevelType PANEL_LEVEL_FIVE = 5;
const TQuotePanelLevelType PANEL_LEVEL_TEN = 10;


class TPanelControl : public TDuiControl, public TDuiPopMenuControlSpi
{
public:
	static const int MIN_WIDTH = 200;
	static const int MID_WIDTH = 240;
	static const int MAX_WIDTH = 550;
	static const int SMALL_MODEL_WIDTH = 60;
	static const int CONTRACT_HEIGHT = 28;
	static int SELL_HEIGHT;
	static int BUY_HEIGHT;
	static const int ROW_HEIGHT = 22;
	static int TICK_ROW_HEIGHT;
	static int LEVEL_ONE_HEIGHT;	                        //һ���и߶�
	static int LEVEL_OTHER_HEIGHT;	                        //�������и߶�
	static const int LINE_PADDING = 5;
	static const int TITLE_TEXT_WIDTH = 40;
	static const int TICK_TIME_WIDTH = 80;
	static const int TICK_OTHER_WIDTH = 42;
	static int QTY_WIDTH;
	static const int BID_BEGIN = 10;
private:
	enum RECT_TYPE          //�̿�������
	{
		CONTRACT,
		CONTRACT_NAME,
		CONTRACT_SEL,
		PRICE,
		TICK,
		RECT_COUNT
	};

public:
	TPanelControl(TDuiWindow& window);
	virtual ~TPanelControl();
	bool SetContract(SContract* contract);
	SContract* GetContract() { return m_Contract; }
	bool SetSpreadContractNo(SContractNoType cno);
	void GetSpreadContractNo(SContractNoType& cno);
	TQuotePanelLevelType GetLevel() { return m_Level; }
	void SetLevel(TQuotePanelLevelType level);

	void ChgAll();
	void ChgQuote();
	void ChgSpreadQuote(const SSpreadContract* scont);
	void ChgTick();
	void SetUpDownRefType(UpDownRefType type);
	int GetIsSmallModle() { return (int)m_bSmallModel; }
	void SetSmallModle(bool bSmallModel) { m_bSmallModel = bSmallModel; }
	void SetIsLeftBid(bool bLeftBid);
	void SetIsBidRedAskGreen(bool bBuyR);      //�Ƿ��̿��������
	void SetIsShowAccumulate(bool bShow);                //�Ƿ���ʾ�̿��ۻ���
	void CancalSelectField();
public:
	virtual bool OnDraw(HDC hdc, HDC mdc, RECT& cr, RECT& ur, bool follow);
	virtual void OnMouseMove(WORD btn, POINTS& pts);
	virtual void OnLButtonDown(WORD btn, POINTS& pts);
	virtual void OnRButtonDown(WORD btn, POINTS& pts);
	virtual void OnLButtonUp(WORD btn, POINTS& pts);
	virtual void OnLButtonDbClk(WORD btn, POINTS& pts);
	virtual void OnKeyDown(WPARAM vk, LPARAM lParam);
	virtual void OnMouseWheel(short rot, WORD btn, POINTS& pts);

	virtual void __cdecl OnPopMenuClick(TDuiPopMenuItem* obj);

private:
	void PrepareRects(RECT& cr);
	void CalUpDown();
	void Draw_Background(HDC hdc, RECT& cr);
	void Draw_SpreadPrice(HDC hdc, RECT& cr);
	void Draw_Price(HDC hdc, RECT& cr);
	void Draw_Level_One(HDC hdc, RECT& cr);
	void Draw_Level_Multiply(HDC hdc, RECT& cr);
	void Draw_Tick(HDC hdc, RECT& cr);
	void Draw_RedGreenBar(HDC hdc, RECT& cr);
	void ClickPanelLinkage(const char* action, POINTS& pts);
	void DrawSmallPanel(HDC hdc, RECT& cr);
	int PreColSmallPanelWidth();
	bool IsDomesticExchange(SExchangeNoType	exchangeNo);
private:
	RECT						m_Rects[RECT_COUNT];						//���л�ͼ����
	SContract* m_Contract;
	TQuotePanelLevelType m_Level;	
	SPriceType m_UpDown;
	SPriceType m_UpDownRate;
	SPriceType m_LastBidPrice;
	SPriceType m_LastAskPrice;
	COLORREF m_UpDownColor;
	COLORREF m_BidColor;
	COLORREF m_AskColor;
	bool m_ShowAllBuySell;						//�Ƿ���ʾ��������

	LONG m_BeginMoveX;

	TCriticalSection m_Crit;
	bool m_Chg[3];
	bool m_DrawChg[3];
	SContractNoType m_SpreadContractNo;                                     //���������洢������Լ����
	SSpreadContract m_SpreadContract;                                 //����������Լ
	bool m_bIsSpread;                         //�Ƿ��Ǳ�������
	SQtyType m_all_buy_vol;
	SQtyType m_all_sell_vol;
	UpDownRefType                                   m_updwonType;
	bool m_bSmallModel;                      //�Ƿ���С�̿�ģʽ
	bool m_bInitWidth;
	bool m_bLeftBid;                          //��������������
	bool m_bBidRAskG;                        // �������
	int  m_nSelectField;                     //�൵ѡ���ֶ�
	bool m_bAccumulate;                      //�̿��ۻ���
};




















#endif
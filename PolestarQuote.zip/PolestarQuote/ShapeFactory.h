#pragma once
class TKLineChart;
class TKLineAxisX;
class ShapePen
{
public:
	ShapePen();
	virtual ~ShapePen();
public:
	void          Create(HWND phwnd, SHAPE_TYPE type, TKLineChart* pChart, TKLineAxisX* pAxisX);
	virtual       void OnClick(const POINT& pt);
	bool          IsOk();		//�ж��Ƿ�������
	bool          IsDrawing();	//�ж��Ƿ����ڻ���
	void          Clear();
	void          GetData(std::vector<ChartDot>& arr);   //ȡ�û��Ƶ�ͼ�� 
	SHAPE_TYPE    GetType() { return m_type; }
	virtual  int  GetMaxGriperCount() = 0;
	virtual  void Draw(HDC mdc) = 0;
protected:
	bool                   m_bOk;
	std::vector<ChartDot>  m_arrData;  //����ͼ�ε�����
	std::vector<POINT>     m_arrPixPoint; //����Ƥ�������
	SHAPE_TYPE			   m_type;
	TKLineChart*           m_pChart;
	TKLineAxisX*           m_pAxisX;
	HWND                   m_Hwnd;
};

class VertHozPen :public ShapePen  //ˮƽ����ֱ��
{
public:
	virtual int  GetMaxGriperCount() { return 1; }
	virtual void Draw(HDC mdc);
};

class NoramlLinePen :public ShapePen
{
public:
	virtual int GetMaxGriperCount() { return 2; }
	virtual void Draw(HDC mdc);
};

class PXXPen :public ShapePen
{
public:
	virtual int GetMaxGriperCount() { return 3; }
	virtual void Draw(HDC mdc);
};

class TrianglePen : public ShapePen
{
public:
	virtual int GetMaxGriperCount() { return 3; }
	virtual void Draw(HDC mdc);
};

class RectPen : public ShapePen
{
public:
	virtual int GetMaxGriperCount() { return 2; }
	virtual void Draw(HDC mdc);
};
class ArcPen : public ShapePen
{
public:
	virtual int GetMaxGriperCount() { return 2; }
	virtual void Draw(HDC mdc);
};

class CirclePen : public ShapePen
{
public:
	virtual int GetMaxGriperCount() { return 2; }
	virtual void Draw(HDC mdc);
};
class ZQXPen : public ShapePen
{
public:
	virtual int GetMaxGriperCount() { return 2; }
	virtual void Draw(HDC mdc);
};

class HJF_BFBGPen : public ShapePen
{
public:
	virtual int GetMaxGriperCount() { return 2; }
	virtual void Draw(HDC mdc);
};

class FBLQPen : public ShapePen
{
public:
	virtual int GetMaxGriperCount() { return 1; }
	virtual void Draw(HDC mdc);
};

class SZX_GSXPen : public ShapePen
{
public:
	virtual int GetMaxGriperCount() { return 2; }
	virtual void Draw(HDC mdc);
};

class XXHG_Pen : public ShapePen
{
public:
	virtual int GetMaxGriperCount() { return 2; }
	virtual void Draw(HDC mdc);
};

class ShapeFactory
{
public:
	ShapeFactory();
	~ShapeFactory();
	ShapePen* CreatePen(HWND phwnd,SHAPE_TYPE type, TKLineChart* pChart, TKLineAxisX* pAxisX);
	TShape*   CreateShape(SHAPE_TYPE type, TKLineChart* pChart, TKLineAxisX* pAxisX, const std::vector<ChartDot>& data, COLORREF clr, int penWid);
	static ShapeFactory* GetInstance()
	{
		static ShapeFactory factory;
		return &factory;
	}
};

ShapeFactory *G_ShapeFactory();
#include "PreInclude.h"



QuoteFontConfig::QuoteFontConfig()
{
	InitData();
	LoadCfg();
}


QuoteFontConfig::~QuoteFontConfig()
{
}
bool QuoteFontConfig::Create(HWND hparent)
{
	CreateFrm(_T("TFontWnd"), hparent, WS_CHILD /*| WS_VISIBLE*/ | WS_CLIPCHILDREN);
	SetWindowPos(m_Hwnd, 0, 0, 0, 800, 400, SWP_NOZORDER);
	PrepareRects();
	CreateSubCtrls();
	return true;
}
void QuoteFontConfig::RegistQuoteFrame(TQuoteFrame* pFrame)
{
	m_vpQuoteFrame.push_back(pFrame);
	if (IsFontExit(L"Calibri"))
	{
		if (m_ftQuote.lfHeight == 30)
			TGridControl::ROW_HEIGHT = 34;
		if(m_ftQuote.lfHeight == 26 )
			TGridControl::ROW_HEIGHT = 30;
		if (m_ftQuote.lfHeight == 24)
			TGridControl::ROW_HEIGHT = 28;
		if (m_ftFirst.lfHeight == 20)
		{
			TPanelControl::LEVEL_ONE_HEIGHT = 22;
			TPanelControl::BUY_HEIGHT = 28;
			TPanelControl::SELL_HEIGHT = 28;
		}
		else if (m_ftFirst.lfHeight == 24)
		{
			TPanelControl::LEVEL_ONE_HEIGHT = 24;
			TPanelControl::BUY_HEIGHT = 32;
			TPanelControl::SELL_HEIGHT = 32;
		}
		else if (m_ftFirst.lfHeight == 28)
		{
			TPanelControl::LEVEL_ONE_HEIGHT = 26;
			TPanelControl::BUY_HEIGHT = 38;
			TPanelControl::SELL_HEIGHT = 38;
		}
		else if (m_ftFirst.lfHeight == 32)
		{
			TPanelControl::LEVEL_ONE_HEIGHT = 34;
			TPanelControl::BUY_HEIGHT = 52;
			TPanelControl::SELL_HEIGHT = 52;
		}
	}
	else
	{
		if (m_ftQuote.lfHeight == 24)
			TGridControl::ROW_HEIGHT = 34;
		if (m_ftQuote.lfHeight == 20)
			TGridControl::ROW_HEIGHT = 30;
		if (m_ftQuote.lfHeight == 18)
			TGridControl::ROW_HEIGHT = 28;

		if (m_ftFirst.lfHeight == 14)
		{
			TPanelControl::LEVEL_ONE_HEIGHT = 22;
			TPanelControl::BUY_HEIGHT = 28;
			TPanelControl::SELL_HEIGHT = 28;
		}
		else if (m_ftFirst.lfHeight == 18)
		{
			TPanelControl::LEVEL_ONE_HEIGHT = 24;
			TPanelControl::BUY_HEIGHT = 32;
			TPanelControl::SELL_HEIGHT = 32;
		}
		else if (m_ftFirst.lfHeight == 22)
		{
			TPanelControl::LEVEL_ONE_HEIGHT = 26;
			TPanelControl::BUY_HEIGHT = 38;
			TPanelControl::SELL_HEIGHT = 38;
		}
		else if (m_ftFirst.lfHeight == 26)
		{
			TPanelControl::LEVEL_ONE_HEIGHT = 34;
			TPanelControl::BUY_HEIGHT = 52;
			TPanelControl::SELL_HEIGHT = 52;
		}
	}
	pFrame->ApplyColorSetting();
}
void QuoteFontConfig::UnRegistQuoteFrame(TQuoteFrame* pFrame)
{
	auto it = m_vpQuoteFrame.begin();
	while (it != m_vpQuoteFrame.end())
	{
		if (*it == pFrame)
			it = m_vpQuoteFrame.erase(it);
		else
			++it;
	}
}
void QuoteFontConfig::InitData()
{
	::GetObject(FONT_FUTURE_TITLE, sizeof(LOGFONT), &m_ftHead);
	::GetObject(FONT_FUTURE_CONTENT, sizeof(LOGFONT), &m_ftQuote);
	::GetObject(FONT_FUTURE_CHS, sizeof(LOGFONT), &m_ftCHS);
	::GetObject(FONT_PANEL_ONE_LEVEL, sizeof(LOGFONT), &m_ftFirst);
	::GetObject(FONT_PANEL_OTHER_LEVEL, sizeof(LOGFONT), &m_ftOther);
	::GetObject(FONT_PANEL_TICK_PRICE, sizeof(LOGFONT), &m_ftDetail);
	::GetObject(FONT_PANEL_BIG_PRICE, sizeof(LOGFONT), &m_ftBigPrice);
}
void QuoteFontConfig::PrepareRects()
{
	int Top_Gap = 5;
	int Left_Gap = 15;
	int RowHigth = 35;
	int nTextWidth = 70;
	if(G_LANG->LangId()==ENU)
		nTextWidth = 90;
	RECT rect;
	GetClientRect(m_Hwnd, &rect);
	InflateRect(&rect, -Left_Gap, -Top_Gap);

	RECT& rc_l = m_Rects[LIST_RECT];
	rc_l = rect;
	rc_l.bottom = rc_l.top + 2*RowHigth;

	RECT& rc_l_t = m_Rects[LIST_TITAL];
	rc_l_t = rc_l;
	rc_l_t.bottom = rc_l.top + RowHigth;

	RECT& rc_l_h = m_Rects[HEADER_RECT];
	rc_l_h = rc_l;
	rc_l_h.top = rc_l_t.bottom;
	rc_l_h.right = rc_l_h.left + nTextWidth;
	rc_l_h.bottom = rc_l_h.top + RowHigth;

	RECT& rc_l_h_c = m_Rects[HEADER_COMB_RECT];
	rc_l_h_c = rc_l_h;
	rc_l_h_c.left = rc_l_h.right;
	rc_l_h_c.right = (rc_l.right + rc_l.left) / 2;

	RECT& rc_l_q = m_Rects[QUOTE_RECT];
	rc_l_q = rc_l_h;
	rc_l_q.left = (rc_l.right + rc_l.left) / 2;
	rc_l_q.right = rc_l_q.left + nTextWidth;

	RECT& rc_l_q_c = m_Rects[QUOTE_COMB_RECT];
	rc_l_q_c = rc_l_q;
	rc_l_q_c.left = rc_l_q.right;
	rc_l_q_c.right = rc_l.right;

	RECT& rc_p = m_Rects[PANEL_RECT];
	rc_p = rect;
	rc_p.top = rc_l.bottom + Top_Gap;

	RECT& rc_p_t = m_Rects[PANEL_TITAL];
	rc_p_t = rc_p;
	rc_p_t.bottom = rc_p.top + RowHigth;

	RECT& rc_p_f = m_Rects[FIRST_LEVEL];
	rc_p_f = rc_p;
	rc_p_f.top = rc_p_t.bottom;
	rc_p_f.right = rc_p_f.left + nTextWidth;
	rc_p_f.bottom = rc_p_f.top + RowHigth;

	RECT& rc_p_f_c = m_Rects[FIRST_COMB_LEVEL];
	rc_p_f_c = rc_p_f;
	rc_p_f_c.left = rc_p_f.right;
	rc_p_f_c.right = (rc_p.right + rc_p.left) / 2;

	RECT& rc_p_o = m_Rects[OTHER_LEVER];
	rc_p_o = rc_p_f;
	rc_p_o.left = (rc_p.right + rc_p.left) / 2;
	rc_p_o.right = rc_p_o.left + nTextWidth;
	
	RECT& rc_p_o_c = m_Rects[OTHER_COMB_LEVER];
	rc_p_o_c = rc_p_o;
	rc_p_o_c.left = rc_p_o.right;
	rc_p_o_c.right = rc_p.right;

	RECT& rc_p_d = m_Rects[TICK_DETAIL];
	rc_p_d = rc_p_f;
	rc_p_d.top = rc_p_f.bottom;
	rc_p_d.bottom = rc_p_d.top + RowHigth;

	RECT& rc_p_d_c = m_Rects[TICK_COMB_DETAIL];
	rc_p_d_c = rc_p_d;
	rc_p_d_c.left = rc_p_d.right;
	rc_p_d_c.right = (rc_p.right + rc_p.left) / 2;
}
void QuoteFontConfig::CreateSubCtrls()
{
	int nWidth = 70;
	for (int i = 0; i < ID_COUNT; i++)
	{
		TCombox& Comb = m_Combs[i];
		Comb.Create(m_Hwnd, i, false);
		Comb.SetFont(FONT_CONTRL_QUOTE);
		Comb.Clear();
		Comb.AddString(G_LANG->LangText(TLI_SMALL_FONT));
		Comb.AddString(G_LANG->LangText(TLI_MIDDLE_FONT));
		Comb.AddString(G_LANG->LangText(TLI_BIG_FONT));
		Comb.AddString(G_LANG->LangText(TLI_EXTRA_LARGE_FONT));
		Comb.ResizeData();
		Comb.SetSelect(0);
		RECT rc = m_Rects[HEADER_COMB_RECT + i];
		Comb.MoveWindow(rc.left, rc.top+5, nWidth, rc.bottom - rc.top);
	}
	if (ENU == G_LANG->LangId() && IsFontExit(L"Calibri"))
	{
		if(m_ftHead.lfHeight == 20)
			m_Combs[HEADER_ID].SetSelect(0);
		else if (m_ftHead.lfHeight == 22)
			m_Combs[HEADER_ID].SetSelect(1);
		else if (m_ftHead.lfHeight == 24)
			m_Combs[HEADER_ID].SetSelect(2);
		else if (m_ftHead.lfHeight == 30)
			m_Combs[HEADER_ID].SetSelect(3);

		if(m_ftCHS.lfHeight == 22)
			m_Combs[QUOTE_ID].SetSelect(0);
		else if (m_ftCHS.lfHeight == 24)
				m_Combs[QUOTE_ID].SetSelect(1);
		else if (m_ftCHS.lfHeight == 26)
			m_Combs[QUOTE_ID].SetSelect(2);
		else if (m_ftCHS.lfHeight == 30)
			m_Combs[QUOTE_ID].SetSelect(3);
	}
	else
	{
		if (m_ftHead.lfHeight == 14)
			m_Combs[HEADER_ID].SetSelect(0);
		else if (m_ftHead.lfHeight == 16)
			m_Combs[HEADER_ID].SetSelect(1);
		else if (m_ftHead.lfHeight == 18)
			m_Combs[HEADER_ID].SetSelect(2);
		else if (m_ftHead.lfHeight == 22)
			m_Combs[HEADER_ID].SetSelect(3);

		if (m_ftCHS.lfHeight == 16)
			m_Combs[QUOTE_ID].SetSelect(0);
		else if (m_ftCHS.lfHeight == 18)
			m_Combs[QUOTE_ID].SetSelect(1);
		else if (m_ftCHS.lfHeight == 20)
			m_Combs[QUOTE_ID].SetSelect(2);
		else if (m_ftCHS.lfHeight == 24)
			m_Combs[QUOTE_ID].SetSelect(3);
	}
	if (IsFontExit(L"Calibri"))
	{
		if(m_ftFirst.lfHeight == 20)
			m_Combs[FIRST_ID].SetSelect(0);
		else if (m_ftFirst.lfHeight == 24)
			m_Combs[FIRST_ID].SetSelect(1);
		else if (m_ftFirst.lfHeight == 28)
			m_Combs[FIRST_ID].SetSelect(2);
		else if (m_ftFirst.lfHeight == 32)
			m_Combs[FIRST_ID].SetSelect(3);

		if (m_ftOther.lfHeight == 20)
			m_Combs[OTHER_ID].SetSelect(0);
		else if (m_ftOther.lfHeight == 24)
			m_Combs[OTHER_ID].SetSelect(1);
		else if (m_ftOther.lfHeight == 28)
			m_Combs[OTHER_ID].SetSelect(2);
		else if (m_ftOther.lfHeight == 32)
			m_Combs[OTHER_ID].SetSelect(3);

		if (m_ftDetail.lfHeight == 18)
			m_Combs[TICK_ID].SetSelect(0);
		else if (m_ftDetail.lfHeight == 20)
			m_Combs[TICK_ID].SetSelect(1);
		else if (m_ftDetail.lfHeight == 22)
			m_Combs[TICK_ID].SetSelect(2);
		else if (m_ftDetail.lfHeight == 26)
			m_Combs[TICK_ID].SetSelect(3);
	}
	else
	{
		if (m_ftFirst.lfHeight == 14)
			m_Combs[FIRST_ID].SetSelect(0);
		else if (m_ftFirst.lfHeight == 18)
			m_Combs[FIRST_ID].SetSelect(1);
		else if (m_ftFirst.lfHeight == 22)
			m_Combs[FIRST_ID].SetSelect(2);
		else if (m_ftFirst.lfHeight == 26)
			m_Combs[FIRST_ID].SetSelect(3);

		if (m_ftOther.lfHeight == 14)
			m_Combs[OTHER_ID].SetSelect(0);
		else if (m_ftOther.lfHeight == 18)
			m_Combs[OTHER_ID].SetSelect(1);
		else if (m_ftOther.lfHeight == 22)
			m_Combs[OTHER_ID].SetSelect(2);
		else if (m_ftOther.lfHeight == 26)
			m_Combs[OTHER_ID].SetSelect(3);

		if (m_ftDetail.lfHeight == 12)
			m_Combs[TICK_ID].SetSelect(0);
		else if (m_ftDetail.lfHeight == 14)
			m_Combs[TICK_ID].SetSelect(1);
		else if (m_ftDetail.lfHeight == 16)
			m_Combs[TICK_ID].SetSelect(2);
		else if (m_ftDetail.lfHeight == 20)
			m_Combs[TICK_ID].SetSelect(3);
	}
}
LRESULT QuoteFontConfig::WndProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_PAINT:
		OnPaint();
		break;
	case WM_DESTROY:
		OnDestory();
		break;
	case SSWM_COMBOX_SELECT:
		OnComboxSelect(wParam, lParam);
		break;
	default:
		return NOT_PROCESSED;
	}
	return PROCESSED;
}
void QuoteFontConfig::OnPaint()
{
	TMemDC memdc(m_Hwnd);
	RECT rect;
	GetClientRect(m_Hwnd, &rect);
	FillRect(memdc.GetHdc(), &rect, BRUSH_BG_QUOTE);
	//�Ȼ��Ʊ���
	HFONT FONT_TiTle = CreateFont(16, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
		CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����"));
	SelectObject(memdc.GetHdc(), FONT_TiTle);
	SetTextColor(memdc.GetHdc(), COLOR_QUOTE_CONFIG_FONT);
	DrawText(memdc.GetHdc(), G_LANG->LangText(TLI_GRID_FONT), wcslen(G_LANG->LangText(TLI_GRID_FONT)), &m_Rects[LIST_TITAL], DT_LEFT | DT_VCENTER | DT_SINGLELINE);
	DrawText(memdc.GetHdc(), G_LANG->LangText(TLI_PANEL_FONT), wcslen(G_LANG->LangText(TLI_PANEL_FONT)), &m_Rects[PANEL_TITAL], DT_LEFT | DT_VCENTER | DT_SINGLELINE);
	DeleteFont(FONT_TiTle);
	//���ƿؼ�����
	HFONT FONT_Ctrl = CreateFont(14, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
		CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����"));
	SelectObject(memdc.GetHdc(), FONT_Ctrl);
	DrawText(memdc.GetHdc(), G_LANG->LangText(TLI_COLUMN_HEADER), wcslen(G_LANG->LangText(TLI_COLUMN_HEADER)), &m_Rects[HEADER_RECT], DT_LEFT | DT_VCENTER | DT_SINGLELINE);
	DrawText(memdc.GetHdc(), G_LANG->LangText(TLI_QUOTE_TEXT), wcslen(G_LANG->LangText(TLI_QUOTE_TEXT)), &m_Rects[QUOTE_RECT], DT_LEFT | DT_VCENTER | DT_SINGLELINE);
	DrawText(memdc.GetHdc(), G_LANG->LangText(TLI_FIRST_PRICE), wcslen(G_LANG->LangText(TLI_FIRST_PRICE)), &m_Rects[FIRST_LEVEL], DT_LEFT | DT_VCENTER | DT_SINGLELINE);
	DrawText(memdc.GetHdc(), G_LANG->LangText(TLI_OTHER_PRICE), wcslen(G_LANG->LangText(TLI_OTHER_PRICE)), &m_Rects[OTHER_LEVER], DT_LEFT | DT_VCENTER | DT_SINGLELINE);
	DrawText(memdc.GetHdc(), G_LANG->LangText(TLI_TICK_DETAIL), wcslen(G_LANG->LangText(TLI_TICK_DETAIL)), &m_Rects[TICK_DETAIL], DT_LEFT | DT_VCENTER | DT_SINGLELINE);
	DeleteFont(FONT_Ctrl);
}
void QuoteFontConfig::OnDestory()
{
	for (int i = 0; i < ID_COUNT; i++)
	{
		m_Combs[i].ReleaseComboxList();
	}
	SaveCfg();
}
void QuoteFontConfig::OnComboxSelect(WPARAM wParam, LPARAM lParam)
{
	int nId = (int)lParam;
	switch (nId)
	{
	case HEADER_ID:
	{
		SetHeaderFont(wParam);
	}
	break;
	case QUOTE_ID:
	{
		SetQuoteFont(wParam);
	}
	break;
	case FIRST_ID:
		SetOneLevelFont(wParam);
		break;
	case OTHER_ID:
		SetOtherLevelFont(wParam);
		break;
	case TICK_ID:
		SetTickFont(wParam);
		break;
	}
	for (auto it = m_vpQuoteFrame.begin(); it != m_vpQuoteFrame.end(); it++)
	{
		TQuoteFrame* pFrame = *it;
		if (pFrame)
		{
			pFrame->ApplyColorSetting();
		}
	}
}
void QuoteFontConfig::SetHeaderFont(int nSel)
{
	int nFontSize = 14;
	if (ENU == G_LANG->LangId() && IsFontExit(L"Calibri"))
	{
		if (nSel == 0)
		{
			nFontSize = 20;
			TGridControl::HEAD_HEIGHT = 28;
		}

		else if (nSel == 1)
		{
			nFontSize = 22;
			TGridControl::HEAD_HEIGHT = 29;
		}
		else if (nSel == 2)
		{
			nFontSize = 24;
			TGridControl::HEAD_HEIGHT = 30;
		}
		else  if (nSel == 3)
		{
			nFontSize = 30;
			TGridControl::HEAD_HEIGHT = 34;
		}

	}
	else
	{
		if (nSel == 0)
		{
			nFontSize = 14;
			TGridControl::HEAD_HEIGHT = 28;
		}
		else if (nSel == 1)
		{
			nFontSize = 16;
			TGridControl::HEAD_HEIGHT = 29;
		}
		else if (nSel == 2)
		{
			nFontSize = 18;
			TGridControl::HEAD_HEIGHT = 30;
		}
		else if (nSel == 3)
		{
			nFontSize = 22;
			TGridControl::HEAD_HEIGHT = 34;
		}
	}
	m_ftHead.lfHeight = nFontSize;
	DeleteObject(FONT_FUTURE_TITLE);
	FONT_FUTURE_TITLE = CreateFontIndirect(&m_ftHead);
}
void QuoteFontConfig::SetQuoteFont(int nSel)
{
	int nFontSize = 22;
	if (IsFontExit(L"Calibri"))
	{
		if (nSel == 0)//С����
		{
			nFontSize = 22;
			TGridControl::ROW_HEIGHT = 26;
		}
		else if (nSel == 1)//������
		{
			nFontSize = 24;
			TGridControl::ROW_HEIGHT = 28;
		}
		else if (nSel == 2)//������
		{
			nFontSize = 26;
			TGridControl::ROW_HEIGHT = 30;
		}
		else if (nSel == 3)//�ش�����
		{
			nFontSize = 30;
			TGridControl::ROW_HEIGHT = 34;
		}
	}
	else
	{
		if (nSel == 0) //С����
		{
			nFontSize = 16;
			TGridControl::ROW_HEIGHT = 26;
		}
		else if (nSel == 1)//������
		{
			nFontSize = 18;
			TGridControl::ROW_HEIGHT = 28;
		}
		else if (nSel == 2)//������
		{
			nFontSize = 20;
			TGridControl::ROW_HEIGHT = 30;
		}
		else if (nSel == 3)//�ش�����
		{
			nFontSize = 24;
			TGridControl::ROW_HEIGHT = 34;
		}
	}
	if (ENU == G_LANG->LangId() && IsFontExit(L"Calibri"))
	{
		if (nSel == 0)//С����
			m_ftCHS.lfHeight = 22;
		else if (nSel == 1)
			m_ftCHS.lfHeight = 24;
		else if (nSel == 2)
			m_ftCHS.lfHeight = 26;
		else if (nSel == 3)
			m_ftCHS.lfHeight = 30;
	}
	else
	{
		if (nSel == 0)//С����
			m_ftCHS.lfHeight = 16;
		else if (nSel == 1)
			m_ftCHS.lfHeight = 18;
		else if (nSel == 2)
			m_ftCHS.lfHeight = 20;
		else if (nSel == 3)
			m_ftCHS.lfHeight = 24;
	}
	m_ftQuote.lfHeight = nFontSize;
	DeleteObject(FONT_FUTURE_CONTENT);
	DeleteObject(FONT_FUTURE_CHS);
	FONT_FUTURE_CONTENT = CreateFontIndirect(&m_ftQuote);
	FONT_FUTURE_CHS = CreateFontIndirect(&m_ftCHS);
}
void QuoteFontConfig::SetOneLevelFont(int nSel)
{
	int nFontSize = 22;
	int nBigPrice = 22;
	if (IsFontExit(L"Calibri"))
	{
		if (nSel == 0)//С����
		{
			nFontSize = 20;
			nBigPrice = 28;
			TPanelControl::LEVEL_ONE_HEIGHT = 22;
			TPanelControl::BUY_HEIGHT = 28;
			TPanelControl::SELL_HEIGHT = 28;
		}
		else if (nSel == 1)//������
		{
			nFontSize = 24;
			nBigPrice = 36;
			TPanelControl::LEVEL_ONE_HEIGHT = 24;
			TPanelControl::BUY_HEIGHT = 32;
			TPanelControl::SELL_HEIGHT = 32;
		}
		else if (nSel == 2)//������
		{
			nFontSize = 28;
			nBigPrice = 60;
			TPanelControl::LEVEL_ONE_HEIGHT = 26;
			TPanelControl::BUY_HEIGHT = 38;
			TPanelControl::SELL_HEIGHT = 38;
		}
		else if (nSel == 3)//�ش�����
		{
			nFontSize = 32;
			nBigPrice = 80;
			TPanelControl::LEVEL_ONE_HEIGHT = 34;
			TPanelControl::BUY_HEIGHT = 52;
			TPanelControl::SELL_HEIGHT = 52;
		}
	}
	else
	{
		if (nSel == 0) //С����
		{
			nFontSize = 14;
			nBigPrice = 22;
			TPanelControl::LEVEL_ONE_HEIGHT = 22;
			TPanelControl::BUY_HEIGHT = 28;
			TPanelControl::SELL_HEIGHT = 28;
		}
		else if (nSel == 1)//������
		{
			nFontSize = 18;
			nBigPrice = 30;
			TPanelControl::LEVEL_ONE_HEIGHT = 24;
			TPanelControl::BUY_HEIGHT = 32;
			TPanelControl::SELL_HEIGHT = 32;
		}
		else if (nSel == 2)//������
		{
			nFontSize = 22;
			nBigPrice = 54;
			TPanelControl::LEVEL_ONE_HEIGHT = 26;
			TPanelControl::BUY_HEIGHT = 38;
			TPanelControl::SELL_HEIGHT = 38;
		}
		else if (nSel == 3)//�ش�����
		{
			nFontSize = 26;
			nBigPrice = 78;
			TPanelControl::LEVEL_ONE_HEIGHT = 34;
			TPanelControl::BUY_HEIGHT = 52;
			TPanelControl::SELL_HEIGHT = 52;
		}
	}
	m_ftFirst.lfHeight = nFontSize;
	m_ftBigPrice.lfHeight = nBigPrice;
	DeleteObject(FONT_PANEL_ONE_LEVEL);
	DeleteObject(FONT_PANEL_BIG_PRICE);
	FONT_PANEL_ONE_LEVEL = CreateFontIndirect(&m_ftFirst);
	FONT_PANEL_BIG_PRICE = CreateFontIndirect(&m_ftBigPrice);
}
void QuoteFontConfig::SetOtherLevelFont(int nSel)
{
	int nFontSize = 14;
	if (IsFontExit(L"Calibri"))
	{
		if (nSel == 0)//С����
		{
			nFontSize = 20;
			TPanelControl::LEVEL_OTHER_HEIGHT = 22;
		}
		else if (nSel == 1)//������
		{
			nFontSize = 24;
			TPanelControl::LEVEL_OTHER_HEIGHT = 24;
		}
		else if (nSel == 2)//������
		{
			nFontSize = 28;
			TPanelControl::LEVEL_OTHER_HEIGHT = 26;
		}
		else if (nSel == 3)//�ش�����
		{
			nFontSize = 32;
			TPanelControl::LEVEL_OTHER_HEIGHT = 26;
		}
	}
	else
	{
		if (nSel == 0) //С����
		{
			nFontSize = 14;
			TPanelControl::LEVEL_OTHER_HEIGHT = 22;
		}
		else if (nSel == 1)//������
		{
			nFontSize = 18;
			TPanelControl::LEVEL_OTHER_HEIGHT = 24;
		}
		else if (nSel == 2)//������
		{
			nFontSize = 22;
			TPanelControl::LEVEL_OTHER_HEIGHT = 26;
		}
		else if (nSel == 3)//�ش�����
		{
			nFontSize = 26;
			TPanelControl::LEVEL_OTHER_HEIGHT = 26;
		}
	}
	m_ftOther.lfHeight = nFontSize;
	DeleteObject(FONT_PANEL_OTHER_LEVEL);
	FONT_PANEL_OTHER_LEVEL = CreateFontIndirect(&m_ftOther);
}
void QuoteFontConfig::SetTickFont(int nSel)
{
	int nFontSize = 22;
	if (IsFontExit(L"Calibri"))
	{
		if (nSel == 0)//С����
		{
			nFontSize = 18;
			TPanelControl::TICK_ROW_HEIGHT = 22;
		}
		else if (nSel == 1)//������
		{
			nFontSize = 20;
			TPanelControl::TICK_ROW_HEIGHT = 23;
		}
		else if (nSel == 2)//������
		{
			nFontSize = 22;
			TPanelControl::TICK_ROW_HEIGHT = 24;
		}
		else if (nSel == 3)//�ش�����
		{
			nFontSize = 26;
			TPanelControl::TICK_ROW_HEIGHT = 24;
		}
	}
	else
	{
		if (nSel == 0) //С����
		{
			nFontSize = 12;
			TPanelControl::TICK_ROW_HEIGHT = 22;
		}
		else if (nSel == 1)//������
		{
			nFontSize = 14;
			TPanelControl::TICK_ROW_HEIGHT = 23;
		}
		else if (nSel == 2)//������
		{
			nFontSize = 16;
			TPanelControl::TICK_ROW_HEIGHT = 24;
		}
		else if (nSel == 3)//�ش�����
		{
			nFontSize = 20;
			TPanelControl::TICK_ROW_HEIGHT = 24;
		}
	}
	m_ftDetail.lfHeight = nFontSize;
	DeleteObject(FONT_PANEL_TICK_PRICE);
	FONT_PANEL_TICK_PRICE = CreateFontIndirect(&m_ftDetail);
}
void QuoteFontConfig::LoadCfg()
{
	wchar_t currpath[1024];
	CurrPath(currpath, sizeof(currpath) / sizeof(wchar_t));

	wchar_t filename[1024];
	wsprintf(filename, L"%s\\config\\PolestarQuote\\PolestarQuote.QuoteFontConfig.%s.pri", currpath, G_LANG->LangName());
	std::ifstream icin;
	icin.open(filename);
	icin >> m_ftHead.lfHeight;
	icin >> m_ftQuote.lfHeight;
	icin >> m_ftCHS.lfHeight;
	icin >> m_ftFirst.lfHeight;
	icin >> m_ftOther.lfHeight;
	icin >> m_ftDetail.lfHeight;
	icin >> m_ftBigPrice.lfHeight;
	icin.close();
	DeleteObject(FONT_FUTURE_TITLE);
	FONT_FUTURE_TITLE = CreateFontIndirect(&m_ftHead);
	DeleteObject(FONT_FUTURE_CONTENT);
	DeleteObject(FONT_FUTURE_CHS);
	FONT_FUTURE_CONTENT = CreateFontIndirect(&m_ftQuote);
	FONT_FUTURE_CHS = CreateFontIndirect(&m_ftCHS);
	DeleteObject(FONT_PANEL_ONE_LEVEL);
	FONT_PANEL_ONE_LEVEL = CreateFontIndirect(&m_ftFirst);
	DeleteObject(FONT_PANEL_OTHER_LEVEL);
	FONT_PANEL_OTHER_LEVEL = CreateFontIndirect(&m_ftOther);
	DeleteObject(FONT_PANEL_TICK_PRICE);
	FONT_PANEL_TICK_PRICE = CreateFontIndirect(&m_ftDetail);
	DeleteObject(FONT_PANEL_BIG_PRICE);
	FONT_PANEL_BIG_PRICE = CreateFontIndirect(&m_ftBigPrice);
}
void QuoteFontConfig::SaveCfg()
{
	wchar_t currpath[1024];
	CurrPath(currpath, sizeof(currpath) / sizeof(wchar_t));

	wchar_t filename[1024];
	wsprintf(filename, L"%s\\config\\PolestarQuote\\PolestarQuote.QuoteFontConfig.%s.pri", currpath, G_LANG->LangName());
	std::ofstream ocout;
	ocout.open(filename);
	ocout << m_ftHead.lfHeight;
	ocout << " ";
	ocout << m_ftQuote.lfHeight;
	ocout << " ";
	ocout << m_ftCHS.lfHeight;
	ocout << " ";
	ocout << m_ftFirst.lfHeight;
	ocout << " ";
	ocout << m_ftOther.lfHeight;
	ocout << " ";
	ocout << m_ftDetail.lfHeight;
	ocout << " ";
	ocout << m_ftBigPrice.lfHeight;
	ocout.close();
}
#pragma once

#define EOF_CHAR		'\0'
#define	TAB_SIZE		4
#define MAX_DIGIT_COUNT 25
#define MAX_CODE_SIZE	240
typedef enum	// character codes
{
	ccLETTER, ccDIGIT, ccSPECIAL, ccQUOTE1, ccEOF_CODE
} CHAR_CODE;
class CFncParser :public CParser
{
public:
	CFncParser();
	virtual ~CFncParser();

	void	GetToken();
	int	    Parse(int& nLine, int& nOffset);
	void    SetIndex(CIndex* pIndex);
private:
	void    CreateResult();
	TOKEN_CODE	NextToken();
	void	GetChar();
	void	SkipBlanks();
	void	SkipComment();
	void	GetWord();
	void	GetNumber();
	void	GetSpecial();
	void	UpShiftWord();
	BOOL	IsParamWord();
	int		SearchAndEnterVariable();
	void	AccumulateValue(float* pValue);
	void	Synchronize();
	void	error(int errorCode);
	void	ParseStatement();
	void	ParseAssignmentStatement(CSymtabNode* pId);
	DWORD	ParseExpression();
	DWORD	ParseLogicExpression();
	DWORD	ParseSimpleExpression();
	DWORD	ParseTerm();
	DWORD	ParseFactor();
	void    PushCode();
	DWORD	ParseInnerFnc();
	DWORD	ParseFncParams(int nParamNum, DWORD dt1 = 0, DWORD dt2 = 0, DWORD dt3 = 0, DWORD dt4 = 0, DWORD dt5 = 0, DWORD dt6 = 0);
private:

	BYTE	m_Char;				// Current input char
	int		m_nLineOffset;		// char offset of current line
	int		m_nLineNumber;		// current line number

	char*	m_pBuf;			// source Buf ptr
	char*	m_pToken;			// token string ptr

	CHAR_CODE m_CharCode[256];
	char	m_szTokenString[80];// token string
	char	m_szWordString[80];	// upshifteds

	int		m_nDigitCount;
	BOOL	m_bCountError;

	float	m_fNumber;			// tNUMBER 's number
	int		m_nErrLine;
	int		m_nErrOffset;
	int		m_nStrIndex;
	std::string	m_strVarNames;
};
extern TOKEN_CODE StatementStartEndList[];
extern TOKEN_CODE LogicOpList[];
extern TOKEN_CODE RelationOpList[] ;
extern TOKEN_CODE AddOpList[];
extern TOKEN_CODE MultiOpList[];
extern TOKEN_CODE DrawFncList[] ;

extern TOKEN_CODE PeriodList[];
extern TOKEN_CODE StkDataList[];
extern TOKEN_CODE StyleList[];
BOOL TokenIn(TOKEN_CODE token, TOKEN_CODE* tokenList);

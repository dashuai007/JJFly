//ListCtrlϵͳ�ؼ�
#pragma once

class TListCtrl
{
public:
	TListCtrl();
	~TListCtrl();
	void Create(HWND hparent, int nindex);
	void MoveWindow(const int& x, const int& y, const int& cx, const int& cy);
	void SetHwnd(HWND hwnd) { m_hWnd = hwnd; }
	HWND GetHwnd() { return m_hWnd; }
	void InsertColumn(int nCol, LPCTSTR lpszColumnHeading, int nFormat = LVCFMT_LEFT, int nWidth = -1, int nSubItem = -1);
	void SetExtendedStyle(DWORD dwNewStyle);
	DWORD GetExtendedStyle();
	BOOL SetColumnWidth(int nCol, int cx);
	BOOL DeleteAllItems();
	int InsertItem(int nItem,LPCTSTR lpszItem);
	void SetItemText(int nItem, int nSubItem, LPCTSTR lpszItem);
	int GetNextItem(int nItem, int nFlags);
	bool DeleteItem(int nItem);
//protected:
//	static		LRESULT	CALLBACK ListProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData);

private:
	HWND m_hWnd;
};


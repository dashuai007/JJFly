#pragma once
class TKChartSpec;
enum SERIES_TYPE
{
	CHART_TYPE = 0,
	KLINE_TYPE,
	TLINE_TYPE,
	TICK_TYPE,
};
class TChartSeries
{
public:
	TChartSeries();
	~TChartSeries();
	virtual bool	GetVisibleMinMaxYValues(float& fMinValue, float& fMaxValue);
	virtual void Draw(HDC mdc);
public:
	double                            m_Data[MAX_SHOW_KLINE_X];
	int                               m_nParamPre;
	wchar_t                           m_ParamName[128];
	wchar_t                           m_ParamValue[128];
	int                               m_PenId;
	TKLineControl*                    m_pKLineCtl;
	TKLineAxisY*                      m_pLeftAxisY;
	RECT                              m_ChartRect;
	bool                              m_bPow; //�Ƿ����y��Ŵ���
	bool                              m_bAutoColor;
	COLORREF                          m_Color;
	SERIES_TYPE                       m_type;
};
//K������
class TKLineSeries : public TChartSeries
{
public:
	TKLineSeries();
	virtual ~TKLineSeries() {};
public:
	void    SetBottomRect(RECT& rc) { m_BottomRect = rc; }
	void    SetKType(KLINE_STYLE style) { m_nStyle = style; }	//K��ͼ��ʽ
	virtual void	Draw(HDC mdc);
	virtual void    DrawBottom(HDC mdc, SHisQuoteData& d, SHisQuoteData& pre_d, RECT& r);
protected:
	void    DrawTower(HDC mdc);
	bool    DrawTodayYestodayLine(HDC mdc,SHisQuoteData& d, int pos);
	void    DrawLastPriceLine(HDC mdc);
	void    DrawScreenHighLowPrice(HDC mdc);
protected:
	RECT                              m_BottomRect;
	KLINE_STYLE                       m_nStyle;
};
//TLine����
class TTLineSeries : public TKLineSeries
{
public:
	TTLineSeries();
	virtual ~TTLineSeries() {};
	void    SetTopRect(RECT& rc) { m_TopRect = rc; }
	virtual void	Draw(HDC mdc);
	void    DrawBottom(HDC mdc, SHisQuoteData& d, RECT& r);
	void    DrawRGBar(HDC mdc, TKChartSpec* pSpec);
private:
	RECT                              m_TopRect;
};
//TICK����
class TTickSeries : public TKLineSeries
{
public:
	TTickSeries();
	virtual ~TTickSeries() {};
	virtual void	Draw(HDC mdc);
	virtual void    DrawBottom(HDC mdc, SHisQuoteData& d, SHisQuoteData& pre_d, RECT& r);
};
//����K������
class TSpreadSeries : public TTickSeries
{
public:
	TSpreadSeries();
	virtual ~TSpreadSeries() {};
	virtual  void Draw(HDC mdc);
};

class TBarSeries : public TChartSeries
{
public:
	TBarSeries();
	virtual ~TBarSeries() {};
	void	Draw(HDC mdc);
};

class TVolumeSeries : public TChartSeries
{
public:
	TVolumeSeries();
	virtual ~TVolumeSeries() {};
	void	Draw(HDC mdc);
};

class TPointSeries : public TChartSeries
{
public:
	TPointSeries();
	virtual ~TPointSeries() {};
	void	 Draw(HDC mdc);
	COLORREF                     m_ArrColor[MAX_SHOW_KLINE_X];
};

//ͼ��������ָ����Ϣ
class TKChartSpec
{
public:
	TKChartSpec();
	~TKChartSpec();
	void    Draw(HDC mdc);
	void	ClearAllSeries();
	bool	CalcVisibleMinMaxYValues();
	float	GetYAxisMinValue() { return (m_bFixedYAxisMinValue ? m_fFixedYAxisMinValue : m_fVisibleMinYValue); }
	float	GetYAxisMaxValue() { return (m_bFixedYAxisMaxValue ? m_fFixedYAxisMaxValue : m_fVisibleMaxYValue); }
public:
	wchar_t						      SpecName[21];					//ָ������
	bool						      Visible;					//��ʾ
	TKLineSpecParam				      Params[6];					//����`
	std::vector<TChartSeries*>		  m_VSeries;                   //������
	float	                          m_fVisibleMinYValue;
	float	                          m_fVisibleMaxYValue;
	float	                          m_fFixedYAxisMinValue;
	float	                          m_fFixedYAxisMaxValue;
	bool	                          m_bFixedYAxisMinValue;
	bool	                          m_bFixedYAxisMaxValue;
	CIndex*                           m_pIndex;
public:
	void DrawLegend(HDC mdc, RECT& rc);
};

#include "PreInclude.h"

TQuoteUtils G_QuoteUtils;

//K����̬
TKLineShapeType	TQuoteUtils::KLineShapes[] = {							//Ŀǰ��16��
	{ 1, 0, 0, false }, { 2, 1, 0, false },								//�����ߵ��� 
	{ 3, 0, 0, true }, { 5, 0, 0, true },								//�޼�϶
	{ 7, 1, 1, true }, { 9, 1, 1, true },								//��϶1�����ΰ������1
	{ 15, 2, 2, true }, { 19, 2, 2, true },								//��϶2�����ΰ������2
	{ 25, 3, 3, true }, { 31, 3, 3, true },	{ 37, 3, 3, true },			//��϶3�����ΰ������3
	{ 45, 4, 4, true }, { 53, 4, 4, true },	{ 61, 4, 4, true },			//��϶4�����ΰ������4
	{ 71, 5, 5, true }, { 81, 5, 5, true },								//��϶5�����ΰ������5
};
int TQuoteUtils::ShapSize = sizeof(KLineShapes) / sizeof(TKLineShapeType);
//��ͼָ��
TKLineSpec G_IndexSpecs[] = {
	{ L"KLINE",	true,TREND_TYPE, &TKLineChart::KLine_CalcIndi, { { L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 } } },
	{ L"TLINE", true,TREND_TYPE,  &TKLineChart::TLine_CalcIndi, { { L"S", 2 },{ L"S", 6 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 } } },
	{ L"TICK", true,TREND_TYPE,  &TKLineChart::Tick_CalcIndi,{ { L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 } } },
	{ L"MA",   true,TREND_TYPE,  &TKLineChart::MA_CalcIndi, { { L"MA1", 5 },{ L"MA2", 10 },{ L"MA3", 20 },{ L"MA4", 40 },{ L"MA5", 60 },{ L"MA6", 100 } } },
	{ L"SAR", false,TREND_TYPE,  &TKLineChart::SAR_CalcIndi, { { L"Step", 2 },{ L"Limit", 20 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 } } },
	{ L"EMA", false,TREND_TYPE,  &TKLineChart::EMA_CalcIndi, { { L"MA1", 5 },{ L"MA2", 10 },{ L"MA3", 20 },{ L"MA4", 60 },{ L"MA5", 0 },{ L"MA6", 0 } } },
	{ L"BOLL", false, TREND_TYPE, &TKLineChart::BOLL_CalcIndi,{ { L"N", 26 },{ L"M", 26 },{ L"P", 2 },{ L"", 0 },{ L"", 0 },{ L"", 0 } } },
	{ L"BBI", false,TREND_TYPE,  &TKLineChart::BBI_CalcIndi, { { L"N1", 3 },{ L"N2", 6 },{ L"N3", 12 },{ L"N4", 24 },{ L"", 0 },{ L"", 0 } } },
     //��ͼ
	{ L"VOL", true, VOLUME_TYPE,&TKLineChart::VOL_CalcIndi, { { L"", 0 }, { L"", 0 }, { L"", 0 }, { L"", 0 }, { L"", 0 }, { L"", 0 } } },
	{ L"MACD", true,SWING_TYPE, &TKLineChart::MACD_CalcIndi, { { L"SHORT", 12 }, { L"LONG", 26 }, { L"M", 9 }, { L"", 0 }, { L"", 0 }, { L"", 0 } } },
	{ L"KDJ", true,SWING_TYPE, &TKLineChart::KDJ_CalcIndi,  { { L"N", 9 }, { L"M1", 3 }, { L"M2", 3 }, { L"", 0 }, { L"", 0 }, { L"", 0 } } },
	{ L"RSI", true, SWING_TYPE,&TKLineChart::RSI_CalcIndi,  { { L"N1", 7 }, { L"N2", 14 }, { L"", 0 }, { L"", 0 }, { L"", 0 }, { L"", 0 } } },
	{ L"WR", true,SWING_TYPE, &TKLineChart::WR_CalcIndi,   { { L"N", 14 }, { L"", 0 }, { L"", 0 }, { L"", 0 }, { L"", 0 }, { L"", 0 } } },
	{ L"BIAS", true,SWING_TYPE, &TKLineChart::BIAS_CalcIndi,  { { L"L1", 6 }, { L"L2", 12 }, { L"L3", 24 }, { L"", 0 }, { L"", 0 }, { L"", 0 } } },
	{ L"DMI", true,SWING_TYPE, &TKLineChart::DMI_CalcIndi,  { { L"N", 14 }, { L"M", 6 }, { L"", 0 }, { L"", 0 }, { L"", 0 }, { L"", 0 } } },
	{ L"OBV", true, VOLUME_TYPE,&TKLineChart::OBV_CalcIndi, { { L"", 0 }, { L"", 0 }, { L"", 0 }, { L"", 0 }, { L"", 0 }, { L"", 0 } } },
	{ L"TRIX", true,SWING_TYPE, &TKLineChart::TRIX_CalcIndi, { { L"P", 12 },{ L"N", 20 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 } } },
	{ L"CR", true, VOLUME_TYPE,&TKLineChart::CR_CalcIndi,{ { L"N", 26 },{ L"M1", 5 },{ L"M2", 10 },{ L"M3", 20 },{ L"", 0 },{ L"", 0 } } },
	{ L"MTM", true,SWING_TYPE, &TKLineChart::MTM_CalcIndi, { { L"P", 6 },{ L"W", 6 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 } } },
	{ L"PSY", true,SWING_TYPE, &TKLineChart::PSY_CalcIndi,{ { L"N", 12 },{ L"M", 6 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 } } },
	{ L"CCI", true,VOLUME_TYPE, &TKLineChart::CCI_CalcIndi,{ { L"N", 14 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 } } },
	{ L"VR", true, VOLUME_TYPE,&TKLineChart::VR_CalcIndi,{ { L"N", 26 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 } } },
	{ L"TheoryPrice", true, OPTION_TYPE,&TKLineChart::TP_CalcIndi, { { L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 } } },
	{ L"IV", true, OPTION_TYPE,&TKLineChart::IV_CalcIndi,{ { L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 } } },
	{ L"Delta", true, OPTION_TYPE,&TKLineChart::Delta_CalcIndi,{ { L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 } } },
	{ L"Gamma", true, OPTION_TYPE,&TKLineChart::Gamma_CalcIndi,{ { L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 } } },
	{ L"Vega", true, OPTION_TYPE,&TKLineChart::Vega_CalcIndi,{ { L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 } } },
	{ L"Theta", true, OPTION_TYPE,&TKLineChart::Theta_CalcIndi, { { L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 } } },
	{ L"c", true, OPTION_TYPE,&TKLineChart::Rho_CalcIndi,{ { L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 },{ L"", 0 } } },
};

TQuoteUtils::TQuoteUtils() : PlateColCount(0), m_InitRows(false), m_InitPages(false)
{
	memset(PlateCols, 0, MAX_PLATECOL_COUNT * sizeof(TPlateCol));
	memset(PlateColsMap, 0, MAX_PLATECOL_COUNT * sizeof(TPlateCol*));
}

void ParsingColsFuncW(void* obj, wchar_t* line, int site[], int slen)
{
	TQuoteUtils& q = (*(TQuoteUtils*)obj);

	//������������е�����
	if (q.PlateColCount >= MAX_PLATECOL_COUNT)
		return;

	TPlateCol col;

	//�����ֶκ�--------------------------------
	col.Field = (unsigned char)_wtoi(&line[site[0]]);
	if (col.Field >= S_FID_MEAN_COUNT)
		return;
		
	//��������б��
	if (S_FIDTYPE_NONE == S_FIDTYPE_ARRAY[col.Field])
		return;

	//ȥ���ظ���
	if (NULL != q.PlateColsMap[col.Field])
		return;		

	//��������
	wcsncpy_s(col.Name, &line[site[1]], sizeof(col.Name)/sizeof(wchar_t) - 1);

	//��������
	col.Width = _wtoi(&line[site[2]]);
		
	//��������
	col.Align = _wtoi(&line[site[3]]);

	//������ʾ
	col.Visible = (L'1' == line[site[4]]);

	TPlateCol* cell = &q.PlateCols[q.PlateColCount++];
	memcpy_s(cell, sizeof(TPlateCol), &col, sizeof(TPlateCol));
	q.PlateColsMap[cell->Field] = cell;
}

void TQuoteUtils::InitCols()
{
	wchar_t currpath[1024];
	CurrPath(currpath, sizeof(currpath)/sizeof(wchar_t));

	wchar_t filename[1024];
	wsprintf(filename, L"%s\\config\\PolestarQuote\\PolestarQuote.QuoteField.%s.pub", currpath, G_LANG->LangName());

	LoopCSV(filename, this, ParsingColsFuncW, 5);
}

TPlatePage* TQuoteUtils::AddPage(TPlateNoType pno, TPlateNameType pname, TPlateNoType parent)
{
	TPlatePage* pp(NULL);
	for (TPlatePageVectorType::iterator iter = PlatePages.begin(); iter != PlatePages.end(); iter++)
	{
		TPlatePage* c = *iter;
		if (0 == strncmp(c->PlateNo, pno, sizeof(TPlateNoType)-1))
			return NULL;
		if (0 == strncmp(c->PlateNo, parent, sizeof(TPlateNoType)-1))
			pp = c;
	}

	TPlatePage* p = new TPlatePage;
	strncpy_s(p->PlateNo, pno, sizeof(p->PlateNo) - 1);
	wcsncpy_s(p->PlateName, pname, sizeof(p->PlateName) / sizeof(wchar_t)-1);
	p->ParentPlate = pp;
	p->IsSelf = false;
	p->PlateColCount = 0;
	p->PlateGuideCount = 0;
	p->IsOption = (0 == strcmp(p->PlateNo, "OPTION"));

	if (0 == strncmp(p->PlateNo, "SELF", 4))
	{
		if (('\0' == p->PlateNo[4])
			|| ('\0' == p->PlateNo[5] && p->PlateNo[4] >= '0' && p->PlateNo[4] <= '9'))
			p->IsSelf = true;
	}
		
	if (NULL != pp)
		pp->ChildPages.push_back(p);			//�����Ӱ��
	else
		PlatePages.push_back(p);				//���Ӹ����

	return p;
}

TPlatePage* TQuoteUtils::GetPageSelf0(int& nChild,bool bChild, char* pName)
{
	for (size_t i = 0; i < PlatePages.size(); i++)
	{
		TPlatePage* page = PlatePages[i];

		if (bChild&&page->ChildPages.size() > 0)
		{
			for (size_t j = 0; j < page->ChildPages.size(); j++)
			{
				TPlatePage* cpage = page->ChildPages[j];

				if (0 == strcmp(cpage->PlateNo, pName))
				{
					nChild = j;
					return cpage;
				}
			}
		}
		else
		{
			if (0 == strcmp(page->PlateNo, pName))
			{
				return page;
			}
		}
	}

	return NULL;
}

void ParsingPagesFuncW(void* obj, wchar_t* line, int site[], int slen)
{
	//��������
	char item_code[21];
	WideCharToMultiByte(936, 0, &line[site[0]], -1, item_code, sizeof(item_code), 0, 0);

	//��������
	wchar_t item_name[21];
	wcsncpy_s(item_name, &line[site[1]], sizeof(item_name) / sizeof(wchar_t)-1);

	//���������
	char item_parent[21];
	WideCharToMultiByte(936, 0, &line[site[2]], -1, item_parent, sizeof(item_parent), 0, 0);

	//��������
	int item_type = _wtoi(&line[site[3]]);

	TPlatePage* p = ((TQuoteUtils*)obj)->AddPage(item_code, item_name, item_parent);
	if (NULL != p)
		p->LoadCols();
}

void TQuoteUtils::InitPages()
{
	if (m_InitPages)
		return;
	m_InitPages = true;

	InitCols();

	//������ѡ
	/*wchar_t currpath[1024];
	CurrPath(currpath, sizeof(currpath)/sizeof(wchar_t));

	wchar_t filename[1024];
	swprintf_s(filename, L"%s\\config\\PolestarQuote\\PolestarQuote.Plate.%s.pub", currpath, G_LANG->LangName());

	LoopCSV(filename, this, ParsingPagesFuncW, 4);*/
	//����ϵͳ���
	SPlate* oPlants[256];
	int nCont = G_StarApi->GetPlateInfo(0, oPlants, sizeof(oPlants) / sizeof(SPlate*));
	for (int i = 0; i < nCont; i++)
	{
		SPlate* plant = oPlants[i];
		wchar_t PlantName[256];
		MByteToWChar(plant->PlateName, PlantName, sizeof(PlantName) / sizeof(wchar_t));
		TPlatePage* p = AddPage(plant->PlateNo, PlantName, plant->ParentPlateNo);
		if (NULL != p)
			p->LoadCols();
	}
}

void TQuoteUtils::InitRows()
{
	if (m_InitRows)
		return;

	m_InitRows = true;

	for (TPlatePageVectorType::iterator iter = PlatePages.begin(); iter != PlatePages.end(); iter++)
	{
		TPlatePage* c = *iter;
		c->LoadRows();
		if (c->IsOption)
		    c->LoadOptionTarget(); //������Ȩ���
		for (TPlatePageVectorType::iterator citer = c->ChildPages.begin(); citer != c->ChildPages.end(); citer++)
		{
			TPlatePage* cc = *citer;
			cc->LoadRows();
		}
	}

	CalSize();
}

void TQuoteUtils::CalSize()
{
	HDC hdc = GetDC(NULL);
	SelectObject(hdc, FONT_PLATE);

	for (TPlatePageVectorType::iterator iter = PlatePages.begin(); iter != PlatePages.end(); iter++)
	{
		TPlatePage* p = *iter;
		GetTextExtentPoint(hdc, p->PlateName, wcslen(p->PlateName), &p->PlateSize);

		for (size_t i = 0; i < p->ChildPages.size(); i++)
		{
			TPlatePage* c = p->ChildPages[i];
			GetTextExtentPoint(hdc, c->PlateName, wcslen(c->PlateName), &c->PlateSize);
		}

		for (TPlateGuideCountType i = 0; i < p->PlateGuideCount; i++)
		{
			TPlateGuide& g = p->PlateGuides[i];
			wchar_t textCName[51];
			MByteToWChar(g.Row->Contract->Commodity->CommodityName, textCName, sizeof(textCName) / sizeof(wchar_t));
			GetTextExtentPoint(hdc, textCName, wcslen(textCName), &g.GuideSize);
		}
	}
	DeleteDC(hdc);
}

bool TQuoteUtils::GetSpreadContract(SContractNoType con, SSpreadContract& spread)
{
	if (strlen(con) <= 0)
		return false;
	//SContractNoType temp;
	//strcpy_s(temp, con);
	//char *con2 = NULL;
	//const char* con1(strtok_s(temp, "-", &con2));
	//if (con1 != NULL && con2 != NULL&&strlen(con2)>0)
	//{

	//	return G_StarApi->GetSpreadInfo(con1, con2, S_SPREADMODE_DIFF, &spread, 1, false);
	//}
	//else
	//{
	//	con1 = strtok_s(temp, "+", &con2);
	//	if (con1 != NULL && con2 != NULL&&strlen(con2)>0)
	//	{
	//		return G_StarApi->GetSpreadInfo(con1, con2, S_SPREADMODE_SUM, &spread, 1, false);
	//	}
	//	else
	//	{
	//		con1 = strtok_s(temp, "/", &con2);
	//		if (con1 != NULL && con2 != NULL&&strlen(con2)>0)
	//		{

	//			return G_StarApi->GetSpreadInfo(con1, con2, S_SPREADMODE_RATIO, &spread, 1, false);
	//		}
	//	}	
	//}
	return G_StarApi->GetSpreadInfo(con, &spread,1,false,S_SPREADSRC_SELF);
}

void TQuoteUtils::GetSpreadContractNo(const SSpreadContract* spread, SContractNoType& cno)
{
	if (!spread)
		return;
	strcpy_s(cno,spread->ContractNo);
}
TPlatePage::TPlatePage()
{
	OptionSeries = NULL;
}
void TPlatePage::LoadRows()
{
	if (IsSelf)
	{
		char currpath[2048];
		CurrPath(currpath, sizeof(currpath));

		char filename[2048] = {0};

		sprintf_s(filename, "%s\\config\\PolestarQuote\\PolestarQuote.PlateRow.%s.%s", currpath, PlateNo, "pri");

		FILE* file(NULL);
		fopen_s(&file, filename, "r");
		if (NULL == file)
			return;
		std::vector<std::string> items;
		std::set<std::string> itemset;

		//����items�ļ�---------------------------------------------------------------------------------------------
		char buf[1024];
		while (true)
		{
			memset(buf, 0, sizeof(buf));
			char* s = fgets(buf, sizeof(buf), file);
			if (!s) break;

			if ('#' == buf[0])
				continue;
			if (strlen(buf) <= 2)
				continue;

			char* tail = &buf[strlen(buf) - 1];
			if ('\n' == tail[0] || '\r' == tail[0])
				tail[0] = '\0';

			tail = &buf[strlen(buf) - 1];
			if ('\n' == tail[0] || '\r' == tail[0])
				tail[0] = '\0';

			char* sbuf = buf;
			char* field(NULL);
			char* ftail(NULL);
			//
			field = strchr(sbuf, '\"');
			if ((NULL == field) || (strlen(field) < 2))
				continue;

			ftail = strchr(&field[1], '\"');
			if (NULL == ftail)
				continue;
			ftail[0] = '\0';

			items.push_back(&field[1]);

			if (strlen(&ftail[1]) >= 4 && '1' == ftail[3])	//�ڶ����ֶ�Ϊ1Ҫ��ʾԭʼ��Լ
				itemset.insert(&field[1]);
		}

		fclose(file);
		//����rows---------------------------------------------------------------------------------------------
		for (size_t i = 0; i < items.size(); i++)
		{
			std::string& item = items[i];
			const char* str(item.c_str());
			const char* pos1(strchr(str, '|'));
			if (NULL == pos1 || '\0' == pos1[1] || '\0' == pos1[2])
				continue;
			const char* pos2(strchr(&pos1[3], '|'));

			SCommodity* comm(NULL);
			SContractNoType cno = {};
			SContractNoType begin = {};

			if (NULL == pos2)	//Ʒ��
			{
				if (G_StarApi->GetCommodityData(NULL, str, &comm, 1, false) <= 0)
					continue;
			}
			else				//��Լ
			{
				strncpy_s(cno, str, sizeof(SContractNoType) - 1);
				const char* pos3(strchr(pos2, '-'));
				const char* pos4(strchr(pos2, '/'));
				const char* pos5(strchr(pos2, '+'));
				if (pos3 != NULL || pos4 != NULL || pos5 != NULL)
				{
					//����������Լ
					TPlateRow row;
					memset(&row, 0, sizeof(TPlateRow));
					strcpy_s(row.ContractNo, cno);
					row.IsSpread = true;
					row.RowIndex = PlateRows.size();
					SSpreadContract SpreadContract;
					if (G_QuoteUtils.GetSpreadContract(row.ContractNo, SpreadContract))
					{
						PlateRows.push_back(row);
						continue;
					}
				}
			}

			SContract* out[16];
			int cnt;

			do
			{
				cnt = G_StarApi->GetContractData((NULL != comm ? comm->CommodityNo : NULL), ('\0' != cno[0] ? cno : begin), out, sizeof(out) / sizeof(SContract*), ('\0' == cno[0]));

				for (int j = 0; j < cnt; j++)
				{
					//��������
					if (NULL != pos2 && itemset.find(out[j]->ContractNo) != itemset.end()) //��Լ�ж�set
					{
						SContract* under = G_StarApi->GetContractUnderlay(out[j]->ContractNo);

						if (NULL != under)
						{
							TPlateRow row;
							memset(&row, 0, sizeof(TPlateRow));
							row.Contract = under;
							row.IsSpread = false;
							row.RowIndex = PlateRows.size();
							PlateRows.push_back(row);
						}
						else
						{
							TPlateRow row;
							memset(&row, 0, sizeof(TPlateRow));
							row.Contract = out[j];
							row.IsSpread = false;
							row.RowIndex = PlateRows.size();
							PlateRows.push_back(row);
						}
					}
					else
					{
						TPlateRow row;
						memset(&row, 0, sizeof(TPlateRow));
						row.Contract = out[j];
						row.IsSpread = false;
						row.RowIndex = PlateRows.size();
						PlateRows.push_back(row);
					}
				}

				if (cnt == sizeof(out) / sizeof(SContract*))
					strncpy_s(begin, out[cnt - 1]->ContractNo, sizeof(SContractNoType) - 1);

			} while (cnt == sizeof(out) / sizeof(SContract*));
		}
	}
	else
	{
		std::set<std::string> itemset;
		//����rows---------------------------------------------------------------------------------------------
		SPlateContent* oContent[1024];
		int nCont = G_StarApi->GetPlateCode(PlateNo, 0, oContent, sizeof(oContent) / sizeof(SPlateContent*));
		for (size_t i = 0; i < nCont; i++)
		{
			SPlateContent* pCOntract = oContent[i];

			const char* str(pCOntract->PlateCode);
			const char* pos1(strchr(str, '|'));
			if (NULL == pos1 || '\0' == pos1[1] || '\0' == pos1[2])
				continue;
			const char* pos2(strchr(&pos1[3], '|'));

			SCommodity* comm(NULL);
			SContractNoType cno = {};
			SContractNoType begin = {};

			if (pCOntract->ContAttr == S_PCODE_COMMODITY)	//Ʒ��
			{
				if (G_StarApi->GetCommodityData(NULL, pCOntract->PlateCode, &comm, 1, false) <= 0)
					continue;
			}
			else				//��Լ
			{
				strncpy_s(cno, pCOntract->PlateCode, sizeof(SContractNoType) - 1);
				if (!pos2)
					continue;
				const char* pos3(strchr(pos2, '-'));
				const char* pos4(strchr(pos2, '/'));
				if (pos3 != NULL || pos4 != NULL)
				{
					//����������Լ
					TPlateRow row;
					memset(&row, 0, sizeof(TPlateRow));
					strcpy_s(row.ContractNo, cno);
					row.IsSpread = true;
					row.RowIndex = PlateRows.size();
					SSpreadContract SpreadContract;
					if (G_QuoteUtils.GetSpreadContract(row.ContractNo, SpreadContract))
					{
						PlateRows.push_back(row);
						continue;
					}
				}
				if (pCOntract->ContAttr == S_PCODE_VIRTUAL_CONTRACT)
					itemset.insert(cno);
			}

			SContract* out[16];
			int cnt;

			do
			{
				cnt = G_StarApi->GetContractData((NULL != comm ? comm->CommodityNo : NULL), ('\0' != cno[0] ? cno : begin), out, sizeof(out) / sizeof(SContract*), ('\0' == cno[0]));

				for (int j = 0; j < cnt; j++)
				{
					//��������
					if (NULL != pos2 && itemset.find(out[j]->ContractNo) != itemset.end()) //��Լ�ж�set
					{
						SContract* under = G_StarApi->GetContractUnderlay(out[j]->ContractNo);

						if (NULL != under)
						{
							TPlateRow row;
							memset(&row, 0, sizeof(TPlateRow));
							row.Contract = under;
							row.IsSpread = false;
							row.RowIndex = PlateRows.size();
							PlateRows.push_back(row);
						}
						else
						{
							TPlateRow row;
							memset(&row, 0, sizeof(TPlateRow));
							row.Contract = out[j];
							row.IsSpread = false;
							row.RowIndex = PlateRows.size();
							PlateRows.push_back(row);
						}
					}
					else
					{
						TPlateRow row;
						memset(&row, 0, sizeof(TPlateRow));
						row.Contract = out[j];
						row.IsSpread = false;
						row.RowIndex = PlateRows.size();
						PlateRows.push_back(row);
					}
				}

				if (cnt == sizeof(out) / sizeof(SContract*))
					strncpy_s(begin, out[cnt - 1]->ContractNo, sizeof(SContractNoType) - 1);

			} while (cnt == sizeof(out) / sizeof(SContract*));
		}
	}	

	//������� �� �ж�������һ����� ֻ����Row��������Guide
	if (NULL != ParentPlate || !ChildPages.empty())
		return;

	//����guide---------------------------------------------------------------------------------------------
	SCommodity* prev(NULL);
	SCommodity* prev_guide(NULL);

	for (size_t i = 0; i < PlateRows.size(); i++)
	{
		TPlateRow& row = PlateRows[i];

		if (row.IsSpread)
			break;
		if (prev != row.Contract->Commodity && prev_guide != row.Contract->Commodity)
		{
			TPlateGuide* guide = &PlateGuides[PlateGuideCount++];
			guide->Row = &row;
			prev_guide = row.Contract->Commodity->TargetCommodity[0];	
		}

		prev = row.Contract->Commodity;

		//����������ɵ���������
		if (PlateGuideCount >= MAX_PLATEGUIDE_COUNT)
			break;
	}
}


void TPlatePage::SaveRows()
{
	if (!IsSelf)
		return;

	char currpath[2048];
	CurrPath(currpath, sizeof(currpath));

	char filename[2048];
	memset(filename, 0, sizeof(filename));

	sprintf_s(filename, "%s\\config\\PolestarQuote\\PolestarQuote.PlateRow.%s.pri", currpath, PlateNo);

	FILE* file(NULL);
	fopen_s(&file, filename, "w");
	if (NULL == file)
		return;

	for (int i = 0; i < (int)PlateRows.size(); i++)
	{
		fputs("\"", file);
		if (PlateRows[i].IsSpread)
			fputs(PlateRows[i].ContractNo, file);
		else
		    fputs(PlateRows[i].Contract->ContractNo, file);
		fputs("\"\r\n", file);
	}
	fclose(file);
}

void TPlatePage::LoadOptionTarget()
{
	if (!IsOption)
		return;
	char currpath[2048];
	CurrPath(currpath, sizeof(currpath));

	char filename[2048];
	memset(filename, 0, sizeof(filename));

	sprintf_s(filename, "%s\\config\\PolestarQuote\\PolestarQuote.OptionTarget.pri", currpath);

	FILE* file(NULL);
	fopen_s(&file, filename, "r");
	if (NULL == file)
		return;
	char buf[1024];
	memset(buf, 0, sizeof(buf));
	char* s = fgets(buf, sizeof(buf), file);
	if (!s)
	{
		fclose(file);
		return;
	}
	char* tail = &buf[strlen(buf) - 1];
	if ('\n' == tail[0] || '\r' == tail[0])
		tail[0] = '\0';
	G_StarApi->GetOptionSeriesData(NULL, buf, &OptionSeries, 1, false);
	fclose(file);
}

void TPlatePage::SaveOptionTarget()
{
	if (!IsOption|| !OptionSeries)
		return;
	char currpath[2048];
	CurrPath(currpath, sizeof(currpath));

	char filename[2048];
	memset(filename, 0, sizeof(filename));

	sprintf_s(filename, "%s\\config\\PolestarQuote\\PolestarQuote.OptionTarget.pri", currpath);

	FILE* file(NULL);
	fopen_s(&file, filename, "w");
	if (NULL == file)
		return;
	fputs(OptionSeries->SeriesNo, file);

	fclose(file);
}

void TPlatePage::LoadCols()
{
	//1.�ް���������ļ�������ϵͳĬ��������
	char currpath[1024];
	CurrPath(currpath, sizeof(currpath)/sizeof(wchar_t));

	SPlateNoType pTmpNo;
	strcpy_s(pTmpNo, PlateNo);
	int i, j;
	for (int i = j = 0; pTmpNo[i] != '\0'; i++)
		if (pTmpNo[i] != '*')
			pTmpNo[j++] = pTmpNo[i];
	pTmpNo[j] = '\0';

	char filename[1024];
	sprintf_s(filename, "%s\\config\\PolestarQuote\\PolestarQuote.QuoteField.%s.pri", currpath, pTmpNo);

	HANDLE file = CreateFileA(filename, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	if (INVALID_HANDLE_VALUE == file)
	{
		PlateColCount = G_QuoteUtils.PlateColCount;
		memcpy_s(PlateCols, MAX_PLATECOL_COUNT * sizeof(TPlateCol), G_QuoteUtils.PlateCols, MAX_PLATECOL_COUNT * sizeof(TPlateCol));
		return;
	}

	//2.���ļ�������������
	PlateColCount = 0;
	TPlateCol*	colmap[MAX_PLATECOL_COUNT];	//����map�������ļ������ظ��У���������ļ���ȱ�ٵ���
	memcpy_s(colmap, MAX_PLATECOL_COUNT * sizeof(TPlateCol*), G_QuoteUtils.PlateColsMap, MAX_PLATECOL_COUNT * sizeof(TPlateCol*));

	char buf[256];	
	while (true) //���ļ�ѭ��
	{
		memset(buf, 0, sizeof(buf));

		DWORD ret;
		if (!ReadFile(file, buf, sizeof(buf), &ret, 0))
			break;
		if (ret <= 0)
			break;

		char* tail = strchr(buf, '\n');
		if (NULL != tail)
		{
			tail[0] = '\0';
			if (tail[-1] == '\r')
				tail[-1] = '\0';
			long back = ret - ((tail - buf) + 1);
			if (back > 0)
				SetFilePointer(file, (-1) * back, 0, FILE_CURRENT);
		}

		if ('#' == buf[0])
			continue;

		TPlateCol col;

		//�����ֶκ�
		char* field = &buf[1];
		tail = strchr(field, L'"');
		if (NULL == tail) continue;
		tail[0] = L'\0';

		SFidMeanType fid((SFidMeanType)atoi(field));
		if ( fid >= S_FID_MEAN_COUNT)
			continue;
		TPlateCol* pcol = colmap[fid];
		if (NULL == pcol)
			continue;
		colmap[fid] = NULL;	//��ֹ�ظ��б�����
		memcpy_s(&col, sizeof(TPlateCol), pcol, sizeof(TPlateCol));

		//��������
		field = &tail[3];
		tail = strchr(field, L'"');
		if (NULL == tail) continue;
		tail[0] = L'\0';
		col.Width = atoi(field);

		//��������
		field = &tail[3];
		tail = strchr(field, L'"');
		if (NULL == tail) continue;
		tail[0] = L'\0';
		col.Align = atoi(field);

		//������ʾ
		field = &tail[3];
		tail = strchr(field, L'"');
		if (NULL == tail) continue;
		tail[0] = L'\0';
		col.Visible = ('1' == field[0]);

		//
		TPlateCol& cell = PlateCols[PlateColCount++];
		memcpy_s(&cell, sizeof(TPlateCol), &col, sizeof(TPlateCol));

		//���������� ��ҪԽ��
		if (PlateColCount >= MAX_PLATECOL_COUNT)
			break;
	}

	CloseHandle(file);

	//3.���Ӱ�������ļ��е�ȱʧ��
	for (TPlateColCountType i = 0; i < MAX_PLATECOL_COUNT; i++)
	{
		if (PlateColCount >= MAX_PLATECOL_COUNT)
			break;

		TPlateCol* pcol = colmap[i];
		if (NULL != pcol)
		{
			TPlateCol& cell = PlateCols[PlateColCount++];
			memcpy_s(&cell, sizeof(TPlateCol), pcol, sizeof(TPlateCol));
		}
	}
}

void TPlatePage::SaveCols()
{
	char currpath[2048];
	CurrPath(currpath, sizeof(currpath));

	SPlateNoType pTmpNo;
	strcpy_s(pTmpNo, PlateNo);
	int i, j;
	for (int i = j = 0; pTmpNo[i] != '\0'; i++)
		if (pTmpNo[i] != '*')
			pTmpNo[j++] = pTmpNo[i];
	pTmpNo[j] = '\0';

	char filename[1024];
	sprintf_s(filename, "%s\\config\\PolestarQuote\\PolestarQuote.QuoteField.%s.pri", currpath, pTmpNo);
	HANDLE file = CreateFileA(filename, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
	if (INVALID_HANDLE_VALUE == file)
		return;

	for (int i = 0; i < (int)PlateColCount; i++)
	{
		TPlateCol& col = PlateCols[i];
		char buf[128];
		sprintf_s(buf, "\"%d\",\"%d\",\"%d\",\"%d\"\r\n", col.Field, col.Width, col.Align, (col.Visible ? 1 : 0));
		DWORD ret;
		WriteFile(file, buf, strlen(buf), &ret, 0);
	}

	CloseHandle(file);
}

int TPlatePage::GetColScrollCount()
{
	int ret(0);
	for (int i = 0; i < PlateColCount; i++)
	{
		if (PlateCols[i].Visible)
			ret++;
	}
	return ret - 1;
}

int TPlatePage::GetRowScrollCount()
{
	if (IsOption)
	{
			return OptionCallCount;
	}
	else
		return PlateRows.size();

	//return 0;
}

bool TPlatePage::IsRowExisted(SContractNoType cno)
{
	if (!IsSelf)
		return false;
	bool bExist = false;
	for (int i = 0; i < (int)PlateRows.size(); i++)
	{
		if (PlateRows[i].IsSpread)
		{
			if (strcmp(PlateRows[i].ContractNo, cno) == 0)
				bExist = true;
		}
		else
		{
			if (strcmp(PlateRows[i].Contract->ContractNo, cno) == 0)
				bExist = true;
		}
	}
	return bExist;
}

//��������------------------------------------------------------------------------------------------------------------
TQuoteCenter G_QuoteCenter;

void TQuoteCenter::Add_GridControl(TGridControl* control)
{
	if (m_GridSet.empty())
		Start();

	TCriticalSection::Lock lock(m_GridControlCrit);
	m_GridSet.insert(control);
}

void TQuoteCenter::Del_GridControl(TGridControl* control)
{
	TCriticalSection::Lock lock(m_GridControlCrit);
	m_GridSet.erase(control);
}

void TQuoteCenter::Add_PanelControl(TPanelControl* control)
{
	TCriticalSection::Lock lock(m_PanelControlCrit);
	m_PanelSet.insert(control);
}

void TQuoteCenter::Del_PanelControl(TPanelControl* control)
{
	TCriticalSection::Lock lock(m_PanelControlCrit);
	m_PanelSet.erase(control);
}

void TQuoteCenter::Add_KLineControl(TKLineControl* control)
{
	TCriticalSection::Lock lock(m_KLineControlCrit);
	m_KLineSet.insert(control);
}

void TQuoteCenter::Del_KLineControl(TKLineControl* control)
{
	TCriticalSection::Lock lock(m_KLineControlCrit);
	m_KLineSet.erase(control);
}

void TQuoteCenter::Sub_Quote(const SContractNoType contractno)
{
	TCriticalSection::Lock lock(m_SubMapCrit);
	
	TSubContractMapType::iterator iter = m_SubMap.find(contractno);
	if (iter != m_SubMap.end())
	{
		iter->second++;
		return;
	}

	m_SubMap.insert(TSubContractMapType::value_type(contractno, 1));
	SContractNoType conArry[1];
	strcpy_s(conArry[0], contractno);
	G_StarApi->SubQuote(conArry, 1, this);
}

void TQuoteCenter::Unsub_Quote(const SContractNoType contractno)
{
	TCriticalSection::Lock lock(m_SubMapCrit);

	TSubContractMapType::iterator iter = m_SubMap.find(contractno);
	if (iter == m_SubMap.end())
		return;

	if (iter->second > 1)
	{
		iter->second--;
		return;
	}

	m_SubMap.erase(iter);
	SContractNoType conArry[1];
	strcpy_s(conArry[0], contractno);
	G_StarApi->UnsubQuote(conArry, 1, this);
}

bool TQuoteCenter::Sub_HisQuote(const SContractNoType contractno, const SKLineTypeType klinetype, const SKLineSliceType klineslice, const SKLineCountType reqcount, TDuiControl* req)
{
	{
		TCriticalSection::Lock lock(m_HisSubMapCrit);
		std::pair<THisSubContractMapType::iterator, THisSubContractMapType::iterator> pair = m_HisSubMap.equal_range(contractno);

		bool exist(false);
		for (THisSubContractMapType::iterator iter = pair.first; iter != pair.second; iter++)
		{
			if (req == iter->second)
			{
				exist = true;
				break;
			}
		}
		if (!exist)
			m_HisSubMap.insert(THisSubContractMapType::value_type(contractno, req));
	}

	SSessionIdType sessionid;
	int r = G_StarApi->SubHisQuote(contractno, klinetype, klineslice, reqcount, sessionid, this);
	return true;
}

bool TQuoteCenter::Unsub_HisQuote(const SContractNoType contractno, TDuiControl* req)
{
	{
		TCriticalSection::Lock lock(m_HisSubMapCrit);
		std::pair<THisSubContractMapType::iterator, THisSubContractMapType::iterator> pair = m_HisSubMap.equal_range(contractno);

		bool exist(false);
		for (THisSubContractMapType::iterator iter = pair.first; iter != pair.second; )
		{
			if (req == iter->second)
			{
				m_HisSubMap.erase(iter++);
				if (iter != pair.second)
					exist = true;
				break;
			}
			else
			{
				iter++;
				exist = true;
			}
		}

		if (exist)
			return false;
	}

	G_StarApi->UnsubHisQuote(contractno, this);
	return true;
}

bool TQuoteCenter::Sub_HisVolatilityQuote(const SContractNoType contractno, const SKLineTypeType klinetype, const SKLineSliceType klineslice, const SKLineCountType reqcount, TDuiControl* req)
{
	{
		TCriticalSection::Lock lock(m_HisSubMapCrit);
		std::pair<THisSubContractMapType::iterator, THisSubContractMapType::iterator> pair = m_HisVolSubMap.equal_range(contractno);

		bool exist(false);
		for (THisSubContractMapType::iterator iter = pair.first; iter != pair.second; iter++)
		{
			if (req == iter->second)
			{
				exist = true;
				break;
			}
		}
		if (!exist)
			m_HisVolSubMap.insert(THisSubContractMapType::value_type(contractno, req));
	}

	SSessionIdType sessionid;
	int r = G_StarApi->SubHisVolatility(contractno, klinetype, klineslice, reqcount, sessionid, this);
	return true;
}
bool TQuoteCenter::Unsub_HisVolatilityQuote(const SContractNoType contractno, TDuiControl* req)
{
	{
		TCriticalSection::Lock lock(m_HisSubMapCrit);
		std::pair<THisSubContractMapType::iterator, THisSubContractMapType::iterator> pair = m_HisVolSubMap.equal_range(contractno);

		bool exist(false);
		for (THisSubContractMapType::iterator iter = pair.first; iter != pair.second; )
		{
			if (req == iter->second)
			{
				m_HisVolSubMap.erase(iter++);
				if (iter != pair.second)
					exist = true;
				break;
			}
			else
			{
				iter++;
				exist = true;
			}
		}

		if (exist)
			return false;
	}

	G_StarApi->UnsubHisVolatility(contractno, this);
	return true;
}

void TQuoteCenter::OnQuote(const SContract* cont, const SQuoteUpdate* quote)
{
	//FutureControl
	if(quote)
	{
		TCriticalSection::Lock lock(m_GridControlCrit);

		for (TGridControlSetType::iterator iter = m_GridSet.begin(); iter != m_GridSet.end(); iter++)
		{
			TGridControl* control = *iter;
			if (control->Update_Quote(cont, quote))
				control->RedrawLater(NULL);
		}
	}

	//PanelControl �����̿ڱ仯
	{
		TCriticalSection::Lock lock(m_PanelControlCrit);

		for (TPanelControlSetType::iterator iter = m_PanelSet.begin(); iter != m_PanelSet.end(); iter++)
		{
			TPanelControl* control = *iter;
			SContract* contract = control->GetContract();
			if (NULL != contract && cont == contract)
			{
				control->ChgQuote();
				control->RedrawLater(NULL);
			}

		}
	}

}

void TQuoteCenter::OnSpreadQuote(const SSpreadContract* scont)
{
	//FutureControl
	{
		TCriticalSection::Lock lock(m_GridControlCrit);

		for (TGridControlSetType::iterator iter = m_GridSet.begin(); iter != m_GridSet.end(); iter++)
		{
			TGridControl* control = *iter;
			if (control->Update_SpreadQuote(scont))
				control->RedrawLater(NULL);
		}
	}
	//PanelControl �����̿ڱ仯
	{
		TCriticalSection::Lock lock(m_PanelControlCrit);

		for (TPanelControlSetType::iterator iter = m_PanelSet.begin(); iter != m_PanelSet.end(); iter++)
		{
			TPanelControl* control = *iter;
			SContractNoType cno,ncno;
			control->GetSpreadContractNo(cno);
			G_QuoteUtils.GetSpreadContractNo(scont, ncno);
			if (strcmp(cno, ncno)==0)
			{
				control->ChgSpreadQuote(scont);
				control->RedrawLater(NULL);
			}

		}
	}
}

void TQuoteCenter::OnHisQuote(const SContractNoType contractno, const SKLineTypeType klinetype, const SSessionIdType sessionid)
{
	//PanelControl  Tick��ϸ�仯
	if ('\0' == klinetype || S_KLINE_TICK == klinetype)
	{
		TCriticalSection::Lock lock(m_PanelControlCrit);
		for (TPanelControlSetType::iterator iter = m_PanelSet.begin(); iter != m_PanelSet.end(); iter++)
		{
			TPanelControl* control = *iter;
			SContract* contract = control->GetContract();
			if (NULL != contract && 0 == strncmp(contract->ContractNo, contractno, sizeof(SContractNoType)-1))
			{
				control->ChgTick();
				control->RedrawLater(NULL);
			}

		}
	}
	if (S_KLINE_DAY == klinetype)
	{
		TCriticalSection::Lock lock(m_GridControlCrit);

		for (TGridControlSetType::iterator iter = m_GridSet.begin(); iter != m_GridSet.end(); iter++)
		{
			TGridControl* control = *iter;
			if (control->Update_HisQuote(contractno))
				control->RedrawLater(NULL);
		}
	}
	//KLineControl	 ���Ӻ����߱仯
	if ('\0' == klinetype) //�����������
	{
		TCriticalSection::Lock lock(m_KLineControlCrit);
		for (TKLineControlSetType::iterator iter = m_KLineSet.begin(); iter != m_KLineSet.end(); iter++)
		{
			TKLineControl* control = *iter;
			if (control->Update_Data(contractno))
			{
				control->RedrawLater(NULL);
			}
		}

	}
	else// if (RAW_KLINE_TICK == klinetype || RAW_KLINE_MINUTE == klinetype || RAW_KLINE_DAY == klinetype) //���ݲ�ѯ����
	{
		TCriticalSection::Lock lock(m_KLineControlCrit);
		for (TKLineControlSetType::iterator iter = m_KLineSet.begin(); iter != m_KLineSet.end(); iter++)
		{
			TKLineControl* control = *iter;
			if (control->Reload_Data(contractno))
			{
				control->RedrawLater(NULL);
			}
		}
	}
}
void TQuoteCenter::OnHisVolatility(const SContractNoType contractno, const SKLineTypeType klinetype, const SSessionIdType sessionid)
{
	//KLineControl	 ���Ӻ����߱仯
	if ('\0' == klinetype) //�����������
	{
		TCriticalSection::Lock lock(m_KLineControlCrit);
		for (TKLineControlSetType::iterator iter = m_KLineSet.begin(); iter != m_KLineSet.end(); iter++)
		{
			TKLineControl* control = *iter;
			if (control->Update_HisVolatilityData(contractno))
			{
				control->RedrawLater(NULL);
			}
		}

	}
	else// if (RAW_KLINE_TICK == klinetype || RAW_KLINE_MINUTE == klinetype || RAW_KLINE_DAY == klinetype) //���ݲ�ѯ����
	{
		TCriticalSection::Lock lock(m_KLineControlCrit);
		for (TKLineControlSetType::iterator iter = m_KLineSet.begin(); iter != m_KLineSet.end(); iter++)
		{
			TKLineControl* control = *iter;
			if (control->Reload_HisVolatilityData(contractno))
			{
				control->RedrawLater(NULL);
			}
		}
	}
}

void TQuoteCenter::OnStrategyNotice(const TStrategyOrder *pdata)
{
	TCriticalSection::Lock lock(m_KLineControlCrit);
	for (TKLineControlSetType::iterator iter = m_KLineSet.begin(); iter != m_KLineSet.end(); iter++)
	{
		TKLineControl* control = *iter;
		if (NULL == pdata || control->CheckContract(pdata->sContractId))
		{
			control->RedrawLater(NULL);
		}
	}
}
void TQuoteCenter::OnSpreadInfoNotice(const TSpreadOrder *pspread)
{
	TCriticalSection::Lock lock(m_KLineControlCrit);
	for (TKLineControlSetType::iterator iter = m_KLineSet.begin(); iter != m_KLineSet.end(); iter++)
	{
		SContractNoType ContractNo;
		G_LineOrderApi->GetSSpreadContractNo(ContractNo,pspread);
		TKLineControl* control = *iter;
		if (NULL == pspread || control->CheckContract(ContractNo))
		{
			control->RedrawLater(NULL);
		}
	}
}
void TQuoteCenter::OnPositionNotice(const TPosition *pdata)
{
	TCriticalSection::Lock lock(m_KLineControlCrit);
	for (TKLineControlSetType::iterator iter = m_KLineSet.begin(); iter != m_KLineSet.end(); iter++)
	{
		TKLineControl* control = *iter;

		char contractid[128];
		if (NULL != pdata)
		{
			if(ctOption == pdata->CommodityType)
				sprintf_s(contractid, "%s|%c|%s|%s%c%s", pdata->ExchangeNo, pdata->CommodityType, pdata->CommodityNo, pdata->ContractNo, pdata->OptionType, pdata->StrikePrice);
			else
				sprintf_s(contractid, "%s|%c|%s|%s", pdata->ExchangeNo, pdata->CommodityType, pdata->CommodityNo, pdata->ContractNo);
		}

		if (NULL == pdata || control->CheckContract(contractid))
		{
			control->RedrawLater(NULL);
		}
	}
}

void TQuoteCenter::OnStopInfoToPosition(const TPosition *p)
{
	OnPositionNotice(p);
}

void TQuoteCenter::Run()
{
	while (!isTerminated())
	{
		Sleep(500);
		TCriticalSection::Lock lock(m_GridControlCrit);

		for (TGridControlSetType::iterator iter = m_GridSet.begin(); iter != m_GridSet.end(); iter++)
		{
			TGridControl* control = *iter;
			if (control->IsNeed_Resume())
				control->RedrawLater(NULL);
		}
	}
}

//����������Ϣ=============================================================================================================
void TKLineContract::Init(TDuiControl* ctl)
{
	Ctl = ctl;

	MainChart = MAIN_CHART_KLINE;
	KLineShape = 5;

	PreKLineType = S_KLINE_DAY;
	PreKLineSlice = 1;
	PreKLineSRate = 1;
	PreKLineTail = 0;

	KLineType = S_KLINE_DAY;
	KLineSlice = 1;
	KLineSRate = 1;
	KLineTail = 0;
	EndTime = 0;
	InitData();
}

void TKLineContract::InitData()
{
	Cont = NULL;
	Tick = 1;
	Nume = 1;
	Deno = 1;
	Prec = 0;
	/*BaseCount = 1;
	CalCount = 1;
	
	Cont2 = NULL;
	Tick2 = 1;
	Nume2 = 1;
	Deno2 = 1;
	Prec2 = 0;
	BaseCount2 = 1;
	CalCount2 = 1;*/
	IsSpread = false;
	IsReload = false;
	KLineData.Init();
}

bool TKLineContract::RegContract(SContract* contract)
{
	if (!IsSpread&&Cont == contract)
		return false;

	SContract* old_cont(NULL);
	if (IsSpread)
	{
		IsSpread = false;
		G_QuoteCenter.Unsub_HisQuote(SpreadNo, Ctl);
	}
	//ˢ�º�Լ
	{
		TCriticalSection::Lock lock(Crit);
		old_cont = Cont;
		Cont = contract;
		KLineData.Init();
	}

	if (NULL != contract)
	{
		Nume = contract->Commodity->PriceNume;
		Deno = contract->Commodity->PriceDeno;
		Tick = contract->Commodity->PriceTick;
		Prec = contract->Commodity->PricePrec;
		SpreadPrec = 0;
		SpreadTick = contract->Commodity->PriceTick;
	//	BaseCount = G_QuoteApi->GetBaseTimeBucketCount(contract->Commodity->CommodityNo);
	//	CalCount = G_QuoteApi->GetCalTimeBucketCount(contract->Commodity->CommodityNo);
	}

	if (NULL != old_cont)
	{
		if (old_cont->Commodity->CommodityType == S_COMMODITYTYPE_OPTION)
			G_QuoteCenter.Unsub_HisVolatilityQuote(old_cont->ContractNo, Ctl);
		G_QuoteCenter.Unsub_HisQuote(old_cont->ContractNo, Ctl);
	}

	return true;
}

bool TKLineContract::CheckContract(const SContractNoType contractno)
{
	if (IsSpread)
	{
		return (0 == strncmp(SpreadNo, contractno, sizeof(SContractNoType) - 1));
	}
	TCriticalSection::Lock lock(Crit);
	if (NULL == Cont)
		return false;
	return (0 == strncmp(Cont->ContractNo, contractno, sizeof(SContractNoType)-1));
}

bool TKLineContract::RegSpreadContract(const SContractNoType contractno)
{
	if (IsSpread)
	{
		G_QuoteCenter.Unsub_HisQuote(SpreadNo, Ctl);
	}
	else
	{
		if (Cont)
		{
			if (Cont->Commodity->CommodityType == S_COMMODITYTYPE_OPTION)
				G_QuoteCenter.Unsub_HisVolatilityQuote(Cont->ContractNo, Ctl);
			G_QuoteCenter.Unsub_HisQuote(Cont->ContractNo, Ctl);
		}
		IsSpread = true;
	}
	{
		TCriticalSection::Lock lock(Crit);
		strcpy_s(SpreadNo, contractno);
	}
	SSpreadContract SpreadContract;
	if (G_QuoteUtils.GetSpreadContract(SpreadNo, SpreadContract))
	{
		TCriticalSection::Lock lock(Crit);
		Cont = SpreadContract.Contract[0];
		KLineData.Init();
		SpreadPrec = SpreadContract.PricePrec;
		SpreadTick = SpreadContract.PriceTick;
		Nume = SpreadContract.Contract[0]->Commodity->PriceNume;
		Deno = SpreadContract.Contract[0]->Commodity->PriceDeno;
		Tick = SpreadContract.Contract[0]->Commodity->PriceTick;
		Prec = SpreadContract.Contract[0]->Commodity->PricePrec;
	}
	return true;
}

bool TKLineContract::SubContract()
{
	if (IsSpread)
	{
		return G_QuoteCenter.Sub_HisQuote(SpreadNo, KLineType, KLineSlice, KLineSRate * (KLineTail + MAX_SHOW_KLINE_X), Ctl);
	}
	if (NULL == Cont)
		return false;

	//�˴�ֱ��ʹ��������ʾk�ߵ�����������ɽ�һ���Ż�������ʾ
	//�����Ż�Ϊ����ʵ����ʾ���ᵼ�´˴������ڽ���Ĵ�С�����Ӷȴ�����
	if(Cont->Commodity->CommodityType == S_COMMODITYTYPE_OPTION)
		G_QuoteCenter.Sub_HisVolatilityQuote(Cont->ContractNo, KLineType, KLineSlice, KLineSRate * (KLineTail + MAX_SHOW_KLINE_X), Ctl);
	return G_QuoteCenter.Sub_HisQuote(Cont->ContractNo, KLineType, KLineSlice, KLineSRate * (KLineTail + MAX_SHOW_KLINE_X), Ctl);
}

void TKLineContract::UnsubContract()
{
	if (IsSpread)
	{
		G_QuoteCenter.Unsub_HisQuote(SpreadNo, Ctl);
		return;
	}
	SContract* old_cont(NULL);
	{
		TCriticalSection::Lock lock(Crit);
		old_cont = Cont;
	}

	if (NULL != old_cont)
	{
		if(old_cont->Commodity->CommodityType == S_COMMODITYTYPE_OPTION)
			G_QuoteCenter.Unsub_HisVolatilityQuote(old_cont->ContractNo, Ctl);
		G_QuoteCenter.Unsub_HisQuote(old_cont->ContractNo, Ctl);
	}
}

bool TKLineContract::ReloadData()
{
	SContract* contract;
	SKLineTypeType ktype;
	SKLineSliceType slice;
	SKLineIndexType tail;
	SKLineSampleRateType srate;
	
	{
		TCriticalSection::Lock lock(Crit);
		contract = Cont;
		ktype = KLineType;
		slice = KLineSlice;
		tail = KLineTail;
		srate = KLineSRate;
	}
	if (NULL == contract)
		return false;

	SHisQuoteData rdata[MAX_SHOW_KLINE_X];
	int rsize(sizeof(rdata) / sizeof(SHisQuoteData));
	rsize = G_StarApi->GetHisQuote(IsSpread?SpreadNo:contract->ContractNo, ktype, slice, srate, tail, rdata, rsize);


	//�ײ����ݹ����ǵ��򣬱��ػ�����ѭ�����飬load��ǰ׷�ӣ�update���׷��
	TCriticalSection::Lock lock(Crit);
	IsReload = true;
	KLineData.AddData(rdata, rsize);
	EndTime = KLineData.Tail().DateTimeStamp;
	return true;
}

bool TKLineContract::UpdateData()
{
	SContract* contract;
	SKLineTypeType ktype;
	SKLineSliceType slice;
	SKLineIndexType tail;
	SKLineSampleRateType srate;
	
	{
		TCriticalSection::Lock lock(Crit);
		contract = Cont;
		ktype = KLineType;
		slice = KLineSlice;
		tail = KLineTail;
		srate = KLineSRate;
	}

	if (NULL == contract)
		return false;

	SHisQuoteData rdata[1];
	int rsize(sizeof(rdata) / sizeof(SHisQuoteData));

	rsize = G_StarApi->GetHisQuote(IsSpread ? SpreadNo : contract->ContractNo, ktype, slice, srate, tail, rdata, rsize);
	if (rsize < 1)
		return false;

	TCriticalSection::Lock lock(Crit);
	KLineData.AppendData(rdata[0]);
	EndTime = KLineData.Tail().DateTimeStamp;
	return IsReload; // �����һ�����ݣ����ܷ���true��������̬ˢ�½���
}

bool TKLineContract::UpdateHisVolatilityData()
{
	SContract* contract;
	SKLineTypeType ktype;
	SKLineSliceType slice;
	SKLineIndexType tail;
	SKLineSampleRateType srate;

	{
		TCriticalSection::Lock lock(Crit);
		contract = Cont;
		ktype = KLineType;
		slice = KLineSlice;
		tail = KLineTail;
		srate = KLineSRate;
	}

	if (NULL == contract)
		return false;

	SHisVolatilityData rdata[1];
	int rsize(sizeof(rdata) / sizeof(SHisVolatilityData));

	rsize = G_StarApi->GetHisVolatility(contract->ContractNo, ktype, slice, srate, EndTime, rdata, rsize);
	if (rsize < 1)
		return false;

	TCriticalSection::Lock lock(Crit);

	SHisVolatilityData& s = rdata[0];

	if (!HisVolatilityData.IsEmpty())	//�����ݣ��ж��Ƿ���������Ҫ��
	{
		SHisVolatilityData& c = HisVolatilityData.Tail();

		if (s.DateTimeStamp < c.DateTimeStamp)
			return false;
		if (s.DateTimeStamp == c.DateTimeStamp && s.KLineIndex < c.KLineIndex)
			return false;

		if (s.DateTimeStamp == c.DateTimeStamp && s.KLineIndex == c.KLineIndex)
		{
			c = s;
			return IsReload;
		}
	}

	//��������
	if (HisVolatilityData.Backward())
		HisVolatilityData.Curr() = s;
	return IsReload; // �����һ�����ݣ����ܷ���true��������̬ˢ�½���
}
bool TKLineContract::ReloadHisVolatilityData()
{
	SContract* contract;
	SKLineTypeType ktype;
	SKLineSliceType slice;
	SKLineIndexType tail;
	SKLineSampleRateType srate;

	{
		TCriticalSection::Lock lock(Crit);
		contract = Cont;
		ktype = KLineType;
		slice = KLineSlice;
		tail = KLineTail;
		srate = KLineSRate;
	}
	if (NULL == contract)
		return false;

	SHisVolatilityData rdata[MAX_SHOW_KLINE_X];
	int rsize(sizeof(rdata) / sizeof(SHisVolatilityData));
	rsize = G_StarApi->GetHisVolatility(contract->ContractNo, ktype, slice, srate, EndTime, rdata, rsize);


	//�ײ����ݹ����ǵ��򣬱��ػ�����ѭ�����飬load��ǰ׷�ӣ�update���׷��
	TCriticalSection::Lock lock(Crit);
	IsReload = true;
	HisVolatilityData.ReadIndex = 0;
	HisVolatilityData.WriteIndex = 0;

	for (int i = 0; i < rsize; i++)
	{
		SHisVolatilityData& s = rdata[i];

		if (!HisVolatilityData.IsEmpty())	//�����ݣ��ж��Ƿ���������Ҫ��
		{
			SHisVolatilityData& c = HisVolatilityData.Data[HisVolatilityData.ReadIndex];
			if (s.DateTimeStamp > c.DateTimeStamp)
				continue;
			if (s.DateTimeStamp == c.DateTimeStamp && s.KLineIndex >= c.KLineIndex)	//��ʱ��tick����ʱ�����ȣ���Ҫ�ж�KLineIndex
				continue;
		}

		if (!HisVolatilityData.Forward())
			break;

		HisVolatilityData.Curr() = s;
	}
	return true;
}
bool TKLineContract::SubAndReload()
{
	if (!SubContract())
	{
		return false;
	}
	bool ret = ReloadData();
	if (Cont->Commodity->CommodityType == S_COMMODITYTYPE_OPTION)
		ReloadHisVolatilityData();
	return ret;
}

int TKLineContract::GetCfgMenuIndex()
{
	if (MAIN_CHART_TLINE == MainChart)
		return TLI_KLINE_TIME;

	if (S_KLINE_TICK == KLineType)
	{
		switch (KLineSlice)
		{
			case 5:
				return TLI_KLINE_SEC5;
			case 10:
				return TLI_KLINE_SEC10;
			case 15:
				return TLI_KLINE_SEC15;
			case 30:
				return TLI_KLINE_SEC30;
			default:
				return TLI_KLINE_TICK;

		}
	}
	else if (S_KLINE_MINUTE == KLineType)
	{
		switch (KLineSlice)
		{
		case 3:
			return TLI_KLINE_MIN3;
		case 5:
			return TLI_KLINE_MIN5;
		case 10:
			return TLI_KLINE_MIN10;
		case 15:
			return TLI_KLINE_MIN15;
		case 30:
			return TLI_KLINE_MIN30;
		case 60:
			return TLI_KLINE_HOUR1;
		default:
			return TLI_KLINE_MIN1;
		}
	}
	else
	{
		switch (KLineSlice)
		{
		case 7:
			return TLI_KLINE_WEEK1;
		case 30:
			return TLI_KLINE_MONTH1;
		case 255:
			return TLI_KLINE_YEAR1;
		default:
			return TLI_KLINE_DAY1;
		}
	}
}

void TKLineContract::SwitchByMenu(int index)
{
	TCriticalSection::Lock lock(Crit);
	MainChart = (TLI_KLINE_TIME == index) ? MAIN_CHART_TLINE : MAIN_CHART_KLINE;	//����ͼΪKline��ͼ����

	switch (index)
	{
	case TLI_KLINE_TIME:
		KLineType = S_KLINE_MINUTE;
		KLineSlice = 1;
		break;
	case TLI_KLINE_TICK:
		KLineType = S_KLINE_TICK;
		KLineSlice = 0;
		break;

	case TLI_KLINE_SEC5:
		KLineType = S_KLINE_TICK;
		KLineSlice = 5;
		break;
	case TLI_KLINE_SEC10:
		KLineType = S_KLINE_TICK;
		KLineSlice = 10;
		break;
	case TLI_KLINE_SEC15:
		KLineType = S_KLINE_TICK;
		KLineSlice = 15;
		break;
	case TLI_KLINE_SEC30:
		KLineType = S_KLINE_TICK;
		KLineSlice = 30;
		break;

	case TLI_KLINE_MIN1:
		KLineType = S_KLINE_MINUTE;
		KLineSlice = 1;
		break;
	case TLI_KLINE_MIN3:
		KLineType = S_KLINE_MINUTE;
		KLineSlice = 3;
		break;
	case TLI_KLINE_MIN5:
		KLineType = S_KLINE_MINUTE;
		KLineSlice = 5;
		break;
	case TLI_KLINE_MIN10:
		KLineType = S_KLINE_MINUTE;
		KLineSlice = 10;
		break;
	case TLI_KLINE_MIN15:
		KLineType = S_KLINE_MINUTE;
		KLineSlice = 15;
		break;
	case TLI_KLINE_MIN30:
		KLineType = S_KLINE_MINUTE;
		KLineSlice = 30;
		break;
	case TLI_KLINE_HOUR1:
		KLineType = S_KLINE_MINUTE;
		KLineSlice = 60;
		break;

	case TLI_KLINE_DAY1:
		KLineType = S_KLINE_DAY;
		KLineSlice = 1;
		break;
	case TLI_KLINE_WEEK1:
		KLineType = S_KLINE_DAY;
		KLineSlice = 7;
		break;
	case TLI_KLINE_MONTH1:
		KLineType = S_KLINE_DAY;
		KLineSlice = 30;
		break;
	case TLI_KLINE_YEAR1:
		KLineType = S_KLINE_DAY;
		KLineSlice = 255;
		break;

	default:
		break;
	}

	KLineTail = 0;
	IsReload = false;
}
void TKLineContract::SwitchByCustom(TKLinePeriod prd)
{
	TCriticalSection::Lock lock(Crit);
	MainChart = MAIN_CHART_KLINE;
	if (prd.kind == 1)
	{
		KLineType = S_KLINE_TICK;
		KLineSlice = prd.multi;
	}
	else if (prd.kind == 2)
	{
		KLineType = S_KLINE_MINUTE;
		KLineSlice = prd.multi;
	}
	else if (prd.kind == 3)
	{
		KLineType = S_KLINE_MINUTE;
		KLineSlice = prd.multi*60;
	}
	else if (prd.kind == 4)
	{
		KLineType = S_KLINE_DAY;
		KLineSlice = prd.multi;
	}
	KLineTail = 0;
	IsReload = false;
}
void TKLineContract::SwitchTLine()
{
	if (MAIN_CHART_TLINE == MainChart)
		return;

	TCriticalSection::Lock lock(Crit);
	
	PreKLineType = KLineType;
	PreKLineSlice = KLineSlice;
	PreKLineTail = KLineTail;
	PreKLineSRate = KLineSRate;
	
	MainChart = MAIN_CHART_TLINE;
	KLineType = S_KLINE_MINUTE;
	KLineSlice = 1;
	KLineTail = 0;
	KLineSRate = 1;
}

void TKLineContract::SwitchKLine()
{
	if (MAIN_CHART_KLINE == MainChart)
		return;

	TCriticalSection::Lock lock(Crit);

	MainChart = MAIN_CHART_KLINE;	
	KLineType = PreKLineType;
	KLineSlice = PreKLineSlice;
	KLineTail = PreKLineTail;
	KLineSRate = PreKLineSRate;
}

bool TKLineContract::KLineZoomIn(int nTail)
{
	if (MAIN_CHART_KLINE != MainChart || NULL == Cont)
		return false;

	TCriticalSection::Lock lock(Crit);

	KLineTail = nTail;
	//�Ŵ�ͼ�Σ����Ͳ����ʣ����K����̬
	if (KLineSRate > 1)
	{
		KLineSRate --;
		if (KLineSRate < 1)
			KLineSRate = 1;
		KLineShape = 0;
	}
	else if (KLineShape < sizeof(G_QuoteUtils.KLineShapes) / sizeof(TKLineShapeType) - 1)
	{
		KLineShape++;
	}
	else
	{
		return false;
	}
	bool ret = ReloadData();
	if (Cont->Commodity->CommodityType == S_COMMODITYTYPE_OPTION)
		ReloadHisVolatilityData();
	return ret;
}
bool TKLineContract::Amplification(int nTail,int nRate,int nShape)
{
	if (MAIN_CHART_KLINE != MainChart || NULL == Cont)
		return false;

	TCriticalSection::Lock lock(Crit);

	KLineTail = nTail;
	KLineSRate = nRate;
	KLineShape = nShape;
	
	bool ret = ReloadData();
	if (Cont->Commodity->CommodityType == S_COMMODITYTYPE_OPTION)
		ReloadHisVolatilityData();
	return ret;
}

bool TKLineContract::KLineZoomOut(int nTail)
{
	if (MAIN_CHART_KLINE != MainChart || NULL == Cont)
		return false;

	TCriticalSection::Lock lock(Crit);

	KLineTail = nTail;
	//��Сͼ�Σ���������ʣ�����K����̬
	if (KLineShape > 0)
	{
		KLineShape--;
		KLineSRate = 1;
	}
	else if (KLineSRate < 4)
	{
		KLineSRate ++;
		KLineShape = 0;
	}
	else
		return false;

	return SubAndReload();
}

bool TKLineContract::CopyTo(TKLineData& dst)
{
	TCriticalSection::Lock lock(Crit);	
	if (NULL == Cont)
		return false;
	memcpy_s(&dst, sizeof(TKLineData), &KLineData, sizeof(TKLineData));
	return true;
}

bool TKLineContract::IsTick()
{
	return (S_KLINE_TICK == KLineType && 0 == KLineSlice);

}
void TKLineContract::UniqueContract(char* pStr,int nLen)
{
	if (NULL == Cont)
		return;
	sprintf_s(pStr, nLen, "%s_%c_%c", Cont->ContractNo, KLineSlice, KLineType);

}
bool TKLineContract::IsEpoleStarSpreadContract()
{
	if (IsSpread)
		return true;
	if (Cont && (Cont->Commodity->CommodityType == S_COMMODITYTYPE_SPDMON || Cont->Commodity->CommodityType == S_COMMODITYTYPE_SPDCOM))
		return true;
	return false;
}
int TKLineAxisX::GetXValueByTime(SDateTimeType time)
{
	if (KData.Size() <= 0)
		return 0;
	int ret = KData.SearchIndexByTime(time);
	if (ret != 0)
		return ret - Begin;
	return ret;
}
int TKLineAxisX::Pix2Value(int pix)
{
	int nWidth =  DataWidth[0];
	if (pix > 0&& nWidth!=0)
	{
		int nSize = (End - Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		return min(nSize, pix / nWidth) ;
		//return pix / nWidth;
	}
	return 0;
}
int TKLineAxisX::Value2Pix(int nInd)
{
	int nWidth = DataWidth[0];
	return nInd *nWidth;
}
#include"PreInclude.h"


CFormulaResultItem::CFormulaResultItem()
	:m_nStyle(dsDEFAULT), m_nLineThick(0), m_nColor(-1)
{
	m_pDataArray = NULL;
	m_nDrawType = 0;
	m_pFncDrawItem = NULL;
}

CFormulaResultItem::~CFormulaResultItem()
{

}


CIndex::CIndex():m_nCodeSize(0), m_pCode(NULL)
{
}


CIndex::~CIndex()
{
}
void CIndex::SetParam(int index, TKLineSpecParam& param)
{
	if (index < sizeof(m_Params) / sizeof(TKLineSpecParam))
	{
		m_Params[index] = param;
    }
}

TKLineSpecParam& CIndex::GetParam(int index)
{
	TKLineSpecParam ret;
	if (index < sizeof(m_Params) / sizeof(TKLineSpecParam))
		ret = m_Params[index];
	return ret;
}

void CIndex::ClearArrays()
{
	if (m_pCode)
	{
		m_nCodeSize = 0;
		delete[] m_pCode;
		m_pCode = NULL;
	}
	for (size_t i = 0; i<m_References.size(); i++)
		delete m_References[i];
	m_References.clear();
	for (size_t i = 0; i<m_ResultItems.size(); i++)
		delete m_ResultItems[i];
	m_ResultItems.clear();
}
uint CIndex::GetStringLength(FILE* file)
{
	ULONGLONG qwLength;
	DWORD dwLength;
	WORD wLength;
	BYTE bLength;

	bLength = fgetc(file);
	if (bLength < 0xff)
		return bLength;
	fread_s(&wLength, sizeof(WORD), sizeof(WORD), 1, file);
	if (wLength < 0xffff)
		return wLength;
	fread_s(&dwLength, sizeof(DWORD), sizeof(DWORD), 1, file);
	if (dwLength < 0xffffffff)
		return dwLength;
	fread_s(&qwLength, sizeof(ULONGLONG), sizeof(ULONGLONG), 1, file);
	return qwLength;
}
void  CIndex::Serialize(FILE* file, bool bLoad,int type)
{
	if (bLoad)
	{
		int nlength = GetStringLength(file);
		char strNmae[256] = "";
		fread_s(strNmae, sizeof(strNmae), sizeof(char), nlength, file);
		int nCodeLen = 0, nNum = 0;
		fread_s(&nCodeLen, sizeof(int), sizeof(int), 1, file);
		memset(&CompressInBuffer, 0, sizeof(CompressInBuffer));
		fread_s(CompressInBuffer, sizeof(CompressInBuffer), sizeof(char), nCodeLen, file);
		nCodeLen = LzhCompress.LzhDecodeMemory(CompressInBuffer, nCodeLen, CompressOutBuffer, COMPRESS_BUFFER_LEN);
		m_nCodeSize = nCodeLen / sizeof(CODE);
		m_pCode = new CODE[m_nCodeSize];
		memcpy(m_pCode, CompressOutBuffer, nCodeLen);
		fread_s(&nCodeLen, sizeof(int), sizeof(int), 1, file);
		if (nCodeLen > 0)
		{
			fread_s(CompressInBuffer, sizeof(CompressInBuffer), sizeof(char), nCodeLen, file);
		}
		DWORD	dwKey;
		fread_s(&dwKey, sizeof(DWORD), sizeof(DWORD), 1, file);
		if (dwKey)
		{
			fread_s(&nCodeLen, sizeof(int), sizeof(int), 1, file);
			if (nCodeLen > 0)
				fread_s(CompressInBuffer, sizeof(CompressInBuffer), sizeof(char), nCodeLen, file);
		}
		else
		{
			fread_s(&nCodeLen, sizeof(int), sizeof(int), 1, file);
			fread_s(CompressInBuffer, sizeof(CompressInBuffer), sizeof(char), nCodeLen, file);
			CompressInBuffer[nCodeLen] = '\0';
			m_strFnc = CompressInBuffer;
		}
		fread_s(&nNum, sizeof(int), sizeof(int), 1, file);
		for (int i = 0; i < nNum; i++)
		{
			REFRERNCE* pReferenceItem = new REFRERNCE;
			nlength = GetStringLength(file);
			fread_s(pReferenceItem->strFmlName, sizeof(pReferenceItem->strFmlName), sizeof(char), nlength, file);
			nlength = GetStringLength(file);
			fread_s(pReferenceItem->strVarName, sizeof(pReferenceItem->strVarName), sizeof(char), nlength, file);
			m_References.push_back(pReferenceItem);
		}
		fread_s(&nNum, sizeof(int), sizeof(int), 1, file);
		for (int i = 0; i<nNum; i++)
		{
			CFormulaResultItem* pResultItem = new CFormulaResultItem;
			nlength = GetStringLength(file);
			fread_s(pResultItem->m_strName, sizeof(pResultItem->m_strName), sizeof(char), nlength, file);
			fread_s(&pResultItem->m_nStyle, sizeof(WORD), sizeof(WORD), 1, file);
			fread_s(&pResultItem->m_nLineThick, sizeof(WORD), sizeof(WORD), 1, file);
			fread_s(&pResultItem->m_nColor, sizeof(int), sizeof(int), 1, file);
			if (pResultItem->m_nColor == 0)
				pResultItem->m_nColor = -1;
			m_ResultItems.push_back(pResultItem);
		}
		nlength = GetStringLength(file);
		char strVarNmae[256] = "";
		fread_s(strVarNmae, sizeof(strVarNmae), sizeof(char), nlength, file);
		strVarNmae[nlength] = '\0';
		m_strVarNames = strVarNmae;
		fread_s(&m_nNumParam, sizeof(int), sizeof(int), 1, file);
		for (int i = 0; i < m_nNumParam; i++)
		{
			nlength = GetStringLength(file);
			char name[11] = "";
			fread_s(name, sizeof(name), sizeof(char), nlength, file);
			float ftmp = 0.0;
			fread_s(&ftmp, sizeof(float), sizeof(float), 1, file);
			fread_s(&ftmp, sizeof(float), sizeof(float), 1, file);
			fread_s(&ftmp, sizeof(float), sizeof(float), 1, file);
			fread_s(&ftmp, sizeof(float), sizeof(float), 1, file);
		}
		nlength = GetStringLength(file);
		char strTmp[2048] = "";
		fread_s(strTmp, sizeof(strTmp), sizeof(char), nlength, file);
		strTmp[nlength] = '\0';
		m_strParamWizard = strTmp;

		nlength = GetStringLength(file);
		fread_s(strTmp, sizeof(strTmp), sizeof(char), nlength, file);
		strTmp[nlength] = '\0';
		m_strNotes = strTmp;

		nlength = GetStringLength(file);
		fread_s(strTmp, sizeof(strTmp), sizeof(char), nlength, file);
		strTmp[nlength] = '\0';
		m_strDescript = strTmp;

		nlength = GetStringLength(file);
		fread_s(strTmp, sizeof(strTmp), sizeof(char), nlength, file);
		strTmp[nlength] = '\0';
		m_strGroup = strTmp;
		fread_s(&m_wForbidenPeriod, sizeof(WORD), sizeof(WORD), 1, file);
		fread_s(&m_nDefaultPeriod, sizeof(int), sizeof(int), 1, file);
		fread_s(&m_bSystem, sizeof(BOOL), sizeof(BOOL), 1, file);
		fread_s(&m_wProperty, sizeof(WORD), sizeof(WORD), 1, file);
		nlength = GetStringLength(file);
		fread_s(strTmp, sizeof(strTmp), sizeof(char), nlength, file);
		strTmp[nlength] = '\0';
		m_strDrawStrings = strTmp;
		DWORD dwVersion = 0x101;
		fread_s(&dwVersion, sizeof(DWORD), sizeof(DWORD), 1, file);
		if (dwVersion == 0x100)//�ɰ�
		{
			
		}
		else//��
		{
			fread_s(&m_lExpireTm, sizeof(__time64_t), sizeof(__time64_t), 1, file);
			nlength = GetStringLength(file);
			fread_s(strTmp, sizeof(strTmp), sizeof(char), nlength, file);
			strTmp[nlength] = '\0';
			m_strLimitUser = strTmp;
			fread_s(&m_bExport, sizeof(BOOL), sizeof(BOOL), 1, file);
			for (int i = 0; i<32; i++)
				fread_s(&m_Reserved[i], sizeof(BYTE), sizeof(BYTE), 1, file);
			
		}
		if (type == 0)
		{
			fread_s(&m_bMainChart, sizeof(BOOL), sizeof(BOOL), 1, file);
			fread_s(&nNum, sizeof(int), sizeof(int), 1, file);
			for (int i = 0; i < nNum; i++)
			{
				float fTick = 0.0;
				fread_s(&fTick, sizeof(float), sizeof(float), 1, file);
				m_Ticks.push_back(fTick);
			}
			fread_s(&m_bEnterSignal, sizeof(BOOL), sizeof(BOOL), 1, file);
		}
		else if (type == 2)
		{
			for (int i = 0; i < 4; i++)
			{
				int nTradePos = 0;
				fread_s(&nTradePos, sizeof(int), sizeof(int), 1, file);
				COLORREF crMark;
				fread_s(&crMark, sizeof(COLORREF), sizeof(COLORREF), 1, file);
			}
			char tmp[256] = "";
			int nLength = 52;
			fread_s(tmp, sizeof(tmp), sizeof(char), nLength, file);
		}
	}
	else
	{

	}
}
#pragma once

typedef struct tagSTACK_ITEM
{
	float		m_fValue;
	CDataArray*	m_pDataArray;
	DWORD		m_DataType;
} STACK_ITEM;
struct CFncDrawItem
{
	int	        m_nType;
	CDataArray	m_DataArray1;
	CDataArray	m_DataArray2;
	CDataArray	m_DataArray3;
	CDataArray	m_DataArray4;
	CDataArray	m_DataArray5;
	float		m_fVar1;
	float		m_fVar2;
};

class CFncRunner :
	public CParser
{
public:
	CFncRunner();
	virtual ~CFncRunner();
	int		Execute();
	void	SetParams(int nNum, TKLineSpecParam* pParam);
	void	SetIndex(CIndex* pIndex);
	void	SetCalcInfo(TKLineData* pStkHisData);
	typedef std::vector<CFormulaResultItem*> FormulaResultItemsVector;
	FormulaResultItemsVector m_vArrResults;
	typedef std::vector<CFncDrawItem*> FncDrawArray;
	FncDrawArray m_FncDrawArray;
private:
	void	RemoveResults();
	void	RemoveVariableSymtab();
	void	CreateResult();
	void	ExecOperator(TOKEN_CODE op);
	void	ExecInnerFnc(TOKEN_CODE op);
	void	ExecFnc0Params();
	void	ExecFnc1Params();
	void	ExecFnc2Params();
	void	ExecFnc3Params();
	void	ExecFnc4Params();
	void	ExecDrawFnc();
	void	PushNumber(float fValue);
	void	PushAddress(CDataArray* pAddress);
	void	ChangeValue2Array(STACK_ITEM *pOperand);
public:
	typedef std::vector<CFormulaResultItem*> FormulaResultItemsVector;
	FormulaResultItemsVector   m_ResultItems;
private:
	STACK_ITEM m_Stack[4000];
	STACK_ITEM* m_pTopOfStack;
	CALCINFO	m_CalcInfo;
	TKLineData* m_pStkHisData;
};


#include "PreInclude.h"



TKLineChart::TKLineChart(): m_pKLineCtl(NULL),Style(csK)
{
}


TKLineChart::~TKLineChart()
{
}
double TKLineChart::YAxis_Pix2Price(int pix)
{
	double dPrece = 0.0;
	RECT ccr = CenterChartRect;
	if (ccr.bottom != ccr.top)
	{
		dPrece = (LeftAxisY.MaxValue - (pix - ccr.top)*(LeftAxisY.MaxValue - LeftAxisY.MinValue) / (ccr.bottom - ccr.top))*1.0 / LeftAxisY.PrecPow*1.0;
	}
	return dPrece;
}
int TKLineChart::YAxis_Price2Pix(double value)
{
	int retPix = 0;
	RECT ccr = CenterChartRect;
	if (LeftAxisY.MaxValue - LeftAxisY.MinValue != 0)
	{
		retPix = ccr.top + (int)((LeftAxisY.MaxValue - (long long)(value * LeftAxisY.PrecPow))
			* (ccr.bottom - ccr.top) / (LeftAxisY.MaxValue - LeftAxisY.MinValue));
	}
	else
	{
		retPix = (ccr.bottom + ccr.top) / 2;
	}
	return retPix;
}
void TKLineChart::CalcAllIndicators(bool bMain, bool bTLine)
{
	for (int i = 0; i < sizeof(KChartSpec) / sizeof(TKChartSpec); i++)
	{
		TKChartSpec& spec = KChartSpec[i];
		spec.ClearAllSeries();
		if (bMain&&bTLine&&i > 0)
			continue;
		//if (bMain/*&&bTLine*/&&i > 0 || !bMain)
		//{
		//	CalcIndicatorIndex(i);
		//}
		//else
		{
			CIndex* pIndex = spec.m_pIndex;
			if (NULL != pIndex && NULL != pIndex->GetCalcIndeCallback())
				(this->*pIndex->GetCalcIndeCallback())(i);
		}
	}
}
void TKLineChart::CalcIndicatorIndex(int nIndex)
{
	static CFncRunner runner;
	TKChartSpec& spec = KChartSpec[nIndex];
	CIndex* pIndex = spec.m_pIndex;
	if (NULL == pIndex)
		return;
	runner.SetCalcInfo(&m_pKLineCtl->m_AxisX.KData);
	runner.SetIndex(pIndex);
	runner.SetParams(PARAM_NUM, spec.Params);
	int nErrCode = runner.Execute();
	//pSeriesGroup->m_nErrCode = nErrCode;
	if (nErrCode != eNoError)
		return;
	INT_PTR nNumResults = runner.m_ResultItems.size();
	CFormulaResultItem* pResultItem;
	CFormulaResultItem* pFmlResultItem;
	TChartSeries* pSeries;
	for (int i = 0; i < nNumResults; i++)
	{
		pResultItem = runner.m_ResultItems.at(i);
		pFmlResultItem = pIndex->m_ResultItems[i];
		pSeries = new TChartSeries;
		AddSeries(spec, pSeries, 1, L"", 2, true, true);
	}
}
void TKLineChart::RecalcAxisY(bool bMain, bool bTLine)
{
	for (int i = 0; i < sizeof(KChartSpec) / sizeof(TKChartSpec); i++)
	{
		/*if (KChartSpec[i].CalcVisibleMinMaxYValues())
		{

		}
		else
		{
			LeftAxisY.MinValue = 0;
			LeftAxisY.MaxValue = 10;
		}*/
	}
}
void TKLineChart::DrawChart(HDC mdc, bool bMain,bool bTLine)
{
		//����ָ����
		for (int i = 0; i < sizeof(KChartSpec) / sizeof(TKChartSpec); i++)
		{
			TKChartSpec& spec = KChartSpec[i];
			if (spec.Visible||i==0)
			{
				spec.Draw(mdc);
			}
		}
}
void  TKLineChart::DrawLegend(HDC mdc)
{
	SelectObject(mdc, PEN_KLINE_CYCLE);
	SelectObject(mdc, FONT_KLINE_NUMBER);
	SetTextColor(mdc, COLOR_KLINE_MENU_TEXT);
	SIZE size;
	for (int j = 0; j < sizeof(KChartSpec) / sizeof(TKChartSpec); j++)
	{
		TKChartSpec& spec = KChartSpec[j];
		if (wcscmp(spec.SpecName, L"TLINE") == 0)
			break;
		if (spec.Visible)
		{
			if (wcscmp(spec.SpecName, L"KLINE") == 0||wcscmp(spec.SpecName, L"TICK") == 0)
				continue;
			if (S_KLINE_TICK == m_pKLineCtl->m_Contract.KLineType && 0 == m_pKLineCtl->m_Contract.KLineSlice&&wcscmp(spec.SpecName, L"MA") == 0)
				continue;
			wchar_t wtext[128] = L"";
			GetParamText(wtext, sizeof(wtext) / sizeof(wchar_t) - 1, spec);
			GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
			RECT r(CenterTopRect);
			r.right = r.left + size.cx;
			DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
			r.left = r.right+TKLineControl::PADDING_X;
			r.right = CenterTopRect.right;
			spec.DrawLegend(mdc, r);
		}
	}
}
void TKLineChart::GetParamText(wchar_t *ptext, int nLegth, TKChartSpec& pSpace)
{
	int nNum = 0;
	for (int i = 0; i < sizeof(pSpace.Params) / sizeof(TKLineSpecParam); i++)
	{
		if (pSpace.Params[i].Value <= 0)
			continue;
		nNum++;
	}
	switch (nNum)
	{
	case 0:
		swprintf_s(ptext, nLegth, L"%s", pSpace.SpecName);
		break;
	case 1:
		swprintf_s(ptext, nLegth, L"%s(%d)", pSpace.SpecName, pSpace.Params[0].Value);
		break;
	case 2:
		swprintf_s(ptext, nLegth, L"%s(%d,%d)", pSpace.SpecName, pSpace.Params[0].Value, pSpace.Params[1].Value);
		break;
	case 3:
		swprintf_s(ptext, nLegth, L"%s(%d,%d,%d)", pSpace.SpecName, pSpace.Params[0].Value, pSpace.Params[1].Value, pSpace.Params[2].Value);
		break;
	case 4:
		swprintf_s(ptext, nLegth, L"%s(%d,%d,%d,%d)", pSpace.SpecName, pSpace.Params[0].Value, pSpace.Params[1].Value, pSpace.Params[2].Value, pSpace.Params[3].Value);
		break;
	case 5:
		swprintf_s(ptext, nLegth, L"%s(%d,%d,%d,%d,%d)", pSpace.SpecName, pSpace.Params[0].Value, pSpace.Params[1].Value, pSpace.Params[2].Value, pSpace.Params[3].Value, pSpace.Params[4].Value);
		break;
	case 6:
		swprintf_s(ptext, nLegth, L"%s(%d,%d,%d,%d,%d,%d)", pSpace.SpecName, pSpace.Params[0].Value, pSpace.Params[1].Value, pSpace.Params[2].Value, pSpace.Params[3].Value, pSpace.Params[4].Value, pSpace.Params[5].Value);
		break;
	}
}
void TKLineChart::CalLeftAxisYMaxMinValue(double Data[MAX_SHOW_KLINE_X], bool rCal, bool bPow)
{
	//������Сֵ
	bool isget(false);
	int curr = m_pKLineCtl->m_AxisX.Begin;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		double value = bPow ? Data[curr]* LeftAxisY.PrecPow : Data[curr];
		if (!isnan(value)&&!isinf(value))
		{
			if (rCal && !isget)
			{
				LeftAxisY.MinValue = value;
				LeftAxisY.MaxValue = value;
				isget = true;
			}
			else
			{
				if (value > LeftAxisY.MaxValue)
					LeftAxisY.MaxValue = value;
				if (value < LeftAxisY.MinValue)
					LeftAxisY.MinValue = value;
			}
		}
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
}
void TKLineChart::CalRightAxisYMaxMinValue(double Data[MAX_SHOW_KLINE_X])
{
	//������Сֵ
	bool isget(false);
	int curr = m_pKLineCtl->m_AxisX.Begin;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		double value = Data[curr];
		if (!isnan(value) &&!isinf(value))
		{
			if (!isget)
			{
				RightAxisY.MinValue = value;
				RightAxisY.MaxValue = value;
				isget = true;
			}
			else
			{
				if (value > RightAxisY.MaxValue)
					RightAxisY.MaxValue = value;
				if (value < RightAxisY.MinValue)
					RightAxisY.MinValue = value;
			}
		}

		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
}
void TKLineChart::CalSubTagLine(TagLineType type, int nPre)
{
	if (LeftAxisY.MinValue == LeftAxisY.MaxValue)	//�������Сֵ
		return;

	//����tagline
	int zone_count = min(3, (LeftRect.bottom - LeftRect.top) / TKLineControl::MIN_ZONE_HEIGHT);
	if (zone_count <= 0)
		return;

	wchar_t frome[21];
	swprintf_s(frome, L"%%.%df", nPre);
	//����tagline
	if (type == LineType_ZERO)
	{
		if (LeftAxisY.MinValue < 0 && LeftAxisY.MaxValue > 0)
		{
			TKLineTagLine& tag = LeftAxisY.TagLine[0];
			tag.ShowDotLine = true;
			tag.ShowText = true;
			tag.ValueColor = COLOR_KLINE_GRID_TEXT;
			wcsncpy_s(tag.ValueText, L"0.00", sizeof(tag.ValueText) / sizeof(wchar_t) - 1);
			tag.Pixel = (int)((LeftRect.bottom - LeftRect.top) * LeftAxisY.MaxValue / (LeftAxisY.MaxValue - LeftAxisY.MinValue));
		}
	}
	else
	{
		for (int i = 0; i < zone_count - 1; i++)
		{
			long double value = 0;
			if (type == LineType_VOL)
				value = LeftAxisY.MaxValue * (i + 1) / zone_count;
			else
			    value = LeftAxisY.MinValue + (LeftAxisY.MaxValue - LeftAxisY.MinValue) * (i + 1) / zone_count;

			TKLineTagLine& tag = LeftAxisY.TagLine[i];
			tag.ShowDotLine = true;
			tag.ShowText = true;
			tag.ValueColor = COLOR_KLINE_GRID_TEXT;
			if(type == LineType_VOL)
				_i64tow_s(value, tag.ValueText, sizeof(tag.ValueText) / sizeof(wchar_t), 10);
			else
			    swprintf_s(tag.ValueText, frome, (1.0 * value / LeftAxisY.PrecPow));
			tag.Pixel = (int)((LeftRect.bottom - LeftRect.top) * (zone_count - (i + 1)) / zone_count);
		}
	}
	
	//����ʮ�ֱ���y��
	if (m_pKLineCtl->m_ShowCross && m_pKLineCtl->m_CrossY >= LeftRect.top && m_pKLineCtl->m_CrossY < LeftRect.bottom)
	{
		long long value = (LeftAxisY.MaxValue - (LeftAxisY.MaxValue - LeftAxisY.MinValue) * (m_pKLineCtl->m_CrossY - LeftRect.top) / (LeftRect.bottom - LeftRect.top));
		if (type == LineType_VOL)
			_i64tow_s(value, m_pKLineCtl->m_CrossTextY, sizeof(m_pKLineCtl->m_CrossTextY) / sizeof(wchar_t), 10);
		else
		    swprintf_s(m_pKLineCtl->m_CrossTextY, frome, 1.0 * value / LeftAxisY.PrecPow);
	}

}
void TKLineChart::AddSeries(TKChartSpec& spec,TChartSeries* pSeries, int penid, wchar_t* name, int nPre, bool bPow, bool bLeftAxisY)
{
	if (!pSeries)
		return;
	pSeries->m_PenId = penid;
	wcscpy_s(pSeries->m_ParamName, name);
	pSeries->m_pKLineCtl = m_pKLineCtl;
	pSeries->m_pLeftAxisY = bLeftAxisY?&LeftAxisY:&RightAxisY;
	pSeries->m_ChartRect = CenterChartRect;
	pSeries->m_nParamPre = nPre;
	pSeries->m_bPow = bPow;
	spec.m_VSeries.push_back(pSeries);
}
//------------------------------------------------------------------------------------------------------------------------
//K��ָ��
//------------------------------------------------------------------------------------------------------------------------
void TKLineChart::KLine_CalcIndi(int index)
{
	if (!m_pKLineCtl)
		return;
	TKChartSpec& spec = KChartSpec[index];
	if (m_pKLineCtl->m_Contract.IsSpread)
	{
		Spread_CalcIndi(index);
		return;
	}

	TKLineSeries* pKSeries = new TKLineSeries;
	pKSeries->SetKType(Style);
	pKSeries->SetBottomRect(CenterBottomRect);
	int nPre = m_pKLineCtl->m_Contract.Prec > 2 ? m_pKLineCtl->m_Contract.Prec : 2;
	AddSeries(spec, pKSeries, 0, L"", nPre, true, true);
	//������Сֵ
	bool isget(false);
	if (!m_pKLineCtl->m_AxisX.KData.IsEmpty())
	{
		int curr = m_pKLineCtl->m_AxisX.Begin;
		while (curr != m_pKLineCtl->m_AxisX.End)
		{
			SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
			long long high = (long long)(LeftAxisY.PrecPow * d.QHighPrice);
			long long low = (long long)(LeftAxisY.PrecPow * d.QLowPrice);
			 
			if (!isget)
			{
				LeftAxisY.MinValue = low;
				m_pKLineCtl->m_AxisX.Min = curr;
				LeftAxisY.MaxValue = high;
				m_pKLineCtl->m_AxisX.Max = curr;
				isget = true;
			}
			else
			{
				if (high > LeftAxisY.MaxValue)
				{
					LeftAxisY.MaxValue = high;
					m_pKLineCtl->m_AxisX.Max = curr;
				}

				if (low < LeftAxisY.MinValue)
				{
					LeftAxisY.MinValue = low;
					m_pKLineCtl->m_AxisX.Min = curr;
				}

			}

			curr = (curr + 1) % MAX_SHOW_KLINE_X;
		}
	}
	LeftAxisY.MidValue = (LeftAxisY.MinValue + LeftAxisY.MaxValue) / 2;


	//if (LeftAxisY.MinValue <= 0 || LeftAxisY.MaxValue <= 0 )	//�������Сֵ
	//	return;

	////����tagline
	int zone_count = min(4, (LeftRect.bottom - LeftRect.top) / TKLineControl::MIN_ZONE_HEIGHT);
	if (zone_count <= 0)
		return;

	long long tick = (long long)(m_pKLineCtl->m_Contract.Tick * LeftAxisY.PrecPow);
	int rate = (int)((LeftAxisY.MaxValue - LeftAxisY.MinValue) / tick);	//���������С�䶯��10���ĸ���
	if (LeftAxisY.MaxValue == LeftAxisY.MinValue)
	{
		long long value = LeftAxisY.MinValue;
		TKLineTagLine& tag = LeftAxisY.TagLine[0];
		tag.ShowDotLine = true;
		tag.ShowText = true;
		tag.ValueColor = COLOR_KLINE_GRID_TEXT;
		FormatPrice(G_StarApi,1.0 * value / LeftAxisY.PrecPow, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, tag.ValueText, true);
		tag.Pixel = (int)((CenterChartRect.bottom - CenterChartRect.top) / 2);
	}
	else
	{
		int nTime = 10;
		if (rate < 0)
			return;
		if (rate <= 10)
			nTime = 1;
		int zone_rate = rate / (zone_count*nTime) + 1;		//һ������ļ۸���
		int minrate = (int)(LeftAxisY.MinValue / (zone_rate * nTime * tick));
		for (int i = 0; i < zone_count; i++)
		{
			long long value = (minrate + i + 1) * zone_rate * nTime * tick;
			if (value >= LeftAxisY.MaxValue)
				break;

			TKLineTagLine& tag = LeftAxisY.TagLine[i];
			tag.ShowDotLine = true;
			tag.ShowText = true;
			tag.ValueColor = COLOR_KLINE_GRID_TEXT;
			FormatPrice(G_StarApi, 1.0 * value / LeftAxisY.PrecPow, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, tag.ValueText, true);
			tag.Pixel = (int)((CenterChartRect.bottom - CenterChartRect.top) * (LeftAxisY.MaxValue - value) / (LeftAxisY.MaxValue - LeftAxisY.MinValue));
		}
	}

	//����ʮ�ֱ���y��
	if (m_pKLineCtl->m_ShowCross && m_pKLineCtl->m_CrossY >= LeftRect.top && m_pKLineCtl->m_CrossY < LeftRect.bottom)
	{
		double value = (LeftAxisY.MaxValue - (LeftAxisY.MaxValue - LeftAxisY.MinValue) * (m_pKLineCtl->m_CrossY - LeftRect.top) / (LeftRect.bottom - LeftRect.top)) * 1.0 / LeftAxisY.PrecPow;
		FormatPrice(G_StarApi, value, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, m_pKLineCtl->m_CrossTextY, true);
	}
}


//------------------------------------------------------------------------------------------------------------------------
//��ʱָ��
//------------------------------------------------------------------------------------------------------------------------
void TKLineChart::TLine_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	/*if (m_pKLineCtl->m_Contract.IsSpread)
		return;*/
	TTLineSeries* pTLineSeries = new TTLineSeries;
	pTLineSeries->SetTopRect(CenterTopRect);
	pTLineSeries->SetBottomRect(CenterBottomRect);
	int nPre = m_pKLineCtl->m_Contract.Prec > 2 ? m_pKLineCtl->m_Contract.Prec : 2;
	AddSeries(spec, pTLineSeries, 0, L"", nPre, true, true);

	//������Сֵ
	bool isget(false);
	int curr = m_pKLineCtl->m_AxisX.Begin;
	while (curr != m_pKLineCtl->m_AxisX.KData.WriteIndex)
	{
		SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
		if (d.QKLineQty <= 0)	//��ʱ���ݳɽ�Ϊ0���ǲ������ݣ������������Сֵ
			continue;

		long long value = (long long)(LeftAxisY.PrecPow * d.QLastPrice);

		if (!isget)
		{
			LeftAxisY.MinValue = value;
			LeftAxisY.MaxValue = value;
			isget = true;
		}
		else
		{
			if (value > LeftAxisY.MaxValue)
				LeftAxisY.MaxValue = value;
			if (value < LeftAxisY.MinValue)
				LeftAxisY.MinValue = value;
		}
	}
	//if (LeftAxisY.MinValue <= 0 || LeftAxisY.MaxValue <= 0)	//�������Сֵ
	//	return;

	//��ȡ�м�ֵ
	SQuoteSnapShot* q(m_pKLineCtl->m_Contract.Cont->SnapShot);
	if (!q)
		return;
	long long preSettingValue = 0;
	if (m_pKLineCtl->m_TLineType == TKLineControl::TLINE_LIMIT_AXIS)
	{
		SQuoteField& fieldUp = q->Data[S_FID_LIMITUPPRICE];
		SQuoteField& fieldDown = q->Data[S_FID_LIMITDOWNPRICE];
		if (S_FIDTYPE_NONE != fieldUp.FidAttr && fieldUp.Price > 0 && S_FIDTYPE_NONE != fieldDown.FidAttr && fieldDown.Price > 0)
		{
			LeftAxisY.MaxValue = (long long)(LeftAxisY.PrecPow *fieldUp.Price);
			LeftAxisY.MinValue = (long long)(LeftAxisY.PrecPow *fieldDown.Price);
		}
	}
	SQuoteField& field = q->Data[S_FID_PRESETTLEPRICE];
	if (S_FIDTYPE_NONE != field.FidAttr && field.Price > 0)
	{
		if (m_pKLineCtl->m_TLineType == TKLineControl::TLINE_SYMMETRIC_AXIS || m_pKLineCtl->m_TLineType == TKLineControl::TLINE_LIMIT_AXIS)
			LeftAxisY.MidValue = (long long)(LeftAxisY.PrecPow * field.Price);
		else if (m_pKLineCtl->m_TLineType == TKLineControl::TLINE_FULL_AXIS)
			LeftAxisY.MidValue = (LeftAxisY.MaxValue + LeftAxisY.MinValue) / 2;
		preSettingValue = (long long)(LeftAxisY.PrecPow * field.Price);
		//���½���������Сֵ
		long long p1 = abs(LeftAxisY.MinValue - LeftAxisY.MidValue);
		long long p2 = abs(LeftAxisY.MaxValue - LeftAxisY.MidValue);
		long long p = ((p1 > p2) ? p1 : p2);
		LeftAxisY.MinValue = LeftAxisY.MidValue - p;
		LeftAxisY.MaxValue = LeftAxisY.MidValue + p;
	}
	else
	{
		LeftAxisY.MidValue = (LeftAxisY.MinValue + LeftAxisY.MaxValue) / 2;
		preSettingValue = LeftAxisY.MidValue;
	}

	//����TLine��Y����ֶ�����������С�����ֵ����Ϊ��С�䶯�۵ķֶα���
	int zone_count = min(5, (LeftRect.bottom - LeftRect.top) / TKLineControl::MIN_ZONE_HEIGHT);
	if (zone_count <= 0)
		return;
	long long tick = (long long)(m_pKLineCtl->m_Contract.Tick * LeftAxisY.PrecPow);
	LeftAxisY.MaxValue = LeftAxisY.MidValue + ((LeftAxisY.MaxValue - LeftAxisY.MidValue) / (tick * zone_count) + 1) * tick * zone_count;
	LeftAxisY.MinValue = LeftAxisY.MidValue - (LeftAxisY.MaxValue - LeftAxisY.MidValue);
	if (preSettingValue == 0)
		return;
	//����tagline
	long long value;
	TKLineTagLine& tag = LeftAxisY.TagLine[0];
	tag.ShowDotLine = true;
	tag.ShowSolidLine = true;
	tag.ShowText = true;
	tag.Pixel = (LeftRect.bottom - LeftRect.top) / 2;
	tag.ValueColor = COLOR_KLINE_WHITE_BAR;
	value = LeftAxisY.MidValue;
	if (value - preSettingValue > 0)
		tag.ValueColor = COLOR_TLINE_RED_BAR;
	else if (value - preSettingValue < 0)
		tag.ValueColor = COLOR_TLINE_GREEN_BAR;
	FormatPrice(G_StarApi, 1.0 * value / LeftAxisY.PrecPow, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, tag.ValueText, true);

	TKLineTagLine& rtag = RightAxisY.TagLine[0];
	rtag.ShowText = true;
	rtag.Pixel = tag.Pixel;
	rtag.ValueColor = COLOR_KLINE_WHITE_BAR;
	if (value - preSettingValue > 0)
	{
		rtag.ValueColor = COLOR_TLINE_RED_BAR;
		rtag.ValueText[0] = L'+';
		FormatPrice(G_StarApi, 1.0 * 100 * (value - preSettingValue) / preSettingValue, 2, 1, &rtag.ValueText[1], true);
	}
	else if (value - preSettingValue < 0)
	{
		rtag.ValueColor = COLOR_TLINE_GREEN_BAR;
		FormatPrice(G_StarApi, 1.0 * 100 * (value - preSettingValue) / preSettingValue, 2, 1, rtag.ValueText, true);
	}
	else
		FormatPrice(G_StarApi, 1.0 * 0, 2, 1, rtag.ValueText, true);
	wcsncat_s(rtag.ValueText, L"%", 1);

	for (int i = 1; i < zone_count; i++)
	{
		TKLineTagLine& tag1 = LeftAxisY.TagLine[i];
		tag1.ShowDotLine = true;
		tag1.ShowText = true;
		tag1.Pixel = tag.Pixel - i * (LeftRect.bottom - LeftRect.top) / (2 * zone_count);
		tag1.ValueColor = COLOR_KLINE_WHITE_BAR;
		value = LeftAxisY.MidValue + i * (LeftAxisY.MaxValue - LeftAxisY.MinValue) / (2 * zone_count);
		if (value - preSettingValue > 0)
			tag1.ValueColor = COLOR_TLINE_RED_BAR;
		else if (value - preSettingValue < 0)
			tag1.ValueColor = COLOR_TLINE_GREEN_BAR;
		FormatPrice(G_StarApi, 1.0 * value / LeftAxisY.PrecPow, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, tag1.ValueText, true);

		TKLineTagLine& rtag1 = RightAxisY.TagLine[i];
		rtag1.ShowText = true;
		rtag1.Pixel = tag1.Pixel;
		rtag1.ValueColor = COLOR_KLINE_WHITE_BAR;
		if (value - preSettingValue > 0)
		{
			rtag1.ValueColor = COLOR_TLINE_RED_BAR;
			rtag1.ValueText[0] = L'+';
			FormatPrice(G_StarApi, 1.0 * 100 * (value - preSettingValue) / preSettingValue, 2, 1, &rtag1.ValueText[1], true);
		}
		else if (value - preSettingValue < 0)
		{
			rtag1.ValueColor = COLOR_TLINE_GREEN_BAR;
			FormatPrice(G_StarApi, 1.0 * 100 * (value - preSettingValue) / preSettingValue, 2, 1, rtag1.ValueText, true);
		}
		else
			FormatPrice(G_StarApi, 1.0 * 0, 2, 1, rtag1.ValueText, true);
		wcsncat_s(rtag1.ValueText, L"%", 1);

		TKLineTagLine& tag2 = LeftAxisY.TagLine[zone_count + i - 1];
		tag2.ShowDotLine = true;
		tag2.ShowText = true;
		tag2.Pixel = tag.Pixel + i * (LeftRect.bottom - LeftRect.top) / (2 * zone_count);
		tag2.ValueColor = COLOR_KLINE_WHITE_BAR;
		value = LeftAxisY.MidValue - i * (LeftAxisY.MaxValue - LeftAxisY.MinValue) / (2 * zone_count);
		if (value - preSettingValue > 0)
			tag2.ValueColor = COLOR_TLINE_RED_BAR;
		else if (value - preSettingValue < 0)
			tag2.ValueColor = COLOR_TLINE_GREEN_BAR;
		FormatPrice(G_StarApi, 1.0 * value / LeftAxisY.PrecPow, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, tag2.ValueText, true);

		TKLineTagLine& rtag2 = RightAxisY.TagLine[zone_count + i - 1];
		rtag2.ShowText = true;
		rtag2.Pixel = tag2.Pixel;
		rtag2.ValueColor = COLOR_KLINE_WHITE_BAR;
		if (value - preSettingValue > 0)
		{
			rtag2.ValueColor = COLOR_TLINE_RED_BAR;
			rtag2.ValueText[0] = L'+';
			FormatPrice(G_StarApi, 1.0 * 100 * (value - preSettingValue) / preSettingValue, 2, 1, &rtag2.ValueText[1], true);
		}
		else if (value - preSettingValue < 0)
		{
			rtag2.ValueColor = COLOR_TLINE_GREEN_BAR;
			FormatPrice(G_StarApi, 1.0 * 100 * (value - preSettingValue) / preSettingValue, 2, 1, rtag2.ValueText, true);
		}
		else
			FormatPrice(G_StarApi, 1.0 * 0, 2, 1, rtag2.ValueText, true);
		wcsncat_s(rtag2.ValueText, L"%", 1);
	}

	//����ʮ�ֱ���y��
	if (m_pKLineCtl->m_ShowCross && m_pKLineCtl->m_CrossY >= LeftRect.top && m_pKLineCtl->m_CrossY < LeftRect.bottom)
	{
		double value = (LeftAxisY.MaxValue - (LeftAxisY.MaxValue - LeftAxisY.MinValue) * (m_pKLineCtl->m_CrossY - LeftRect.top) / (LeftRect.bottom - LeftRect.top)) * 1.0 / LeftAxisY.PrecPow;
		FormatPrice(G_StarApi, value, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, m_pKLineCtl->m_CrossTextY, true);
	}
}
//------------------------------------------------------------------------------------------------------------------------
//����ͼָ��
//------------------------------------------------------------------------------------------------------------------------

void TKLineChart::Tick_CalcIndi(int index)
{
	if (!m_pKLineCtl)
		return;
	if (m_pKLineCtl->m_Contract.IsSpread)
	{
		Spread_CalcIndi(index);
		return;
	}
	TKChartSpec& spec = KChartSpec[index];

	TTickSeries* pTickSeries = new TTickSeries;
	pTickSeries->SetBottomRect(CenterBottomRect);
	int nPre = m_pKLineCtl->m_Contract.Prec > 2 ? m_pKLineCtl->m_Contract.Prec : 2;
	AddSeries(spec, pTickSeries, 0, L"", nPre, true, true);

	//������Сֵ
	bool isget(false);
	int curr = m_pKLineCtl->m_AxisX.Begin;
	while (curr != m_pKLineCtl->m_AxisX.KData.WriteIndex)
	{
		SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		long long value = (long long)(LeftAxisY.PrecPow * d.QLastPrice);

		if (!isget)
		{
			LeftAxisY.MinValue = value;
			LeftAxisY.MaxValue = value;
			isget = true;
		}
		else
		{
			if (value > LeftAxisY.MaxValue)
				LeftAxisY.MaxValue = value;
			if (value < LeftAxisY.MinValue)
				LeftAxisY.MinValue = value;
		}

		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	LeftAxisY.MidValue = (LeftAxisY.MinValue + LeftAxisY.MaxValue) / 2;

	//if (LeftAxisY.MinValue <= 0 || LeftAxisY.MaxValue <= 0)	//�������Сֵ
	//	return;

	//����TLine��Y����ֶ�����������С�����ֵ����Ϊ��С�䶯�۵ķֶα���
	int zone_count = min(4, (LeftRect.bottom - LeftRect.top) / TKLineControl::MIN_ZONE_HEIGHT);
	if (zone_count <= 0)
		return;

	long long tick = (long long)(m_pKLineCtl->m_Contract.Tick * LeftAxisY.PrecPow);
	int rate = (int)((LeftAxisY.MaxValue - LeftAxisY.MinValue) / (1 * tick));	//���������С�䶯��10���ĸ���
	if (LeftAxisY.MaxValue == LeftAxisY.MinValue)
	{
		long long value = LeftAxisY.MinValue;
		TKLineTagLine& tag = LeftAxisY.TagLine[0];
		tag.ShowDotLine = true;
		tag.ShowText = true;
		tag.ValueColor = COLOR_KLINE_GRID_TEXT;
		FormatPrice(G_StarApi, 1.0 * value / LeftAxisY.PrecPow, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, tag.ValueText, true);
		tag.Pixel = (int)((CenterChartRect.bottom - CenterChartRect.top) / 2);
	}
	else
	{
		if (rate <= 0)
			return;
		int zone_rate = rate / zone_count + 1;		//һ������ļ۸���

													//����tagline
		int minrate = (int)(LeftAxisY.MinValue / (zone_rate * 1 * tick));
		for (int i = 0; i < zone_count; i++)
		{
			long long value = (minrate + i + 1) * zone_rate * 1 * tick;
			if (value >= LeftAxisY.MaxValue)
				break;

			TKLineTagLine& tag = LeftAxisY.TagLine[i];
			tag.ShowDotLine = true;
			tag.ShowText = true;
			tag.ValueColor = COLOR_KLINE_GRID_TEXT;
			FormatPrice(G_StarApi, 1.0 * value / LeftAxisY.PrecPow, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, tag.ValueText, true);
			tag.Pixel = (int)((CenterChartRect.bottom - CenterChartRect.top) * (LeftAxisY.MaxValue - value) / (LeftAxisY.MaxValue - LeftAxisY.MinValue));
		}
	}

	//����ʮ�ֱ���y��
	if (m_pKLineCtl->m_ShowCross && m_pKLineCtl->m_CrossY >= LeftRect.top && m_pKLineCtl->m_CrossY < LeftRect.bottom)
	{
		double value = (LeftAxisY.MaxValue - (LeftAxisY.MaxValue - LeftAxisY.MinValue) * (m_pKLineCtl->m_CrossY - LeftRect.top) / (LeftRect.bottom - LeftRect.top)) * 1.0 / LeftAxisY.PrecPow;
		FormatPrice(G_StarApi, value, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, m_pKLineCtl->m_CrossTextY, true);
	}
}
void TKLineChart::Spread_CalcIndi(int index)
{
	if (!m_pKLineCtl)
		return;
	TKChartSpec& spec = KChartSpec[index];
	TSpreadSeries* pSpreadSeries = new TSpreadSeries;
	pSpreadSeries->SetBottomRect(CenterBottomRect);
	int nPre = m_pKLineCtl->m_Contract.Prec > 2 ? m_pKLineCtl->m_Contract.Prec : 2;
	AddSeries(spec, pSpreadSeries, 0, L"", nPre, true, true);
	//������Сֵ
	bool isget(false);
	int curr = m_pKLineCtl->m_AxisX.Begin;
	while (curr != m_pKLineCtl->m_AxisX.KData.WriteIndex)
	{
		SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		long long value = (long long)(LeftAxisY.PrecPow * d.QLastPrice);

		if (!isget)
		{
			LeftAxisY.MinValue = value;
			LeftAxisY.MaxValue = value;
			isget = true;
		}
		else
		{
			if (value > LeftAxisY.MaxValue)
				LeftAxisY.MaxValue = value;
			if (value < LeftAxisY.MinValue)
				LeftAxisY.MinValue = value;
		}

		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	LeftAxisY.MidValue = (LeftAxisY.MinValue + LeftAxisY.MaxValue) / 2;

	//����TLine��Y����ֶ�����������С�����ֵ����Ϊ��С�䶯�۵ķֶα���
	int zone_count = min(4, (LeftRect.bottom - LeftRect.top) / TKLineControl::MIN_ZONE_HEIGHT);
	if (zone_count <= 0)
		return;

	long long tick = (long long)(m_pKLineCtl->m_Contract.SpreadTick * LeftAxisY.PrecPow);
	double rate = (double)((LeftAxisY.MaxValue - LeftAxisY.MinValue) / (1.0 * tick));	//���������С�䶯��10���ĸ���
	if (LeftAxisY.MaxValue == LeftAxisY.MinValue)
	{
		long long value = LeftAxisY.MinValue;
		TKLineTagLine& tag = LeftAxisY.TagLine[0];
		tag.ShowDotLine = true;
		tag.ShowText = true;
		tag.ValueColor = COLOR_KLINE_GRID_TEXT;
		FormatPrice(G_StarApi, 1.0 * value / LeftAxisY.PrecPow, m_pKLineCtl->m_Contract.SpreadPrec, m_pKLineCtl->m_Contract.Deno, tag.ValueText, true);
		tag.Pixel = (int)((CenterChartRect.bottom - CenterChartRect.top) / 2);
	}
	else
	{
		if (rate <= 0)
			return;
		int zone_rate = (int)(rate / zone_count + 1);		//һ������ļ۸���

															//����tagline
		int minrate = (int)(LeftAxisY.MinValue / (zone_rate * 1 * tick));
		for (int i = 0; i < zone_count; i++)
		{
			long long value = (minrate + i + 1) * zone_rate * 1 * tick;
			if (value >= LeftAxisY.MaxValue)
				break;

			TKLineTagLine& tag = LeftAxisY.TagLine[i];
			tag.ShowDotLine = true;
			tag.ShowText = true;
			tag.ValueColor = COLOR_KLINE_GRID_TEXT;
			FormatPrice(G_StarApi, 1.0 * value / LeftAxisY.PrecPow, m_pKLineCtl->m_Contract.SpreadPrec, m_pKLineCtl->m_Contract.Deno, tag.ValueText, true);
			tag.Pixel = (int)((CenterChartRect.bottom - CenterChartRect.top) * (LeftAxisY.MaxValue - value) / (LeftAxisY.MaxValue - LeftAxisY.MinValue));
		}
	}

	//����ʮ�ֱ���y��
	if (m_pKLineCtl->m_ShowCross && m_pKLineCtl->m_CrossY >= LeftRect.top && m_pKLineCtl->m_CrossY < LeftRect.bottom)
	{
		double value = (LeftAxisY.MaxValue - (LeftAxisY.MaxValue - LeftAxisY.MinValue) * (m_pKLineCtl->m_CrossY - LeftRect.top) / (LeftRect.bottom - LeftRect.top)) * 1.0 / LeftAxisY.PrecPow;
		FormatPrice(G_StarApi, value, m_pKLineCtl->m_Contract.SpreadPrec, m_pKLineCtl->m_Contract.Deno, m_pKLineCtl->m_CrossTextY, true);
	}
}

void TKLineChart::SubContract_CalcIndi(int index)
{
	if (!m_pKLineCtl)
		return;
	//������Сֵ
	bool isget(false);
	if (!m_pKLineCtl->m_AxisX.KData.IsEmpty())
	{
		int curr = m_pKLineCtl->m_AxisX.Begin;
		while (curr != m_pKLineCtl->m_AxisX.End)
		{
			SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
			long long high = (long long)(LeftAxisY.PrecPow * d.QHighPrice);
			long long low = (long long)(LeftAxisY.PrecPow * d.QLowPrice);
			 
			if (!isget)
			{
				LeftAxisY.MinValue = low;
				m_pKLineCtl->m_AxisX.Min = curr;
				LeftAxisY.MaxValue = high;
				m_pKLineCtl->m_AxisX.Max = curr;
				isget = true;
			}
			else
			{
				if (high > LeftAxisY.MaxValue)
				{
					LeftAxisY.MaxValue = high;
					m_pKLineCtl->m_AxisX.Max = curr;
				}

				if (low < LeftAxisY.MinValue)
				{
					LeftAxisY.MinValue = low;
					m_pKLineCtl->m_AxisX.Min = curr;
				}

			}

			curr = (curr + 1) % MAX_SHOW_KLINE_X;
		}
	}
	LeftAxisY.MidValue = (LeftAxisY.MinValue + LeftAxisY.MaxValue) / 2;
	//����TLine��Y����ֶ�����������С�����ֵ����Ϊ��С�䶯�۵ķֶα���
	int zone_count = min(4, (LeftRect.bottom - LeftRect.top) / TKLineControl::MIN_ZONE_HEIGHT);
	if (zone_count <= 0)
		return;

	long long tick = (long long)(m_pKLineCtl->m_Contract.SpreadTick * LeftAxisY.PrecPow);
	double rate = (double)((LeftAxisY.MaxValue - LeftAxisY.MinValue) / (1.0 * tick));	//���������С�䶯��10���ĸ���
	if (LeftAxisY.MaxValue == LeftAxisY.MinValue)
	{
		long long value = LeftAxisY.MinValue;
		TKLineTagLine& tag = LeftAxisY.TagLine[0];
		tag.ShowDotLine = true;
		tag.ShowText = true;
		tag.ValueColor = COLOR_KLINE_GRID_TEXT;
		FormatPrice(G_StarApi, 1.0 * value / LeftAxisY.PrecPow, m_pKLineCtl->m_Contract.SpreadPrec, m_pKLineCtl->m_Contract.Deno, tag.ValueText, true);
		tag.Pixel = (int)((CenterChartRect.bottom - CenterChartRect.top) / 2);
	}
	else
	{
		if (rate <= 0)
			return;
		int zone_rate = (int)(rate / zone_count + 1);		//һ������ļ۸���

															//����tagline
		int minrate = (int)(LeftAxisY.MinValue / (zone_rate * 1 * tick));
		for (int i = 0; i < zone_count; i++)
		{
			long long value = (minrate + i + 1) * zone_rate * 1 * tick;
			if (value >= LeftAxisY.MaxValue)
				break;

			TKLineTagLine& tag = LeftAxisY.TagLine[i];
			tag.ShowDotLine = true;
			tag.ShowText = true;
			tag.ValueColor = COLOR_KLINE_GRID_TEXT;
			FormatPrice(G_StarApi, 1.0 * value / LeftAxisY.PrecPow, m_pKLineCtl->m_Contract.SpreadPrec, m_pKLineCtl->m_Contract.Deno, tag.ValueText, true);
			tag.Pixel = (int)((CenterChartRect.bottom - CenterChartRect.top) * (LeftAxisY.MaxValue - value) / (LeftAxisY.MaxValue - LeftAxisY.MinValue));
		}
	}

	//����ʮ�ֱ���y��
	if (m_pKLineCtl->m_ShowCross && m_pKLineCtl->m_CrossY >= LeftRect.top && m_pKLineCtl->m_CrossY < LeftRect.bottom)
	{
		double value = (LeftAxisY.MaxValue - (LeftAxisY.MaxValue - LeftAxisY.MinValue) * (m_pKLineCtl->m_CrossY - LeftRect.top) / (LeftRect.bottom - LeftRect.top)) * 1.0 / LeftAxisY.PrecPow;
		FormatPrice(G_StarApi, value, m_pKLineCtl->m_Contract.SpreadPrec, m_pKLineCtl->m_Contract.Deno, m_pKLineCtl->m_CrossTextY, true);
	}
}
void TKLineChart::SubContract_DrawChart(HDC mdc, int index)
{

}
void TKLineChart::MA_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	//���ƾ���ָ��----------------------------------------------------------------------------------------------------
	if (spec.Visible)
	{
		if (S_KLINE_TICK == m_pKLineCtl->m_Contract.KLineType && 0 == m_pKLineCtl->m_Contract.KLineSlice)
		{
			int curr = m_pKLineCtl->m_AxisX.Begin;
			SPriceType turnover(0);
			SQtyType qty(0);
			TChartSeries* pSeries = new TChartSeries;
			AddSeries(spec, pSeries, 1, L"", 2, true, true);
			while (curr != m_pKLineCtl->m_AxisX.End)
			{
				SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
				double& Ma = pSeries->m_Data[curr];

				if (d.QLastQty > 0)
				{
					turnover += d.QLastPrice * d.QLastQty;
					qty += d.QLastQty;
				}
				Ma = turnover / qty;
				d.QSettlePrice = turnover / qty;
				curr = (curr + 1) % MAX_SHOW_KLINE_X;
			}
		}
		else
		{
			for (int ma_i = 0; ma_i < sizeof(spec.Params) / sizeof(TKLineSpecParam); ma_i++)
			{
				TKLineSpecParam& param = spec.Params[ma_i];
				if (param.Value <= 0)
					continue;

				TChartSeries* pSeries = new TChartSeries;
				AddSeries(spec, pSeries, ma_i, param.Name, 2, true, true);
				int curr = m_pKLineCtl->m_AxisX.KData.ReadIndex;
				while (curr != m_pKLineCtl->m_AxisX.End)
				{
					SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);

					double& Ma = pSeries->m_Data[curr];
					double& close = m_Cache[0][curr];
					close = d.QLastPrice;
					Ma = SPEC_MA(m_Cache[0], curr, param.Value);
					curr = (curr + 1) % MAX_SHOW_KLINE_X;
				}//while

			}// ma_i
		}
	}
}
void TKLineChart::SAR_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	double AfStep = spec.Params[0].Value / 100.0;
	double AfLimit = spec.Params[1].Value / 100.0;
	double SarValue = 0;
	SPEC_SAR(AfStep, AfLimit);
	TPointSeries* pPointSeries = new TPointSeries;
	AddSeries(spec, pPointSeries, 0, L"SARLINE", 2, true, true);
	int curr(m_pKLineCtl->m_AxisX.Begin);
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		double& SarValue = pPointSeries->m_Data[curr];
		SarValue = m_Cache[0][curr];
		pPointSeries->m_ArrColor[curr] =  (m_Cache[1][curr] == 1) ? COLOR_KLINE_RED_BAR : COLOR_KLINE_GREEN_BAR;
		curr = (curr + 1) % MAX_SHOW_KLINE_X;

	}//while
}

void TKLineChart::EMA_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	for (int ma_i = 0; ma_i < sizeof(spec.Params) / sizeof(TKLineSpecParam); ma_i++)
	{
		TKLineSpecParam& param = spec.Params[ma_i];
		if (param.Value <= 0)
			continue;
		TChartSeries* pMaSeries = new TChartSeries;
		AddSeries(spec, pMaSeries, ma_i, param.Name, 2, true, true);
		int curr = m_pKLineCtl->m_AxisX.KData.ReadIndex;
		while (curr != m_pKLineCtl->m_AxisX.End)
		{
			double& ma = pMaSeries->m_Data[curr];
			ma = SPEC_CLOSE(curr);
			ma = SPEC_EMA(pMaSeries->m_Data, curr, param.Value);
			curr = (curr + 1) % MAX_SHOW_KLINE_X;
		}
	}
}

void TKLineChart::BOLL_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	int param1 = spec.Params[0].Value; //N
	int param2 = spec.Params[1].Value; //M	
	int param3 = spec.Params[2].Value; //P
	if (param1 <= 0 || param2 <= 0 || param3 <= 0)
		return;
	TChartSeries* pMidSeries = new TChartSeries;
	TChartSeries* pTopSeries = new TChartSeries;
	TChartSeries* pBottomSeries = new TChartSeries;
	int nPre = m_pKLineCtl->m_Contract.Prec > 2 ? m_pKLineCtl->m_Contract.Prec : 2;
	AddSeries(spec, pMidSeries, 0, L"MID", nPre, true, true);
	AddSeries(spec, pTopSeries, 1, L"TOP", nPre, true, true);
	AddSeries(spec, pBottomSeries, 2, L"BOTTOM", nPre, true, true);
	//������Сֵ
	int curr = m_pKLineCtl->m_AxisX.KData.ReadIndex;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		double& close = m_Cache[0][curr];
		double& mid = pMidSeries->m_Data[curr];
		double& top = pTopSeries->m_Data[curr];
		double& bottom = pBottomSeries->m_Data[curr];
		close = SPEC_CLOSE(curr);
		mid = SPEC_MA(m_Cache[0], curr, param1);
		double tmp = SPCE_STD(m_Cache[0], curr, param2);
		top = mid + param3*tmp;
		bottom = mid - param3*tmp;
		curr = (curr + 1) % MAX_SHOW_KLINE_X;

	}
	CalLeftAxisYMaxMinValue(pTopSeries->m_Data, false, true);
	CalLeftAxisYMaxMinValue(pBottomSeries->m_Data, false, true);
}

void TKLineChart::BBI_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible )
		return;
	int param1 = spec.Params[0].Value; //N1
	int param2 = spec.Params[1].Value; //N2	
	int param3 = spec.Params[2].Value; //N3
	int param4 = spec.Params[3].Value; //N4
	if (param1 <= 0 || param2 <= 0 || param3 <= 0 || param4 <= 0)
		return;
	TChartSeries* pBBISeries = new TChartSeries;
	int nPre = m_pKLineCtl->m_Contract.Prec > 2 ? m_pKLineCtl->m_Contract.Prec : 2;
	AddSeries(spec, pBBISeries, 0, L"BBI", nPre, true, true);
	int curr = m_pKLineCtl->m_AxisX.KData.ReadIndex;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		double& close = m_Cache[0][curr];
		double& BBI = pBBISeries->m_Data[curr];
		close = SPEC_CLOSE(curr);
		BBI = (SPEC_MA(m_Cache[0], curr, param1) + SPEC_MA(m_Cache[0], curr, param2) + SPEC_MA(m_Cache[0], curr, param3) + SPEC_MA(m_Cache[0], curr, param4)) / 4;
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	CalLeftAxisYMaxMinValue(pBBISeries->m_Data, false, true);
}

void TKLineChart::VOL_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	TVolumeSeries* pVolSeries = new TVolumeSeries;
	TChartSeries* pPosSeries = new TChartSeries;
	AddSeries(spec, pVolSeries, 0, L"VOL", 0,false, true);
	AddSeries(spec, pPosSeries, 0, L"POS", 0,false,false);
	int curr = m_pKLineCtl->m_AxisX.Begin;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		double& vol = pVolSeries->m_Data[curr];
		double& pos = pPosSeries->m_Data[curr];
		vol = SPEC_VOL(curr);
		pos = d.QPositionQty;
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}

	CalLeftAxisYMaxMinValue(pVolSeries->m_Data, true, false);
	CalRightAxisYMaxMinValue(pPosSeries->m_Data);

	CalSubTagLine(LineType_VOL);
	
}

void TKLineChart::MACD_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	int param1 = spec.Params[0].Value; //����EMA
	int param2 = spec.Params[1].Value; //����EMA	
	int param3 = spec.Params[2].Value; //DIF�Ƶ�DEA
	if (param1 <= 0 || param2 <= 0 || param3 <= 0)
		return;
	TChartSeries* pDifSeries = new TChartSeries;
	TChartSeries* pDeaSeries = new TChartSeries;
	TBarSeries*   pMacdSeries = new TBarSeries;
	int nPre = m_pKLineCtl->m_Contract.Prec > 2 ? m_pKLineCtl->m_Contract.Prec : 2;
	AddSeries(spec, pDifSeries, 0, L"DIFF", nPre, true, true);
	AddSeries(spec, pDeaSeries, 1, L"DEA", nPre, true, true);
	AddSeries(spec, pMacdSeries, 1, L"DEA", nPre, true, true);

	int curr = m_pKLineCtl->m_AxisX.KData.ReadIndex;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		int pre = (curr - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		if (SPEC_CLOSE(curr) == 0 || SPEC_CLOSE(pre) == 0)
		{
			m_Cache[0][curr] = SPEC_CLOSE(curr);
			m_Cache[1][curr] = SPEC_CLOSE(curr);
			pDifSeries->m_Data[curr] = 0;
			pDeaSeries->m_Data[curr] = 0;
			pMacdSeries->m_Data[curr] = 0;
			curr = (curr + 1) % MAX_SHOW_KLINE_X;
			continue;
		}
		//����short

		double& s1 = m_Cache[0][curr];
		s1 = SPEC_CLOSE(curr);
		s1 = SPEC_EMA(m_Cache[0], curr, param1);

		//����long
		double& s2 = m_Cache[1][curr];
		s2 = SPEC_CLOSE(curr);
		s2 = SPEC_EMA(m_Cache[1], curr, param2);

		//����diff
		double& diff = pDifSeries->m_Data[curr];
		diff = s1 - s2;

		//����dea
		double& dea = pDeaSeries->m_Data[curr];
		dea = diff;
		dea = SPEC_EMA(pDeaSeries->m_Data, curr, param3);

		//����macd
		double& macd = pMacdSeries->m_Data[curr];
		macd = 2 * (diff - dea);

		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	CalLeftAxisYMaxMinValue(pDifSeries->m_Data, true, true);
	CalLeftAxisYMaxMinValue(pDeaSeries->m_Data, false, true);
	CalLeftAxisYMaxMinValue(pMacdSeries->m_Data, false, true);
	//����tagline
	CalSubTagLine(LineType_ZERO);
}


void TKLineChart::KDJ_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	int param1 = spec.Params[0].Value; //N
	int param2 = spec.Params[1].Value; //M1	
	int param3 = spec.Params[2].Value; //M2
	if (param1 <= 0 || param2 <= 0 || param3 <= 0)
		return;
	TChartSeries* pKSeries = new TChartSeries;
	TChartSeries* pDSeries = new TChartSeries;
	TChartSeries* pJSeries = new TChartSeries;
	int nPre = m_pKLineCtl->m_Contract.Prec > 2 ? m_pKLineCtl->m_Contract.Prec : 2;
	AddSeries(spec,pKSeries, 0, L"K", nPre, true, true);
	AddSeries(spec, pDSeries, 1, L"D", nPre, true, true);
	AddSeries(spec, pJSeries, 2, L"J", nPre, true, true);
	//ָ�����

	int curr = m_pKLineCtl->m_AxisX.KData.ReadIndex;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		double& high = m_Cache[0][curr];
		high = SPEC_HIGH(curr);
		double& low = m_Cache[1][curr];
		low = SPEC_LOW(curr);
		//����RSV
		double lowest = SPEC_Lowest(m_Cache[1],curr, param1);
		double highest = SPEC_Highest(m_Cache[0],curr, param1);

		double rsv = SPEC_SettlePrice(curr);
		double& k = pKSeries->m_Data[curr];
		double& d = pDSeries->m_Data[curr];
		double& j = pJSeries->m_Data[curr];

		rsv = 100 * ((highest > lowest) ? (SPEC_CLOSE(curr) - lowest) / (highest - lowest) : 1);

		k = rsv;
		k = SPEC_SMA(pKSeries->m_Data, curr, param2, 1);

		d = k;
		d = SPEC_SMA(pDSeries->m_Data, curr, param3, 1);

		j = 3 * k - 2 * d;

		curr = (curr + 1) % MAX_SHOW_KLINE_X;

	}
	CalLeftAxisYMaxMinValue(pJSeries->m_Data, true, true);
	CalLeftAxisYMaxMinValue(pKSeries->m_Data, false, true);
	CalLeftAxisYMaxMinValue(pDSeries->m_Data, false, true);

	CalSubTagLine(LineType_Data);
}
void TKLineChart::RSI_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	int param1 = spec.Params[0].Value; //RSI1
	int param2 = spec.Params[1].Value; //RSI2
	if (param1 <= 0 || param2 <= 0)
		return;
	TChartSeries* pRSI1Series = new TChartSeries;
	TChartSeries* pRSI2Series = new TChartSeries;
	AddSeries(spec, pRSI1Series, 0, L"RSI1", 2, true, true);
	AddSeries(spec, pRSI2Series, 1, L"RSI2", 2, true, true);
	//ָ�����
	int curr = m_pKLineCtl->m_AxisX.KData.ReadIndex;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		double& r1 = pRSI1Series->m_Data[curr];
		double& r1_a = m_Cache[1][curr];
		double& r1_b = m_Cache[2][curr];

		double& r2 = pRSI2Series->m_Data[curr];
		double& r2_a = m_Cache[4][curr];
		double& r2_b = m_Cache[5][curr];

		if (curr == m_pKLineCtl->m_AxisX.KData.ReadIndex)
		{
			r1 = 0;
			r1_a = 0;
			r1_b = 0;

			r2 = 0;
			r2_a = 0;
			r2_b = 0;
		}
		else
		{
			int pre = (curr - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
			r1_a = SPEC_MAX(SPEC_CLOSE(curr) - SPEC_CLOSE(pre), 0);
			r2_a = r1_a;
			r1_a = SPEC_SMA(m_Cache[1], curr, param1, 1);
			r2_a = SPEC_SMA(m_Cache[4], curr, param2, 1);

			r1_b = abs(SPEC_CLOSE(curr) - SPEC_CLOSE(pre));
			r2_b = r1_b;
			r1_b = SPEC_SMA(m_Cache[2], curr, param1, 1);
			r2_b = SPEC_SMA(m_Cache[5], curr, param2, 1);

			r1 = 0;
			if (0 != r1_b)
				r1 = 100 * r1_a / r1_b;

			r2 = 0;
			if (0 != r2_b)
				r2 = 100 * r2_a / r2_b;
		}

		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	CalLeftAxisYMaxMinValue(pRSI1Series->m_Data, true, true);
	CalLeftAxisYMaxMinValue(pRSI2Series->m_Data, false, true);

	CalSubTagLine(LineType_Data);
}

void TKLineChart::WR_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	int param1 = spec.Params[0].Value; //N
	if (param1 <= 0)
		return;
	TChartSeries* pWRSeries = new TChartSeries;
	AddSeries(spec, pWRSeries, 0, L"WR1", 2, true, true);
	//ָ�����
	int curr = m_pKLineCtl->m_AxisX.KData.ReadIndex;
	while (curr != m_pKLineCtl->m_AxisX.KData.WriteIndex)
	{
		double& high = m_Cache[0][curr];
		high = SPEC_HIGH(curr);
		double& low = m_Cache[1][curr];
		low = SPEC_LOW(curr);
		//����RSV
		double lowest = SPEC_Lowest(m_Cache[1],curr, param1);
		double highest = SPEC_Highest(m_Cache[0], curr, param1);

		double& wr = pWRSeries->m_Data[curr];
		wr = -100 * ((highest > lowest) ? (highest - SPEC_CLOSE(curr)) / (highest - lowest) : 0);
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	CalLeftAxisYMaxMinValue(pWRSeries->m_Data, true, true);

	CalSubTagLine(LineType_Data);
}

void TKLineChart::BIAS_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	int param1 = spec.Params[0].Value; //BIAS1
	int param2 = spec.Params[1].Value; //BIAS2
	int param3 = spec.Params[2].Value; //BIAS3
	if (param1 <= 0 || param2 <= 0 || param3 <= 0)
		return;
	TChartSeries* pV1Series = new TChartSeries;
	TChartSeries* pV2Series = new TChartSeries;
	TChartSeries* pV3Series = new TChartSeries;
	AddSeries(spec, pV1Series, 0, L"BIAS1", 2, true, true);
	AddSeries(spec, pV2Series, 1, L"BIAS2", 2, true, true);
	AddSeries(spec, pV3Series, 2, L"BIAS3", 2, true, true);
	//ָ�����
	int curr = m_pKLineCtl->m_AxisX.KData.ReadIndex;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
	
		double& close = m_Cache[0][curr];
		close = SPEC_CLOSE(curr);

		double& v1 = pV1Series->m_Data[curr];
		v1 = SPEC_MA(m_Cache[0], curr, param1);
		if (0 != v1)
			v1 = 100 * (close - v1) / v1;

		double& v2 = pV2Series->m_Data[curr];
		v2 = SPEC_MA(m_Cache[0], curr, param2);
		if (0 != v2)
			v2 = 100 * (close - v2) / v2;

		double& v3 = pV3Series->m_Data[curr];
		v3 = SPEC_MA(m_Cache[0], curr, param3);
		if (0 != v3)
			v3 = 100 * (close - v3) / v3;

		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}

	CalLeftAxisYMaxMinValue(pV1Series->m_Data,true, true);
	CalLeftAxisYMaxMinValue(pV2Series->m_Data, false, true);
	CalLeftAxisYMaxMinValue(pV3Series->m_Data, false, true);
	CalSubTagLine(LineType_Data);
}

void TKLineChart::DMI_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	int param1 = spec.Params[0].Value; //N
	int param2 = spec.Params[1].Value; //M
	if (param1 <= 0 || param2 <= 0)
		return;
	TChartSeries* pPdiSeries = new TChartSeries;
	TChartSeries* pMdiSeries = new TChartSeries;
	TChartSeries* pAdxSeries = new TChartSeries;
	TChartSeries* pAdxrSeries = new TChartSeries;
	AddSeries(spec, pPdiSeries, 0, L"PDI", 2, true, true);
	AddSeries(spec, pMdiSeries, 1, L"MDI", 2, true, true);
	AddSeries(spec, pAdxSeries, 2, L"ADX", 2, true, true);
	AddSeries(spec, pAdxrSeries, 3, L"ADXR", 2, true, true);
	//ָ�����
	int curr = m_pKLineCtl->m_AxisX.KData.ReadIndex;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		int pre = (curr - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		double& maxDif = m_Cache[0][curr];
		double HD = 0.0;
		double LD = 0.0;
		if (curr == m_pKLineCtl->m_AxisX.KData.ReadIndex)
		{
			maxDif = NAN;
			HD = NAN;
			LD = NAN;
		}
		else
		{
			maxDif = SPEC_MAX(SPEC_MAX(SPEC_HIGH(curr) - SPEC_LOW(curr), abs(SPEC_HIGH(curr) - SPEC_CLOSE(pre))), abs(SPEC_LOW(curr) - SPEC_CLOSE(pre)));			
			HD = SPEC_HIGH(curr) - SPEC_HIGH(pre);
			LD = SPEC_LOW(pre) - SPEC_LOW(curr);
		}
		double TR = SPEC_SUM(m_Cache[0], curr, param1);

		double& dmpCache = m_Cache[1][curr];
		dmpCache = SPEC_IIF(HD > 0&&HD > LD, HD, 0);
		double DMP= SPEC_SUM(m_Cache[1], curr, param1);

		double& dmmCache = m_Cache[2][curr];
		dmmCache = SPEC_IIF(LD > 0 && LD > HD, LD, 0);
		double DMM = SPEC_SUM(m_Cache[2], curr, param1);

		double& PDI = pPdiSeries->m_Data[curr];
		double& MDI = pMdiSeries->m_Data[curr];
		if (curr == m_pKLineCtl->m_AxisX.KData.ReadIndex)
		{
			PDI = NAN;
			MDI = NAN;
		}
		else
		{
			PDI = DMP * 100 / TR;
			MDI = DMM * 100 / TR;
		}

		double& adxCache = m_Cache[3][curr];
		adxCache = abs(MDI - PDI) / (MDI + PDI) * 100;
		double& ADX = pAdxSeries->m_Data[curr];
		ADX = SPEC_MA(m_Cache[3], curr, param2);

		double& ADXR = pAdxrSeries->m_Data[curr];
		ADXR = (ADX + SPEC_REF(pAdxSeries->m_Data, curr, param2)) / 2;
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	CalLeftAxisYMaxMinValue(pPdiSeries->m_Data, true, true);
	CalLeftAxisYMaxMinValue(pMdiSeries->m_Data, false, true);
	CalLeftAxisYMaxMinValue(pAdxSeries->m_Data, false, true);
	CalLeftAxisYMaxMinValue(pAdxrSeries->m_Data, false, true);
	CalSubTagLine(LineType_Data);
}

void TKLineChart::OBV_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	TChartSeries* pObvSeries = new TChartSeries;
	AddSeries(spec, pObvSeries, 0, L"OBV", 2, true, true);
	int curr = m_pKLineCtl->m_AxisX.KData.ReadIndex;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		int pre = (curr - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		double& obv = pObvSeries->m_Data[curr];
		double& Vol = m_Cache[0][curr];
		Vol = SPEC_IIF(SPEC_CLOSE(curr)>SPEC_CLOSE(pre),SPEC_VOL(curr), SPEC_IIF(SPEC_CLOSE(curr)<SPEC_CLOSE(pre),-SPEC_VOL(curr),0));
		obv = pObvSeries->m_Data[pre]+ Vol;
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	CalLeftAxisYMaxMinValue(pObvSeries->m_Data, true, true);
	CalSubTagLine(LineType_Data);
}
void TKLineChart::TRIX_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	int param1 = spec.Params[0].Value; //P
	int param2 = spec.Params[1].Value; //N
	if (param1 <= 0 || param2 <= 0)
		return;
	TChartSeries* pTrixSeries = new TChartSeries;
	TChartSeries* pTrmaSeries = new TChartSeries;
	AddSeries(spec, pTrixSeries, 0, L"TRIX", 3, true, true);
	AddSeries(spec, pTrmaSeries, 1, L"TRMA",3, true, true);
	int curr = m_pKLineCtl->m_AxisX.KData.ReadIndex;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		double& TR1 = m_Cache[0][curr];
		double& TR2 = m_Cache[1][curr];
		double& TR3 = m_Cache[2][curr];
		TR1 = SPEC_CLOSE(curr);;
		TR1 = SPEC_EMA(m_Cache[0], curr, param1);
		TR2 = TR1;
		TR2 = SPEC_EMA(m_Cache[1], curr, param1);
		TR3 = TR2;
		TR3 = SPEC_EMA(m_Cache[2], curr, param1);
		
		double& TRIX = pTrixSeries->m_Data[curr];
		if (curr == m_pKLineCtl->m_AxisX.KData.ReadIndex)
			TRIX = 0;
		else
		{
			double TRPre = SPEC_REF(m_Cache[2], curr, 1);
			TRIX = (TR3 - TRPre) / TRPre * 100;
		}
		double& TRMA = pTrmaSeries->m_Data[curr];
		TRMA = SPEC_MA(pTrixSeries->m_Data, curr, param2);
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	CalLeftAxisYMaxMinValue(pTrixSeries->m_Data, true, true);
	CalLeftAxisYMaxMinValue(pTrmaSeries->m_Data, false, true);
	CalSubTagLine(LineType_Data,3);
}
void TKLineChart::CR_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	int param1 = spec.Params[0].Value; //N
	int param2 = spec.Params[1].Value; //M1
	int param3 = spec.Params[2].Value; //M2
	int param4 = spec.Params[3].Value; //M3
	if (param1 <= 0 || param2 <= 0 || param3 <= 0 || param4 <= 0)
		return;
	TChartSeries* pCRSeries = new TChartSeries;
	TChartSeries* pMA1Series = new TChartSeries;
	TChartSeries* pMA2Series = new TChartSeries;
	TChartSeries* pMA3Series = new TChartSeries;
	AddSeries(spec, pCRSeries, 0, L"CR", 2, true, true);
	AddSeries(spec, pMA1Series, 1, L"CRMA1", 2, true, true);
	AddSeries(spec, pMA2Series, 2, L"CRMA2", 2, true, true);
	AddSeries(spec, pMA3Series, 3, L"CRMA3", 2, true, true);
	int curr = m_pKLineCtl->m_AxisX.KData.ReadIndex;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		double& midPrice = m_Cache[0][curr];
		double& M1 = m_Cache[1][curr];
		double& M2 = m_Cache[2][curr];
		double& Ma1 = m_Cache[3][curr];
		double& Ma2 = m_Cache[4][curr];
		double& Ma3 = m_Cache[5][curr];
		double& CR = pCRSeries->m_Data[curr];
		double& CRMA1 = pMA1Series->m_Data[curr];
		double& CRMA2 = pMA2Series->m_Data[curr];
		double& CRMA3 = pMA3Series->m_Data[curr];
		if (curr == m_pKLineCtl->m_AxisX.KData.ReadIndex)
		{
			midPrice = (SPEC_HIGH(curr) + SPEC_LOW(curr) + SPEC_CLOSE(curr)) / 3;
			M1 = SPEC_MAX(0, SPEC_HIGH(curr) - midPrice);
			M2 = SPEC_MAX(0, midPrice - SPEC_LOW(curr));
			CR = 0;
			Ma1 = CR;
			Ma2 = CR;
			Ma3 = CR;
			CRMA1 = Ma1;
			CRMA2 = Ma2;
			CRMA3 = Ma3;
		}
		else
		{
			midPrice = (SPEC_HIGH(curr) + SPEC_LOW(curr) + SPEC_CLOSE(curr)) / 3;
			M1 = SPEC_MAX(0, SPEC_HIGH(curr) - SPEC_REF(m_Cache[0], curr, 1));
			M2 = SPEC_MAX(0, SPEC_REF(m_Cache[0], curr, 1) - SPEC_LOW(curr));
			CR = SPEC_SUM(m_Cache[1], curr, param1) / SPEC_SUM(m_Cache[2], curr, param1) * 100;
			Ma1 = SPEC_MA(pCRSeries->m_Data, curr, param2);
			Ma2 = SPEC_MA(pCRSeries->m_Data, curr, param3);
			Ma3 = SPEC_MA(pCRSeries->m_Data, curr, param4);
			CRMA1 = SPEC_REF(m_Cache[3], curr, param2 / 2.5 + 1);
			CRMA2 = SPEC_REF(m_Cache[4], curr, param3 / 2.5 + 1);
			CRMA3 = SPEC_REF(m_Cache[5], curr, param4 / 2.5 + 1);
		}
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	CalLeftAxisYMaxMinValue(pCRSeries->m_Data, true, true);
	CalLeftAxisYMaxMinValue(pMA1Series->m_Data, false, true);
	CalLeftAxisYMaxMinValue(pMA2Series->m_Data, false, true);
	CalLeftAxisYMaxMinValue(pMA3Series->m_Data, false, true);
	CalSubTagLine(LineType_Data);
}
void TKLineChart::MTM_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	int param1 = spec.Params[0].Value; //P
	int param2 = spec.Params[1].Value; //w
	if (param1 <= 0 || param2 <= 0)
		return;
	TChartSeries* pMtmSeries = new TChartSeries;
	TChartSeries* pMtmmaSeries = new TChartSeries;
	int nPre = m_pKLineCtl->m_Contract.Prec > 2 ? m_pKLineCtl->m_Contract.Prec : 2;
	AddSeries(spec, pMtmSeries, 0, L"MTM", nPre, true, true);
	AddSeries(spec, pMtmmaSeries, 1, L"MTMMA", nPre, true, true);
	int curr = m_pKLineCtl->m_AxisX.KData.ReadIndex;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		double& close = m_Cache[0][curr];
		double& MTM = pMtmSeries->m_Data[curr];
		double& MTMMA = pMtmmaSeries->m_Data[curr];
		close = SPEC_CLOSE(curr);
		if (curr == m_pKLineCtl->m_AxisX.KData.ReadIndex)
		{
			MTM = 0;
			MTMMA = 0;
		}
		else
		{
			MTM = SPEC_CLOSE(curr) - SPEC_REF(m_Cache[0], curr, param1);
			MTMMA = SPEC_MA(pMtmSeries->m_Data, curr, param2);
		}
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	CalLeftAxisYMaxMinValue(pMtmSeries->m_Data, true, true);
	CalLeftAxisYMaxMinValue(pMtmmaSeries->m_Data, false, true);
	CalSubTagLine(LineType_ZERO);
}

void TKLineChart::PSY_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	int param1 = spec.Params[0].Value; //N
	int param2 = spec.Params[1].Value; //M
	if (param1 <= 0 || param2 <= 0)
		return;
	TChartSeries* pPsySeries = new TChartSeries;
	TChartSeries* pPsymaSeries = new TChartSeries;
	int nPre = m_pKLineCtl->m_Contract.Prec > 2 ? m_pKLineCtl->m_Contract.Prec : 2;
	AddSeries(spec, pPsySeries, 0, L"PSY", nPre, true, true);
	AddSeries(spec, pPsymaSeries, 1, L"PSYMA", nPre, true, true);
	bool ContiongArry[MAX_SHOW_KLINE_X];
	int curr = m_pKLineCtl->m_AxisX.KData.ReadIndex;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		bool& con = ContiongArry[curr];
		double& close = m_Cache[0][curr];
		double& PSY = pPsySeries->m_Data[curr];
		double& PSYMA = pPsymaSeries->m_Data[curr];
		close = SPEC_CLOSE(curr);
		if (curr == m_pKLineCtl->m_AxisX.KData.ReadIndex)
		{
			con = false;
			PSY = 0;
			PSYMA = NAN;
		}
		else
		{
			con = close > SPEC_REF(m_Cache[0],curr,1);
			PSY = SPEC_COUNT(ContiongArry, curr, param1)*1.0 / param1 * 100;
			PSYMA = SPEC_MA(pPsySeries->m_Data, curr, param2);
		}
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	CalLeftAxisYMaxMinValue(pPsySeries->m_Data, true, true);
	CalLeftAxisYMaxMinValue(pPsymaSeries->m_Data, false, true);
	CalSubTagLine(LineType_Data);
}

void TKLineChart::CCI_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	int param1 = spec.Params[0].Value; //N
	if (param1 <= 0)
		return;
	TChartSeries* pCCISeries = new TChartSeries;
	AddSeries(spec, pCCISeries, 0, L"CCI", 2, true, true);
	int curr = m_pKLineCtl->m_AxisX.KData.ReadIndex;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		double& TYP = m_Cache[0][curr];
		TYP = (SPEC_CLOSE(curr) + SPEC_HIGH(curr) + SPEC_LOW(curr)) / 3;
		double& CCI = pCCISeries->m_Data[curr];
		CCI = (TYP - SPEC_MA(m_Cache[0], curr, param1)) / (0.015 * SPEC_AVEDEV(m_Cache[0], curr, param1));
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	CalLeftAxisYMaxMinValue(pCCISeries->m_Data, true, true);
	CalSubTagLine(LineType_Data);
}
void TKLineChart::VR_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	int param1 = spec.Params[0].Value; //N
	if (param1 <= 0)
		return;
	TChartSeries* pVRSeries = new TChartSeries;
	AddSeries(spec, pVRSeries, 0, L"", 2, true, true);
	int curr = m_pKLineCtl->m_AxisX.KData.ReadIndex;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		double& close = m_Cache[0][curr];
		close = SPEC_CLOSE(curr);
		double LC = SPEC_REF(m_Cache[0], curr, 1);
		double& V1 = m_Cache[1][curr];
		V1 = SPEC_IIF(close > LC, SPEC_VOL(curr), 0);
		double& V2 = m_Cache[2][curr];
		V2 = SPEC_IIF(close <= LC, SPEC_VOL(curr), 0);
		double& VR = pVRSeries->m_Data[curr];
		VR = SPEC_SUM(m_Cache[1], curr, param1) / SPEC_SUM(m_Cache[2], curr, param1) * 100;
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	CalLeftAxisYMaxMinValue(pVRSeries->m_Data, true, true);
	CalSubTagLine(LineType_Data);
}

void TKLineChart::TP_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	if (m_pKLineCtl->m_Contract.Cont->Commodity->CommodityType != S_COMMODITYTYPE_OPTION)
		return;
	TChartSeries* pTPSeries = new TChartSeries;
	int nPre = m_pKLineCtl->m_Contract.Prec > 2 ? m_pKLineCtl->m_Contract.Prec : 2;
	AddSeries(spec, pTPSeries, 0, L"", nPre, true, true);
	int curr = m_pKLineCtl->m_AxisX.Begin;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		SHisQuoteData d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		double& TP = pTPSeries->m_Data[curr];
		TP = m_pKLineCtl->m_Contract.HisVolatilityData.Data[m_pKLineCtl->m_Contract.HisVolatilityData.ReadIndex].TheoryPrice;
		int cindex = (m_pKLineCtl->m_Contract.HisVolatilityData.WriteIndex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		while (cindex != m_pKLineCtl->m_Contract.HisVolatilityData.ReadIndex )
		{
			SHisVolatilityData v = m_pKLineCtl->m_Contract.HisVolatilityData.Data[cindex];
			if (v.DateTimeStamp <= d.DateTimeStamp)
			{
				TP = v.TheoryPrice;
				break;
			}
			cindex = (cindex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		}
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	CalLeftAxisYMaxMinValue(pTPSeries->m_Data, true, true);
	CalSubTagLine(LineType_Data);
}
void TKLineChart::IV_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	if (m_pKLineCtl->m_Contract.Cont->Commodity->CommodityType != S_COMMODITYTYPE_OPTION)
		return;
	TChartSeries* pIVSeries = new TChartSeries;
	AddSeries(spec, pIVSeries, 0, L"", 4, true, true);
	int curr = m_pKLineCtl->m_AxisX.Begin;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		SHisQuoteData d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		double& IV = pIVSeries->m_Data[curr];
		IV = m_pKLineCtl->m_Contract.HisVolatilityData.Data[m_pKLineCtl->m_Contract.HisVolatilityData.ReadIndex].Sigma;
		int cindex = (m_pKLineCtl->m_Contract.HisVolatilityData.WriteIndex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		while (cindex != m_pKLineCtl->m_Contract.HisVolatilityData.ReadIndex)
		{
			SHisVolatilityData v = m_pKLineCtl->m_Contract.HisVolatilityData.Data[cindex];
			if (v.DateTimeStamp <= d.DateTimeStamp)
			{
				IV = v.Sigma;
				break;
			}
			cindex = (cindex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		}
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	CalLeftAxisYMaxMinValue(pIVSeries->m_Data, true, true);
	CalSubTagLine(LineType_Data);
}
void TKLineChart::Delta_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	if (m_pKLineCtl->m_Contract.Cont->Commodity->CommodityType != S_COMMODITYTYPE_OPTION)
		return;
	TChartSeries* pDeltaSeries = new TChartSeries;
	AddSeries(spec, pDeltaSeries, 0, L"", 4, true, true);
	int curr = m_pKLineCtl->m_AxisX.Begin;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		SHisQuoteData d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		double& Delta = pDeltaSeries->m_Data[curr];
		Delta = m_pKLineCtl->m_Contract.HisVolatilityData.Data[m_pKLineCtl->m_Contract.HisVolatilityData.ReadIndex].Delta;
		int cindex = (m_pKLineCtl->m_Contract.HisVolatilityData.WriteIndex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		while (cindex != m_pKLineCtl->m_Contract.HisVolatilityData.ReadIndex)
		{
			SHisVolatilityData v = m_pKLineCtl->m_Contract.HisVolatilityData.Data[cindex];
			if (v.DateTimeStamp <= d.DateTimeStamp)
			{
				Delta = v.Delta;
				break;
			}
			cindex = (cindex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		}
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	CalLeftAxisYMaxMinValue(pDeltaSeries->m_Data, true, true);
	CalSubTagLine(LineType_Data);
}
void TKLineChart::Gamma_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	if (m_pKLineCtl->m_Contract.Cont->Commodity->CommodityType != S_COMMODITYTYPE_OPTION)
		return;
	TChartSeries* pGammaSeries = new TChartSeries;
	AddSeries(spec, pGammaSeries, 0, L"", 4, true, true);
	int curr = m_pKLineCtl->m_AxisX.Begin;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		SHisQuoteData d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		double& Gamma = pGammaSeries->m_Data[curr];
		Gamma = m_pKLineCtl->m_Contract.HisVolatilityData.Data[m_pKLineCtl->m_Contract.HisVolatilityData.ReadIndex].Gamma;
		int cindex = (m_pKLineCtl->m_Contract.HisVolatilityData.WriteIndex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		while (cindex != m_pKLineCtl->m_Contract.HisVolatilityData.ReadIndex)
		{
			SHisVolatilityData v = m_pKLineCtl->m_Contract.HisVolatilityData.Data[cindex];
			if (v.DateTimeStamp <= d.DateTimeStamp)
			{
				Gamma = v.Gamma;
				break;
			}
			cindex = (cindex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		}
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	CalLeftAxisYMaxMinValue(pGammaSeries->m_Data, true, true);
	CalSubTagLine(LineType_Data);
}
void TKLineChart::Vega_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	if (m_pKLineCtl->m_Contract.Cont->Commodity->CommodityType != S_COMMODITYTYPE_OPTION)
		return;
	TChartSeries* pVegaSeries = new TChartSeries;
	AddSeries(spec, pVegaSeries, 0, L"", 4, true, true);
	int curr = m_pKLineCtl->m_AxisX.Begin;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		SHisQuoteData d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		double& Vega = pVegaSeries->m_Data[curr];
		Vega = m_pKLineCtl->m_Contract.HisVolatilityData.Data[m_pKLineCtl->m_Contract.HisVolatilityData.ReadIndex].Vega;
		int cindex = (m_pKLineCtl->m_Contract.HisVolatilityData.WriteIndex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		while (cindex != m_pKLineCtl->m_Contract.HisVolatilityData.ReadIndex)
		{
			SHisVolatilityData v = m_pKLineCtl->m_Contract.HisVolatilityData.Data[cindex];
			if (v.DateTimeStamp <= d.DateTimeStamp)
			{
				Vega = v.Vega;
				break;
			}
			cindex = (cindex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		}
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	CalLeftAxisYMaxMinValue(pVegaSeries->m_Data, true, true);
	CalSubTagLine(LineType_Data);
}
void TKLineChart::Theta_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	if (m_pKLineCtl->m_Contract.Cont->Commodity->CommodityType != S_COMMODITYTYPE_OPTION)
		return;
	TChartSeries* pThetaSeries = new TChartSeries;
	AddSeries(spec, pThetaSeries, 0, L"",4, true, true);
	int curr = m_pKLineCtl->m_AxisX.Begin;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		SHisQuoteData d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		double& Theta = pThetaSeries->m_Data[curr];
		Theta = m_pKLineCtl->m_Contract.HisVolatilityData.Data[m_pKLineCtl->m_Contract.HisVolatilityData.ReadIndex].Theta;
		int cindex = (m_pKLineCtl->m_Contract.HisVolatilityData.WriteIndex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		while (cindex != m_pKLineCtl->m_Contract.HisVolatilityData.ReadIndex)
		{
			SHisVolatilityData v = m_pKLineCtl->m_Contract.HisVolatilityData.Data[cindex];
			if (v.DateTimeStamp <= d.DateTimeStamp)
			{
				Theta = v.Theta;
				break;
			}
			cindex = (cindex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		}
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	CalLeftAxisYMaxMinValue(pThetaSeries->m_Data, true, true);
	CalSubTagLine(LineType_Data);
}
void TKLineChart::Rho_CalcIndi(int index)
{
	TKChartSpec& spec = KChartSpec[index];
	if (!spec.Visible)
		return;
	if (m_pKLineCtl->m_Contract.Cont->Commodity->CommodityType != S_COMMODITYTYPE_OPTION)
		return;
	TChartSeries* pRhoSeries = new TChartSeries;
	AddSeries(spec, pRhoSeries, 0, L"", 4, true, true);
	int curr = m_pKLineCtl->m_AxisX.Begin;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		SHisQuoteData d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		double& Rho = pRhoSeries->m_Data[curr];
		Rho = m_pKLineCtl->m_Contract.HisVolatilityData.Data[m_pKLineCtl->m_Contract.HisVolatilityData.ReadIndex].Rho;
		int cindex = (m_pKLineCtl->m_Contract.HisVolatilityData.WriteIndex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		while (cindex != m_pKLineCtl->m_Contract.HisVolatilityData.ReadIndex)
		{
			SHisVolatilityData v = m_pKLineCtl->m_Contract.HisVolatilityData.Data[cindex];
			if (v.DateTimeStamp <= d.DateTimeStamp)
			{
				Rho = v.Rho;
				break;
			}
			cindex = (cindex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		}
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	CalLeftAxisYMaxMinValue(pRhoSeries->m_Data, true, true);
	CalSubTagLine(LineType_Data);
}
double TKLineChart::SPEC_HIGH(int curr)
{
	if (curr >= 0 && curr < MAX_SHOW_KLINE_X)
	{
		SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		if (m_pKLineCtl->m_Contract.IsTick())
			return d.QLastPrice;
		else
			return d.QHighPrice;
	}
	return 0;
}
double TKLineChart::SPEC_LOW(int curr)
{
	if (curr >= 0 && curr < MAX_SHOW_KLINE_X)
	{
		SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		if (m_pKLineCtl->m_Contract.IsTick())
			return d.QLastPrice;
		else
			return d.QLowPrice;
	}
	return 0;
}
double TKLineChart::SPEC_CLOSE(int curr)
{
	if (curr >= 0 && curr < MAX_SHOW_KLINE_X)
	{
		SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		return d.QLastPrice;
	}
	return 0;
}
double TKLineChart::SPEC_SettlePrice(int curr)
{
	if (curr >= 0 && curr < MAX_SHOW_KLINE_X)
	{
		SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		return d.QSettlePrice;
	}
	return 0;
}
long long TKLineChart::SPEC_VOL(int curr)
{
	if (curr >= 0 && curr < MAX_SHOW_KLINE_X)
	{
		bool istick(m_pKLineCtl->m_Contract.IsTick());
		SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		return (istick ? d.QLastQty : d.QKLineQty);
	}
	return 0;
}
double TKLineChart::SPEC_Lowest(double input[], int curr, int n)
{
	double ret(input[curr]);
	if (curr == m_pKLineCtl->m_AxisX.KData.ReadIndex)
		return ret;

	int cindex(curr);
	while (cindex != m_pKLineCtl->m_AxisX.KData.ReadIndex && --n > 0)
	{
		cindex = (cindex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		if(input[cindex] < ret )
		    ret = input[cindex];
	}
	return ret;
}

double TKLineChart::SPEC_Highest(double input[], int curr, int n)
{
	double ret(input[curr]);
	if (curr == m_pKLineCtl->m_AxisX.KData.ReadIndex)
		return ret;

	int cindex(curr);
	while (cindex != m_pKLineCtl->m_AxisX.KData.ReadIndex && --n > 0)
	{
		cindex = (cindex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		if (input[cindex] > ret)
			ret = input[cindex];
	}
	return ret;
}                          

double TKLineChart::SPEC_MA(double input[], int curr, int n)
{
	double ret(0);
	int rcount(0);
	
	//if (curr == m_pKLineCtl->m_AxisX.KData.ReadIndex)
	//	return ret;
	int nCount(n);
	int cindex(curr);
	while (cindex != m_pKLineCtl->m_AxisX.KData.ReadIndex && --n >= 0)
	{
		

		if (!isnan(input[cindex])&&!isinf(input[cindex]))
		{
			ret += input[cindex];
			rcount++;
		}
		cindex = (cindex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	}
	if (rcount < nCount)
		return NAN;
	else
	    return ret / rcount;
}

double TKLineChart::SPEC_SMA(double input[], int curr, int n, int m)
{
	if (curr == m_pKLineCtl->m_AxisX.KData.ReadIndex)
		return input[curr];

	int pre = (curr - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;

	return (m * input[curr] + (n - m) * input[pre]) / n;
}

double TKLineChart::SPEC_EMA(double input[], int curr, int n)
{
	return SPEC_SMA(input, curr, n + 1, 2);
}
double TKLineChart::SPCE_VariancePS(double input[], int curr, int n)
{
	double ret(0);
	if (curr == m_pKLineCtl->m_AxisX.KData.ReadIndex)
		return ret;
	if (n > 0)
	{
		int rcount = 0;
		long double SumSqr = 0.0;
		double Mean = SPEC_MA(input, curr, n);
		int cindex(curr);
		while (cindex != m_pKLineCtl->m_AxisX.KData.ReadIndex && --n >= 0)
		{
			if (!isnan(input[cindex])&&!isinf(input[cindex]))
			{
				SumSqr = SumSqr + pow(input[cindex] - Mean, 2);
				rcount++;
			}
			cindex = (cindex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		}
		if (rcount < n)
			ret = NAN;
		else
		   ret = SumSqr / rcount;
	}
	return ret;
}
double TKLineChart::SPCE_STD(double input[], int curr, int n)
{
	double VarPSValue = SPCE_VariancePS(input, curr, n);
	if (VarPSValue > 0)
	{
		return sqrt(VarPSValue);
	}
	return 0;
}
bool TKLineChart::SPEC_SAR(double AfStep, double AfLimit)
{
	double Af = AfStep;
	double HHValue = 0; //���ֵ
	double LLValue = 0; //���ֵ
	double ParOpen = 0;//��һ��K��ͣ��ֵ
	int Position = 0;//�ֲַ���
	int curr(m_pKLineCtl->m_AxisX.KData.ReadIndex);
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		//����SARֵ
		SPriceType& sarVal = m_Cache[0][curr];

		if (curr == m_pKLineCtl->m_AxisX.KData.ReadIndex)
		{
			Position = 1;
			HHValue = d.QHighPrice;
			LLValue = d.QLowPrice;
			sarVal = LLValue;
			ParOpen = sarVal + Af * (HHValue - sarVal);
			if (ParOpen > d.QLowPrice)
			{
				ParOpen = d.QLowPrice;
			}
		}
		else
		{
			SHisQuoteData& pred = m_pKLineCtl->m_AxisX.KData.GetData(curr - 1);
			if (Position == 1) //��ͷ
			{
				if (d.QLowPrice <= ParOpen)
				{
					Position = -1;
					sarVal = HHValue;
					HHValue = d.QHighPrice;
					LLValue = d.QLowPrice;
					Af = AfStep;
					ParOpen = sarVal + Af * (LLValue - sarVal);
					if (ParOpen < d.QHighPrice)
						ParOpen = d.QHighPrice;
					if (ParOpen < pred.QHighPrice)
						ParOpen = pred.QHighPrice;
				}
				else
				{
					sarVal = ParOpen;
					if (d.QHighPrice > HHValue&&Af < AfLimit)
					{
						if (Af + AfStep > AfLimit)
							Af = AfLimit;
						else
							Af = Af + AfStep;
					}
					if (d.QHighPrice > HHValue)
					{
						HHValue = d.QHighPrice;
					}
					if (d.QLowPrice < LLValue)
					{
						LLValue = d.QLowPrice;
					}
					ParOpen = sarVal + Af * (HHValue - sarVal);
					if (ParOpen > d.QLowPrice)
					{
						ParOpen = d.QLowPrice;
					}
					if (ParOpen > pred.QLowPrice)
					{
						ParOpen = pred.QLowPrice;
					}
				}
			}
			else //��ͷ
			{
				if (d.QHighPrice >= ParOpen)
				{
					Position = 1;
					sarVal = LLValue;
					HHValue = d.QHighPrice;
					LLValue = d.QLowPrice;
					Af = AfStep;
					ParOpen = sarVal + Af * (HHValue - sarVal);
					if (ParOpen > d.QLowPrice)
					{
						ParOpen = d.QLowPrice;
					}
					if (ParOpen > pred.QLowPrice)
					{
						ParOpen = pred.QLowPrice;
					}
				}
				else
				{
					sarVal = ParOpen;
					if (d.QLowPrice < LLValue&&Af < AfLimit)
					{
						if (Af + AfStep > AfLimit)
							Af = AfLimit;
						else
							Af = Af + AfStep;
					}
					if (d.QHighPrice > HHValue)
					{
						HHValue = d.QHighPrice;
					}
					if (d.QLowPrice < LLValue)
					{
						LLValue = d.QLowPrice;
					}
					ParOpen = sarVal + Af * (LLValue - sarVal);
					if (ParOpen < d.QHighPrice)
					{
						ParOpen = d.QHighPrice;
					}
					if (ParOpen < pred.QHighPrice)
					{
						ParOpen = pred.QHighPrice;
					}
				}
			}
		}
		m_Cache[1][curr] = Position;
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	return true;
}
double TKLineChart::SPEC_SUM(double input[], int curr, int n)
{
	double ret(0);
	if (curr == m_pKLineCtl->m_AxisX.KData.ReadIndex)
		return ret;

	int cindex(curr);
	while (cindex != m_pKLineCtl->m_AxisX.KData.ReadIndex && --n >= 0)
	{
		if (!isnan(input[cindex]))
		    ret += input[cindex];
		cindex = (cindex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	}
	return ret;
}
int TKLineChart::SPEC_COUNT(bool Condition[], int curr, int n)
{
	int ret = 0;
	int cindex(curr);
	while (cindex != m_pKLineCtl->m_AxisX.KData.ReadIndex && --n >= 0)
	{
		if (Condition[cindex])
			ret++;
		cindex = (cindex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	}
	if (curr == m_pKLineCtl->m_AxisX.KData.ReadIndex&&Condition[cindex])
		ret++;
	return ret;
}
double TKLineChart::SPEC_MAX(double v1, double v2)
{
	if (v1 > v2)
		return v1;
	else
		return v2;
}
double TKLineChart::SPEC_IIF(bool con, double trueValue, double falseValue)
{
	if (con)
		return trueValue;
	else
		return falseValue;
}
double TKLineChart::SPEC_REF(double input[], int curr, int n)
{
	int cindex = (curr - n + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	if (cindex >= 0 && cindex < MAX_SHOW_KLINE_X)
		return input[cindex];
	else
		return NAN;
}
double TKLineChart::SPEC_AVEDEV(double input[], int curr, int n)
{
	double Mean = SPEC_MA(input, curr, n);
	long double ret(0);
	int cindex(curr);
	int rcount(0);
	int nCount(n);
	while (cindex != m_pKLineCtl->m_AxisX.KData.ReadIndex && --n >= 0)
	{
		if (!isnan(input[cindex]) && !isinf(input[cindex]))
		{
			ret += abs(input[cindex] - Mean);
			rcount++;
		}
		cindex = (cindex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	}
	if (rcount < nCount)
		return NAN;
	else
	    return ret/ rcount;
}
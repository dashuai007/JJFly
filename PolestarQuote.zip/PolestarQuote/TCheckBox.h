#pragma once
#include "IxFrm.h"
class TCheckBox :
	public TIxFrm
{
public:
	TCheckBox();
	~TCheckBox();
	virtual LRESULT WndProc(UINT message, WPARAM wParam, LPARAM lParam);
	bool Create(HWND hwnd,int nindex = 0);
	void MoveWindow(const int& x, const int& y, const int& cx, const int& cy);
public:
	void SetBkColor(COLORREF color);
	void SetColor(COLORREF color);
	void SetText(const wchar_t* pText);
	void SetCheck(bool check);
	bool GetCheck() { return m_bChecked; }
private:
	void OnPaint();
private:
	COLORREF m_color;
	COLORREF m_colorBK;
	wchar_t m_strText[81];
	bool m_bChecked;
	bool m_bInRect;
	int	m_nindex;
private:
	const int m_selchecksize = 15;
};


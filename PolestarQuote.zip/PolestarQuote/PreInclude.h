#ifndef _PRE_INCLUDE_
#define _PRE_INCLUDE_

#define WIN32_LEAN_AND_MEAN
#define ISOLATION_AWARE_ENABLED 1
#include <windows.h>
#include <WindowsX.h>
#include <ShellAPI.h>
#include <math.h>

#include <typeinfo>
#include <tchar.h>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <sstream>
#include <iterator>
#include <fstream>
#include <iostream>
#include "..\Common\WinTools.h"
#include "..\Common\TMemDC.h"
#include "IxFrm.h"
#include "Dui_Include.h"
#include "PluginMgr_API.h"
#include "LanguageApi_API.h"
#include "MainFrame_API.h"
#include "ConfigFrame_API.h"
#include "StarApi_API.h"

#include "TradeApi_Type.h"
#include "TradeApi_Struct.h"
#include "RawTradeApi_Struct.h"
#include "StrategyTrade_API.h"
#include "CommonModule_API.h"
#include "IQuickData.h"

#include "resource.h"
#include "Global.h"
#include "DrawHelper.h"
#include "TPopupWnd.h"
#pragma comment( lib, "comctl32.lib") 
#include <commctrl.h >
#include <Commdlg.h>
#include "TComboxList.h"
#include "TCombox.h"
#include "TCheckBox.h"
#include "CxSpin.h"
#include "TEdit.h"
#include "TStaticButton.h"
#include "TListCtrl.h"
#include "OptionTacticType.h"
#include "TCheckRect.h"
#include "QuoteType.h"
#include "KLineData.h"
#include "SeriesData.h"
#include "DrawObjectStore.h"
#include "DrawToolDlg.h"
#include "Shape.h"
#include "ShapeFactory.h"
#include "ShapeChart.h"
#include "TOptionStrategy.h"
#include "QuoteUtils.h"
#include "DataArray.h"
#include "IndexParseType.h"
#include "InnerFnc.h"
#include "IndexParams.h"
#include "Index.h"
#include "IndexMgr.h"
#include "Parser.h"
#include "FncParser.h"
#include "FncRunner.h"
#include "CustomPeriodDlg.h"
#include "IntervalStatisticsDlg.h"
#include "ChartSeries.h"
#include "KLineChart.h"
#include "PlateControl.h"
#include "GridControl.h"
#include "PanelControl.h"
#include "KLineControl.h"
#include "QuoteFrame.h"
#include "ConfigWindow.h"
#include "QuoteBaseConfig.h"
#include "QuoteSkinConfig.h"
#include "QuoteFontConfig.h"
#include "QuoteShortcutConfig.h"
#endif


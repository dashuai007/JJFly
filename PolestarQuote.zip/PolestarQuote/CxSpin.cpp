#include "PreInclude.h"

//extern G_COLOREF g_ColorRefData;


CxSpin::CxSpin()
{
	m_bTracking = m_bHover = m_bFocus = m_bDown = false;
}
CxSpin::~CxSpin()
{
}
bool CxSpin::Create(HWND hparent, int nindex)
{
	m_Hwnd = CreateWindowEx(0, UPDOWN_CLASS,NULL,WS_CHILDWINDOW | WS_VISIBLE,0, 0,0, 0, hparent,(HMENU)nindex, GetModuleHandle(NULL),NULL);
	SetWindowSubclass(m_Hwnd, CxSpin::SpinProc, nindex,(DWORD_PTR)this);
	return 0;
}
void CxSpin::MoveWindow(const int& x, const int& y, const int& cx, const int& cy)
{
	SetWindowPos(m_Hwnd, 0, x, y, cx, cy, SWP_NOZORDER);
	InvalidateRect(m_Hwnd, 0, true);
}
void CxSpin::DrawTriangle(HDC &hdc, int nStartx, int nStarty, int nWidth,bool bNormal)//��������
{
	if (nWidth % 2 == 0)
		return;
	if (bNormal)
	{
		int nMidx = nStartx + nWidth / 2;
		int nMidy = nStarty + nWidth / 2;
		MoveToEx(hdc, nStartx, nStarty, NULL);
		LineTo(hdc, nMidx, nMidy);

		int nEndx = nStartx + nWidth - 1;
		int nEndy = nStarty;
		LineTo(hdc, nEndx + 1, nEndy - 1);
	}
	else
	{
		int nMidx = nStartx + nWidth / 2;
		int nMidy = nStarty - nWidth / 2;
		MoveToEx(hdc, nStartx, nStarty, NULL);
		LineTo(hdc, nMidx, nMidy);

		int nEndx = nStartx + nWidth - 1;
		int nEndy = nStarty;
		LineTo(hdc, nEndx + 1, nEndy + 1);
	}
	
}
void CxSpin::DrawItemFrame(bool bHover, bool bFocus, bool bDown)
{
	HPEN   hGrayPen = CreatePen(PS_SOLID, 1, RGB(150,150,150));
	
	HDC hDC = ::GetWindowDC(m_Hwnd);
	RECT rect, rectClient;
	::GetWindowRect(m_Hwnd, &rect);
	rectClient.left = 0;
	rectClient.top = 0;
	rectClient.right = rect.right - rect.left;
	rectClient.bottom = rect.bottom - rect.top;

	int nWidth = GetSystemMetrics(SM_CXHTHUMB);
	int nxBorder = GetSystemMetrics(SM_CXBORDER);
	int nyBorder = GetSystemMetrics(SM_CYBORDER);
	
	if (bDown)
	{	
		RECT rectArrow(rectClient);
		InflateRect(&rectArrow, -nxBorder, -nyBorder);
		int nw = rectArrow.right - rectArrow.left;
		int nvline = (rectArrow.bottom - rectArrow.top) / 2+1;

		::SetBkColor(hDC, RGB(255,255,255));
		::ExtTextOut(hDC, 0, 0, ETO_OPAQUE, &rectArrow, NULL, 0, NULL);

		SelectObject(hDC, hGrayPen);

		MoveToEx(hDC, rectArrow.left, nvline, NULL);
		LineTo(hDC, rectArrow.right, nvline);

		RECT rectDraw(rectArrow);
		if (m_point.y < nvline)
		{
			rectDraw.bottom = nvline;
			::FillSolidRect(hDC, &rectDraw, RGB(243, 243, 243));
		}	
		else if (m_point.y == nvline)
		{}
		else
		{
			rectDraw.top = nvline+1;
			::FillSolidRect(hDC, &rectDraw, RGB(243, 243, 243));
		}

		DrawTriangle(hDC, rectArrow.left + (rectArrow.right - rectArrow.left) / 2 - 2, rectArrow.top + rectArrow.bottom / 4 + nw / 6, 5, false);

		DrawTriangle(hDC, rectArrow.left + (rectArrow.right - rectArrow.left) / 2 - 2, rectArrow.top + rectArrow.bottom * 3 / 4 - nw / 6, 5);
	}
	else
	{
		RECT rectArrow(rectClient);
		InflateRect(&rectArrow, -nxBorder, -nyBorder);
		int nw = rectArrow.right - rectArrow.left;
		int nvline = (rectArrow.bottom - rectArrow.top) / 2+1;

		if (!IsWindowEnabled(m_Hwnd))
			::SetBkColor(hDC, RGB(255, 0, 0));
		else
			::SetBkColor(hDC, RGB(255, 255, 255));
		::ExtTextOut(hDC, 0, 0, ETO_OPAQUE, &rectArrow, NULL, 0, NULL);

		SelectObject(hDC, hGrayPen);

		MoveToEx(hDC, rectArrow.left, nvline, NULL);
		LineTo(hDC, rectArrow.right, nvline);

		DrawTriangle(hDC, rectArrow.left + (rectArrow.right - rectArrow.left) / 2 - 2, rectArrow.top + rectArrow.bottom / 4 + nw / 6, 5, false);

		DrawTriangle(hDC, rectArrow.left + (rectArrow.right - rectArrow.left) / 2 - 2, rectArrow.top + rectArrow.bottom * 3 / 4 - nw / 6, 5);
	}
	if (bHover || bFocus)
		::FrameRect(hDC, &rectClient, BRUSH_CONTRL_FOCUSE);
	else
		::FrameRect(hDC, &rectClient, BRUSH_CONTRL_FRAME);
	
	::ReleaseDC(m_Hwnd, hDC);

	DeleteObject(hGrayPen);
}
LRESULT	CxSpin::SpinProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData)
{
	CxSpin* pSpin = (CxSpin*)dwRefData;
	if(!pSpin)
		return DefSubclassProc(hwnd, message, wParam, lParam);
	switch (message)
	{
	case WM_NCPAINT:
	case WM_PAINT:
		{
		    DefSubclassProc(hwnd, message, wParam, lParam);
		    pSpin->DrawItemFrame(pSpin->m_bHover, pSpin->m_bFocus, pSpin->m_bDown);
			return 0;
		}
	case WM_MOUSEMOVE:
		if (!pSpin->m_bTracking)
		{
			TRACKMOUSEEVENT tme;
			tme.cbSize = sizeof(tme);
			tme.hwndTrack = pSpin->m_Hwnd;
			tme.dwFlags = TME_LEAVE | TME_HOVER;
			tme.dwHoverTime = 50;
			pSpin->m_bTracking =_TrackMouseEvent(&tme)==TRUE;
		}
		break;
	case WM_MOUSELEAVE:
		pSpin->m_bTracking = false;
		pSpin->m_bHover = false;
		pSpin->m_bDown = false;
		InvalidateRect(pSpin->m_Hwnd, 0, true);
		break;
	case WM_MOUSEHOVER:
		pSpin->m_bHover = true;
		InvalidateRect(pSpin->m_Hwnd, 0, true);
		break;
	case WM_SETFOCUS:
		pSpin->m_bFocus = true;
		InvalidateRect(pSpin->m_Hwnd, 0, true);
		break;
	case WM_KILLFOCUS:
		pSpin->m_bFocus = false;
		pSpin->m_bDown = false;
		InvalidateRect(pSpin->m_Hwnd, 0, true);
		break;//break;
	case WM_LBUTTONDOWN:
		pSpin->m_point.x = LOWORD(lParam);
		pSpin->m_point.y = HIWORD(lParam);
		pSpin->m_bDown = true;
		InvalidateRect(pSpin->m_Hwnd, 0, true);
		break;
	case WM_LBUTTONUP:
		pSpin->m_point.x = LOWORD(lParam);
		pSpin->m_point.y = HIWORD(lParam);
		pSpin->m_bDown = false;
		InvalidateRect(pSpin->m_Hwnd, 0, true);
		break;
	case WM_ERASEBKGND:
		return true;
	//case WM_CAPTURECHANGED:
	//	pSpin->DrawItemFrame(pSpin->m_bHover, pSpin->m_bFocus, pSpin->m_bDown);
	//	return 0;
	}
	return DefSubclassProc(hwnd, message, wParam, lParam);//Ĭ�ϻص�����
}

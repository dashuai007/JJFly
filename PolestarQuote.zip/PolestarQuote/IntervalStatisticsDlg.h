#pragma once
class IntervalStatisticsDlg
{
public:
	IntervalStatisticsDlg();
	~IntervalStatisticsDlg();
	bool ShowDlg(TQuoteFrame* pFrame, RSStruct* pRsData);
private:
	void OnInitDlg();
	void SetDlgRect();
	static INT_PTR CALLBACK IntervalStatisticsProc(HWND, UINT, WPARAM, LPARAM);
	void OnCommand(WPARAM wParam, LPARAM lParam);
	void OnNotify(WPARAM wParam, LPARAM lParam);
	void OnDeltaposSpin1(int iDelta);
	void OnDeltaposSpin2(int iDelta);
	void RefreshData();
	void GetCSDateTime(bool bStar,wchar_t* pTime, int nSize);
private:
	HWND           m_hWnd;        //���ھ��
	int            m_nResult;
	TQuoteFrame*   m_pFrame;
	RSStruct*      m_pRsData;
};


#include "PreInclude.h"


IndexParams IndexParams::m_Instance;
IndexParams::IndexParams()
{
}


IndexParams::~IndexParams()
{
}
void IndexParams::AddParams(std::wstring name, std::vector<TKLineSpecParam>& vParams)
{
	m_mapParamModify[name] = vParams;
}
bool IndexParams::GetParams(std::wstring name, std::vector<TKLineSpecParam>& vParams)
{
	ParamModifyMapType::iterator iter = m_mapParamModify.find(name);
	if (iter != m_mapParamModify.end())
	{
		vParams = iter->second;
		return true;
	}
	return false;
}
void IndexParams::EraseParam(std::wstring name)
{
	ParamModifyMapType::iterator iter = m_mapParamModify.find(name);
	if (iter != m_mapParamModify.end())
	{
		m_mapParamModify.erase(iter);
	}
}
void IndexParams::LoadModifyParamInfo()
{
	char currpath[1024];
	CurrPath(currpath, sizeof(currpath));

	char filename[1024];
	sprintf_s(filename, "%s\\config\\PolestarQuote\\PolestarQuote.Param.pri", currpath);

	FILE* file(NULL);
	fopen_s(&file, filename, "rb");
	if (NULL == file)
		return;
	int nSize = 0;
	fread_s(&nSize, sizeof(int), sizeof(int), 1, file);
	for (int i = 0; i < nSize; i++)
	{
		wchar_t name[21] = L"";
		fread_s(name, sizeof(name), sizeof(name), 1, file);
		int nLength = 0;
		fread_s(&nLength, sizeof(int), sizeof(int), 1, file);
		std::vector<TKLineSpecParam> vParams;
		for (int j = 0; j < nLength; j++)
		{
			TKLineSpecParam param;
			fread_s(&param, sizeof(TKLineSpecParam), sizeof(TKLineSpecParam), 1, file);
			vParams.push_back(param);
		}
		m_mapParamModify[name] = vParams;
	}
	fclose(file);
}

void IndexParams::SaveModifyParamInfo()
{
	char currpath[1024];
	CurrPath(currpath, sizeof(currpath));

	int nSize = m_mapParamModify.size();
	if (nSize <= 0)
		return;
	char filename[1024];
	sprintf_s(filename, "%s\\config\\PolestarQuote\\PolestarQuote.Param.pri", currpath);

	FILE* file(NULL);
	fopen_s(&file, filename, "wb");
	if (NULL == file)
		return;
	fwrite(&nSize, sizeof(int), 1, file);
	for (auto iter = m_mapParamModify.begin(); iter != m_mapParamModify.end(); iter++)
	{
		wchar_t name[21] = L"";
		wcscpy_s(name, iter->first.c_str());
		fwrite(name, sizeof(name), 1, file);
		nSize = iter->second.size();
		fwrite(&nSize, sizeof(int), 1, file);
		for (int j = 0; j < nSize; j++)
		{
			fwrite(&iter->second[j], sizeof(TKLineSpecParam), 1, file);
		}
	}
	fclose(file);
}
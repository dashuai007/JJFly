#include "PreInclude.h"

TCheckRect::TCheckRect() :m_nType(0)
, m_bChecked(false)
, m_bEnable(true)
, m_StrikePrice(0)
, m_Contract(NULL)
{
}
TCheckRect::TCheckRect(int nType, SPriceType dPrice, SContract* pCon, bool bEnable)
{
	m_nType = nType;
	m_bChecked = false;
	m_bEnable = bEnable;
	m_StrikePrice = dPrice;
	m_Contract = pCon;
}
TCheckRect::~TCheckRect()
{
}
void TCheckRect::SetRect(int nLf,int nTp,int nRt,int nBt)
{
	left = nLf;
	top = nTp;
	right = nRt;
	bottom = nBt;
}
void TCheckRect::SetChecked(bool bChecked)
{
		m_bChecked = bChecked;
}
SPriceType TCheckRect::GetPremium()
{
	SPriceType dPrice = 0.0;
	if (m_Contract)
	{
		SQuoteSnapShot* qCall(m_Contract->SnapShot);
		if (qCall)
		{
			SQuoteField* field = &qCall->Data[m_nType == 0? S_FID_BESTASKPRICE : S_FID_BESTBIDPRICE];
			if (S_FIDATTR_NONE != field->FidAttr)
			{
				dPrice = field->Price;
			}
			else
			{
				 field = &qCall->Data[S_FID_LASTPRICE];
				if (S_FIDATTR_NONE != field->FidAttr)
				{
					dPrice = field->Price;
				}
				else
				{
					field = &qCall->Data[S_FID_PRESETTLEPRICE];
					if (S_FIDATTR_NONE != field->FidAttr)
					{
						dPrice = field->Price;
					}
				}
			}

		}
	}
	return dPrice;
}
void TCheckRect::Draw(HDC mdc)
{
	OffsetRect(this,0, 4);
	::InflateRect(this, -3, -5);
	SetBkMode(mdc, TRANSPARENT);
	if (m_bEnable)
	{
		COLORREF col_BK = COLOR_FUTURE_BACKGROUND == 0 ? RGB(150, 150, 150): RGB(50, 50, 50);
		HBRUSH hBackground = CreateSolidBrush(col_BK);
		HPEN pen = CreatePen(PS_USERSTYLE, 2, col_BK);
		SelectObject(mdc, pen);
		FrameRect(mdc, this, hBackground);
		if (m_bChecked)
		{
			SelectObject(mdc, pen);
			InflateRect(this, -2, -2);

			POINT pp[3];
			pp[0].x = left;
			pp[0].y = top + (bottom - top) / 2;
			pp[1].x = pp[0].x + 3;
			pp[1].y = bottom - 3;
			pp[2].x = right-1;
			pp[2].y = top + 3;

			MoveToEx(mdc, pp[0].x, pp[0].y, NULL);
			LineTo(mdc, pp[1].x, pp[1].y);
			MoveToEx(mdc, pp[1].x, pp[1].y, NULL);
			LineTo(mdc, pp[2].x, pp[2].y);

			InflateRect(this, 2, 2);
		}
		DeleteObject(hBackground);
		DeleteObject(pen);
	}
	else
	{
		COLORREF col_BK = COLOR_FUTURE_BACKGROUND == 0 ? RGB(50, 50, 50) : RGB(150, 150, 150);
		HBRUSH hDisBrush = CreateSolidBrush(col_BK);
		FrameRect(mdc, this, hDisBrush);
		DeleteObject(hDisBrush);
	}
}
TCheckList::TCheckList():m_nRows(0)
{
	
}
void TCheckList::InitCheckRectData(SOptionSeriesNoType SeriesNo)
{
	RemoveAll();
	SOptionContractPair* pairs[1024];
	m_nRows = G_StarApi->GetOptionContractPairData(SeriesNo, 0, pairs, sizeof(pairs) / sizeof(SOptionContractPair*));
	for (int i = 0; i < m_nRows; i++)
	{
		SOptionContractPair* cp = pairs[i];
		if (!cp)
			continue;
		SPriceType dStrikePrice = atof(cp->StrikePrice) * cp->Contract1->Commodity->PriceMultiple;
		m_CallBuyChecks.push_back(TCheckRect(0, dStrikePrice, cp->Contract1));
		m_CallSellChecks.push_back(TCheckRect(1, dStrikePrice, cp->Contract1));
		m_PutBuyChecks.push_back(TCheckRect(0, dStrikePrice, cp->Contract2));
		m_PutSellChecks.push_back(TCheckRect(1, dStrikePrice, cp->Contract2));
	}
}
TCheckRect& TCheckList::GetAt(int nIndex, TACTICOPERATE opt)
{
	if (nIndex < 0 || nIndex >= m_CallBuyChecks.size() || nIndex >= m_CallSellChecks.size() || nIndex >= m_PutBuyChecks.size() || nIndex >= m_PutSellChecks.size())
		return TCheckRect(0,0);
	switch (opt)
	{
	case LONGCALL:
		return m_CallBuyChecks.at(nIndex);
	case SHORTCALL:
		return m_CallSellChecks.at(nIndex);
	case LONGPUT:
		return m_PutBuyChecks.at(nIndex);
	case SHORTPUT:
		return m_PutSellChecks.at(nIndex);
	}
	return TCheckRect(0,0);
}
void TCheckList::SetCheckRow(TACTICOPERATE opt, int nRow)
{
	if (nRow < 0 || nRow >= m_CallBuyChecks.size()|| nRow >= m_CallSellChecks.size()|| nRow >= m_PutBuyChecks.size()|| nRow >= m_PutSellChecks.size())
		return;
	switch (opt)
	{
	case LONGCALL:
	{
		m_CallBuyChecks[m_nCallBuyChecked].SetChecked(false);
		m_CallBuyChecks[nRow].SetChecked(true);
		m_nCallBuyChecked = nRow;
		break;
	}
	case SHORTCALL:
	{
		m_CallSellChecks[m_nCallSellChecked].SetChecked(false);
		m_CallSellChecks[nRow].SetChecked(true);
		m_nCallSellChecked = nRow;
		break;
	}
	case LONGPUT:
	{
		m_PutBuyChecks[m_nPutBuyChecked].SetChecked(false);
		m_PutBuyChecks[nRow].SetChecked(true);
		m_nPutBuyChecked = nRow;
		break;
	}
	case SHORTPUT:
	{
		m_PutSellChecks[m_nPutSellChecked].SetChecked(false);
		m_PutSellChecks[nRow].SetChecked(true);
		m_nPutSellChecked = nRow;
		break;
	}
	}
}
void TCheckList::SetFreeCheckRow(TACTICOPERATE opt, int nRow)
{
	if (nRow < 0 || nRow >= m_CallBuyChecks.size() || nRow >= m_CallSellChecks.size() || nRow >= m_PutBuyChecks.size() || nRow >= m_PutSellChecks.size())
		return;
	switch (opt)
	{
	case LONGCALL:
	{
		m_CallBuyChecks[nRow].SetChecked(!m_CallBuyChecks[nRow].GetIsChecked());
		break;
	}
	case SHORTCALL:
	{
		m_CallSellChecks[nRow].SetChecked(!m_CallSellChecks[nRow].GetIsChecked());
		break;
	}
	case LONGPUT:
	{
		m_PutBuyChecks[nRow].SetChecked(!m_PutBuyChecks[nRow].GetIsChecked());
		break;
	}
	case SHORTPUT:
	{
		m_PutSellChecks[nRow].SetChecked(!m_PutSellChecks[nRow].GetIsChecked());
		break;
	}
	}
}
int TCheckList::GetCheckListChecked(TACTICOPERATE opt)
{
	int nRow = 0;
	switch (opt)
	{
	case LONGCALL:
		nRow = m_nCallBuyChecked;
		break;
	case SHORTCALL:
		nRow = m_nCallSellChecked;
		break;
	case LONGPUT:
		nRow = m_nPutBuyChecked;
		break;
	case SHORTPUT:
		nRow = m_nPutSellChecked;
		break;
	}
	return nRow;
}
void TCheckList::DisableAll()
{
	for (size_t i = 0; i < m_nRows; i++)
	{
		if (i < m_CallBuyChecks.size()&&m_CallBuyChecks[i].IsEnable())
		{
			m_CallBuyChecks[i].SetEnable(false);
		}
		if (i < m_CallSellChecks.size() && m_CallSellChecks[i].IsEnable())
		{
			m_CallSellChecks[i].SetEnable(false);
		}
		if (i < m_PutBuyChecks.size() && m_PutBuyChecks[i].IsEnable())
		{
			m_PutBuyChecks[i].SetEnable(false);
		}
		if (i < m_PutSellChecks.size() && m_PutSellChecks[i].IsEnable())
		{
			m_PutSellChecks[i].SetEnable(false);
		}
	}
}
void TCheckList::DisableNoChecked()
{
	for (size_t i = 0; i < m_nRows; i++)
	{
		if (i < m_CallBuyChecks.size() && m_CallBuyChecks[i].IsEnable() && !m_CallBuyChecks[i].GetIsChecked())
		{
			m_CallBuyChecks[i].SetEnable(false);
		}
		if (i < m_CallSellChecks.size() && m_CallSellChecks[i].IsEnable() && !m_CallSellChecks[i].GetIsChecked())
		{
			m_CallSellChecks[i].SetEnable(false);
		}
		if (i < m_PutBuyChecks.size() && m_PutBuyChecks[i].IsEnable() && !m_PutBuyChecks[i].GetIsChecked())
		{
			m_PutBuyChecks[i].SetEnable(false);
		}
		if (i < m_PutSellChecks.size() && m_PutSellChecks[i].IsEnable() && !m_PutSellChecks[i].GetIsChecked())
		{
			m_PutSellChecks[i].SetEnable(false);
		}
	}
}
void TCheckList::EnableAll()
{
	for (size_t i = 0; i < m_nRows; i++)
	{
		if (i < m_CallBuyChecks.size() && !m_CallBuyChecks[i].IsEnable())
		{
			m_CallBuyChecks[i].SetEnable(true);
		}
		if (i < m_CallSellChecks.size() && !m_CallSellChecks[i].IsEnable())
		{
			m_CallSellChecks[i].SetEnable(true);
		}
		if (i < m_PutBuyChecks.size() && !m_PutBuyChecks[i].IsEnable())
		{
			m_PutBuyChecks[i].SetEnable(true);
		}
		if (i < m_PutSellChecks.size() && !m_PutSellChecks[i].IsEnable())
		{
			m_PutSellChecks[i].SetEnable(true);
		}
	}
}
void TCheckList::WithoutChecked()
{
	m_nCallBuyChecked = 0;
	m_nCallSellChecked = 0;
	m_nPutBuyChecked = 0;
	m_nPutSellChecked = 0;
	for (size_t i = 0; i < m_nRows; i++)
	{
		if (i < m_CallBuyChecks.size() && m_CallBuyChecks[i].GetIsChecked())
		{
			m_CallBuyChecks[i].SetChecked(false);
		}
		if (i < m_CallSellChecks.size() && m_CallSellChecks[i].GetIsChecked())
		{
			m_CallSellChecks[i].SetChecked(false);
		}
		if (i < m_PutBuyChecks.size() && m_PutBuyChecks[i].GetIsChecked())
		{
			m_PutBuyChecks[i].SetChecked(false);
		}
		if (i < m_PutSellChecks.size() && m_PutSellChecks[i].GetIsChecked())
		{
			m_PutSellChecks[i].SetChecked(false);
		}
	}
}
void TCheckList::RemoveAll()
{
	m_CallBuyChecks.clear();
	m_CallSellChecks.clear();
	m_PutBuyChecks.clear();
	m_PutSellChecks.clear();
}
void TCheckList::BackDirect()
{
	m_nCallBuyChecked = 0;
	m_nCallSellChecked = 0;
	m_nPutBuyChecked = 0;
	m_nPutSellChecked = 0;
	for (size_t i = 0; i < m_nRows; i++)
	{
		if (i < m_CallBuyChecks.size() && !m_CallBuyChecks[i].GetIsChecked() || i < m_CallSellChecks.size() && !m_CallSellChecks[i].GetIsChecked())
		{
			if (i < m_CallBuyChecks.size() && m_CallBuyChecks[i].GetIsChecked())
			{
				m_CallBuyChecks[i].SetChecked(false);
				m_CallSellChecks[i].SetChecked(true);
			}
			else if (i < m_CallSellChecks.size() && m_CallSellChecks[i].GetIsChecked())
			{
				m_CallSellChecks[i].SetChecked(false);
				m_CallBuyChecks[i].SetChecked(true);
			}
		}
		if (i < m_PutBuyChecks.size() &&! m_PutBuyChecks[i].GetIsChecked() || i < m_PutSellChecks.size() && !m_PutSellChecks[i].GetIsChecked())
		{
			if (i < m_PutBuyChecks.size() && m_PutBuyChecks[i].GetIsChecked())
			{
				m_PutBuyChecks[i].SetChecked(false);
				m_PutSellChecks[i].SetChecked(true);
			}
			else if (i < m_PutSellChecks.size() && m_PutSellChecks[i].GetIsChecked())
			{
				m_PutSellChecks[i].SetChecked(false);
				m_PutBuyChecks[i].SetChecked(true);
			}
		}
	}
}
bool TCheckList::IsAnyCheched()
{
	for (size_t i = 0; i < m_nRows; i++)
	{
		if (i < m_CallBuyChecks.size() && m_CallBuyChecks[i].GetIsChecked())
		{
			return true;
		}
		if (i < m_CallSellChecks.size() && m_CallSellChecks[i].GetIsChecked())
		{
			return true;
		}
		if (i < m_PutBuyChecks.size() && m_PutBuyChecks[i].GetIsChecked())
		{
			return true;
		}
		if (i < m_PutSellChecks.size() && m_PutSellChecks[i].GetIsChecked())
		{
			return true;
		}
	}
	return false;
}
void TCheckList::GetCheckedContract(CheckedContract& Checked)
{
	int nCount = 0;
	for (size_t i = 0; i < m_nRows; i++)
	{
		if (i < m_CallBuyChecks.size() && m_CallBuyChecks[i].GetIsChecked()&& nCount <= sizeof(Checked.operations)/sizeof(ContractOperation))
		{
			Checked.operations[nCount].type = LONGCALL;
			Checked.operations[nCount].Strike = m_CallBuyChecks[i].GetStrikePrice();
			Checked.operations[nCount].money = m_CallBuyChecks[i].GetPremium();
			SContract* pCon = m_CallBuyChecks[i].GetContract();
			if (pCon)
			{
				strcpy_s(Checked.operations[nCount].ContractNo, pCon->ContractNo);
			}
			nCount++;
		}
		if (i < m_CallSellChecks.size() && m_CallSellChecks[i].GetIsChecked())
		{
			Checked.operations[nCount].type = SHORTCALL;
			Checked.operations[nCount].Strike = m_CallSellChecks[i].GetStrikePrice();
			Checked.operations[nCount].money = m_CallSellChecks[i].GetPremium();
			SContract* pCon = m_CallSellChecks[i].GetContract();
			if (pCon)
			{
				strcpy_s(Checked.operations[nCount].ContractNo, pCon->ContractNo);
			}
			nCount++;
		}
		if (i < m_PutBuyChecks.size() && m_PutBuyChecks[i].GetIsChecked())
		{
			Checked.operations[nCount].type = LONGPUT;
			Checked.operations[nCount].Strike = m_PutBuyChecks[i].GetStrikePrice();
			Checked.operations[nCount].money = m_PutBuyChecks[i].GetPremium();
			SContract* pCon = m_PutBuyChecks[i].GetContract();
			if (pCon)
			{
				strcpy_s(Checked.operations[nCount].ContractNo, pCon->ContractNo);
			}
			nCount++;
		}
		if (i < m_PutSellChecks.size() && m_PutSellChecks[i].GetIsChecked())
		{
			Checked.operations[nCount].type = SHORTPUT;
			Checked.operations[nCount].Strike = m_PutSellChecks[i].GetStrikePrice();
			Checked.operations[nCount].money = m_PutSellChecks[i].GetPremium();
			SContract* pCon = m_PutSellChecks[i].GetContract();
			if (pCon)
			{
				strcpy_s(Checked.operations[nCount].ContractNo, pCon->ContractNo);
			}
			nCount++;
		}
	}
	Checked.ContractNum = nCount;
}
#include "PreInclude.h"

TQuoteFrame::TQuoteFrame() : m_Plate(*this), m_Grid(*this), m_KLine(*this), m_Panel(*this), m_PanelWidth(TPanelControl::MID_WIDTH)
{
	m_Panel.SetVisible(false);
	m_KLine.SetVisible(false);
	m_Grid.Switch_Plate(m_Plate.GetActivePageWithL2());
	Show(NULL, 0, 0, BRUSH_QUOTEFRAME_BACKGROUND, 0, 0, 0, 0);
	LoadCustomPeriod();
}
TQuoteFrame::~TQuoteFrame()
{
	SaveCustomPeriod();
	for (auto it = g_vFrames.begin(); it != g_vFrames.end();)
	{
		if (*it == this)
			it = g_vFrames.erase(it);
		else
			++it;

	}
}
void TQuoteFrame::AdjustPlateSelf0()
{
	TPlatePage* plate = m_Plate.GetActivePageWithL2();
	if (NULL != plate && 0 == strcmp(plate->PlateNo, "SELF1"))
		AdjustPlate();
}

void TQuoteFrame::AdjustPlate(bool bSwichPlate)
{
	TPlatePage* plate = m_Plate.GetActivePageWithL2();
	if (plate)
	{
		RECT wr;
		GetRect(wr);

		SIZE size = { wr.right - wr.left, wr.bottom - wr.top };
		POINT p;
		SIZE s;
		s.cx = size.cx;
		s.cy = plate->IsOption ? min(TPlateControl::L1_HEIGHT, size.cy) : min(TPlateControl::PLATE_HEIGHT, size.cy);
		p.x = 0;
		p.y = size.cy - s.cy;
		m_Plate.MoveAndSize(&p, &s);
		m_Plate.SetScroll(0, 1, plate->GetColScrollCount());

		uint nBottem = plate->IsOption ? max(size.cy - TPlateControl::L1_HEIGHT, 0) : max(size.cy - TPlateControl::PLATE_HEIGHT, 0);
		//�������
		s.cx = size.cx - (m_Panel.IsVisible() ? m_PanelWidth : 0);
		s.cy = nBottem;
		p.x = 0;
		p.y = 0;
		m_Grid.MoveAndSize(&p, &s);
		if(bSwichPlate)
		    m_Grid.Switch_Plate(plate);
		if (m_Panel.IsVisible())
		{
			s.cx = m_PanelWidth;
			s.cy = nBottem;
			p.x = size.cx - m_PanelWidth;
			p.y = 0;
			m_Panel.MoveAndSize(&p, &s);
			m_Panel.ChgAll();
			//SetPanelContract();
		}
		m_Plate.Redraw(NULL);
		m_Grid.Redraw(NULL);
		//��������ѡ�к�Լ�仯
		if(m_Grid.IsVisible())
		   SetPanelContract();

		SaveCfg();
	}
}

void TQuoteFrame::ScrollGrid()
{
	m_Grid.SetColBegin(m_Plate.GetScrollPos());

	m_Grid.Reload_ColsAndRows();
	m_Grid.Redraw(NULL);
}

void TQuoteFrame::AdjustGuide()
{
	m_Grid.SetSelectRow(m_Plate.GetGuideRowIndex());
	m_Grid.SetRowBegin(m_Plate.GetGuideRowIndex());
	m_Grid.Reload_Rows();
	m_Grid.Redraw(NULL);
	m_Grid.LinkageCurrContract("AdjustGuide");

	//��������ѡ�к�Լ�仯
	SetPanelContract();
}

void TQuoteFrame::ConfigColumn()
{
	//������ ��Ҫͬʱ������������� �� ����������	
	TColumnConfigWindow cfg(m_Plate.GetActivePageWithL2());
	if (cfg.ShowColumnConfigWindow())
	{
		TPlatePage* plate = m_Plate.GetActivePageWithL2();
		if (plate)
		{
			m_Plate.SetScroll(0, 1, plate->GetColScrollCount());
			m_Plate.Redraw(NULL);

			m_Grid.Reload_ColsAndRows();
			m_Grid.Redraw(NULL);
		}
	}
}

void TQuoteFrame::SelectContract()
{
	TSelectContractWindow sc(m_Plate.GetActivePageWithL2());
	if (sc.ShowSelectContractWindow())
		AdjustPlate();
}

void TQuoteFrame::SingleSelectContract()
{
	if (!m_KLine.IsVisible())
		return;
	TSingleSelectContractWindow sc;
	if (sc.ShowSelectContractWindow())
	{
		SContractNoType sno;
		sc.GetSelContractNo(sno);
		m_KLine.SetSubContract(sno);
	}
}

void TQuoteFrame::FutureScrollLeft()
{
	m_Plate.ScrollLeft();
}

void TQuoteFrame::FutureScrollRight()
{
	m_Plate.ScrollRight();
}

void TQuoteFrame::SetPanelContract()
{
	SContract* contract = m_Grid.GetSelectContract();
	if (contract == NULL)
	{
		SContractNoType sno;
		if (m_Grid.GetSpreadNo(sno))
		{
			if (m_Panel.SetSpreadContractNo(sno))
				m_Panel.RedrawLater(NULL);
		}
	}
	else
	{
		if (m_Panel.SetContract(contract))
			m_Panel.RedrawLater(NULL);
	}
}
void TQuoteFrame::CancalSelectField()
{
	if (m_Panel.IsVisible())
		m_Panel.CancalSelectField();
}
void TQuoteFrame::SetPanelWidth(int width)
{
	m_PanelWidth = width;

	RECT wr;
	GetRect(wr);

	SIZE size = { wr.right - wr.left, wr.bottom - wr.top };
	POINT p;
	SIZE s;

	if (m_Grid.IsVisible())		//�������״̬
	{
		uint nBottem = m_Grid.IsOption() ? max(size.cy - TPlateControl::L1_HEIGHT, 0) : max(size.cy - TPlateControl::PLATE_HEIGHT, 0);
		//�������
		s.cx = size.cx - (m_Panel.IsVisible() ? m_PanelWidth : 0);
		s.cy = nBottem;
		p.x = 0;
		p.y = 0;
		m_Grid.MoveAndSize(&p, &s);
		m_Grid.Reload_ColsAndRows();
		//�����̿�
		if (m_Panel.IsVisible())
		{
			s.cx = m_PanelWidth;
			s.cy = nBottem;
			p.x = size.cx - m_PanelWidth;
			p.y = 0;
			m_Panel.MoveAndSize(&p, &s);
		}
		m_Grid.Redraw(NULL);
		m_Panel.ChgAll();
		m_Panel.Redraw(NULL);
	}
	else						//K��״̬
	{
		//K�߿ؼ�
		s.cx = size.cx - (m_Panel.IsVisible() ? m_PanelWidth : 0);
		s.cy = size.cy;
		p.x = 0;
		p.y = 0;
		m_KLine.MoveAndSize(&p, &s);

		//�����̿�
		if (m_Panel.IsVisible())
		{
			s.cx = m_PanelWidth;
			s.cy = size.cy;
			p.x = size.cx - m_PanelWidth;
			p.y = 0;
			m_Panel.MoveAndSize(&p, &s);
			m_Panel.ChgAll();
		}
		m_KLine.Redraw(NULL);
		m_Panel.Redraw(NULL);
	}

	SaveCfg();
}

void TQuoteFrame::SwitchToGrid()
{
	SetCurrCursor(CURSOR_ARROW);

	m_Grid.SetVisible(true);
	m_Plate.SetVisible(true);
	m_KLine.SetVisible(false);
	m_Grid.SetFocus();
	m_KLine.DelRectTool();

	RECT wr;
	GetRect(wr);

	SIZE size = { wr.right - wr.left, wr.bottom - wr.top };
	ReSize(size);

	Redraw(NULL);

	SetPanelContract();

	SaveCfg();
}

void TQuoteFrame::SwitchToTLine()
{
	m_Grid.SetVisible(false);
	m_Plate.SetVisible(false);
	m_KLine.SetVisible(true);
	m_KLine.SetFocus();
	m_KLine.SwitchToTLine();
	SContract* contract = m_Grid.GetSelectContract();
	if (contract == NULL)
	{
		SContractNoType sno;
		if (m_Grid.GetSpreadNo(sno))
		{
			m_KLine.SetSpreadContractLinkage(sno);
		}
	}
	else
	{
		m_KLine.SetContract(contract);
	}
	RECT wr;
	GetRect(wr);

	SIZE size = { wr.right - wr.left, wr.bottom - wr.top };
	ReSize(size);

	Redraw(NULL);

	SaveCfg();
}
void TQuoteFrame::SwitchToTargetKLine()
{
	m_Grid.SetVisible(false);
	m_Plate.SetVisible(false);
	m_KLine.SetVisible(true);
	m_KLine.SetFocus();
	m_KLine.SwitchToKLine();
	SContract* contract = m_Grid.GetTargetContract();
	if (contract != NULL)
	{
		m_KLine.SetContract(contract);
	}
	RECT wr;
	GetRect(wr);

	SIZE size = { wr.right - wr.left, wr.bottom - wr.top };
	ReSize(size);

	Redraw(NULL);

	SaveCfg();
}
void TQuoteFrame::SwitchToTargetTLine()
{
	m_Grid.SetVisible(false);
	m_Plate.SetVisible(false);
	m_KLine.SetVisible(true);
	m_KLine.SetFocus();
	m_KLine.SwitchToTLine();
	SContract* contract = m_Grid.GetTargetContract();
	if (contract != NULL)
	{
		m_KLine.SetContract(contract);
	}
	RECT wr;
	GetRect(wr);

	SIZE size = { wr.right - wr.left, wr.bottom - wr.top };
	ReSize(size);

	Redraw(NULL);

	SaveCfg();
}
void TQuoteFrame::SwitchToKLine()
{
	m_Grid.SetVisible(false);
	m_Plate.SetVisible(false);
	m_KLine.SetVisible(true);
	m_KLine.SetFocus();
	SContract* contract = m_Grid.GetSelectContract();
	if (contract == NULL)
	{
		SContractNoType sno;
		if (m_Grid.GetSpreadNo(sno))
		{
			m_KLine.SwitchLineType(TLI_KLINE_TICK);
			m_KLine.SetSpreadContractLinkage(sno);
		}
	}
	else
	{
		m_KLine.SwitchToKLine();
		m_KLine.SetContract(contract);
	}

	RECT wr;
	GetRect(wr);

	SIZE size = { wr.right - wr.left, wr.bottom - wr.top };
	ReSize(size);

	Redraw(NULL);

	SaveCfg();
}

void TQuoteFrame::ChangeKLineContractUp()
{
	if (m_Grid.SelectUp())
	{
		SContract* contract = m_Grid.GetSelectContract();
		if (contract == NULL)
		{
			SContractNoType sno;
			if (m_Grid.GetSpreadNo(sno))
			{
				m_KLine.SetSpreadContractLinkage(sno);
			}
		}
		else
		{
			m_KLine.SetContract(contract);
		}
		SetPanelContract();
		SaveCfg();
		m_KLine.Redraw(NULL);
	}
}

void TQuoteFrame::ChangeKLineContractDown()
{
	if (m_Grid.SelectDown())
	{
		SContract* contract = m_Grid.GetSelectContract();
		if (contract == NULL)
		{
			SContractNoType sno;
			if (m_Grid.GetSpreadNo(sno))
			{
				m_KLine.SetSpreadContractLinkage(sno);
			}
		}
		else
		{
			m_KLine.SetContract(contract);
		}
		SetPanelContract();
		SaveCfg();
		m_KLine.Redraw(NULL);
	}
}

bool TQuoteFrame::IsPanelVisible()
{
	return m_Panel.IsVisible();
}

TQuotePanelLevelType TQuoteFrame::GetPanelLevel()
{
	if (!m_Panel.IsVisible()|| m_Panel.GetIsSmallModle())
		return 0;
	return m_Panel.GetLevel();
}
bool TQuoteFrame::IsPanelSmall()
{
	if (!m_Panel.IsVisible())
		return false;
	return m_Panel.GetIsSmallModle();
}
void TQuoteFrame::OpenClosePanel(int nIndex)
{
	if (nIndex == 31)
		m_Panel.SetVisible(false);
	else
	    m_Panel.SetVisible(true);

	if (m_Panel.IsVisible())
	{
		if (m_Grid.IsVisible())
		{
			SContract* contract = m_Grid.GetSelectContract();
			if (contract == NULL)
			{
				SContractNoType sno;
				if (m_Grid.GetSpreadNo(sno))
				{
					m_Panel.SetSpreadContractNo(sno);
				}
			}
			else
			{
				m_Panel.SetContract(contract);
			}
		}
		else
		{
			if (m_KLine.IsSpreadContract())
			{
				SContractNoType sno;
				if (m_KLine.GetSpreadNo(sno))
				{
					m_Panel.SetSpreadContractNo(sno);
				}
			}
			else
			{
				SContract* contract = m_KLine.GetContract();
				m_Panel.SetContract(contract);
			}
		}
		switch (nIndex)
		{
		case 32:
			m_Panel.SetLevel(PANEL_LEVEL_ONE);
			m_Panel.SetSmallModle(false);
			SetPanelWidth(TPanelControl::MID_WIDTH);
			break;
		case 33:
			m_Panel.SetLevel(PANEL_LEVEL_FIVE);
			m_Panel.SetSmallModle(false);
			SetPanelWidth(TPanelControl::MID_WIDTH);
			break;
		case 34:
			m_Panel.SetLevel(PANEL_LEVEL_TEN);
			m_Panel.SetSmallModle(false);
			SetPanelWidth(TPanelControl::MID_WIDTH);
			break;
		case 35:
			m_Panel.SetSmallModle(true);
			SetPanelWidth(TPanelControl::SMALL_MODEL_WIDTH);
			return;
		}
	}
	else
	{
		RECT wr;
		GetRect(wr);

		SIZE size = { wr.right - wr.left, wr.bottom - wr.top };
		ReSize(size);

		Redraw(NULL);

		SaveCfg();
	}

	
}

void TQuoteFrame::SetContract(SContract* contract)
{
	if (m_Grid.IsVisible())
	{
		if (m_Grid.SetContract(contract))
		{
			if (m_Panel.IsVisible())
			{
				m_Panel.SetContract(contract);
				m_Panel.Redraw(NULL);
			}
		}
	}
	else
	{
		if (m_KLine.IsLinkageWindow())
		{
			m_KLine.SetContract(contract);
			m_KLine.Redraw(NULL);
			if (m_Panel.IsVisible())
			{
				m_Panel.SetContract(contract);
				m_Panel.Redraw(NULL);
			}
		}
	}

	SaveCfg();
}
bool IsSpreadCommidity(SCommodityNoType ComNo)
{
	const char* pos1(strchr(ComNo, '|'));
	if (NULL == pos1 || '\0' == pos1[1] || '\0' == pos1[2])
		return false;
	if (pos1[1]=='S'|| pos1[1] == 'M')
		return true;
	return false;
}
void TQuoteFrame::QuickLinkage(SContract* contract)
{
	if (m_Grid.IsVisible())
	{
		if (IsSpreadCommidity(contract->Commodity->CommodityNo))
			return;
		SContractNoType srccno;
		G_StarApi->GetContractSrc(contract->ContractNo, srccno);

		//���
		//�Ȱ���Լԭʼ���������Ұ�飬�Ҳ����Ļ���ӳ���Ľ�����Ʒ�ֲ���
		bool bFand = false;
		const char* pos1 = strchr(srccno, '|');
		if (pos1&&pos1 > srccno)
		{
			SExchangeNoType srcExc;
			memcpy_s(srcExc, sizeof(SExchangeNoType), srccno, pos1 - srccno);
			srcExc[pos1 - srccno] = '\0';
			if (m_Plate.SelectPage(srcExc, contract->Commodity->CommodityNo))
				bFand = true;
		}
		if (!bFand&&m_Plate.SelectPage(contract->Commodity->Exchange->ExchangeNo, contract->Commodity->CommodityNo))
			bFand = true;
		if(bFand)
		{
			m_Grid.Switch_Plate(m_Plate.GetActivePageWithL2());
			m_Plate.Redraw(NULL);
		}
		if (m_Grid.SetContract(contract))
		{
			if (m_Panel.IsVisible())
			{
				m_Panel.SetContract(contract);
				m_Panel.Redraw(NULL);
			}
		}
	}
	else
	{
		if (m_KLine.IsLinkageWindow())
		{
			m_KLine.SetContract(contract);
			m_KLine.Redraw(NULL);
			if (m_Panel.IsVisible())
			{
				m_Panel.SetContract(contract);
				m_Panel.Redraw(NULL);
			}
		}
	}

	SaveCfg();
}
void TQuoteFrame::QuickOptionLinkage()
{
	//���
	if (m_Plate.SelectPage("OPTION",NULL))
	{
		m_Grid.Switch_Plate(m_Plate.GetActivePageWithL2());
		m_Plate.Redraw(NULL);
	}
}
void TQuoteFrame::SwitchKLineIndicate(wchar_t* pName)
{
	if (m_KLine.IsVisible())
	{
		m_KLine.SwitchKLineIndicate(pName);
	}
}
void TQuoteFrame::QuickSelfLinkage(char* pName)
{
	int nChild = 0;
	TPlatePage* page = G_QuoteUtils.GetPageSelf0(nChild,true, pName);
	if (NULL == page)
		return;
	m_Plate.SetActivePage(page->ParentPlate, nChild);
	AdjustPlate();
	SetCurrCursor(CURSOR_ARROW);
	if (m_KLine.IsVisible())
	{
		m_Grid.SetVisible(true);
		m_Plate.SetVisible(true);
		m_KLine.SetVisible(false);
		m_Grid.SetFocus();
		m_KLine.DelRectTool();

		//RECT wr;
		//GetRect(wr);

		//SIZE size = { wr.right - wr.left, wr.bottom - wr.top };
		//ReSize(size);

		Redraw(NULL);
		SetPanelContract();
	}
}
void TQuoteFrame::QuickLinkage(TLangIndex_PolestarQuote nType,bool bLinkage)
{
	if (m_Grid.IsVisible())
	{
		m_Grid.SetVisible(false);
		m_Plate.SetVisible(false);
		m_KLine.SetVisible(true);
		m_KLine.SetFocus();
		m_KLine.SwitchLineType(nType);
		SContract* contract = m_Grid.GetSelectContract();
		if (m_Grid.IsOption())
		{
			m_Grid.DelALLRectTool();
		}
		if (contract != NULL)
		{
			m_KLine.SetContract(contract);
		}
		else
		{
			SContractNoType sno;
			if (m_Grid.GetSpreadNo(sno))
			{
				m_KLine.SetSpreadContractLinkage(sno);
			}
			else
			{
				//��ѡ���ԼK��ͼ����֣��������һ�����׺�Լ
				SCommodity* comm(NULL);
				if (G_StarApi->GetCommodityData("ZCE", '\0', &comm, 1, false))
				{
					if (comm&&G_StarApi->GetContractData(comm->CommodityNo, '\0', &contract, 1, false))
					{
						m_KLine.SetContract(contract);
					}
				}
			}
		}
		RECT wr;
		GetRect(wr);

		SIZE size = { wr.right - wr.left, wr.bottom - wr.top };
		ReSize(size);

		Redraw(NULL);
	}
	else
	{
		if (bLinkage&&m_KLine.IsLinkageWindow()|| !bLinkage)
		{
			m_KLine.SwitchLineTypeAndRedow(nType);
		}
	}
	SaveCfg();
}

bool TQuoteFrame::SetLinkState(const char* action)
{
	return m_KLine.SetLineState(action);
}

bool TQuoteFrame::LoadCfg(HWND hwnd)
{
	char cfg[8001];
	if (!G_MainFrame->GetProperty(hwnd, cfg, sizeof(cfg)))
		return false;

	//�ȶ�ȡ����-----------------------------------------------------
	int frame(0); 
	int panel(0); //�̿� 0-�رգ�����0����
	int level(0);
	int sub(0);
	int small(0); //�Ƿ�С�̿�
	char contractid[128];
	contractid[0] = '\0';
	SContract* contract(NULL);
	char plateno[128];
	plateno[0] = '\0';
	char maincfg[1024];
	maincfg[0] = '\0';
	int showGraph(0);
	char drawobject[7002];
	drawobject[0]= '\0';
	char* pos1 = strstr(cfg, "frame=");
	if (NULL != pos1)
	{
		char* pos2 = strchr(pos1, ';');
		if (NULL != pos2)
		{
			pos2[0] = '\0';
			frame = atoi(&pos1[6]);
			pos2[0] = ';';
		}
	}

	pos1 = strstr(cfg, "panel=");
	if (NULL != pos1)
	{
		char* pos2 = strchr(pos1, ';');
		if (NULL != pos2)
		{
			pos2[0] = '\0';
			panel = atoi(&pos1[6]);

			small = panel / 1000000;
			panel = panel % 1000000;
			level = panel / 10000;
			panel = panel % 10000;
			pos2[0] = ';';
		}
	}

	pos1 = strstr(cfg, "sub=");
	if (NULL != pos1)
	{
		char* pos2 = strchr(pos1, ';');
		if (NULL != pos2)
		{
			pos2[0] = '\0';
			sub = atoi(&pos1[4]);
			pos2[0] = ';';
		}
	}

	pos1 = strstr(cfg, "contractid=");
	if (NULL != pos1)
	{
		char* pos2 = strchr(pos1, ';');
		if (NULL != pos2)
		{
			pos2[0] = '\0';
			
			SContract* cont;
			if (G_StarApi->GetContractData(NULL, &pos1[11], &cont, 1, false))
				contract = cont;

			pos2[0] = ';';
		}
	}

	pos1 = strstr(cfg, "plate=");
	if (NULL != pos1)
	{
		char* pos2 = strchr(pos1, ';');
		if (NULL != pos2)
		{
			pos2[0] = '\0';
			strncpy_s(plateno, &pos1[6], sizeof(plateno)-1);
			pos2[0] = ';';
		}
	}

	pos1 = strstr(cfg, "maincfg=");
	if (NULL != pos1)
	{
		char* pos2 = strchr(pos1, ';');
		if (NULL != pos2)
		{
			pos2[0] = '\0';
			strncpy_s(maincfg, &pos1[8], sizeof(maincfg) - 1);
			pos2[0] = ';';
		}
	}
	pos1 = strstr(cfg, "showgraph=");
	if (NULL != pos1)
	{
		char* pos2 = strchr(pos1, ';');
		if (NULL != pos2)
		{
			pos2[0] = '\0';
			showGraph = atoi(&pos1[10]);
			pos2[0] = ';';
		}
	}
	pos1 = strstr(cfg, "drawobject=");
	if (NULL != pos1)
	{
		char* pos2 = strchr(pos1, ';');
		if (NULL != pos2)
		{
			pos2[0] = '\0';
			strncpy_s(drawobject, &pos1[11], sizeof(drawobject)-1);
			pos2[0] = ';';
		}
	}
	LoadSpecialCfg();
	m_Grid.SetIsShowOptionGraph(showGraph);
	//��������-------------------------------------------------------
	if (panel > 0)
	{
		
		m_PanelWidth =  panel;
		if (small)
		{
			m_Panel.SetSmallModle(small);
			m_PanelWidth = TPanelControl::SMALL_MODEL_WIDTH;
		}
		if (level > 0)
			m_Panel.SetLevel((TQuotePanelLevelType)level);

		m_Panel.SetVisible(true);
		m_Panel.SetContract(contract);
	}
	else
	{
		m_Panel.SetVisible(false);
	}
	//���ػ�ͼ����
	m_KLine.SetChartObject(drawobject, sizeof(drawobject));
	if (frame > 0)
	{
		m_Grid.SetVisible(false);
		m_Plate.SetVisible(false);
		m_KLine.SetVisible(true);
		m_KLine.SetCfg(frame);
		m_KLine.SetContract(contract);
	}
	m_KLine.SetMainCfg(maincfg, sizeof(maincfg) - 1);
	//���
	//m_Plate.SelectPage(plateno);
	if (m_Plate.SelectPage(plateno))
	{
		m_Grid.Switch_Plate(m_Plate.GetActivePageWithL2());
		m_Plate.Redraw(NULL);
	}
	RECT wr;
	GetRect(wr);

	SIZE size = { wr.right - wr.left, wr.bottom - wr.top };
	ReSize(size);

	return true;
}
void TQuoteFrame::LoadSpecialCfg()
{
    //��ȡ�����ļ�
	char currpath[1024];
	CurrPath(currpath, sizeof(currpath) / sizeof(wchar_t));

	char filename[1024];
	sprintf_s(filename, "%s\\config\\PolestarQuote\\PolestarQuote.SpecialCfg.pri", currpath);
	bool bZceuse = GetPrivateProfileIntA("ZCE", "bzceuse", 0, filename);
	int nRowHigth = GetPrivateProfileIntA("ZCE", "rowhigth", 26, filename);
	char TargetCol[255];
	GetPrivateProfileStringA("ZCE", "targetcol", NULL, TargetCol, sizeof(TargetCol), filename);
	m_Grid.SetIsZceUse(bZceuse);
	m_Grid.SetRowHigth(nRowHigth);
	m_Grid.SetTargetAddCol(TargetCol);
}
void TQuoteFrame::SaveCfg()
{
	int frame(0); //������ʽ 0-��������TLI_KLINE_TIME��TLI_KLINE_YEAR1
	int panel(0); //�̿� 0-�رգ�����0����
	char contractid[128];
	contractid[0] = '\0';
	char maincfg[1024];
	maincfg[0] = '\0';
	//�����ͼ��
	if (m_KLine.IsVisible())
	{
		frame = m_KLine.GetCfg();
	}
	m_KLine.GetMainCfg(maincfg, sizeof(maincfg));
	//�̿�
	if (m_Panel.IsVisible())
	{
		panel = m_PanelWidth + m_Panel.GetLevel() * 10000+ m_Panel.GetIsSmallModle() * 1000000;
	}

	//��Լ
	SContract* cont = (m_Grid.IsVisible() ? m_Grid.GetSelectContract() : m_KLine.GetContract());
	if (NULL != cont)
		strncpy_s(contractid, cont->ContractNo, sizeof(contractid)-1);	

	//���
	TPlatePage* page = m_Plate.GetActivePageWithL2();
	int Showgraph(0);
	if (m_Grid.IsVisible())
	{
		Showgraph = m_Grid.GetIsShowOptionGraph();
	}

	//��ͼ����
	char drawobject[7002];
	drawobject[0] = '\0';
	m_KLine.GetChartObject(drawobject, sizeof(drawobject));
	//����
	char cfg[8001];
	sprintf_s(cfg, "frame=%d;panel=%d;contractid=%s;plate=%s;maincfg=%s;showgraph=%d;drawobject=%s;", frame, panel, contractid, (NULL != page ? page->PlateNo : ""), maincfg, Showgraph,drawobject);
	G_MainFrame->SetProperty(GetHwnd(), cfg);
}

void TQuoteFrame::SetUpDownRefType(UpDownRefType type)
{
//	if (m_Grid.IsVisible())
		m_Grid.SetUpDownRefType(type);
	//if (m_Panel.IsVisible())
		m_Panel.SetUpDownRefType(type);
}
void TQuoteFrame::SetIsShowDevision(bool bShow)
{
	m_KLine.SetIsShowDevision(bShow);
}
void TQuoteFrame::SetIsShowTimeLineRGBar(bool bShow)
{
	m_KLine.SetIsShowTimeLineRGBar(bShow);
}
void TQuoteFrame::SetShowColumnMirror(bool bShow)
{
	m_Grid.SetColumnMirror(bShow);
}
void TQuoteFrame::SetIsLeftBid(bool bLeftBid)
{
	m_Panel.SetIsLeftBid(bLeftBid);
}
void TQuoteFrame::SetIsEnterTLine(bool bTLnie)
{
	m_Grid.SetIsEnterTLine(bTLnie);
}
void TQuoteFrame::SetIsBidRedAskGreen(bool bBuyR)
{
	m_Panel.SetIsBidRedAskGreen(bBuyR);
}
void TQuoteFrame::SetIsShowAccumulate(bool bShow)
{
	m_Panel.SetIsShowAccumulate(bShow);
}
void TQuoteFrame::OptionOrderPanelSync(const char* Content)
{
	m_Grid.OptionOrderPanelSync(Content);
}
void TQuoteFrame::ApplyColorSetting()
{
	if (m_Grid.IsVisible())
	{
		m_Grid.Refresh_Data();
		m_Grid.Redraw(NULL);
		m_Plate.Redraw(NULL);
	}
	else 
	{
		m_KLine.Redraw(NULL);
	}
	m_Panel.ChgAll();
	m_Panel.Redraw(NULL);
}
void TQuoteFrame::OnShow(WPARAM wParam, LPARAM lParam)
{
	m_Grid.SetFocus();
}

void TQuoteFrame::OnSize(WPARAM wParam, LPARAM lParam)
{
	const POINTS& pts = *(POINTS*)&lParam;
	SIZE size = { pts.x, pts.y };
	ReSize(size);
}
void TQuoteFrame::OnDestroy()
{
	g_BaseCfgDlg->UnRegistQuoteFrame(this);
	g_SkinCfgDlg->UnRegistQuoteFrame(this);
	g_FontCfgDlg->UnRegistQuoteFrame(this);
}
void TQuoteFrame::OnNcDestroy()
{
	delete this;
}
void TQuoteFrame::ReSize(SIZE size)
{
	POINT p;
	SIZE s;
	
	if (m_Grid.IsVisible())		//�������״̬
	{
		//��鹤����
		s.cx = size.cx;
		s.cy = m_Grid.IsOption() ? min(TPlateControl::L1_HEIGHT, size.cy): min(TPlateControl::PLATE_HEIGHT, size.cy);
		p.x = 0;
		p.y = size.cy - s.cy;
		m_Plate.MoveAndSize(&p, &s);
		uint nBottem = m_Grid.IsOption()? max(size.cy - TPlateControl::L1_HEIGHT, 0) : max(size.cy - TPlateControl::PLATE_HEIGHT, 0);
		//�������
		s.cx = size.cx - (m_Panel.IsVisible() ? m_PanelWidth : 0);
		s.cy = nBottem;
		p.x = 0;
		p.y = 0;
		m_Grid.MoveAndSize(&p, &s);
		m_Grid.Reload_ColsAndRows();

		//�����̿�
		if (m_Panel.IsVisible())
		{
			s.cx = m_PanelWidth;
			s.cy = nBottem;
			p.x = size.cx - m_PanelWidth;
			p.y = 0;
			m_Panel.MoveAndSize(&p, &s);
			m_Panel.ChgAll();
			//SetPanelContract();
		}

		//���ú��������
		if(m_Plate.GetActivePageWithL2())
		   m_Plate.SetScroll(m_Plate.GetScrollPos(), 1, m_Plate.GetActivePageWithL2()->GetColScrollCount());
	}
	else						//K��״̬
	{
		//K�߿ؼ�
		s.cx = size.cx - (m_Panel.IsVisible() ? m_PanelWidth : 0);
		s.cy = size.cy;
		p.x = 0;
		p.y = 0;
		m_KLine.ResetShapeRect();
		m_KLine.MoveAndSize(&p, &s);
		//�����̿�
		if (m_Panel.IsVisible())
		{
			s.cx = m_PanelWidth;
			s.cy = size.cy;
			p.x = size.cx - m_PanelWidth;
			p.y = 0;
			m_Panel.MoveAndSize(&p, &s);
			m_Panel.ChgAll();
			//SetPanelContract();
		}
	}
}
void TQuoteFrame::OpenDrawToolDlg()
{
	if (!g_pDrawTool)
		g_pDrawTool = new DrawToolDlg();
	if (!IsWindow(g_pDrawTool->GetHwnd()))
		g_pDrawTool->Create(this);
}
void TQuoteFrame::OpenCustomPeriodDlg()
{
	
	CustomPeriodDlg dlg;
	dlg.m_arrPeriod.clear();
	dlg.m_arrPeriod.assign(m_arrUserPeriod.begin(), m_arrUserPeriod.end());
	if (dlg.ShowDlg(this))
	{
		m_arrUserPeriod.clear();
		m_arrUserPeriod.assign(dlg.m_arrPeriod.begin(), dlg.m_arrPeriod.end());
		UpdateUserPeriod();
	}

}
void TQuoteFrame::OpenIntervalStatisticsDlg(RSStruct* pRsData)
{
	IntervalStatisticsDlg dlg;
	dlg.ShowDlg(this, pRsData);
}
void TQuoteFrame::CalIntervalStatistics(int nStar, int nEnd)
{
	m_KLine.CalIntervalStatistics(nStar, nEnd);
}
void TQuoteFrame::UpdateUserPeriod()
{
	for (size_t i = 0; i < g_vFrames.size(); i++)
	{
		TQuoteFrame* pFrame = g_vFrames[i];
		if (pFrame)
		{
			pFrame->m_arrUserPeriod.assign(m_arrUserPeriod.begin(), m_arrUserPeriod.end());
			pFrame ->m_KLine.m_arrUserPeriod.assign(m_arrUserPeriod.begin(), m_arrUserPeriod.end());
		}
	}
}

void TQuoteFrame::LoadCustomPeriod()
{
	char currpath[1024];
	CurrPath(currpath, sizeof(currpath));

	char filename[1024];
	sprintf_s(filename, "%s\\config\\PolestarQuote\\PolestarQuote.CustomPeriod.pri", currpath);

	FILE* file(NULL);
	fopen_s(&file, filename, "rb");
	if (NULL == file)
		return;
	int nSize = 0;
	fread_s(&nSize, sizeof(int), sizeof(int), 1, file);
	//�Զ�������
	for (int i = 0; i < nSize; i++)
	{
		TKLinePeriod pid;
		fread_s(&pid, sizeof(TKLinePeriod), sizeof(TKLinePeriod), 1, file);
		if (pid.kind == 3)
			continue;
		m_arrUserPeriod.push_back(pid);
	}
	fclose(file);
	m_KLine.m_arrUserPeriod.assign(m_arrUserPeriod.begin(), m_arrUserPeriod.end());
}
void TQuoteFrame::KeyF3()
{
	m_Grid.SetVisible(false);
	m_Plate.SetVisible(false);
	m_KLine.SetVisible(true);
	m_KLine.SetFocus();
	m_KLine.SwitchToTLine();
	SContractNoType cno = "SSE|T|INDEX|000001";
	SContract* contract = NULL;
	if (!G_StarApi->GetContractData(NULL, cno, &contract, 1, false))
		return;
	m_KLine.SetContract(contract);
	if (m_Panel.IsVisible())
	{
		m_Panel.SetContract(contract);
		m_Panel.Redraw(NULL);
	}
	RECT wr;
	GetRect(wr);

	SIZE size = { wr.right - wr.left, wr.bottom - wr.top };
	ReSize(size);

	Redraw(NULL);

	SaveCfg();
}
void TQuoteFrame::KeyF4()
{
	m_Grid.SetVisible(false);
	m_Plate.SetVisible(false);
	m_KLine.SetVisible(true);
	m_KLine.SetFocus();
	m_KLine.SwitchToTLine();
	SContractNoType cno = "SZSE|T|INDEX|399001";
	SContract* contract = NULL;
	if (!G_StarApi->GetContractData(NULL, cno, &contract, 1, false))
		return;
	m_KLine.SetContract(contract);
	if (m_Panel.IsVisible())
	{
		m_Panel.SetContract(contract);
		m_Panel.Redraw(NULL);
	}
	RECT wr;
	GetRect(wr);

	SIZE size = { wr.right - wr.left, wr.bottom - wr.top };
	ReSize(size);

	Redraw(NULL);

	SaveCfg();
}
void TQuoteFrame::KeyF6()
{
	int nChild = 0;
	TPlatePage* page = G_QuoteUtils.GetPageSelf0(nChild,false);
	if (NULL == page)
		return;
	m_Plate.SetActivePage(page);
	AdjustPlateSelf0();
	SetCurrCursor(CURSOR_ARROW);
	if (m_KLine.IsVisible())
	{
		m_Grid.SetVisible(true);
		m_Plate.SetVisible(true);
		m_KLine.SetVisible(false);
		m_Grid.SetFocus();
		m_KLine.DelRectTool();

		//RECT wr;
		//GetRect(wr);

		//SIZE size = { wr.right - wr.left, wr.bottom - wr.top };
		//ReSize(size);

		Redraw(NULL);
		SetPanelContract();
	}
}
void TQuoteFrame::PriceAlertLinkage()
{
	char content[128];
	if (m_Grid.IsVisible())		//�������״̬
	{
		SContract* contract = m_Grid.GetSelectContract();
		if (contract == NULL)
		{
			SContractNoType sno;
			if (m_Grid.GetSpreadNo(sno))
			{
				sprintf_s(content, "contractid=%s;", sno);
			}
		}
		else
		{
			sprintf_s(content, "contractid=%s;", contract->ContractNo);
		}
	}
	else
	{
		if (m_KLine.IsSpreadContract())
		{
			SContractNoType sno;
			if (m_KLine.GetSpreadNo(sno))
			{
				sprintf_s(content, "contractid=%s;", sno);
			}
		}
		else
		{
			SContract* contract = m_KLine.GetContract();
			sprintf_s(content, "contractid=%s;", contract->ContractNo);
		}
	}
	PolestarQuoteLinkage(GetHwnd(), "PriceAlert", content);
}
void TQuoteFrame::SaveCustomPeriod()
{
	char currpath[1024];
	CurrPath(currpath, sizeof(currpath));

	int nSize = m_arrUserPeriod.size();
	if (nSize < 0)
		return;
	char filename[1024];
	sprintf_s(filename, "%s\\config\\PolestarQuote\\PolestarQuote.CustomPeriod.pri", currpath);

	FILE* file(NULL);
	fopen_s(&file, filename, "wb");
	if (NULL == file)
		return;
	fwrite(&nSize, sizeof(int), 1, file);
	//�Զ�������
	for (size_t i = 0; i < m_arrUserPeriod.size(); i++)
	{
		TKLinePeriod pid = m_arrUserPeriod[i];
		fwrite(&pid, sizeof(TKLinePeriod), 1, file);
	}
	fclose(file);
}
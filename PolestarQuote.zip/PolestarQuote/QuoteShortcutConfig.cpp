﻿#include "PreInclude.h"



QuoteShortcutConfig::QuoteShortcutConfig():m_nIndex(-1)
{
}


QuoteShortcutConfig::~QuoteShortcutConfig()
{
}
bool QuoteShortcutConfig::Create(HWND hparent)
{
	CreateFrm(_T("TShortcutWnd"), hparent, WS_CHILD /*| WS_VISIBLE*/ | WS_CLIPCHILDREN);
	SetWindowPos(m_Hwnd, 0, 0, 0, 800, 400, SWP_NOZORDER);
	PrepareRects();
	CreateSubCtrls();
	return true;
}
LRESULT QuoteShortcutConfig::WndProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_PAINT:
		OnPaint();
		break;
	case WM_DESTROY:
		OnDestory();
		break;
	case WM_NOTIFY:
		if (wParam == 4)
		{
			LPNMITEMACTIVATE now;
			now = (LPNMITEMACTIVATE)lParam;//得到NMITEMACTIVATE结构指针 
			switch (now->hdr.code)
			{//判断通知码  
			case NM_CLICK:
				OnListClick(now->iItem);
				break;
			}
		}
	case SSWM_STATIC_BUTTON_CLICKDOWN:
		if (lParam == 3)
		{
			OnModifyClick();
		}
		break;
	default:
		return NOT_PROCESSED;
	}
	return PROCESSED;
}
void QuoteShortcutConfig::OnPaint()
{
	TMemDC memdc(m_Hwnd);
	RECT rect;
	GetClientRect(m_Hwnd, &rect);
	FillRect(memdc.GetHdc(), &rect, BRUSH_BG_QUOTE);
}
void QuoteShortcutConfig::OnDestory()
{

}
void QuoteShortcutConfig::PrepareRects()
{
	int Top_Gap = 5;
	int Left_Gap = 15;
	RECT rect;
	GetClientRect(m_Hwnd, &rect);
	InflateRect(&rect, -Left_Gap, -Top_Gap);

	RECT& rc_l = m_Rects[LIST_RECT];
	rc_l = rect;
	rc_l.right = rc_l.left + 500;
	rc_l.bottom = rc_l.top + 200;

	RECT& rc_p = m_Rects[PLATE_RECT];
	rc_p = rc_l;
	rc_p.right = rc_l.left + 240;
	rc_p.top = rc_l.bottom + 10;
	rc_p.bottom = rc_p.top + 23;

	RECT& rc_s = m_Rects[SC_KEY_RECT];
	rc_s = rc_p;
	rc_s.left = rc_p.right + 20;
	rc_s.right = rc_s.left + 80;

	RECT& rc_m = m_Rects[MODIFY_RECT];
	rc_m = rc_s;
	rc_m.left = rc_s.right + 20;
	rc_m.right = rc_m.left + 40;
}
void QuoteShortcutConfig::CreateSubCtrls()
{
	m_ListCtrl.Create(m_Hwnd,4);
	RECT rc = m_Rects[LIST_RECT];
	m_ListCtrl.MoveWindow(rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top);
	m_ListCtrl.SetExtendedStyle(m_ListCtrl.GetExtendedStyle() | LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT | LVS_SHOWSELALWAYS);
	m_ListCtrl.InsertColumn(0,L"id", 0, 0);
	m_ListCtrl.InsertColumn(1, G_LANG->LangText(TLI_PLATE_NAME), 0, 250);
	m_ListCtrl.InsertColumn(2, G_LANG->LangText(TLI_SHORTCUT_NAME), 0, 250);
	m_ListCtrl.SetColumnWidth(1, LVSCW_AUTOSIZE_USEHEADER);

	m_PlateName.Create(m_Hwnd, 0, 1,2);
	rc = m_Rects[PLATE_RECT];
	m_PlateName.EnableEdit(false);
	m_PlateName.MoveWindow(rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top);

	m_Shortcut.Create(m_Hwnd, 0, 2,2);
	m_Shortcut.SetEditStyle(true);
	rc = m_Rects[SC_KEY_RECT];
	m_Shortcut.MoveWindow(rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top);

	m_Modify.Create(m_Hwnd, 3);
	rc = m_Rects[MODIFY_RECT];
	m_Modify.MoveWindow(rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top);
	m_Modify.SetButtonText(G_LANG->LangText(TLI_MODIFY));
	UpdateList();
}
void QuoteShortcutConfig::UpdateList()
{
	m_ListCtrl.DeleteAllItems();
	int nCount = G_QuickData->GetQryCount(Search_Auto);
	_quickdata* pQuickdata = new _quickdata[nCount];
	G_QuickData->GetGetQuick(Search_Auto, pQuickdata, nCount);
	for (size_t i = 0; i < nCount; i++)
	{
		_quickdata Quickdata = pQuickdata[i];
		wchar_t tmp[101] = L"";
		_itow_s(Quickdata.nindex, tmp, 10);
		m_ListCtrl.InsertItem(i, tmp);

		MByteToWChar(Quickdata.szdescripe, tmp, sizeof(tmp), CP_ACP);
		m_ListCtrl.SetItemText(i, 1, tmp);

		MByteToWChar(Quickdata.szkey, tmp, sizeof(tmp), CP_ACP);
		m_ListCtrl.SetItemText(i, 2, tmp);
	}
	delete[] pQuickdata;
}
void QuoteShortcutConfig::OnListClick(int nRow)
{
	wchar_t tmp[101] = L"";
	ListView_GetItemText(m_ListCtrl.GetHwnd(), nRow, 0, tmp, sizeof(tmp));
	m_nIndex = _wtoi(tmp);
	ListView_GetItemText(m_ListCtrl.GetHwnd(), nRow, 1, tmp, sizeof(tmp));
	m_PlateName.SetWindowTextW(tmp);
	ListView_GetItemText(m_ListCtrl.GetHwnd(), nRow, 2, tmp, sizeof(tmp));
	m_Shortcut.SetWindowTextW(tmp);
}
void QuoteShortcutConfig::OnModifyClick()
{
	wchar_t tmp[101] = L"";
	m_Shortcut.GetWindowTextW(tmp, sizeof(tmp));
	//错误检查
	if (wcslen(tmp) > 8)
	{
		MessageBox(m_Hwnd,G_LANG->LangText(TLI_MDSC_ERR_CODE_1), G_LANG->LangText(TLI_TIPINFO), MB_ICONINFORMATION);
		return;
	}
	char cKey[101] = "";
	WCharToMByte(tmp, cKey,sizeof(cKey), CP_ACP);
	bool bInclude = false;
	for (int i = 0; cKey[i] != 0; i++)
	{
		if (cKey[i] < 0 || cKey[i]>127)
		{
			bInclude = true;
			continue;
		}
		if (ispunct(cKey[i]))
			bInclude = true;

	}
	if (bInclude)
	{
		MessageBox(m_Hwnd, G_LANG->LangText(TLI_MDSC_ERR_CODE_2), G_LANG->LangText(TLI_TIPINFO), MB_ICONINFORMATION);
		return;
	}
	int ret = G_QuickData->ModifyQuickKey(m_nIndex, cKey);
	if (ret == 0)
	{
		m_PlateName.SetWindowTextW(L"");
		m_Shortcut.SetWindowTextW(L"");
		m_nIndex = -1;
		UpdateList();
	}
	else
	{
		wchar_t errInfo[256] = L"";
		switch (ret)
		{
		case Code_NotFund:
			wcscpy_s(errInfo, G_LANG->LangText(TLI_MDSC_ERR_CODE_3));
			break;
		case Code_KeyCF:
			wcscpy_s(errInfo, G_LANG->LangText(TLI_MDSC_ERR_CODE_4));
			break;
		case Code_KeyInvalid:
			wcscpy_s(errInfo, G_LANG->LangText(TLI_MDSC_ERR_CODE_5));
			break;
		}
		MessageBox(m_Hwnd, errInfo, G_LANG->LangText(TLI_TIPINFO), MB_ICONINFORMATION);
	}
}
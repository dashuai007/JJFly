#pragma once

const int MAX_SHOW_KLINE_X = 2400;							//������ʾ������ָ�������Ҫ��Ԥ��������
const int MAX_SHOW_KLINE_Y = 1200;							//ÿ����������һ��
//��ʷ����ѭ������
class TKLineData
{
public:
	TKLineData();
	virtual ~TKLineData();
	inline void Init()
	{
		CurrIndex = 0;
		ReadIndex = 0;
		WriteIndex = 0;
	}
	inline bool IsEmpty()
	{
		return ReadIndex == WriteIndex;
	}
	inline bool IsFull()
	{
		return ((WriteIndex + 1) % MAX_SHOW_KLINE_X == ReadIndex);
	}
	inline int Size()
	{
		return (WriteIndex - ReadIndex + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	}
	inline bool Forward()
	{
		if ((WriteIndex + 1) % MAX_SHOW_KLINE_X == ReadIndex)
			return false;
		ReadIndex = (ReadIndex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		CurrIndex = ReadIndex;
		return true;
	}
	inline bool Backward()
	{
		if (IsFull())
			ReadIndex = (ReadIndex + 1) % MAX_SHOW_KLINE_X;
		CurrIndex = WriteIndex;
		WriteIndex = (WriteIndex + 1) % MAX_SHOW_KLINE_X;
		return true;
	}
	inline SHisQuoteData& Curr()
	{
		return Data[CurrIndex];
	}
	inline SHisQuoteData& Head()
	{
		return Data[ReadIndex];
	}
	inline SHisQuoteData& Tail()
	{
		return Data[(WriteIndex - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X];
	}
	inline SHisQuoteData& GetData(int nIndex)
	{
		return Data[(nIndex + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X];
	}
	void CopyData(SHisQuoteData* pData,int& N);
	void AddData(SHisQuoteData* pData,int rsize);
	bool AppendData(SHisQuoteData& s);
	int SearchIndexByTime(SDateTimeType time);
	int							ReadIndex;
	int							WriteIndex;
private:
	int							CurrIndex;					//����׷�Ӷ����ͱ��������ƶ�
	SHisQuoteData				Data[MAX_SHOW_KLINE_X];
};

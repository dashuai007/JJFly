#ifndef _TCOMBOXLIST_H
#define _TCOMBOXLIST_H

typedef struct tagComboxStruct
{
	wchar_t			sztext[40];
	wchar_t			szvalue[40];
	wchar_t			szparam;
	int				nindex;
	bool			bshow;
	void*			pvalue;

	tagComboxStruct()
	{
		bshow = true;
		pvalue = NULL;
		memset(sztext, 0, 40);
		memset(szvalue, 0, 40);
	}
}ComboxStruct;

class TComboxList : public TPopupWnd
{
public:
	TComboxList();
	virtual ~TComboxList();
	enum{ Combox_Normal = 0,Combox_Check};
public:
	virtual	bool			Create(HWND hparent,int nstyle = Combox_Normal);
	void					SetData(const std::vector<ComboxStruct>& stldata);
	ComboxStruct			GetData(int nindex){ return m_stldata.at(nindex); }
public:
	void					SetFixWidth(bool bfix){ m_bfix = bfix; }
	int						GetListHeight();
	virtual  void			MoveWindow(const int& x, const int& y, const int& cx, const int& cy);
public:
	void					SetBkColor(COLORREF clrbk){ m_clrbk = clrbk; }
	void					SetFgColor(COLORREF clrFg){ m_clrfg = clrFg; }
protected:
	virtual		LRESULT		WndProc(UINT message, WPARAM wParam, LPARAM lParam);
	virtual		void		DrawMain(TMemDC* pmemdc, RECT& rect);

protected:
	void					OnPaint();
	void					OnSize();
	void					OnLbuttonDown(WPARAM wParam, LPARAM lParam);
	void					OnMouseMove(WPARAM wParam, LPARAM lParam);
	void					OnVScroll(WPARAM wParam, LPARAM lParam);
	void					OnMouseWheel(WPARAM wParam, LPARAM lParam);
	void					OnMouseLeave();
protected:
	int						m_nmouseover;
	int						m_nleftalign;
	int						m_nstyle;
protected:
	int						GetLineHeight();
	int						GetLineWidth();
	void					ResetScrollBars(bool brestpos = false);
	void					RefreshData();
	bool					IsOnlyShow();
private:
	bool					m_btrack;
	bool					m_bVscrollVisable;
	bool					m_bfix;
	HFONT					m_font;
	std::vector<ComboxStruct>		m_stldata;

	COLORREF				m_clrbk;
	COLORREF				m_clrfg;
private:
	const	int				m_nlinegap = 10;
	const	int				m_nmaxheight = 230;
};
#endif
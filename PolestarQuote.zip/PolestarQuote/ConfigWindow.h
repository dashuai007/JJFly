#ifndef _CONFIG_WINDOW_
#define _CONFIG_WINDOW_

//�����д���--------------------------------------------------------------------------------------------------------
typedef std::map<TPlateCol*, TPlateCol*> TPlateColCacheMapType;

class TColumnConfigWindow : public TDuiWindow, public TDuiButtonControlSpi
{
public:
	static const int WINDOW_WIDTH = 380;
	static const int WINDOW_HEIGHT = 524;
	static const int CAPTION_HEIGHT = 36;
	static const int WINDOW_BORDER = 1;
	static const int LISTVIEW_WIDTH = 280;
	static const int BTN_WIDTH = 80;
	static const int BTN_HEIGHT = 24;
	static const int BOTTOM_HEIGHT = 24;
public:
	TColumnConfigWindow(TPlatePage* plate);
	bool ShowColumnConfigWindow();

	virtual void OnButtonClick(TDuiButtonControl* obj);

protected:
	virtual void OnSize(WPARAM wParam, LPARAM lParam);
	virtual LRESULT OnMessage(UINT message, WPARAM wParam, LPARAM lParam);
private:
	void LoadData();
	void SaveData();
	void ApplayOnePlate(TPlatePage* p);
private:
	TDuiLabelControl m_Label;
	TDuiListViewControl m_ListView;
	TDuiButtonControl m_UpBtn;
	TDuiButtonControl m_DownBtn;
	TDuiButtonControl m_TopBtn;				//�ö�
	TDuiButtonControl m_BottomBtn;			//�õ�
	TDuiButtonControl m_OkBtn;
	TDuiButtonControl m_CancelBtn;
	TCheckBox         m_AllPlate;           //Ӧ�õ����а��
	TPlatePage* m_Plate;
	TPlateColCacheMapType m_CacheMap;
	bool m_ReturnOk;
};

//ѡ���Լ����--------------------------------------------------------------------------------------------------------
class TSelectContractWindow : public TDuiWindow, public TDuiButtonControlSpi, public TDuiListViewControlSpi
{
public:
	static const int WINDOW_WIDTH = 820;
	static const int WINDOW_HEIGHT = 550;
	static const int CAPTION_HEIGHT = 36;
	static const int WINDOW_BORDER = 1;
	static const int LEFT_LISTVIEW_WIDTH = 240;
	static const int LISTVIEW_WIDTH = 220;
	static const int BTN_WIDTH = 80;
	static const int BTN_HEIGHT = 24;
	static const int MAX_SELF_CONTRACT_NUM = 500;   //������ѡ����Լ
	const char SpreadNo[51] = "Local Spread";
	const char OTHER_EXCHANGE_No[51] = "Other Exchange";
public:
	TSelectContractWindow(TPlatePage* plate);

	bool ShowSelectContractWindow();

	virtual void OnButtonClick(TDuiButtonControl* obj);
	virtual void OnListViewClick(TDuiListViewControl* obj);
	virtual void OnListViewDbClick(TDuiListViewControl* obj);
protected:
	virtual void OnSize(WPARAM wParam, LPARAM lParam);

private:
	void LoadTreeDate();
	void LoadCommodity(SExchangeNoType eno,Node* pExcNode);
	void LoadContract();
	void LoadSpreadContract();
	void LoadSelect();
	bool SelectIn();						//ѡ�� ��ѡ
	bool SelectOut();						//ѡ�� ��ѡ
	bool SelectAll();                       //ȫѡ
	bool ClearAll();
	void ApplySelect();
	bool IsThreeLevel(Node* pNode);
	bool RefushTipWindow();
private:
	TDuiLabelControl m_Label;
	
	TDuiTreeViewControl m_TreeView;
	TDuiListViewControl m_ContractView;
	TDuiListViewControl m_SelectView;

	TDuiButtonControl m_InBtn;				//ѡ��
	TDuiButtonControl m_OutBtn;				//ѡ��
	TDuiButtonControl m_SelAllBtn;			//ȫѡ
	TDuiButtonControl m_ClearAllBtn;		//ȫ��
	TDuiButtonControl m_UpBtn;				//����
	TDuiButtonControl m_DownBtn;			//����
	TDuiButtonControl m_OkBtn;
	TDuiButtonControl m_CancelBtn;
	TDuiLabelControl  m_TipLabe;
	TPlatePage* m_Plate;

	std::vector<TPlateRow> m_SelectVec;

};
//��ѡ��Լ����--------------------------------------------------------------------------------------------------------
class TSingleSelectContractWindow : public TDuiWindow, public TDuiButtonControlSpi, public TDuiListViewControlSpi
{
public:
	static const int WINDOW_WIDTH = 580;
	static const int WINDOW_HEIGHT = 550;
	static const int CAPTION_HEIGHT = 36;
	static const int WINDOW_BORDER = 1;
	static const int LEFT_LISTVIEW_WIDTH = 240;
	static const int LISTVIEW_WIDTH = 220;
	static const int BTN_WIDTH = 80;
	static const int BTN_HEIGHT = 24;
	static const int MAX_SELF_CONTRACT_NUM = 500;   //������ѡ����Լ
	const char SpreadNo[51] = "Local Spread";
	const char OTHER_EXCHANGE_No[51] = "Other Exchange";
public:
	TSingleSelectContractWindow();

	bool ShowSelectContractWindow();
	void GetSelContractNo(SContractNoType& sno);
	virtual void OnButtonClick(TDuiButtonControl* obj);
	virtual void OnListViewClick(TDuiListViewControl* obj);
	virtual void OnListViewDbClick(TDuiListViewControl* obj);
protected:
	virtual void OnSize(WPARAM wParam, LPARAM lParam);

private:
	void LoadTreeDate();
	void LoadCommodity(SExchangeNoType eno, Node* pExcNode);
	void LoadContract();
	void LoadSpreadContract();
	bool LoadSelContract();
	bool IsThreeLevel(Node* pNode);
private:
	TDuiLabelControl m_Label;
	TDuiTreeViewControl m_TreeView;
	TDuiListViewControl m_ContractView;

	TDuiButtonControl m_OkBtn;
	TDuiButtonControl m_CancelBtn;
	SContractNoType   m_SelectCNo;
	bool m_Ret;
};
//����MA��ϴ���----------------------------------------------------------------------------------------------------------
class TMaConfigWindow : public TDuiWindow, public TDuiButtonControlSpi
{
public:
	static const int CAPTION_HEIGHT = 36;
	static const int WINDOW_BORDER = 1;
	static const int WINDOW_WIDTH = 240;
	static const int WINDOW_HEIGHT = 390;
	static const int LABEL_HEIGHT = 30;
	static const int LABEL_WIDTH = 55;
	static const int LABEL_GAP = 15;

	static const int EDIT_WIDTH = 130;

	static const int BTN_HEIGHT = 24;
	static const int BTN_WIDTH = 60;

public:
	TMaConfigWindow(TKChartSpec* linespace);

	bool ShowMaConfigWindow();

public:
	virtual void OnButtonClick(TDuiButtonControl* obj);

protected:
	virtual void OnSize(WPARAM wParam, LPARAM lParam);

private:
	void ClearEdit();
	void SaveEdit();
	void SetEditText(TKLineSpecParam Params[6]);
private:
	TDuiLabelControl m_Label;

	TDuiLabelControl m_Label_1;
	TDuiLabelControl m_Label_2;
	TDuiLabelControl m_Label_3;
	TDuiLabelControl m_Label_4;
	TDuiLabelControl m_Label_5;
	TDuiLabelControl m_Label_6;

	TDuiEditControl m_Edit_1;
	TDuiEditControl m_Edit_2;
	TDuiEditControl m_Edit_3;
	TDuiEditControl m_Edit_4;
	TDuiEditControl m_Edit_5;
	TDuiEditControl m_Edit_6;

	TDuiButtonControl m_Btn_Restore;
	TDuiButtonControl m_Btn_Clear;
	TDuiButtonControl m_Btn_Ok;
	TDuiButtonControl m_Btn_Cancel;

	TKChartSpec*	m_LineSpace;

	bool m_Ret;
};

#endif
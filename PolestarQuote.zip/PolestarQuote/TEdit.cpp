#include "PreInclude.h"

TEdit::TEdit()
{
	m_bmouseover = false;
	m_bmousetrack = false;
	m_blbtndown = false;
	m_benable = true;
	m_sztext = L"";
	m_nid = 0;
	m_editstyle = TES_NORMAL;
	m_hbmp = 0;
}
TEdit::~TEdit()
{
	RemoveWindowSubclass(m_edit, TEdit::EditProc, m_nid);
}

bool TEdit::Create(HWND hparent, DWORD specialstyle /*= 0*/, int nindex /* = 0 */, int ngapsize/* = 7*/)
{
	CreateFrm(_T("TEdit"), hparent, WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN);

	specialstyle |= WS_CHILD /*| WS_VISIBLE*/ | WS_CLIPSIBLINGS | WS_TABSTOP | ES_AUTOHSCROLL;
	m_edit = CreateWindowEx(0, WC_EDIT, 0, specialstyle, 0, 0, 0, 0, m_Hwnd, (HMENU)nindex, GetModuleHandle(NULL), 0);
	m_nid = nindex;
	SetWindowSubclass(m_edit, TEdit::EditProc, m_nid, 0);
	m_gapsize = ngapsize;
	return true;
}

void TEdit::MoveWindow(const int& x, const int& y, const int& cx, const int& cy)
{
 	SetWindowPos(m_Hwnd, 0, x, y, cx, cy, SWP_NOZORDER);
 	InvalidateRect(m_Hwnd, 0, true);
}

//property
void TEdit::EnableEdit(bool benable /*= true*/)
{
	wchar_t sztext[MAX_PATH];
	m_benable = benable;
	::GetWindowTextW(m_edit, sztext, sizeof(sztext));
	SetWindowText(sztext);

	EnableWindow(m_edit, benable);
}
void TEdit::SetEditBmp(int nposstyle, HBITMAP hbmp/* = NULL*/)
{
	m_editstyle = nposstyle;
	m_hbmp = hbmp;
}
void TEdit::SetFont(HFONT hfont)
{
	SendMessage(m_edit, WM_SETFONT, (WPARAM)hfont, 0);
	InvalidateRect(m_edit, 0, false);
}

void TEdit::SetWindowText(const wchar_t* ptext)
{
	::SetWindowTextW(m_edit, ptext);
	if (wcslen(ptext)/* && m_benable*/)
		ShowWindow(m_edit, SW_SHOW);
	else
		ShowWindow(m_edit, SW_HIDE);
	InvalidateRect(m_Hwnd, 0, false);
}

void TEdit::GetWindowText(wchar_t* ptext,int nmaxcount)
{
	::GetWindowTextW(m_edit, ptext, nmaxcount);
}	

void TEdit::SetEditStyle(bool bupper)
{
	DWORD dwstyle;
	dwstyle = (DWORD)GetWindowLong(m_edit, GWL_STYLE);
	if (bupper) dwstyle = ~ES_LOWERCASE&(dwstyle | ES_UPPERCASE);
	else dwstyle = dwstyle&~ES_LOWERCASE&~ES_UPPERCASE;
	SetWindowLong(m_edit, GWL_STYLE, dwstyle);
}
//MSG
void TEdit::OnPaint()
{
	TMemDC memdc(m_Hwnd);
	HBRUSH framebrush = CreateSolidBrush(RGB(130, 130, 130)/*RGB(229, 195, 101)*/);
	HBRUSH hinablebrush = CreateSolidBrush(RGB(176, 176, 176));
	HBRUSH  hoverbrush = CreateSolidBrush(RGB(27, 152, 255));

	RECT	 rect;
	GetClientRect(m_Hwnd, &rect);
	SetBkMode(memdc.GetHdc(), TRANSPARENT);

	HBRUSH hframe;
	if (!m_benable)
		hframe = hinablebrush;
	else if(m_bmouseover)
		hframe = hoverbrush;
	else
		hframe = framebrush;

	HBRUSH hbrdef;
	hbrdef = CreateSolidBrush(RGB(255, 255, 255));
	FillRect(memdc.GetHdc(), &rect, hbrdef);
	DeleteObject(hbrdef);
	if (m_hbmp)
	{
		BITMAP bitmap;
		memset(&bitmap, 0, sizeof(BITMAP));
		GetObject(m_hbmp, sizeof(BITMAP), &bitmap);
		HDC bmpdc = CreateCompatibleDC(memdc.GetDVdc());
		SelectObject(bmpdc, m_hbmp);
		if (m_editstyle == TES_LEFT)
			BitBlt(memdc.GetHdc(), 2, rect.top + (rect.bottom - rect.top - bitmap.bmHeight)/2, bitmap.bmWidth, bitmap.bmHeight, bmpdc, 0, 0, SRCCOPY);
		else if (m_editstyle == TES_RIGHT)
			BitBlt(memdc.GetHdc(), rect.right - bitmap.bmWidth, 0, bitmap.bmWidth, bitmap.bmHeight, bmpdc, 0, 0, SRCCOPY);
		DeleteDC(bmpdc);
	}
	FrameRect(memdc.GetHdc(), &rect, hframe);

	//	if (!m_bmouseover)
	SetTextColor(memdc.GetHdc(), COLOR_IMAGE_GRAY);
	SelectObject(memdc.GetHdc(), FONT_CONTRL_QUOTE);
	InflateRect(&rect, -3, -4);
	DrawText(memdc.GetHdc(), m_sztext.c_str(), m_sztext.length(), &rect, DT_LEFT | DT_VCENTER);
	InflateRect(&rect, 3, 4);

	DrawMain(&memdc, rect, framebrush);
	DeleteObject(framebrush);
	DeleteObject(hoverbrush);
	DeleteObject(hinablebrush);
}

void TEdit::OnSize()
{
	RECT rect; GetClientRect(m_Hwnd, &rect);

	BITMAP bitmap;
	memset(&bitmap, 0, sizeof(BITMAP));
	int nleft, nright;
	nleft = m_gapsize; nright = rect.right - rect.left - m_gapsize;
	if (m_hbmp)
		GetObject(m_hbmp, sizeof(BITMAP), &bitmap);
	if (m_editstyle == TES_LEFT)
		nleft += bitmap.bmWidth;
	else if (m_editstyle == TES_RIGHT)
		nright -= bitmap.bmWidth-2;
	::MoveWindow(m_edit, nleft, m_gapsize, nright - nleft, rect.bottom - rect.top - 2 * m_gapsize, false);
}

void TEdit::OnLbuttonDown(WPARAM wParam, LPARAM lParam)
{
	if (m_benable)ShowWindow(m_edit, SW_SHOW);
	SetFocus(m_edit);
}

void TEdit::OnLbuttonUp()
{
	if (m_hbmp)
	{
		BITMAP bitmap;
		GetObject(m_hbmp, sizeof(BITMAP), &bitmap);
		RECT rect; GetClientRect(m_Hwnd, &rect);
		if (m_editstyle == TES_LEFT)
			rect.right = rect.left + bitmap.bmWidth;
		else if (m_editstyle == TES_RIGHT)
			rect.left = rect.right - bitmap.bmWidth;
		POINT pt; GetCursorPos(&pt);
		ScreenToClient(m_Hwnd, &pt);
		if (PtInRect(&rect, pt))
		{
			PostMessage(GetParent(), SSWM_SET_EDIT_CLICKDOWN, 0, (LPARAM)m_Hwnd);
		}
	/*	else
		{
			PostMessage(GetParent(), SSWM_SET_EDITBITMAP_CLICKDOWN, 0, (LPARAM)m_Hwnd);
		}*/
	}
}
void TEdit::OnMouseMove(WPARAM wParam, LPARAM lParam)
{
	m_bmouseover = true;
	if (!m_bmousetrack)
	{
		TRACKMOUSEEVENT tme;
		tme.cbSize = sizeof(tme);
		tme.dwFlags = TME_LEAVE;
		tme.hwndTrack = m_Hwnd;
		tme.dwHoverTime = 0;
		::TrackMouseEvent(&tme);
	}
	InvalidateRect(m_Hwnd, 0, false);
}

void TEdit::OnMouseLeave(WPARAM wParam, LPARAM lParam)
{
	POINT pt;
	GetCursorPos(&pt);
	ScreenToClient(m_Hwnd, &pt);

	RECT rect;
	GetClientRect(m_Hwnd, &rect);
	if (!PtInRect(&rect, pt)&&GetFocus()!=m_edit)
	{
		m_bmousetrack = false;
		m_bmouseover = false;
	}

	InvalidateRect(m_Hwnd, 0, false);
}

void TEdit::OnKillFocus(WPARAM wParam, LPARAM lParam)
{
	char sztext[21];

	HWND hwnd = GetFocus();
	GetWindowTextA(m_edit, sztext, sizeof(sztext));
	if (strlen(sztext) == 0 && hwnd!=m_edit)
		ShowWindow(m_edit,SW_HIDE);
	m_bmousetrack = false;
	m_bmouseover = false;
	InvalidateRect(m_Hwnd, 0, false);
}

void TEdit::OnCommand(WPARAM wParam, LPARAM lParam)
{
	HWND hwnd = GetParent();
	SendMessage(hwnd, WM_COMMAND, wParam, lParam);
}

LRESULT TEdit::WndProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_PAINT:
		OnPaint();
		break;
	case WM_SIZE:
		OnSize();
		break;
	case WM_LBUTTONUP:
		OnLbuttonUp();
		break;
	case WM_LBUTTONDOWN:
		OnLbuttonDown(wParam, lParam);
		break;
	case WM_MOUSEMOVE:
		OnMouseMove(wParam, lParam);
		break;
	case WM_MOUSELEAVE:
		OnMouseLeave(wParam, lParam);
		break;
	case WM_SETFOCUS:
		m_bmouseover = true;
		InvalidateRect(m_Hwnd, 0, false);
		PostMessage(m_Hwnd,WM_LBUTTONDOWN, 0, 0);
		break;
	case WM_KILLFOCUS:
		OnKillFocus(wParam, lParam);
		break;
	case WM_COMMAND:
		OnCommand(wParam, lParam);
		break;
	case SSWM_TAB_SWITCH_FOCUS:
		SendMessage(GetParent(), SSWM_TAB_SWITCH_FOCUS, 0, (LPARAM)m_Hwnd);
		break;
// 	case SSWM_EDIT_CLEAR_TEXT:
// 		SetWindowText("");
// 		break;
	case WM_CTLCOLOREDIT:
		if (!m_benable)
			SetTextColor((HDC)wParam, COLOR_IMAGE_GRAY);
		break;
	default:
		return NOT_PROCESSED;
	}

	return PROCESSED;
}

LRESULT TEdit::EditProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData)
{
	HWND hparent = ::GetParent(hwnd);
	switch (message)
	{
	case WM_LBUTTONDOWN:
		SetFocus(hwnd);
		break;
	case WM_KEYDOWN:
		if (VK_TAB == (int)wParam)
			SendMessage(hparent, SSWM_TAB_SWITCH_FOCUS, 0, 0);
		break;
	case WM_KILLFOCUS:
	case WM_ACTIVATE:
		SendMessage(hparent, message, wParam, lParam);
		break;
	}
	return DefSubclassProc(hwnd, message, wParam, lParam);
}
#include "PreInclude.h"

//ȫ�ֶ���---------------------------------------------------------------------------------------------------------------------------------
IMainFrame* G_MainFrame(NULL);
ILanguageApi* G_LANG(NULL);
IStrategyTradeAPI* G_LineOrderApi(NULL);
IConfigFrame* G_ConfigFrame(NULL);
ICommonModule* G_CommonApi(NULL);
IStarApi* G_StarApi(NULL);
IQuickData* G_QuickData(NULL);
//���鴰��---------------------------------------------------------------------------------------------------------------------------------
HBRUSH BRUSH_QUOTEFRAME_BACKGROUND;


//���-------------------------------------------------------------------------------------------------------------------------------------
COLORREF COLOR_PLATE_BACKGROUND = RGB(39, 38, 39);
COLORREF COLOR_PLATE_FONT = RGB(142, 146, 153);
COLORREF COLOR_PLATE_FONT2 = RGB(112, 116, 123);
COLORREF COLOR_PLATE_FONT_HOT = RGB(255, 255, 255);
COLORREF COLOR_PLATE_FONT_HOT2 = RGB(225, 225, 225);

HBRUSH BRUSH_PLATE_BACKGROUND;

HPEN PEN_PLATE_LINE;
HPEN PEN_PLATE_MENU;
HPEN PEN_PLATE_MENU_HOVER;

HFONT FONT_PLATE;
HFONT FONT_BLOD_PLATE;
//������-------------------------------------------------------------------------------------------------------------------------------------
HBRUSH BRUSH_SCROLL_BACKGROUND;
HBRUSH BRUSH_SCROLL_FOREGROUND;
HBRUSH BRUSH_SCROLL_BLOCK;

HPEN PEN_SCROLL_GRAPH;
COLORREF COLOR_SCROLL_FOREGROUND = COLOR_PLATE_BACKGROUND;
//�ڻ�����-----------------------------------------------------------------------------------------------------------------------------------
COLORREF COLOR_FUTURE_BACKGROUND = RGB(0, 0, 0);
COLORREF COLOR_FUTURE_HEAD_BACKGROUND = RGB(0, 0, 0);		  //��ͷ����ɫ
COLORREF COLOR_FUTURE_ROW_BACKGROUND = RGB(0, 0, 0);          //���ı���ɫ
COLORREF COLOR_FUTURE_SEL_BACKGROUND = RGB(0, 0, 0);		  //ѡ�б���ɫ
COLORREF COLOR_FUTURE_TITLE = RGB(0, 220, 220);               //��ͷ����
COLORREF COLOR_FUTURE_STR = RGB(220, 220, 8);			      //�ַ����ֶ�
COLORREF COLOR_FUTURE_SEL_TEXT = RGB(220, 220, 8);;           //ѡ������ɫ
COLORREF COLOR_FUTURE_UP = RGB(255, 60, 57);                  //���� ����
COLORREF COLOR_FUTURE_DOWN = RGB(0, 220, 0);				  //�۸��
COLORREF COLOR_FUTURE_CHANGED = RGB(220, 220, 8);				 //�۸�䶯ɫ
COLORREF COLOR_OPTION_SERIES = RGB(80, 80, 80);				   //��Ȩ����ɫ
COLORREF COLOR_FUTURE_EQUAL = RGB(231, 231, 231);
COLORREF COLOR_FUTURE_SEL = RGB(220, 220, 10);
COLORREF COLOR_INMONEY_BACKGROUND = RGB(35, 15, 15);//RGB(30, 0, 0);//RGB(35, 15, 15);		//ʵֵ��Ȩ����ɫ
COLORREF COLOR_OUTMONEY_BACKGROUND = RGB(20, 35, 20);//RGB(0, 30, 0);//RGB(20, 35, 20);		//��ֵ��Ȩ����ɫ
HBRUSH BRUSH_FUTURE_BACKGROUND;
HBRUSH BRUSH_FUTURE_HEAD_BACKGROUND;
HBRUSH BRUSH_FUTURE_ROW_BACKGROUND;
HBRUSH BRUSH_FUTURE_SEL_BACKGROUND;
HBRUSH BRUSH_FUTURE_SEL;
HBRUSH BRUSH_FUTURE_VSCROLL;
HBRUSH BRUSH_INMONEY_BACKGROUND;
HBRUSH BRUSH_OUTMONEY_BACKGROUND;
HBRUSH BRUSH_FUTURE_UP;
HBRUSH BRUSH_FUTURE_DOWN;
HBRUSH BRUSH_OPTION_BENEFIT_BACKGROUND;
HBRUSH BRUSH_OPTION_BENEFIT;

HPEN PEN_FUTURE_TITLELINE;
HPEN PEN_OPTION_TITLE_LINE;
HPEN PEN_OPTION_SERIES;

HFONT FONT_FUTURE_TITLE;
HFONT FONT_FUTURE_CHS;
HFONT FONT_FUTURE_CONTENT;

HPEN PEN_OPTION_AXIS;
HPEN PEN_OPTION_BENEFIT_LINE;
HPEN PEN_OPTION_BALANCE_LINE;
HPEN PEN_OPTION_STRIKE_LINE;
//���ô���-----------------------------------------------------------------------------------------------------------------------------------
COLORREF COLOR_CONFIGWINDOW_BACKGROUND = RGB(48, 48, 56);
HBRUSH BRUSH_CONFIGWINDOW_BACKGROUND;
HBRUSH BRUSH_DUICONTROL_BACKGROUND;
HBRUSH BRUSH_DRAW_TOOL_BACKGROUND;
//�����̿�-----------------------------------------------------------------------------------------------------------------------------------
//�����̿�-----------------------------------------------------------------------------------------------------------------------------------
COLORREF COLOR_PANEL_BACKGROUND = RGB(5, 8, 8);
COLORREF COLOR_PANEL_LINE = RGB(46, 46, 46); //RGB(138, 0, 0);
COLORREF COLOR_PANEL_STR = RGB(255, 255, 0);				//���ж��ǵ��� �䶯�ַ���
COLORREF COLOR_PANEL_PRICE_TEXT = RGB(231, 231, 231);
COLORREF COLOR_PANEL_TICK_TEXT = RGB(128, 128, 128);
COLORREF COLOR_PANEL_MULTI_BID = RGB(255, 255, 0);
COLORREF COLOR_PANEL_MULTI_ASK = RGB(255, 255, 0);

HBRUSH BRUSH_PANEL_BACKGROUND;
HBRUSH BRUSH_PANEL_LINE;

HPEN PEN_PANEL_LINE;
HPEN PEN_PANEL_DOT_LINE;
HPEN PEN_PANEL_ARROW;

HFONT FONT_PANEL_TEXT;
HFONT FONT_PANEL_CONTRACT;
HFONT FONT_PANEL_BIG_PRICE;
HFONT FONT_PANEL_SMALL_PRICE;
HFONT FONT_PANEL_TICK_PRICE;
HFONT FONT_PANEL_ONE_LEVEL;
HFONT FONT_PANEL_OTHER_LEVEL;

//K�ߴ���-------------------------------------------------------------------------------------------------------------------------------------
COLORREF COLOR_KLINE_BACKGROUND = RGB(0, 0, 0);
COLORREF COLOR_KLINE_RED_BAR = RGB(255, 60, 57);
COLORREF COLOR_KLINE_GREEN_BAR = RGB(0, 240, 240);
COLORREF COLOR_KLINE_WHITE_BAR = RGB(231, 231, 231);
COLORREF COLOR_TLINE_PRICE = RGB(231, 231, 231);
COLORREF COLOR_TLINE_AVG_PRICE = RGB(220, 220, 10);
COLORREF COLOR_KLINE_MENU_TEXT = RGB(220, 220, 0); 
COLORREF COLOR_KLINE_CROSS = RGB(255, 255, 255);
HBRUSH BRUSH_KLINE_BACKGROUND;
HBRUSH BRUSH_KLINE_RED_BAR;
HBRUSH BRUSH_KLINE_GREEN_BAR;
HBRUSH BRUSH_KLINE_CROSS;
HBRUSH BRUSH_KLINE_GRID_LINE;

HPEN PEN_KLINE_GRID_LINE;
HPEN PEN_KLINE_GRID_DOTLINE;
HPEN PEN_TLINE_PRICE;
HPEN PEN_TLINE_AVG_PRICE;
HPEN PEN_TLINE_RED_BAR;
HPEN PEN_TLINE_GREEN_BAR;
HPEN PEN_KLINE_RED_BAR;
HPEN PEN_KLINE_GREEN_BAR;
HPEN PEN_KLINE_WHITE_BAR;
HPEN PEN_KLINE_RED_BAR_DOT;
HPEN PEN_KLINE_GREEN_BAR_DOT;
HPEN PEN_KLINE_CYCLE;
HPEN PEN_KLINE_GRAY_DOT;

HFONT FONT_KLINE_TEXT;
HFONT FONT_KLINE_NUMBER;
HFONT FONT_TIP_TEXT;
//��Ȩ����
COLORREF COLOR_STRATEGY_LINE = RGB(198, 197, 2);
HBRUSH BRUSH_STRATEGY_LINE;

COLORREF COLOR_SPEC_LINE[] = {
	RGB(231, 231, 231),
	RGB(220, 220, 10),
	RGB(255, 0, 255),
	RGB(0, 240, 0),
	RGB(120, 120, 120),
	RGB(240, 0, 0),
};
HPEN PEN_SPEC_LINE[sizeof(COLOR_SPEC_LINE)/sizeof(COLORREF)];

//�����µ�
COLORREF COLOR_LINE_ORDER_BUY = RGB(255, 255, 255);
HPEN PEN_LINE_ORDER_BUY;
COLORREF COLOR_LINE_ORDER_SELL = RGB(255, 255, 255);
HPEN PEN_LINE_ORDER_SELL;
COLORREF COLOR_LINE_ORDER_COVER = RGB(255, 255, 255);
HPEN PEN_LINE_ORDER_COVER;
COLORREF COLOR_LINE_ORDER_BACK = RGB(255, 255, 255);
HPEN PEN_LINE_ORDER_BACK;
COLORREF COLOR_LINE_ORDER_LOSS = RGB(255, 255, 255);
HPEN PEN_LINE_ORDER_LOSS;
COLORREF COLOR_LINE_ORDER_PROFIT = RGB(255, 255, 255);
HPEN PEN_LINE_ORDER_PROFIT;
COLORREF COLOR_LINE_POSITION_BUY = RGB(255, 255, 255);    //�ֲֶ�
HPEN PEN_LINE_POSITION_BUY;
COLORREF COLOR_LINE_POSITION_SELL = RGB(255, 255, 255);  //�ֲֿ�
HPEN PEN_LINE_POSITION_SELL;

//���ָ��
HCURSOR CURSOR_ARROW;
HCURSOR CURSOR_WE;		//����
HCURSOR CURSOR_NS;		//����
HCURSOR CURSOR_WSE;		//���Ϻ�����
HCURSOR CURSOR_ESW;		//���º�����
HCURSOR CURSOR_ALL;
HCURSOR CURSOR_HAND;
HCURSOR CURSOR_HAND_MOVE;
HCURSOR CURSOR_HAND_POINT;
HCURSOR CURSOR_LINE;
HCURSOR CURSOR_DEL;

//ϵͳ���ÿؼ�
HBRUSH BRUSH_IMAGE_GRAY;
HBRUSH g_brush_white;
HBRUSH BRUSH_BG_QUOTE;
HBRUSH BRUSH_CONTRL_FOCUSE;
HBRUSH BRUSH_CONTRL_FRAME;
HBRUSH BRUSH_DRAWLINE_CLOSE;
QuoteBaseConfig* g_BaseCfgDlg = NULL;
QuoteSkinConfig* g_SkinCfgDlg = NULL;
QuoteFontConfig* g_FontCfgDlg = NULL;
QuoteShortcutConfig* g_ShortcutCfgDlg = NULL;
DrawToolDlg*     g_pDrawTool = NULL;
std::vector<TQuoteFrame*> g_vFrames;
HFONT FONT_CONTRL_QUOTE;
//ϵͳ���
SKIN_STYLE                  G_STYLE = BLACK_STYLE;
//����ص�---------------------------------------------------------------------------------------------------------------------------------
extern "C"
{
	//���������ʱ�Ļص��¼�
	__declspec(dllexport) void __cdecl OnPluginLoad(LanguageID l)
	{
		InitDuiRes(ENU == l);

		//���鴰��
		BRUSH_QUOTEFRAME_BACKGROUND = CreateSolidBrush(COLOR_QUOTEFRAME_BACKGROUND);

		//���
		BRUSH_PLATE_BACKGROUND = CreateSolidBrush(COLOR_PLATE_BACKGROUND);
		
		PEN_PLATE_LINE = CreatePen(PS_SOLID, 1, COLOR_PLATE_LINE);
		PEN_PLATE_MENU = CreatePen(PS_SOLID, 1, COLOR_PLATE_MENU);
		PEN_PLATE_MENU_HOVER = CreatePen(PS_SOLID, 1, COLOR_PLATE_MENU_HOVER);

		//������
		BRUSH_SCROLL_BACKGROUND = CreateSolidBrush(COLOR_SCROLL_BACKGROUND);
		BRUSH_SCROLL_FOREGROUND = CreateSolidBrush(COLOR_SCROLL_FOREGROUND);
		BRUSH_SCROLL_BLOCK = CreateSolidBrush(COLOR_SCROLL_BLOCK);

		PEN_SCROLL_GRAPH = CreatePen(PS_SOLID, 1, COLOR_SCROLL_GRAPH);

		//�ڻ�����
		BRUSH_FUTURE_BACKGROUND = CreateSolidBrush(COLOR_FUTURE_BACKGROUND);
		BRUSH_FUTURE_HEAD_BACKGROUND = CreateSolidBrush(COLOR_FUTURE_HEAD_BACKGROUND);
		BRUSH_FUTURE_ROW_BACKGROUND = CreateSolidBrush(COLOR_FUTURE_ROW_BACKGROUND);
		BRUSH_FUTURE_SEL_BACKGROUND = CreateSolidBrush(COLOR_FUTURE_SEL_BACKGROUND);
		BRUSH_FUTURE_SEL = CreateSolidBrush(COLOR_FUTURE_SEL);
		BRUSH_FUTURE_VSCROLL = CreateSolidBrush(COLOR_FUTURE_VSCROLL);
		BRUSH_INMONEY_BACKGROUND = CreateSolidBrush(COLOR_INMONEY_BACKGROUND);
		BRUSH_OUTMONEY_BACKGROUND = CreateSolidBrush(COLOR_OUTMONEY_BACKGROUND);

		BRUSH_FUTURE_UP = CreateSolidBrush(COLOR_FUTURE_UP);
		BRUSH_FUTURE_DOWN = CreateSolidBrush(COLOR_FUTURE_DOWN);
		BRUSH_OPTION_BENEFIT_BACKGROUND = CreateSolidBrush(COLOR_OPTION_BENEFIT_BACKGROUND);
		BRUSH_OPTION_BENEFIT = CreateSolidBrush(COLOR_OPTION_BENEFIT_LINE);

		PEN_FUTURE_TITLELINE = CreatePen(PS_SOLID, 1, COLOR_FUTURE_TITLELINE);
		PEN_OPTION_TITLE_LINE = CreatePen(PS_SOLID, 1, COLOR_FUTURE_TITLE);

		PEN_OPTION_AXIS = CreatePen(PS_SOLID, 1, COLOR_OPTION_AXIS);
		PEN_OPTION_BENEFIT_LINE = CreatePen(PS_SOLID, 2, COLOR_OPTION_BENEFIT_LINE);
		PEN_OPTION_BALANCE_LINE = CreatePen(PS_DOT, 1, COLOR_FUTURE_TITLE);
		PEN_OPTION_STRIKE_LINE = CreatePen(PS_SOLID, 1, COLOR_FUTURE_STR);
		PEN_OPTION_SERIES = CreatePen(PS_SOLID, 1, COLOR_OPTION_SERIES);
		//���ô���
		BRUSH_CONFIGWINDOW_BACKGROUND = CreateSolidBrush(COLOR_CONFIGWINDOW_BACKGROUND);
		BRUSH_DUICONTROL_BACKGROUND = CreateSolidBrush(COLOR_DUICONTROL_BACKGROUND);
		BRUSH_CONTRL_FOCUSE = CreateSolidBrush(COLOR_CONTRL_FOCUSE);
		BRUSH_CONTRL_FRAME = CreateSolidBrush(COLOR_IMAGE_GRAY);
		g_brush_white = CreateSolidBrush(g_color_white);
		//�����̿�
		BRUSH_PANEL_BACKGROUND = CreateSolidBrush(COLOR_PANEL_BACKGROUND);
		BRUSH_PANEL_LINE = CreateSolidBrush(COLOR_PANEL_LINE);

		PEN_PANEL_LINE = CreatePen(PS_SOLID, 1, COLOR_PANEL_LINE);
		PEN_PANEL_DOT_LINE = CreatePen(PS_DOT, 1, COLOR_PANEL_LINE);
		PEN_PANEL_ARROW = CreatePen(PS_SOLID, 1, COLOR_PANEL_PRICE_TEXT);
		//K�ߴ���
		BRUSH_KLINE_BACKGROUND = CreateSolidBrush(COLOR_KLINE_BACKGROUND);
		BRUSH_KLINE_RED_BAR = CreateSolidBrush(COLOR_KLINE_RED_BAR);
		BRUSH_KLINE_GREEN_BAR = CreateSolidBrush(COLOR_KLINE_GREEN_BAR);
		BRUSH_KLINE_CROSS = CreateSolidBrush(COLOR_KLINE_CROSS);
		BRUSH_KLINE_GRID_LINE = CreateSolidBrush(COLOR_KLINE_GRID_LINE);

		PEN_KLINE_GRID_LINE = CreatePen(PS_SOLID, 1, COLOR_KLINE_GRID_LINE);
		PEN_KLINE_GRID_DOTLINE = CreatePen(PS_DOT, 1, COLOR_KLINE_DOT_GRID_LINE);
		PEN_TLINE_PRICE = CreatePen(PS_SOLID, 1, COLOR_TLINE_PRICE);
		PEN_TLINE_AVG_PRICE = CreatePen(PS_SOLID, 1, COLOR_TLINE_AVG_PRICE);
		PEN_TLINE_RED_BAR = CreatePen(PS_SOLID, 1, COLOR_TLINE_RED_BAR);
		PEN_TLINE_GREEN_BAR = CreatePen(PS_SOLID, 1, COLOR_TLINE_GREEN_BAR);
		PEN_KLINE_RED_BAR = CreatePen(PS_SOLID, 1, COLOR_KLINE_RED_BAR);
		PEN_KLINE_GREEN_BAR = CreatePen(PS_SOLID, 1, COLOR_KLINE_GREEN_BAR);
		PEN_KLINE_WHITE_BAR = CreatePen(PS_SOLID, 1, COLOR_KLINE_WHITE_BAR);
		PEN_KLINE_RED_BAR_DOT = CreatePen(PS_DOT, 1, COLOR_KLINE_RED_BAR);
		PEN_KLINE_GREEN_BAR_DOT = CreatePen(PS_DOT, 1, COLOR_KLINE_GREEN_BAR);
		PEN_KLINE_CYCLE = CreatePen(PS_SOLID, 1, COLOR_KLINE_MENU_TEXT);
		PEN_KLINE_GRAY_DOT = CreatePen(PS_DOT, 1, COLOR_KLINE_DIVISION);

		for (int i = 0; i < sizeof(COLOR_SPEC_LINE) / sizeof(COLORREF); i++)
		{
			PEN_SPEC_LINE[i] = CreatePen(PS_SOLID, 1, COLOR_SPEC_LINE[i]);
		}
		//��ͼ����
		BRUSH_DRAWLINE_CLOSE = CreateSolidBrush(COLOR_DRAW_LINE_CLOSE);
		BRUSH_DRAW_TOOL_BACKGROUND = CreateSolidBrush(COLOR_DRAW_TOOL_BACKGROUND);
		//�����µ�
		PEN_LINE_ORDER_BUY = CreatePen(PS_DOT, 1, COLOR_LINE_ORDER_BUY);
		PEN_LINE_ORDER_SELL = CreatePen(PS_DOT, 1, COLOR_LINE_ORDER_SELL);
		PEN_LINE_ORDER_COVER = CreatePen(PS_DOT, 1, COLOR_LINE_ORDER_COVER);
		PEN_LINE_ORDER_BACK = CreatePen(PS_DOT, 1, COLOR_LINE_ORDER_BACK);
		PEN_LINE_ORDER_LOSS = CreatePen(PS_DOT, 1, COLOR_LINE_ORDER_LOSS);
		PEN_LINE_ORDER_PROFIT = CreatePen(PS_DOT, 1, COLOR_LINE_ORDER_PROFIT);
		PEN_LINE_POSITION_BUY = CreatePen(PS_DOT, 1, COLOR_LINE_POSITION_BUY);
		PEN_LINE_POSITION_SELL = CreatePen(PS_DOT, 1, COLOR_LINE_POSITION_SELL);

		HANDLE dll = GetModuleHandle(L"PolestarQuote.dll");
		CURSOR_HAND = LoadCursor((HINSTANCE)dll, MAKEINTRESOURCE(IDC_CURSOR3));
		CURSOR_HAND_MOVE = LoadCursor((HINSTANCE)dll, MAKEINTRESOURCE(IDC_CURSOR4));
		CURSOR_HAND_POINT = LoadCursor(NULL,IDC_HAND);
		CURSOR_LINE = LoadCursor((HINSTANCE)dll, MAKEINTRESOURCE(IDC_CURSOR2));
		CURSOR_DEL = LoadCursor((HINSTANCE)dll, MAKEINTRESOURCE(IDC_CURSOR1));

		CURSOR_ARROW = LoadCursor(NULL, IDC_ARROW);
		CURSOR_WE = LoadCursor(NULL, IDC_SIZEWE);
		CURSOR_NS = LoadCursor(NULL, IDC_SIZENS);
		CURSOR_WSE = LoadCursor(NULL, IDC_SIZENWSE);
		CURSOR_ESW = LoadCursor(NULL, IDC_SIZENESW);
		CURSOR_ALL = LoadCursor(NULL, IDC_SIZEALL);
		//ϵͳ���ÿؼ�
		BRUSH_IMAGE_GRAY = CreateSolidBrush(COLOR_IMAGE_GRAY);
		HBRUSH BRUSH_BG_QUOTE = CreateSolidBrush(COLOR_QUOTE_CONFIG_BG);

		//��Ȩ����
		BRUSH_STRATEGY_LINE = CreateSolidBrush(COLOR_STRATEGY_LINE);
		//���崴��--------------------------------------------------------------------------------------------------------------------	
		if (ENU == l && IsFontExit(L"Calibri"))
		{
			FONT_PLATE = CreateFont(18, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Calibri")); 

			FONT_BLOD_PLATE = CreateFont(18, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Calibri"));

			FONT_FUTURE_TITLE = CreateFont(20, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Calibri"));
			FONT_FUTURE_CHS = CreateFont(22, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
					CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Calibri"));

			FONT_PANEL_TEXT = CreateFont(18, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Calibri"));
			FONT_PANEL_CONTRACT = CreateFont(24, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Calibri"));

			FONT_KLINE_TEXT = CreateFont(18, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Calibri"));

			FONT_TIP_TEXT = CreateFont(16, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Calibri"));
		}
		else
		{
			FONT_PLATE = CreateFont(12, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����")); 

			FONT_BLOD_PLATE = CreateFont(12, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����"));

			FONT_FUTURE_TITLE = CreateFont(14, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����"));

			FONT_FUTURE_CHS = CreateFont(16, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����"));

			FONT_PANEL_TEXT = CreateFont(12, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����"));

			FONT_PANEL_CONTRACT = CreateFont(18, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����"));

			FONT_KLINE_TEXT = CreateFont(12, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
					CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����"));

			FONT_TIP_TEXT = CreateFont(12, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����"));
		}

		if (IsFontExit(L"Calibri"))
		{
			FONT_FUTURE_CONTENT = CreateFont(22, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Calibri"));

			FONT_PANEL_BIG_PRICE = CreateFont(28, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Calibri"));

			FONT_PANEL_SMALL_PRICE = CreateFont(20, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Calibri"));

			FONT_PANEL_ONE_LEVEL = CreateFont(20, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Calibri"));

			FONT_PANEL_OTHER_LEVEL = CreateFont(20, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Calibri"));

			FONT_PANEL_TICK_PRICE = CreateFont(18, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Calibri"));

			FONT_KLINE_NUMBER = CreateFont(18, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Calibri"));

			FONT_CONTRL_QUOTE = CreateFont(18, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Calibri"));
		}
		else
		{
			FONT_FUTURE_CONTENT = CreateFont(16, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����"));

			FONT_PANEL_BIG_PRICE = CreateFont(22, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����"));

			FONT_PANEL_SMALL_PRICE = CreateFont(14, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����"));

			FONT_PANEL_ONE_LEVEL = CreateFont(14, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����"));

			FONT_PANEL_OTHER_LEVEL = CreateFont(14, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����"));

			FONT_PANEL_TICK_PRICE = CreateFont(12, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
					CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����"));

			FONT_KLINE_NUMBER = CreateFont(12, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
					CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����"));
			FONT_CONTRL_QUOTE =  CreateFont(12, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����"));
		}

	}

	//�ͷŲ���ص�
	__declspec(dllexport) void __cdecl OnPluginFree()
	{

	}

	//���ȫ��������ɺ�Ļص��¼�
	__declspec(dllexport) void __cdecl OnPluginInit(TPluginMgrApi* p)
	{
		G_LANG = (ILanguageApi*)p->CreatePluginApi(PLUG_LANGUAGEAPI_NAME, PLUG_LANGUAGEAPI_VERSION);
		if (NULL == G_LANG)
			return;
		G_LANG->SetModule(LANG_POLESTARQUOTE);

		//LoadContractName();		//��Լ�������� �����Խӿڣ�������G_LANG��ȡ֮�����
		G_StarApi = (IStarApi*)p->CreatePluginApi(PLUG_STARAPI_NAME, PLUG_STARAPI_VERSION);
		if (g_BaseCfgDlg == NULL)
			g_BaseCfgDlg = new QuoteBaseConfig();
		if (g_SkinCfgDlg == NULL)
			g_SkinCfgDlg = new QuoteSkinConfig();
		if (g_FontCfgDlg == NULL)
			g_FontCfgDlg = new QuoteFontConfig();
		if (g_ShortcutCfgDlg == NULL)
			g_ShortcutCfgDlg = new QuoteShortcutConfig();
		G_LineOrderApi = (IStrategyTradeAPI*)p->CreatePluginApi(PLUG_STRATEGYTRADE_NAME, PLUG_STRATEGYTRADE_VERSION);
		G_ConfigFrame = (IConfigFrame*)p->CreatePluginApi(PLUG_CONFIGFRAME_NAME, PLUG_CONFIGFRAME_VERSION);
		G_ConfigFrame->reg_config_dlg(G_LANG->LangText(TLI_BASIC_SETTINGS), QuoteBaseConfigDlgCreatefunc, cmtQuote, 0, "esunny.epolestar.configframe");
		G_ConfigFrame->reg_config_dlg(G_LANG->LangText(TLI_APPEARANCESETTINGS), QuoteSkinConfigDlgCreatefunc, cmtQuote, 1, "esunny.epolestar.configframe");
		G_ConfigFrame->reg_config_dlg(G_LANG->LangText(TLI_FONT_CONFIG), QuoteFontConfigDlgCreatefunc, cmtQuote, 2, "esunny.epolestar.configframe");
		G_ConfigFrame->reg_config_dlg(G_LANG->LangText(TLI_SHORTCUT_KEY), QuoteShortcutKeyConfigDlgCreatefunc, cmtQuote, 3, "esunny.epolestar.configframe");
		if ((NULL != G_StarApi))
		{
			if (NULL != G_LineOrderApi)
				G_LineOrderApi->RegistStrategyInfo(&G_QuoteCenter);
			G_MainFrame = (IMainFrame*)p->CreatePluginApi(PLUG_MAINFRAME_NAME, PLUG_MAINFRAME_VERSION);
			if (NULL != G_MainFrame)
				G_MainFrame->RegMenuItem(MAKE_MENUORDER(0, 10001, 1), G_LANG->LangText(TLI_POLESTAR_QUOTE), PolestarQuoteMenuClick);
			TMenuItemEx item[6];
			char* Actions[] = { "GRID" ,"TLINE" ,"KLINE","KLINE" ,"GRID" ,"DRAWTOOLS" };
			char* Contents[] = { "" ,"" ,"d1","t0" ,"option" ,"" };
			for (int i = 0; i < sizeof(item) / sizeof(TMenuItemEx); i++)
			{
				wcscpy_s(item[i].ClassName, L"class TQuoteFrame");
				item[i].MenuOrder = MAKE_MENUORDER(0, 10001, 1);
				item[i].SubOrder = 0;
				wcscpy_s(item[i].MenuText, G_LANG->LangText(TLI_MENU_QUOTE_GRID+i));
				strcpy_s(item[i].sAction, Actions[i]);
				strcpy_s(item[i].sContent, Contents[i]);
			}
			G_MainFrame->AddMenuItemEx(MAKE_MENUORDER(0, 10001, 1), item, sizeof(item) / sizeof(TMenuItemEx));
		}
		G_CommonApi = (ICommonModule*)p->CreatePluginApi(PLUG_COMMONMOULE_NAME, PLUG_COMMONMOULE_VERSION);
		G_QuickData = (IQuickData*)p->CreatePluginApi(PLUG_QUICKMACRO_NAME, PLUG_QUICKMACRO_VERSION);
		//CIndexMgr::GetInstance()->Load();
	}

	//�����¶API
	__declspec(dllexport) void* __cdecl CreatePluginApi(const wchar_t v[])
	{

		return NULL;
	}

	//�ͷ�API
	__declspec(dllexport) void __cdecl FreePluginApi(void* p)
	{

	}
}

//��������------------------------------------------------------------------------------------------------------------------------------------
void OnPolestarQuoteLinkage(HWND From, HWND To, const char* Sender, const char* Action, const char* Content)
{
	//�����µ�
	if (0 == strcmp(Sender, LINE_ORDER_LINKAGE_SENDER))
	{
		OnLineOrderLinkage(From, To, Action);
		return;
	}

	//ָ���� �ɷֺ�Լ����	Action = "SyncContract"
	if (0 == strcmp(Sender, AGRIDX_STRATEGY_LINKAGE_SENDER))
	{
		OnAgridxLinkage(From, To, Action, Content);
		return;
	}

	//��������
	if (0 == strcmp(Sender, QUICK_MACRO_LINKAGE_SENDER))
	{
		OnQuickMacroLinkage(From, To, Action, Content);
		return;
	}

	//������TOOL_BAR_LINKAGE_SENDER
	if (0 == strcmp(Sender, TOOL_BAR_LINKAGE_SENDER)|| 0 == strcmp(Sender, SYSTEM_MENU_LINKAGE_SENDER))
	{
		OnToolBarLinkage(From, To, Action, Content);
		return;
	}
	//�ж���Դ�Ƿ��������
	if (0 != strcmp(Sender, POLESTAR_QUOTE_LINKAGE_SENDER) && 0 != strcmp(Sender, MOUSE_ORDER_LINKAGE_SENDER))
		return;

	//�ж϶���
	//if (0 != strcmp(Action, POLESTAR_QUOTE_LINKAGE_ACTION))
	//	return;

	//�ж���Դ ��ֹ��ѭ��
	if (0 == strcmp(Sender, POLESTAR_QUOTE_LINKAGE_SENDER))
	{
		const char* srcgrid = strstr(Content, "src=grid");
		if (NULL == srcgrid)
			return;
	}
	//��Ȩͬ��
	if (0 == strcmp(Action, "OptionSync"))
	{
		//�ж��Ƿ����鴰��
		wchar_t cname[128];
		GetClassName(To, cname, sizeof(cname) / sizeof(wchar_t));
		if (0 != wcscmp(cname, L"class TQuoteFrame"))
			return;

		//�ҵ�TQuoteFrame����
		TQuoteFrame* qf = (TQuoteFrame*)GetWindowLongPtr(To, 0);
		if (NULL == qf)
			return;

		//ִ������
		qf->OptionOrderPanelSync(Content);
		return;
	}

	//������Լ
	const char* pos = strstr(Content, "contractid=");
	if (NULL == pos)
		return;

	const char* pos1 = strchr(pos, ';');

	//�ж��Ƿ����鴰��
	wchar_t cname[128];
	GetClassName(To, cname, sizeof(cname) / sizeof(wchar_t));
	if (0 != wcscmp(cname, L"class TQuoteFrame"))
		return;

	//�ҵ�TQuoteFrame����
	TQuoteFrame* qf = (TQuoteFrame*)GetWindowLongPtr(To, 0);
	if (NULL == qf)
		return;

	//��ȡ��Լ
	SContract* cont;
	SContractNoType cno;
	strncpy_s(cno, &pos[11], sizeof(SContractNoType) - 1);
	if (NULL != pos1)
		cno[pos1 - pos - 11] = '\0';

	if (!G_StarApi->GetContractData(NULL, cno, &cont, 1, false))
		return;
	if (cont&&0 == strcmp(Sender, MOUSE_ORDER_LINKAGE_SENDER))
	{
		//ִ������
		if(cont->Commodity->OptionProperty == S_OPTIONTYPE_NONE)
		   qf->QuickLinkage(cont);
	}
	else
	{
		//ִ������
		qf->SetContract(cont);
	}
}

void OnLineOrderLinkage(HWND From, HWND To, const char* Action)
{
	//�ж��Ƿ����鴰��
	wchar_t cname[128];
	GetClassName(To, cname, sizeof(cname) / sizeof(wchar_t));
	if (0 != wcscmp(cname, L"class TQuoteFrame"))
		return;

	//�ҵ�TQuoteFrame����
	TQuoteFrame* qf = (TQuoteFrame*)GetWindowLongPtr(To, 0);
	if (NULL == qf)
		return;

	//ִ������
	qf->SetLinkState(Action);
}

void OnAgridxLinkage(HWND From, HWND To, const char* Action, const char* Content)
{
	//�ж��Ƿ����鴰��
	wchar_t cname[128];
	GetClassName(To, cname, sizeof(cname) / sizeof(wchar_t));
	if (0 != wcscmp(cname, L"class TQuoteFrame"))
		return;

	//�ҵ�TQuoteFrame����
	TQuoteFrame* qf = (TQuoteFrame*)GetWindowLongPtr(To, 0);
	if (NULL == qf)
		return;

	//ͬ��SELF0���
	int nChild = 0;
	TPlatePage* page = G_QuoteUtils.GetPageSelf0(nChild);
	if (NULL == page)
		return;

	//��������Լ
	const char* cstr = strstr(Content, "contractid=");
	if (NULL == cstr)
		return;

	int begin = (cstr - Content + strlen("contractid="));
	int pos = begin;
	while (true)
	{
		const char* s1 = &Content[pos];
		const char* s2 = strchr(s1, ':');

		SContract* cont;
		SContractNoType cno;
		strncpy_s(cno, s1, (s2 > s1 ? s2 - s1 : sizeof(SContractNoType)-1));
		if (!G_StarApi->GetContractData(NULL, cno, &cont, 1, false))
			break;

		if (begin == pos)//��һ����������
			page->PlateRows.clear();

		TPlateRow row;
		memset(&row, 0, sizeof(TPlateRow));
		row.Contract = cont;
		row.RowIndex = page->PlateRows.size();
		page->PlateRows.push_back(row);

		if (s2 > s1)
			pos += (s2 - s1) + 1;
		if (NULL == s2)
			break;
	}

	qf->AdjustPlateSelf0();
}
void OnQuickMacroLinkage(HWND From, HWND To, const char* Action, const char* Content)
{
	//�ж��Ƿ����鴰��
	wchar_t cname[128];
	GetClassName(To, cname, sizeof(cname) / sizeof(wchar_t));
	if (0 != wcscmp(cname, L"class TQuoteFrame"))
		return;

	//�ҵ�TQuoteFrame����
	TQuoteFrame* qf = (TQuoteFrame*)GetWindowLongPtr(To, 0);
	if (NULL == qf)
		return;
	const char* srcgContrac = strstr(Content, "Type=Contract;");
	if (srcgContrac != NULL)
	{
		//������Լ
		const char* pos = strstr(Content, "Key=");
		if (NULL == pos)
			return;

		const char* pos1 = strchr(pos, ';');
		//��ȡ��Լ
		SContract* cont;
		SContractNoType cno;
		strncpy_s(cno, &pos[4], sizeof(SContractNoType) - 1);
		if (NULL != pos1)
			cno[pos1 - pos - 4] = '\0';

		if (!G_StarApi->GetContractData(NULL, cno, &cont, 1, false))
			return;

		//ִ������
		qf->QuickLinkage(cont);
	}
	else
	{
		TLangIndex_PolestarQuote nType = TLI_INVALUE;
		if (strstr(Content, "Type=Kline;") != NULL)
		{
			const char* pos = strstr(Content, "Key=");
			if (NULL == pos)
				return;
			int nKey = atoi(&pos[4]);
			switch (nKey)
			{
			case 1:
				nType = TLI_KLINE_MIN1;
				break;
			case 2:
				nType = TLI_KLINE_MIN3;
				break;
			case 3:
				nType = TLI_KLINE_MIN5;
				break;
			case 4:
				nType = TLI_KLINE_MIN10;
				break;
			case 5:
				nType = TLI_KLINE_MIN15;
				break;
			case 6:
				nType = TLI_KLINE_MIN30;
				break;
			case 7:
				nType = TLI_KLINE_HOUR1;
				break;
			case 9:
				nType = TLI_KLINE_DAY1;
				break;
			}
		}
		else if (strstr(Content, "Type=Time;") != NULL)
			nType = TLI_KLINE_TIME;
		else if (strstr(Content, "Type=Tick;") != NULL)
			nType = TLI_KLINE_TICK;
		else if (strstr(Content, "Type=Indicator;") != NULL)
		{
			const char* pos = strstr(Content, "Key=");
			if (pos)
			{
				const char* pos1 = strchr(pos, ';');
				char tmp[101] = "";
				strncpy_s(tmp, &pos[4], sizeof(SContractNoType) - 1);
				if (NULL != pos1)
					tmp[pos1 - pos - 4] = '\0';
				wchar_t pName[101] =L"";
				MByteToWChar(tmp, pName, sizeof(pName) / sizeof(wchar_t));
				qf->SwitchKLineIndicate(pName);
			}
		}
		else if (strstr(Content, "Type=Auto;") != NULL)
		{
			const char* pos = strstr(Content, "Descripte=");
			if (pos)
			{
				const char* pos1 = strchr(pos, ';');
				char tmp[101] = "";
				strncpy_s(tmp, &pos[10], sizeof(SContractNoType) - 1);
				if (NULL != pos1)
					tmp[pos1 - pos - 10] = '\0';
				qf->QuickSelfLinkage(tmp);
			}
		}

		if (nType != TLI_INVALUE)
		{
			qf->QuickLinkage(nType,true);
		}
	}
}
void OnToolBarLinkage(HWND From, HWND To, const char* Action, const char* Content)
{
	//�ж��Ƿ����鴰��
	wchar_t cname[128];
	GetClassName(To, cname, sizeof(cname) / sizeof(wchar_t));
	if (0 != wcscmp(cname, L"class TQuoteFrame"))
		return;

	//�ҵ�TQuoteFrame����
	TQuoteFrame* qf = (TQuoteFrame*)GetWindowLongPtr(To, 0);
	if (NULL == qf)
		return;
	if (strcmp(Action, "GRID") == 0)
	{
		if (strcmp(Content, "option") == 0)
			qf->QuickOptionLinkage();
		 qf->SwitchToGrid();
	}
	else if (strcmp(Action, "DRAWTOOLS") == 0)
	{
		qf->OpenDrawToolDlg();
	}
	else
	{
		TLangIndex_PolestarQuote nType = TLI_INVALUE;
		if(strcmp(Action, "TLINE") == 0)
			nType = TLI_KLINE_TIME;
		else if (strcmp(Action, "KLINE") == 0)
		{
			if (strcmp(Content, "d1") == 0)
				nType = TLI_KLINE_DAY1;
			else if (strcmp(Content, "t0") == 0)
				nType = TLI_KLINE_TICK;
			else if (strcmp(Content, "m1") == 0)
				nType = TLI_KLINE_MIN1;
			else if (strcmp(Content, "m3") == 0)
				nType = TLI_KLINE_MIN3;
			else if (strcmp(Content, "m5") == 0)
				nType = TLI_KLINE_MIN5;
			else if (strcmp(Content, "m10") == 0)
				nType = TLI_KLINE_MIN10;
			else if (strcmp(Content, "m15") == 0)
				nType = TLI_KLINE_MIN15;
			else if (strcmp(Content, "m30") == 0)
				nType = TLI_KLINE_MIN30;
			else if (strcmp(Content, "h1") == 0)
				nType = TLI_KLINE_HOUR1;
		}
		if (nType != TLI_INVALUE)
		{
			qf->QuickLinkage(nType,false);
		}
	}
	
}
//����ϵͳ֪ͨ--------------------------------------------------------------------------------------------------------------------------------
bool PolestarQuoteLinkage(HWND hwnd, const char* action, const char* content)
{
	G_MainFrame->Linkage(hwnd, POLESTAR_QUOTE_LINKAGE_SENDER, action, content);
	return true;
}

//�˵��ص�---------------------------------------------------------------------------------------------------------------------------------
void __cdecl PolestarQuoteMenuClick(const unsigned int MenuIndex, const HWND PastLife)
{
	//��������Ҫ�������ݳ�ʼ����Ϻ���У�����ֻ�ɴ���һ�Σ����Էŵ���λ��
	G_QuoteUtils.InitPages();
	G_QuoteUtils.InitRows();

	TQuoteFrame* qf = new TQuoteFrame;	
	G_MainFrame->PutInnerEx(qf->GetHwnd(), OnPolestarQuoteLinkage);
	if (PastLife && qf->LoadCfg(PastLife))
	{
		qf->RedrawLater(NULL);
		G_MainFrame->SetProperty(PastLife, NULL);
		qf->SaveCfg();
	}
	g_BaseCfgDlg->RegistQuoteFrame(qf);
	g_SkinCfgDlg->RegistQuoteFrame(qf);
	g_FontCfgDlg->RegistQuoteFrame(qf);
	g_vFrames.push_back(qf);
}

HWND __stdcall QuoteBaseConfigDlgCreatefunc(const wchar_t * sub_title, const HWND parent)
{
	if (!IsWindow(g_BaseCfgDlg->GetHwnd()))
		g_BaseCfgDlg->Create(parent);
	return g_BaseCfgDlg->GetHwnd();
}
HWND __stdcall QuoteSkinConfigDlgCreatefunc(const wchar_t * sub_title, const HWND parent)
{
	if (!IsWindow(g_SkinCfgDlg->GetHwnd()))
		g_SkinCfgDlg->Create(parent);
	return g_SkinCfgDlg->GetHwnd();
}
HWND __stdcall QuoteFontConfigDlgCreatefunc(const wchar_t * sub_title, const HWND parent)
{
	if (!IsWindow(g_FontCfgDlg->GetHwnd()))
		g_FontCfgDlg->Create(parent);
	return g_FontCfgDlg->GetHwnd();
}
HWND __stdcall QuoteShortcutKeyConfigDlgCreatefunc(const wchar_t * sub_title, const HWND parent)
{
	if (!IsWindow(g_ShortcutCfgDlg->GetHwnd()))
		g_ShortcutCfgDlg->Create(parent);
	return g_ShortcutCfgDlg->GetHwnd();
}
void DefaultSendOrder(TSendOrder&SendOrder)
{
	memset(&SendOrder, 0, sizeof(TSendOrder));

	SendOrder.CommodityType = ctNone;
	SendOrder.OptionType = otNone;
	SendOrder.OptionType2 = otNone;
	SendOrder.OrderType = otUnDefine;
	SendOrder.OrderWay = owETrade;
	SendOrder.ValidType = vtGFD;
	SendOrder.IsRiskOrder = bNo;
	SendOrder.Direct = dNone;
	SendOrder.Offset = oNone;
	SendOrder.SellOffset = oNone;
	SendOrder.Hedge = hNone;
	SendOrder.TriggerMode = tmNone;
	SendOrder.TriggerCondition = tcNone;
	SendOrder.StrategyType = stNone;
	SendOrder.AddOneIsValid = tsDay;
	SendOrder.SellHedge = hNone;
}
std::vector<std::string> SplitString(const std::string & str, char cSplit)
{
	std::vector<std::string> vecstr;
	std::string tempstr(str);
	std::string::iterator tempit = tempstr.begin();
	while (tempit != tempstr.end())
	{
		tempit = std::find<std::string::iterator, char>(tempstr.begin(), tempstr.end(), cSplit);
		if (tempit != tempstr.end())
		{
			std::iterator_traits<std::string::iterator>::value_type dis = distance(tempstr.begin(), tempit);
			vecstr.push_back(tempstr.substr(0, dis));
			if (++tempit != tempstr.end())
			{
				tempstr.erase(tempstr.begin(), tempit);
				tempit = tempstr.begin();
			}
			else
				break;
		}
		else//û�ҵ�' '��������  ����abc;������ȻҪ����
		{
			std::iterator_traits<std::string::iterator>::value_type dis = distance(tempit, tempstr.end());
			vecstr.push_back(tempstr);
			break;
		}
	}
	return vecstr;
}
bool ParseOptionContractStr(const std::string& strValue, char(&ContractNo)[11], TOptionType &OptionType, char(&StrikePrice)[11])
{
	bool bRet = true;
	do {
		std::string::size_type posFlag = std::string::npos;
		if (std::string::npos != (posFlag = strValue.find(otCall)))
			OptionType = otCall;
		else if (std::string::npos != (posFlag = strValue.find(otPut)))
			OptionType = otPut;
		else
		{
			bRet = false;
			break;
		}
		strncpy_s(ContractNo, strValue.substr(0, posFlag).c_str(), sizeof(ContractNo) - 1);
		strncpy_s(StrikePrice, strValue.substr(posFlag + 1).c_str(), sizeof(StrikePrice) - 1);
	} while (false);
	return bRet;
}

void QOptionContractNoTypeToTradeOptionContract(const std::string &id, TContractKey &ContractKey)
{
	std::vector<std::string> vecStr;
	memset(&ContractKey, 0, sizeof(TContractKey));
	ContractKey.ExchangeNo;
	ContractKey.CommodityType = ctOption;
	ContractKey.CommodityNo;
	ContractKey.ContractNo;
	ContractKey.StrikePrice;
	ContractKey.OptionType = otNone;
	ContractKey.ContractNo2;
	ContractKey.StrikePrice2;
	ContractKey.OptionType2 = otNone;

	vecStr = SplitString(id.c_str(), '|');
	if (vecStr.size() < 3)
		return;
	strncpy_s(ContractKey.ExchangeNo, vecStr[0].c_str(), sizeof(ContractKey.ExchangeNo) - 1);
	strncpy_s(ContractKey.CommodityNo, vecStr[2].c_str(), sizeof(ContractKey.CommodityNo) - 1);
	//��Ȩ	<Exg>|<Type>|<Root>|<YEAR><MONTH>[DAY]<OFlag><STRIKEPRICE>
	if (vecStr.size() > 3)
		ParseOptionContractStr(vecStr[3], ContractKey.ContractNo, ContractKey.OptionType, ContractKey.StrikePrice);
}
#define DEFAULT_DPI		96
void SCALING_DPI(DEVMODE& dm)
{
	if (dm.dmLogPixels > DEFAULT_DPI)
	{
		dm.dmPosition.x *= DEFAULT_DPI;
		dm.dmPosition.x /= dm.dmLogPixels;
		dm.dmPosition.y *= DEFAULT_DPI;
		dm.dmPosition.y /= dm.dmLogPixels;
		dm.dmPelsWidth *= DEFAULT_DPI;
		dm.dmPelsWidth /= dm.dmLogPixels;
		dm.dmPelsHeight *= DEFAULT_DPI;
		dm.dmPelsHeight /= dm.dmLogPixels;
	}
}
void GetCurrScreenRect(RECT& r)
{
	POINT cp;
	GetCursorPos(&cp);

	DISPLAY_DEVICE dd;
	memset(&dd, 0, sizeof(DISPLAY_DEVICE));
	dd.cb = sizeof(DISPLAY_DEVICE);

	DEVMODE dm;
	memset(&dm, 0, sizeof(DEVMODE));
	dm.dmSize = sizeof(DEVMODE);
	dm.dmDriverExtra = 0;

	for (int i = 0; EnumDisplayDevices(0, i, &dd, 0); i++)
	{
		if (!EnumDisplaySettingsEx(dd.DeviceName, ENUM_CURRENT_SETTINGS, &dm, 0))
			continue;
		SCALING_DPI(dm);
		if (0 == dm.dmPosition.x && 0 == dm.dmPosition.y)
		{
			r.left = dm.dmPosition.x;
			r.top = dm.dmPosition.y;
			r.right = r.left + dm.dmPelsWidth;
			r.bottom = r.top + dm.dmPelsHeight;
		}

		//�ڴ��豸��Ļ�ڲ��������ж�ȥ�����������λ�úͳߴ磬�����������ڶ���
		if (cp.x >= dm.dmPosition.x && cp.y >= dm.dmPosition.y
			&& cp.x < dm.dmPosition.x + (int)dm.dmPelsWidth && cp.y < dm.dmPosition.y + (int)dm.dmPelsHeight)
		{
			r.left = dm.dmPosition.x;
			r.top = dm.dmPosition.y;
			r.right = r.left + dm.dmPelsWidth;
			r.bottom = r.top + dm.dmPelsHeight;
			return;
		}
	}
}
//ʮ������ת������
int HexToBin(const char * Text, char * Buffer, int BufSize)
{
	const int Convert['f' - '0' + 1] =
	{
		0, 1, 2, 3, 4, 5, 6, 7, 8, 9, -1, -1, -1, -1, -1, -1,
		-1, 10, 11, 12, 13, 14, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, 10, 11, 12, 13, 14, 15
	};

	uchar * pText = (uchar*)Text;

	int I = BufSize, Count = 0;
	char CurrChar, NextChar;
	while (I > 0)
	{
		CurrChar = *(pText++);
		NextChar = *(pText++);

		if (!(('0' <= CurrChar && CurrChar <= 'f') && ('0' <= NextChar && NextChar <= 'f')))
			break;
		Buffer[0] = char((Convert[CurrChar - '0'] << 4) + Convert[NextChar - '0']);
		Buffer++;
		Count++;
		I--;
	};
	Buffer -= Count;
	return BufSize - I;
}
//������תʮ������
void BinToHex(const char * Buffer, char * Text, int BufSize)
{
	const char Convert[17] = "0123456789ABCDEF";
	uchar * pBuf = (uchar *)Buffer;
	char * pText = Text;

	for (int I = 0; I < BufSize; I++)
	{
		pText[0] = Convert[pBuf[I] >> 4];
		pText[1] = Convert[pBuf[I] & 0xF];
		pText += 2;
	};
	pText[0] = 0;
}

//////////////////////////////////////////////////////////////////////////
bool MByteToWChar(LPCSTR lpcszStr, LPWSTR lpwszStr, DWORD dwSize, UINT codepage/* = 936*/)
{
	// Get the required size of the buffer that receives the Unicode 
	// string. 
	DWORD dwMinSize;
	dwMinSize = MultiByteToWideChar(codepage, 0, lpcszStr, -1, NULL, 0);

	if (dwSize < dwMinSize)
		return false;

	// Convert headers from ASCII to Unicode.
	MultiByteToWideChar(codepage, 0, lpcszStr, -1, lpwszStr, dwMinSize);

	return true;
}

bool WCharToMByte(LPCWSTR lpcwszStr, LPSTR lpszStr, DWORD dwSize, UINT codepage/* = 936*/)
{
	DWORD dwMinSize;
	dwMinSize = WideCharToMultiByte(codepage, NULL, lpcwszStr, -1, NULL, 0, NULL, FALSE);
	if (dwSize < dwMinSize)
		return false;
	WideCharToMultiByte(codepage, NULL, lpcwszStr, -1, lpszStr, dwSize, NULL, FALSE);
	return true;
}
SRetType FormatPrice(IStarApi* pStarApi, const SPriceType price, const SCommodityPrecType prec, const SCommodityDenoType deno, W_Price_Type out, bool showdeno)
{
	if (!pStarApi)
		return 0;
	SPriceStrType tmpText;
	G_StarApi->FormatPrice(price,prec, deno,tmpText, true,false);
	MByteToWChar(tmpText, out, sizeof(W_Price_Type) / sizeof(wchar_t), 1252);
	return 1;
}
SRetType FormatPrice(IStarApi* pStarApi, const SPriceType price, const SCommodity* commodity, W_Price_Type out, bool showdeno)
{
	if (!pStarApi)
		return 0;
	SPriceStrType tmpText;
	G_StarApi->FormatPrice(price, commodity, tmpText, true,false);
	MByteToWChar(tmpText, out, sizeof(W_Price_Type) / sizeof(wchar_t), 1252);
	return 1;
}
SRetType FormatGreek(const SGreekType price, const SCommodityPrecType prec, W_Price_Type out)
{
	SPriceStrType tmpText;
	char format[21] = "";
	sprintf_s(format, "%%.%df", prec);
	sprintf_s(tmpText, format, price);
	MByteToWChar(tmpText, out, sizeof(W_Price_Type) / sizeof(wchar_t), 1252);
	return 1;
}
bool GetContractCode(IStarApi* pStarApi, const SContractNoType contractno, W_Contract_Code_Type code)
{
	if (!pStarApi)
		return 0;
	SContractCodeType tmpText;
	if (!G_StarApi->GetContractCode(contractno, tmpText))
		return 0;
	MByteToWChar(tmpText, code, sizeof(W_Contract_Code_Type) / sizeof(wchar_t), 1252);
	return 1;
}
bool GetContractName(IStarApi* pStarApi, const SContractNoType contractno, W_Contract_Name_Type name)
{
	if (!pStarApi)
		return 0;
	SContractNameType tmpText;
	if (!G_StarApi->GetContractName(contractno, tmpText))
		return 0;
	MByteToWChar(tmpText, name, sizeof(W_Contract_Name_Type) / sizeof(wchar_t));
	return 1;
}
void GetSpreadRatio(SContractNoType cno, wchar_t* ratio,int nLen)
{
	wchar_t tmpTxt[101];
	SSpreadContract spread;
	if (G_StarApi->GetSpreadInfo(cno, &spread, 1, false) <= 0)
		return;
	for (int i = 0; i < spread.ValidLegs; i++)
	{
		if (i == 0)
		{
			swprintf_s(tmpTxt, L"%g", spread.SpreadRate[i]);
		}
		else
		{
			wchar_t tmp[11];
			swprintf_s(tmp, L":%g", spread.SpreadRate[i]);
			wcsncat_s(tmpTxt, tmp, wcslen(tmp));
		}
	}
	wcscpy_s(ratio, nLen, tmpTxt);
}


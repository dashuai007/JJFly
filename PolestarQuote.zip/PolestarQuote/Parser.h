#pragma once
class CSymtabNode
{
public:
	CSymtabNode();
	virtual ~CSymtabNode();
	char		m_strName[11];
	int			m_itType;
	DWORD		m_DataType;
	int			m_nStyle;
	int			m_nColor;
	int			m_nLineThick;
	float		m_fValue;
	int			m_nIndex;
	BOOL		m_bOutput;
	CDataArray*	m_pDataArray;
	int 		m_nDrawType;
};

class CParser
{
public:
	CParser();
	virtual ~CParser();
	void    SetIndex(CIndex* pIndex);
	void	InitParamSymtab();
	void	DeleteSymtabs();
	void	SaveCode();
	void	LoadCode();
protected:
	int	EnterSymtab(char* strName, int itType = itUNASSIGNED);
	int SearchSymtab(char* strName, int itType);
	CIndex* m_pIndex;
	std::vector<CSymtabNode *> m_vSymtabs;
	int		        m_nCodeSize;
	CODE	        m_Codes[20000];
	CODE	        m_Code;
	TOKEN_CODE		m_Token;
	TOKEN_CODE		m_fncType;
	int		        m_nSymtabIndex;
	int		        m_nErrCode;
	CODE*	m_pCode;
};


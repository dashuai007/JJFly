#pragma once

void     DrawLine(HDC hDC, int x1, int y1, int x2, int y2, COLORREF clr, int nWid = 1);
void     DrawLine(HDC hDC, POINT& from,POINT& to, COLORREF clr, int nWid = 1);
//����һ��β�˴��м�ͷ���߶�
void     DrawArrowLine(HDC hDC, const POINT& ptFrom, const POINT& ptTo, COLORREF clr, int nWid = 1);
void     DotLine(HDC hDC, int x1, int y1, int x2, int y2, COLORREF clr, int nPenWid = 1, int nStyle = PS_DOT);
void     DrawRect(HDC hDC, int x1, int y1, int x2, int y2, COLORREF clr, int nWid);
void     DrawArc(HDC hDC, COLORREF clr, int nLeft, int nTop, int nRight, int nBottom, int nXStart, int nYStart, int nXEnd, int nYEnd, int nPenWid = 1);
int      LinearRegression(double *data, int rows, double *a, double *b, double *SquarePoor);		//�����Իع�
POINT    Getplumb(const POINT& pt1, const POINT& pt2, const POINT& ptOut); //����
int      PointToLine(const POINT& pt, const POINT& linePt1, const POINT& linePt2);
COLORREF AlphaColor(COLORREF clr1, COLORREF clr2, int nAlpha);
void     FillSolidRect(HDC hDC, CONST RECT *lprc, COLORREF clr);
void     LigherColor(COLORREF& lColor, int lScale);
COLORREF GetLigherColor(COLORREF clr, int nLevel);
//����һ��СԲȦ������и���ʮ�ֲ�
void     DrawMaoDian(HDC hDC, const POINT& pt, COLORREF clr);
DWORD    ColorReverse();
bool     PtInLine(const POINT& pt, const POINT& start, const POINT& end);
bool     PtInEllips(const POINT& pt, const RECT& rc, BOOL bTop);

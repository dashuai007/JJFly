#pragma once
//ָ������洢

typedef std::map<std::wstring, std::vector<TKLineSpecParam>> ParamModifyMapType;
class IndexParams
{
public:
	IndexParams();
	~IndexParams();
	static IndexParams* GetInstance() { return &m_Instance; }
	void AddParams(std::wstring name, std::vector<TKLineSpecParam>& vParams);
	bool GetParams(std::wstring name, std::vector<TKLineSpecParam>& vParams);
	void EraseParam(std::wstring name);
	void LoadModifyParamInfo();
	void SaveModifyParamInfo();
private:
	static IndexParams          m_Instance;
	ParamModifyMapType          m_mapParamModify;                           //�����޸Ĺ���ָ�����
};


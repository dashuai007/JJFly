#pragma once
//��ͼ����
class ChartDot
{
public:
	ChartDot()
	{
		x = 0;
		y = 0;
		tm = 0;
	}
	ChartDot(int dX, double dY, long tm)
	{
		x = dX;
		y = dY;
		this->tm = tm;
	}
public:
	SDateTimeType tm;  //������������꣬������������
	int x;
	double y;  //������������꣬������������

};
class CLine
{
public:
	CLine() { pt1 = { 0,0 }; pt2 = {0,0}; }
	CLine(const POINT& ptA, const POINT& ptB) :pt1(ptA), pt2(ptB) {}
	CLine(int x1, int y1, int x2, int y2) { pt1.x = x1; pt1.y = y1; pt2.x = x2; pt2.y = y2; }
public:
	POINT pt1;
	POINT pt2;

};
CLine    DrawZhiXian(HDC hDC, const POINT& pt1, const POINT& pt2, COLORREF clr, int nWid, int left, int right);
CLine    DrawSheXian(HDC hDC, const POINT& ptOrigin, const POINT& pt2, COLORREF clr, int nPenWid);
class TKLineChart;
class TKLineAxisX;
class TShape
{
public:
	TShape();
	virtual ~TShape();
public:
	void        Create(SHAPE_TYPE type, TKLineChart* pChart, TKLineAxisX* pAxisX, const std::vector<ChartDot>& data, COLORREF clr, int penWid);
	SHAPE_TYPE  GetType() { return m_type; }
	void        BeginDraw(HDC mdc);
	virtual     void Draw(HDC mdc) { ; }			//����
	void        EndDraw(HDC mdc);
	POINT       Griper2Pix(const ChartDot& dot);
	void        OnClick(const POINT& pt);				//��굥���¼�
	void        OnMove(const POINT& pt);
	bool        IsSelected() { return m_bSelected; }
	void        SetHot(bool bHot) { m_bFocus = bHot; }
	void        Select(bool bSel, int nGripper = -1);		//ѡ��/ȡ��ѡ��
	virtual int HitTest(const POINT& pt);   //��ײ���,����ֵ: >=0���������ê��, -1:��Ч, -2:��
	void        ResetAxis();
	void        ResetXAxis();
	bool        IsSizing() { return m_curMovingGripperIdx != -1; }
	void        SetIcon(int nIcon) { m_nIcon = nIcon; }
	void        GetStoreinfo(char* pStr, int len);
	void        SetStoreinfo(char* pStr, int len);
	int         GetStoreSize();
	void        GetGripers(std::vector<ChartDot>& ogripers);
	COLORREF    GetColor() { return m_clr; }
	int         GetWidth() { return m_nPenWid; }
protected:
	void        DrawGripers(HDC mdc);
protected:
	std::vector<ChartDot>  m_Gripers;
	std::vector<POINT>     m_PointsOrigin;  //δ�ƶ�ǰʱ�Ŀ���
	POINT                  m_PointOrigin;
	std::vector<CLine>     m_arrLines;
	int                    m_curMovingGripperIdx;
	SHAPE_TYPE			   m_type;
	TKLineChart*           m_pChart;
	TKLineAxisX*           m_pAxisX;
	COLORREF               m_clr;
	int                    m_nPenWid;
	int                    m_nIcon;
	bool                   m_bSelected;
	bool                   m_bFocus;
	COLORREF               m_clrNormal;
	bool                   m_bResetAxis;
	TCriticalSection       m_Crit;
	const int              Version = 1;
};
class THorizVertLine : public TShape   //ˮƽ��ֱ��
{
public:
	virtual void Draw(HDC pDC);			//����
};
class TNormalLine : public TShape     //ֱ�ߣ����ߣ��߶Σ���ͷ�߶�
{
public:
	virtual void Draw(HDC pDC);			//����
};
class  TPXX : public TShape
{
public:
	virtual void Draw(HDC pDC);			//����
};
class TTriangle : public TShape
{
public:
	virtual void Draw(HDC pDC);			//����
};
class TRectShape : public TShape
{
public:
	virtual void Draw(HDC pDC);			//����
};
class TArcShape : public TShape
{
public:
	virtual int  HitTest(const POINT&  pt);   //��ײ���
	virtual void Draw(HDC pDC);			//����
private:
	bool m_bUp;
	RECT m_circleRect;
};
class TCircleShape :public TShape
{
public:
	virtual int  HitTest(const POINT&  pt);   //��ײ���
	virtual void Draw(HDC pDC);			//����
private:
	bool m_bUp;
	std::vector<RECT> m_circleRects;
};
class TZQXShape :public TShape
{
public:
	virtual void Draw(HDC pDC);			//����
};

class THJFG_BFBShape : public TShape
{
public:
	virtual void Draw(HDC pDC);			//����
};

class TFBLQShape : public TShape
{
public:
	virtual void Draw(HDC pDC);			//����
};

class TSZX_GSXShape : public TShape
{
public:
	virtual void Draw(HDC pDC);			//����
};

class TXXHG_Shape : public TShape
{
public:
	virtual void Draw(HDC pDC);			//����
};



#include "PreInclude.h"



IntervalStatisticsDlg::IntervalStatisticsDlg()
{
}


IntervalStatisticsDlg::~IntervalStatisticsDlg()
{
}
bool IntervalStatisticsDlg::ShowDlg(TQuoteFrame* pFrame, RSStruct* pRsData)
{
	m_pFrame = pFrame;
	m_pRsData = pRsData;
	m_nResult = DialogBoxParam(GetModuleHandle(L"PolestarQuote"), MAKEINTRESOURCE(IDD_DLG_REGIONSTATISTIC), pFrame->GetHwnd(), IntervalStatisticsProc, (LPARAM)this);
	return m_nResult == IDOK;
}
void IntervalStatisticsDlg::OnInitDlg()
{
	SetDlgRect();
	SetDlgItemText(m_hWnd, IDC_STATIC3, G_LANG->LangText(TLI_STAR_TIME));
	SetDlgItemText(m_hWnd, IDC_STATIC4, G_LANG->LangText(TLI_END_TIME));
	SetDlgItemText(m_hWnd, IDC_STATIC5, G_LANG->LangText(TLI_INITIAL_PRICE));
	SetDlgItemText(m_hWnd, IDC_STATIC6, G_LANG->LangText(TLI_HIGHEST_PRICE));
	SetDlgItemText(m_hWnd, IDC_STATIC7, G_LANG->LangText(TLI_LOWEST_PRICE));
	SetDlgItemText(m_hWnd, IDC_STATIC8, G_LANG->LangText(TLI_FINAL_PRICE));
	SetDlgItemText(m_hWnd, IDC_STATIC9, G_LANG->LangText(TLI_VOLUME));
	SetDlgItemText(m_hWnd, IDC_STATIC10, G_LANG->LangText(TLI_HOLD_CHANGES));
	SetDlgItemText(m_hWnd, IDC_STATIC11, G_LANG->LangText(TLI_AVERAGE_PRICE));
	SetDlgItemText(m_hWnd, IDC_STATIC12, G_LANG->LangText(TLI_INTERVAL_GROWTH));
	SetDlgItemText(m_hWnd, IDC_STATIC13, G_LANG->LangText(TLI_INTERVAL_SWING));
	RefreshData();
}
void IntervalStatisticsDlg::GetCSDateTime(bool bStar, wchar_t* pTime,int nSize)
{
	if (m_pRsData->StarTime <= 0 || m_pRsData->EndTime <= 0)
		wcscpy_s(pTime, nSize, L"1980-01-01 00:00:00");
	else
	{
		SDateTimeType ltime = bStar ? m_pRsData->StarTime : m_pRsData->EndTime;
		SDateType date = (SDateType)(ltime / 1000000000LL);
		STimeType time = ltime % 1000000000LL / 1000LL;

		if (date > 0 && time > 0)
		{
			swprintf_s(pTime, nSize, L"%04d/%02d/%02d %02d:%02d:%02d", date / 10000, date / 100 % 100, date % 100, time / 10000, time / 100 % 100, time % 100);
		}
		else if (date > 0)
		{
			if (date % 100 > 0)
				swprintf_s(pTime, nSize, L"%04d/%02d/%02d", date / 10000, date / 100 % 100, date % 100);
			else if (date % 10000 > 0)
				swprintf_s(pTime, nSize, L"%04d/%02d", date / 10000, date / 100 % 100);
			else
				swprintf_s(pTime, nSize, L"%04d", date / 10000);
		}
		else
		{
			swprintf_s(pTime, nSize, L"%02d:%02d:%02d", time / 10000, time / 100 % 100, time % 100);
		}
	}
}
void IntervalStatisticsDlg::RefreshData()
{
	if (!m_pRsData)
		return;
	int nPrec = m_pRsData->Precision;
	int nDemor = m_pRsData->CommodityDenominator;
	wchar_t csTitle[101]=L"", wtext[101] = L"";
	if (!GetContractCode(G_StarApi, m_pRsData->cno, wtext))
	{
		MultiByteToWideChar(1252, 0, m_pRsData->cno, -1, wtext, sizeof(wtext) / sizeof(wchar_t));
	}
	swprintf_s(csTitle, L"%s %s", wtext, G_LANG->LangText(TLI_INTERVAL_STATISTICS));
	SetWindowText(m_hWnd, csTitle);
	GetCSDateTime(true, wtext, sizeof(wtext) / sizeof(wchar_t));
	SetDlgItemText(m_hWnd, IDC_EDIT1, wtext);
	GetCSDateTime(false, wtext, sizeof(wtext) / sizeof(wchar_t));
	SetDlgItemText(m_hWnd, IDC_EDIT2, wtext);
	FormatPrice(G_StarApi, m_pRsData->Star, nPrec, nDemor, wtext, false);
	SetDlgItemText(m_hWnd, IDC_EDIT3, wtext);
	FormatPrice(G_StarApi, m_pRsData->High, nPrec, nDemor, wtext, false);
	SetDlgItemText(m_hWnd, IDC_EDIT4, wtext);
	FormatPrice(G_StarApi, m_pRsData->Low, nPrec, nDemor, wtext, false);
	SetDlgItemText(m_hWnd, IDC_EDIT5, wtext);
	FormatPrice(G_StarApi, m_pRsData->End, nPrec, nDemor, wtext, false);
	SetDlgItemText(m_hWnd, IDC_EDIT6, wtext);
	_i64tow_s(m_pRsData->Volume, wtext, sizeof(wtext) / sizeof(wchar_t), 10);
	SetDlgItemText(m_hWnd, IDC_EDIT7, wtext);
	_i64tow_s(m_pRsData->AmountDif, wtext, sizeof(wtext) / sizeof(wchar_t), 10);
	SetDlgItemText(m_hWnd, IDC_EDIT8, wtext);
	FormatPrice(G_StarApi, m_pRsData->WeightAve, nPrec, nDemor, wtext, false);
	SetDlgItemText(m_hWnd, IDC_EDIT10, wtext);
	swprintf_s(wtext, L"%.2f%%", m_pRsData->rise * 100);
	SetDlgItemText(m_hWnd, IDC_EDIT11, wtext);
	swprintf_s(wtext, L"%.2f%%", m_pRsData->swing * 100);
	SetDlgItemText(m_hWnd, IDC_EDIT12, wtext);
	swprintf_s(wtext, G_LANG->LangText(TLI_PERIOD), m_pRsData->nCount);
	SetDlgItemText(m_hWnd, IDC_STATIC14, wtext);
	swprintf_s(wtext, G_LANG->LangText(TLI_UP_NUM), m_pRsData->nUp);
	SetDlgItemText(m_hWnd, IDC_STATIC15, wtext);
	swprintf_s(wtext, G_LANG->LangText(TLI_DOWN_NUM), m_pRsData->nDown);
	SetDlgItemText(m_hWnd, IDC_STATIC16, wtext);
	swprintf_s(wtext, G_LANG->LangText(TLI_EQUAL_NUM), m_pRsData->nEque);
	SetDlgItemText(m_hWnd, IDC_STATIC17, wtext);
}
void IntervalStatisticsDlg::SetDlgRect()
{
	RECT r = { 0, 0, 0, 0 };
	if (m_pFrame)
		m_pFrame->GetRect(r);
	r.right -= r.left;
	r.bottom -= r.top;
	RECT rc;
	GetWindowRect(m_hWnd, &rc);
	int nWidth = rc.right - rc.left;
	int nHigth = rc.bottom - rc.top;
	SetWindowPos(m_hWnd, 0, r.left + (r.right - nWidth) / 2, r.top + (r.bottom - nHigth) / 2, nWidth, nHigth, SWP_NOZORDER);
	ShowWindow(m_hWnd, SW_SHOW);
}
void IntervalStatisticsDlg::OnCommand(WPARAM wParam, LPARAM lParam)
{
	int nId = (int)wParam;
	switch (nId)
	{
	case IDOK:
		EndDialog(m_hWnd, IDOK);
		break;
	}
}
void IntervalStatisticsDlg::OnNotify(WPARAM wParam, LPARAM lParam)
{
	switch (wParam)
	{
	case IDC_SPIN1:
		OnDeltaposSpin1(-((LPNMUPDOWN)lParam)->iDelta);
		break;
	case IDC_SPIN2:
		OnDeltaposSpin2(-((LPNMUPDOWN)lParam)->iDelta);
		break;
	}
}
void IntervalStatisticsDlg::OnDeltaposSpin1(int iDelta)
{
	if (!m_pRsData || !m_pFrame)
		return;
	if (iDelta == 1)
	{
		if (m_pRsData->nStar == m_pRsData->nAxisBegin)
			return;
		m_pRsData->nStar = (m_pRsData->nStar - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	}
	else if (iDelta == -1)
	{
		if (m_pRsData->nStar == (m_pRsData->nEnd - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X)
			return;
		m_pRsData->nStar = (m_pRsData->nStar + 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	}
	m_pFrame->CalIntervalStatistics(m_pRsData->nStar, m_pRsData->nEnd);
	RefreshData();
}
void IntervalStatisticsDlg::OnDeltaposSpin2(int iDelta)
{
	if (!m_pRsData|| !m_pFrame)
		return;
	if (iDelta == 1)
	{
		if (m_pRsData->nEnd == (m_pRsData->nStar + 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X)
			return;
		m_pRsData->nEnd = (m_pRsData->nEnd -1+MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	}
	else if (iDelta == -1)
	{
		if (m_pRsData->nEnd == (m_pRsData->nAxisEnd-1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X)
			return;
		m_pRsData->nEnd = (m_pRsData->nEnd + 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	}
	m_pFrame->CalIntervalStatistics(m_pRsData->nStar, m_pRsData->nEnd);
	RefreshData();
}
INT_PTR CALLBACK IntervalStatisticsDlg::IntervalStatisticsProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	IntervalStatisticsDlg* dlg(NULL);
	switch (msg)
	{
	case WM_INITDIALOG:
		dlg = (IntervalStatisticsDlg*)(lParam);
		if (dlg)
		{
			dlg->m_hWnd = hWnd;
			SetWindowLongPtr(hWnd, DWL_USER, (LONG)dlg);
			dlg->OnInitDlg();
		}
		break;
	default:
		dlg = (IntervalStatisticsDlg*)GetWindowLongPtr(hWnd, DWL_USER);
		break;
	}
	if (NULL != dlg&&dlg->m_hWnd != 0)
	{
		switch (msg)
		{
		case WM_CLOSE:
			EndDialog(hWnd, IDCLOSE);
			return TRUE;
		case WM_COMMAND:
			dlg->OnCommand(wParam, lParam);
			return TRUE;
		case WM_NOTIFY:
			dlg->OnNotify(wParam, lParam);
			return TRUE;
		}
	}
	return FALSE; // ��������
}

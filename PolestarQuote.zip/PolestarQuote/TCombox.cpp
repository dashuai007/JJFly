#include "PreInclude.h"

TCombox::TCombox()
{
	m_bmouseover = false;
	m_bmousetrack = false;
	m_blbtndown = false;
	m_buserdef = false;
	m_font = FONT_CONTRL_QUOTE;

	m_pcomboxlist = NULL;
	m_edit = NULL;
	m_nselect = -1;
}

TCombox::~TCombox()
{
	ReleaseComboxList();
}

bool TCombox::Create(HWND hwnd, int nindex/* = 0*/, bool bedit/* = true*/)
{
	m_nindex = nindex;
	m_bedit = bedit;
	CreateFrm(_T("TCombox"), hwnd, WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN);
	if (m_bedit)
	{
		DWORD dwStyle;
		dwStyle = WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS | WS_TABSTOP | ES_AUTOHSCROLL;
		m_edit = CreateWindowEx(0, WC_EDIT, 0, dwStyle, 0, 0, 0, 0, m_Hwnd, 0, GetModuleHandle(NULL), 0);
		SendMessage(m_edit, WM_SETFONT, (WPARAM)FONT_PANEL_SMALL_PRICE, 0);
		SetWindowSubclass(m_edit, TCombox::EditProc, 0, 0);
	}
	return true;
}

void TCombox::MoveWindow(const int& x, const int& y, const int& cx, const int& cy)
{
	SetWindowPos(m_Hwnd, 0, x, y, cx, m_nComboxHeight, SWP_NOZORDER);
	InvalidateRect(m_Hwnd, 0, true);
}

//property
void TCombox::SetUserComboxList(TPopupWnd* pwnd)
{
	ReleaseComboxList();
	m_pcomboxlist = pwnd;
	m_buserdef = true;
}

void TCombox::SetFont(HFONT hfont)
{
	m_font = hfont;
	InvalidateRect(m_Hwnd, 0, false);
}

void TCombox::SetText(const wchar_t* ptext)
{
	m_sztext = ptext;
	SetWindowText(m_edit, ptext);
	InvalidateRect(m_Hwnd, 0, false);
}
wchar_t* TCombox::GetText()
{
	wchar_t sztext[MAX_PATH];
	if (m_bedit)
	{
		GetWindowText(m_edit, sztext, MAX_PATH);
		m_sztext = sztext;
	}
	return const_cast<wchar_t*>(m_sztext.c_str());
}

wchar_t TCombox::GetParam()
{
	if (m_nselect < 0 || m_nselect >= (int)m_stldata.size()) return '\0';

	ComboxStruct stcom = m_stldata.at(m_nselect);
	return stcom.szparam;
}

ComboxStruct* TCombox::GetComboxStruct()
{
	if (m_nselect < 0 || m_nselect >= (int)m_stldata.size()) return NULL;

//	ComboxStruct stcom = m_stldata.at(m_nselect);
	return &m_stldata.at(m_nselect);
}

void TCombox::SetSelect(int nindex)
{
	if (nindex < 0 || nindex >= (int)m_stldata.size()) return;

	m_nselect = nindex;
	ComboxStruct stcom = m_stldata.at(nindex);
	SetText(stcom.sztext);
}
//action
void TCombox::AddString(const wchar_t* ptext, const wchar_t* pwvalue, const wchar_t szparam, const void* pvalue/* = NULL*/)
{
	ComboxStruct stdata;
	stdata.nindex = m_stldata.size();
	wcscpy_s(stdata.sztext, ptext);
	stdata.szparam = szparam;
	if (pwvalue)wcscpy_s(stdata.szvalue, pwvalue);
	if (pvalue)stdata.pvalue = (void*)pvalue;
	
	m_stldata.push_back(stdata);
}

void TCombox::ReleaseComboxList()
{
	if (!m_buserdef&&m_pcomboxlist)
	{
		delete m_pcomboxlist;
		m_pcomboxlist = NULL;
	}
}

void TCombox::Clear()
{
	m_sztext = _T("");
	m_stldata.clear();
	CreateDropList();
	((TComboxList*)m_pcomboxlist)->SetData(m_stldata);
}
void	TCombox::ResizeData()
{
	CreateDropList();
	((TComboxList*)m_pcomboxlist)->SetData(m_stldata);
}
//MSG
LRESULT TCombox::WndProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case WM_PAINT:
		OnPaint();
		break;
	case WM_SIZE:
		OnSize();
		break;
	case WM_LBUTTONDOWN:
		OnLbuttonDown(wParam, lParam);
		break;
	case WM_MOUSEMOVE:
		OnMouseMove(wParam, lParam);
		break;
	case WM_MOUSELEAVE:
		OnMouseLeave(wParam, lParam);
		break;
	case SSWM_COMBOX_SELECT:
		OnComboxSelect(wParam, lParam);
		break;
	case WM_CTLCOLOREDIT:
		SetBkColor((HDC)wParam, g_color_white);
		break;
	default:
		return NOT_PROCESSED;
	}

	return PROCESSED;
}

void TCombox::CreateDropList()
{
	if (m_pcomboxlist) return;

	int nwidth;
	RECT rect; GetClientRect(m_Hwnd, &rect);
	nwidth = rect.right - rect.left;
	m_pcomboxlist = new TComboxList;
	m_pcomboxlist->Create(m_Hwnd);
	m_pcomboxlist->MoveWindow(0, 0, nwidth, 200);
	((TComboxList*)m_pcomboxlist)->SetData(m_stldata);
}

void TCombox::OnPaint()
{
	TMemDC memdc(m_Hwnd);

	RECT	 rect;
	GetClientRect(m_Hwnd,&rect);

	HBRUSH framebrush = CreateSolidBrush(RGB(126, 180, 234));
	HBRUSH hframe;
	if (m_bmouseover)
		hframe = framebrush;
	else
		hframe = BRUSH_IMAGE_GRAY;

	FillRect(memdc.GetHdc(), &rect, g_brush_white);
	FrameRect(memdc.GetHdc(), &rect, hframe);

	DrawDrop(&memdc, rect,framebrush);

	if (!m_bedit)
	{
		RECT	 rctext;
		rctext = rect;
		rctext.right -= m_nDropWidth;
		InflateRect(&rctext, -4, -2);
		SelectObject(memdc.GetHdc(), m_font);
		SetBkMode(memdc.GetHdc(), TRANSPARENT);
		DrawText(memdc.GetHdc(), m_sztext.c_str(),m_sztext.length(), &rctext, DT_LEFT | DT_VCENTER|DT_SINGLELINE);
	}
	
	DeleteObject(framebrush);
}

void TCombox::DrawDrop(TMemDC* pmemdc, const RECT& rect, HBRUSH framebrush)
{
	HDC hdc = pmemdc->GetHdc();
	HBRUSH hoverbrush = CreateSolidBrush(RGB(253, 244, 191));

	RECT rcdrop;
	rcdrop = rect;
	rcdrop.left = rcdrop.right - m_nDropWidth;

	if (m_bmouseover)
	{ 
		FrameRect(hdc, &rcdrop, framebrush);
	}

	if (m_blbtndown)
		FillRect(hdc, &rcdrop, framebrush);

	SelectObject(hdc, GetStockObject(NULL_PEN));
	SelectObject(hdc, BRUSH_IMAGE_GRAY);
	POINT gpt[3];
	gpt[0].x = rcdrop.left+2;
	gpt[0].y = rcdrop.top + (rcdrop.bottom - rcdrop.top-3) / 2 ;
	gpt[2].x = rcdrop.right-3;
	gpt[2].y = gpt[0].y;
	gpt[1].x = (gpt[0].x + gpt[2].x) / 2;
	gpt[1].y = gpt[0].y + 5;
	Polygon(hdc, gpt, sizeof(gpt) / sizeof(POINT));
	DeleteObject(hoverbrush);
}

void TCombox::OnSize()
{
	RECT rect; GetClientRect(m_Hwnd, &rect);
	if(m_bedit)::MoveWindow(m_edit, m_gapsize, m_gapsize+2, rect.right - rect.left - m_gapsize - m_nDropWidth, rect.bottom - rect.left - 2 * m_gapsize - 3, true);
}

void TCombox::OnLbuttonDown(WPARAM wParam, LPARAM lParam)
{
	POINT pt;
	pt.x = LOWORD(lParam);
	pt.y = HIWORD(lParam);

	RECT rccombox, rect;
	GetClientRect(m_Hwnd, &rect);
	rccombox = rect;

	if(m_bedit)rccombox.left = rccombox.right - m_nDropWidth;
	if (PtInRect(&rccombox, pt))
	{
		CreateDropList();
		pt.x = rect.left; pt.y = rect.bottom-1;
		::ClientToScreen(m_Hwnd, &pt);
		GetClientRect(m_pcomboxlist->GetHwnd(), &rect);
		m_pcomboxlist->MoveWindow(pt.x, pt.y, rect.right - rect.left, rect.bottom - rect.top);
		m_pcomboxlist->ShowWindow(SW_SHOW);
	}
}

void TCombox::OnMouseMove(WPARAM wParam, LPARAM lParam)
{
	POINT pt;
	pt.x = LOWORD(lParam);
	pt.y = HIWORD(lParam);

	m_bmouseover = true;
	if (!m_bmousetrack)
	{
		TRACKMOUSEEVENT tme;
		tme.cbSize = sizeof(tme);
		tme.dwFlags = TME_LEAVE;
		tme.hwndTrack = m_Hwnd;
		tme.dwHoverTime = 0;
		::TrackMouseEvent(&tme);
	}
	InvalidateRect(m_Hwnd, 0, false);
}

void TCombox::OnMouseLeave(WPARAM wParam, LPARAM lParam)
{
	m_bmousetrack = false;
	m_bmouseover = false;

	InvalidateRect(m_Hwnd, 0, false);
}

void TCombox::OnComboxSelect(WPARAM wParam, LPARAM lParam)
{
	int nindex = (int)lParam;
	if (nindex >= 0 && nindex < (int)m_stldata.size())
	{
		m_nselect = nindex;
		std::wstring sztext = m_stldata[nindex].sztext;
		SetText(sztext.c_str());
	}

	PostMessage(GetParent(), SSWM_COMBOX_SELECT, nindex, m_nindex);
}

LRESULT TCombox::EditProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData)
{
	HWND hparent = ::GetParent(hwnd);
	switch (message)
	{
	case WM_LBUTTONDOWN:
		SetFocus(hwnd);
		break;
	case WM_KEYDOWN:
		if (VK_TAB == (int)wParam)
			SendMessage(hparent, SSWM_TAB_SWITCH_FOCUS, 0, 0);
		break;
	case WM_KILLFOCUS:
	case WM_ACTIVATE:
		SendMessage(hparent, message, wParam, lParam);
		break;
	}
	return DefSubclassProc(hwnd, message, wParam, lParam);
}
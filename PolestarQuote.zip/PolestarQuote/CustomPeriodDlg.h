//�Զ������ڶԻ���

#pragma once
class CustomPeriodDlg
{
public:
	CustomPeriodDlg();
	~CustomPeriodDlg();
	bool ShowDlg(TQuoteFrame* pFrame);
	void SetDlgRect();
	inline HWND GetHwnd() const { return m_hWnd; }
	std::vector<TKLinePeriod> m_arrPeriod;
private:
	void OnInitDlg();
	void UpdateList();
	static INT_PTR CALLBACK CustomPeriodProc(HWND, UINT, WPARAM, LPARAM);
	void OnCommand(WPARAM wParam, LPARAM lParam);
	void OnButtonAdd();
	void OnButtonDel();
	void OnOk();
private:
	HWND           m_hWnd;        //���ھ��
	HWND           m_hCmbType;    //����ѡ���
	TListCtrl      m_ListCtrl;    //�����б�
	int            m_nResult;
	TQuoteFrame*   m_pFrame;
};


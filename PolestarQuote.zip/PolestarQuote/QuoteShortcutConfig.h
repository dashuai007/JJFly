#pragma once
class QuoteShortcutConfig :
	public TIxFrm
{
public:
	QuoteShortcutConfig();
	~QuoteShortcutConfig();
	bool Create(HWND hparent);
private:
	enum RECT_TYPE
	{
		LIST_RECT = 0,
		PLATE_RECT,
		SC_KEY_RECT,
		MODIFY_RECT,
		RECT_COUNT
	};
	//ͼ�λ���
	void PrepareRects();
	void CreateSubCtrls();
	void UpdateList();
	virtual LRESULT WndProc(UINT message, WPARAM wParam, LPARAM lParam);
	void OnPaint();
	void OnDestory();
	void OnListClick(int nRow);
	void OnModifyClick();
	TListCtrl                 m_ListCtrl;    //�����б�
	RECT					  m_Rects[RECT_COUNT];						//���л�ͼ����
	TEdit                     m_PlateName;   //�������
	TEdit                     m_Shortcut;    //��ݼ�
	TStaticButton             m_Modify;       //�޸�
	int                       m_nIndex;
};


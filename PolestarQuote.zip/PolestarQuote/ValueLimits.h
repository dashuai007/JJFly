#pragma once

#define between(num1,  Min, Max) \
if( ((num1) < (Min)) || ((num1) > (Max))) \
{ return false ;}

#define _IN(num1,  Min, Max) \
	if( ((num1) < (Min)) || ((num1) > (Max))) \
{ return false ;}


#define VOLATILITY_MIN 0.0000001
#define VOLATILITY_MAX 100.99999

#define DAY_MIN 1
#define DAY_MAX 7700

#define YEAR_MIN 0.00001
#define YEAR_MAX 20

#define PRICE_MIN 0.000001
#define PRICE_MAX 1000000000000.0

#define INTEREST_RATE_MIN 0.0 
#define INTEREST_RATE_MAX 100000.0 

#define STEPS_MIN  20
#define STEPS_MAX  2000

#define ITERATION_MIN 15
#define ITERATION_MAX 100

#define ACCURACY_MIN  0.000000001
#define ACCURACY_MAX  1

#define IVPRICE_MIN 0
#define IVPRICE_MAX 1000000000000.0
#pragma once
class CDataArray
{
public:
	CDataArray();
	CDataArray(int nNumData, int nStartIndex);
	virtual ~CDataArray();

	void	SetSize(int nNumData, int nStartIndex);
	void	CopyFrom(CDataArray *pSrc);
	void	CopyFrom(float fValue);
	BOOL	GetMinMaxValue(float& fMinValue, float& fMaxValue, int nStartIndex, int nEndIndex);
	void	SetAt(int nIndex, float fValue);

	float*	m_pData;
	int		m_nNumData;
	int		m_nStartIndex;
};


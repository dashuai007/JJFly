#include "PreInclude.h"

CSymtabNode::CSymtabNode()
	:m_bOutput(FALSE), m_pDataArray(NULL),
	m_nStyle(dsDEFAULT), m_nColor(-1), m_nLineThick(0)
{
	m_nDrawType = 0;
}
CSymtabNode::~CSymtabNode()
{
	if (m_pDataArray) delete m_pDataArray;
	m_pDataArray = NULL;
}

CParser::CParser():m_pIndex(NULL)
{
}


CParser::~CParser()
{
	DeleteSymtabs();
}

void CParser::SetIndex(CIndex* pIndex)
{
	m_pIndex = pIndex;
	DeleteSymtabs();
	InitParamSymtab();
}

void CParser::InitParamSymtab()
{
	int nIndex;
	CSymtabNode* pNode;
	for (int i = 0; i< PARAM_NUM; i++)
	{
		char ParamName[11];
		TKLineSpecParam param = m_pIndex->GetParam(i);
		WCharToMByte(param.Name, ParamName, strlen(ParamName));
		nIndex = EnterSymtab(ParamName, itPARAM);
		pNode = m_vSymtabs[nIndex];
		pNode->m_DataType = dtNUMBER;
		pNode->m_fValue = param.Value;
	}
}
void CParser::DeleteSymtabs()
{
	for (size_t i = 0; i<m_vSymtabs.size(); i++)
		delete m_vSymtabs[i];
	m_vSymtabs.clear();
}
void CParser::SaveCode()
{
	m_pIndex->m_nCodeSize = m_nCodeSize;
	m_pIndex->m_pCode = new CODE[m_nCodeSize];
	CODE* pCodeDest = m_pIndex->m_pCode;
	CODE* pCodeSrc = &(m_Codes[0]);
	for (int i = 0; i<m_nCodeSize; i++)
	{
		pCodeDest->nOperator = pCodeSrc->nOperator;
		pCodeDest->fValue = pCodeSrc->fValue;
		pCodeSrc++; 
		pCodeDest++;
	}
}
void CParser::LoadCode()
{
	m_nCodeSize = m_pIndex->m_nCodeSize;
	CODE* pCodeDest = &(m_Codes[0]);
	CODE* pCodeSrc = m_pIndex->m_pCode;
	for (int i = 0; i<m_nCodeSize; i++)
	{
		pCodeDest->nOperator = pCodeSrc->nOperator;
		pCodeDest->fValue = pCodeSrc->fValue;
		pCodeSrc++; 
		pCodeDest++;
	}
}
int	CParser::EnterSymtab(char* strName, int itType)
{
	CSymtabNode* pNewNode = new CSymtabNode;
	strcpy_s(pNewNode->m_strName,strName);
	pNewNode->m_itType = itType;
	m_vSymtabs.push_back(pNewNode);
	return m_vSymtabs.size() - 1;
}

int CParser::SearchSymtab(char* strName, int itType)
{
	int nStart, nEnd;
	if (itType == itPARAM)
	{
		nStart = 0;
		nEnd = PARAM_NUM;
	}
	else
		if (itType == itVARIABLE)
		{
			nStart = PARAM_NUM;
			nEnd = m_vSymtabs.size();
		}
		else
			if (itType == (itVARIABLE | itPARAM))
			{
				nStart = 0;
				nEnd = m_vSymtabs.size();
			}
	for (int i = nStart; i<nEnd; i++)
	{
		if (strcmp(strName ,m_vSymtabs[i]->m_strName)==0)
		{
			return i;
		}
	}
	return -1;
}
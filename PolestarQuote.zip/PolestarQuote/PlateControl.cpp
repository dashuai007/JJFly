#include "PreInclude.h"

TPlateControl::TPlateControl(TDuiWindow& window) : TDuiControl(window), m_ActivePage(NULL), m_L2_SelectIndex(0), m_MenuBtn_Hover(false),
m_Scroll_Pos(0), m_Scroll_Page(10), m_Scroll_Count(50), m_Scroll_Move(false)
{
	if (G_QuoteUtils.PlatePages.size() > 0)
		m_ActivePage = G_QuoteUtils.PlatePages[0];
	for (size_t i = 0; i < G_QuoteUtils.PlatePages.size(); i++)
	{
		TPlatePage* p = G_QuoteUtils.PlatePages[i];
		TPlatePage* pp = p;
		if (p->ChildPages.size() > 0)
			pp = p->ChildPages[0];
		if (pp->PlateRows.size() > 0)
		{
			m_ActivePage = p;
			break;
		}
	}

	AssignPages();
}

bool TPlateControl::SetScroll(int pos, int page, int count)
{
	if (m_Scroll_Pos == pos && m_Scroll_Page == page && m_Scroll_Count == count)
		return false;

	m_Scroll_Pos = pos;
	m_Scroll_Page = page;
	m_Scroll_Count = count;
	//Redraw(NULL);
	return true;				
}

void TPlateControl::SetActivePage(TPlatePage* active, int nChild)
{
	m_ActivePage = active;
	m_L2_SelectIndex = nChild;
}

TPlatePage* TPlateControl::GetActivePageWithL2()
{
	if (!m_ActivePage)
		return NULL;
	if (m_ActivePage->ChildPages.empty())
		return m_ActivePage;

	if (m_L2_SelectIndex >= 0 && m_L2_SelectIndex < m_ActivePage->ChildPages.size())
		return m_ActivePage->ChildPages[m_L2_SelectIndex];
	else
		return m_ActivePage->ChildPages[0];
}

size_t TPlateControl::GetGuideRowIndex()
{
	if (!m_ActivePage)
		return 0;
	if (m_ActivePage->PlateGuideCount <= 0)
		return 0;

	if (m_L2_SelectIndex >= 0 && m_L2_SelectIndex < m_ActivePage->PlateGuideCount)
		return m_ActivePage->PlateGuides[m_L2_SelectIndex].Row->RowIndex;
	
	return 0;
}

void TPlateControl::ScrollLeft()
{
	if (m_Scroll_Pos > 0)
	{
		m_Scroll_Pos--;
		Redraw(NULL);
		((TQuoteFrame*)GetWindow())->ScrollGrid();
	}
}

void TPlateControl::ScrollRight()
{
	if (m_Scroll_Pos < m_Scroll_Count - m_Scroll_Page)
	{
		m_Scroll_Pos++;
		Redraw(NULL);
		((TQuoteFrame*)GetWindow())->ScrollGrid();
	}
}
bool IsCommidityEquire(SCommodityNoType ComNo1, SCommodityNoType ComNo2)
{
	const char* pos1(strchr(ComNo1, '|'));
	if (NULL == pos1 || '\0' == pos1[1] || '\0' == pos1[2])
		return false;
	const char* pos2(strchr(ComNo2, '|'));
	if (NULL == pos2 || '\0' == pos2[1] || '\0' == pos2[2])
		return false;
	if (strcmp(&pos1[3], &pos2[3]) == 0)
		return true;
	return false;
}
bool TPlateControl::SelectPage(TPlateNoType plateno, SCommodityNoType ComNo)
{
	if ('\0' == plateno[0])
		return false;

	for (size_t i = 0; i < G_QuoteUtils.PlatePages.size(); i++)
	{
		TPlatePage* page = G_QuoteUtils.PlatePages[i];
		if (page->ChildPages.size() > 0)
		{
			for (size_t j = 0; j < page->ChildPages.size(); j++)
			{
				TPlatePage* cpage = page->ChildPages[j];
				if (0 == strcmp(plateno, cpage->PlateNo))
				{
					m_ActivePage = page;
					m_L2_SelectIndex = j;
					((TQuoteFrame*)GetWindow())->AdjustPlate(false);
					return true;
				}
			}
			continue;
		}
		else if (0 == strcmp(plateno, page->PlateNo)&&ComNo != NULL)
		{
			for (size_t j = 0; j < page->PlateGuideCount; j++)
			{
				TPlateGuide* guide = &page->PlateGuides[j];
				if (IsCommidityEquire(ComNo, guide->Row->Contract->Commodity->CommodityNo))
				{
					m_ActivePage = page;
					m_L2_SelectIndex = j;
					((TQuoteFrame*)GetWindow())->AdjustPlate(false);
					return true;
				}
			}
		}

		if (0 == strcmp(plateno, page->PlateNo))
		{
			m_ActivePage = page;
			m_L2_SelectIndex = 0;
			((TQuoteFrame*)GetWindow())->AdjustPlate(false);
			return true;
		}

	}

	return false;
}


bool TPlateControl::OnDraw(HDC hdc, HDC mdc, RECT& cr, RECT& ur, bool follow)
{
	//����
	FillRect(mdc, &cr, BRUSH_PLATE_BACKGROUND);

	//�߶ȴ���
	/*if (cr.bottom != PLATE_HEIGHT)
		return true;*/

	//����page��Ӱ�쵽L1��ʾ�������Ƿ���ʾMenuBtn
	AssignPages();
	SelectObject(mdc, PEN_PLATE_LINE);
	if (m_ActivePage && !m_ActivePage->IsOption)
	{
		//һ���Ͷ��� �ָ���
		MoveToEx(mdc, 0, L2_HEIGHT, 0);
		LineTo(mdc, cr.right, L2_HEIGHT);
	}
	//һ�����--------------------------------------------------------------------------------------------------------
	Draw_L1(mdc, cr, ur);

	//һ�����˵�--------------------------------------------------------------------------------------------------------
	Draw_MenuBtn(mdc, cr, ur);
	if (m_ActivePage && !m_ActivePage->IsOption)
	{
		//�������--------------------------------------------------------------------------------------------------------
		Draw_L2(mdc, cr, ur);

		//�������˵�---------------------------------------------------------------------------------------------------
		Draw_SubMenuBtn(mdc, cr, ur);
		//������--------------------------------------------------------------------------------------------------------
		Draw_Scroll(mdc, cr, ur);
	}
	//
	return true;
}

void TPlateControl::OnMouseMove(WORD btn, POINTS& pts)
{
	RECT wr;
	GetRect(wr);
	wr.right -= wr.left;
	wr.bottom -= wr.top;
	int nHigth = 0;
	if (m_ActivePage &&!m_ActivePage->IsOption)
		nHigth = L2_HEIGHT + LINE_HEIGHT;
	//���������ж�menubtn�ĻЧ��
	if (0 == btn && pts.y >= nHigth && pts.y <nHigth + L1_HEIGHT
		&& m_MenuPages.size() > 0 && pts.x >= wr.right - MENU_WIDTH && pts.x < wr.right)
	{
		if (!m_MenuBtn_Hover)
		{
			m_MenuBtn_Hover = true;
			Redraw(NULL);
			TrackMouseLeave();
			return;
		}
		return;
	}

	if (m_MenuBtn_Hover)
	{
		m_MenuBtn_Hover = false;
		Redraw(NULL);
		return;
	}

	//������£��ж��ϷŹ������������˳�
	if (MK_LBUTTON == btn && m_Scroll_Move)
	{
		POINT p;
		GetCursorPos(&p);
		ScreenToClient(p);

		if (p.x == m_Scroll_Begin.x)
			return;

		int curr = MoveScrollPos(p.x);
		if (curr < 0 || curr == m_Scroll_Pos || curr >= m_Scroll_Count)
			return;

		m_Scroll_Pos = curr;
		m_Scroll_Begin = p;
		Redraw(NULL);

		((TQuoteFrame*)GetWindow())->ScrollGrid();

		return;
	}
}

void TPlateControl::OnLButtonDown(WORD btn, POINTS& pts)
{
	if (MK_LBUTTON != btn)
		return;

	RECT wr;
	GetRect(wr);
	wr.right -= wr.left;
	wr.bottom -= wr.top;
	int nHigth = 0;
	if (m_ActivePage && !m_ActivePage->IsOption)
		nHigth = L2_HEIGHT + LINE_HEIGHT;
	//����һ����� ���� �˵���
	if (pts.y >= nHigth && pts.y < nHigth + L1_HEIGHT)
	{
		//�жϲ˵���
		if (m_MenuPages.size() > 0 && pts.x >= wr.right - MENU_WIDTH && pts.x < wr.right)
		{
			POINT p = { wr.right, nHigth };
			ClientToScreen(p);			
		
			ShowPopPlate(p.x - TDuiPopMenuControl::POPMENU_WIDTH, p.y - m_MenuPages.size() * TDuiPopMenuControl::POPMENU_CELL_HEIGHT);

			return;
		}

		//�ж�page
		TPlatePage* page = FindPageByX(pts.x);
		if (NULL != page)
		{
			m_ActivePage = page;
			m_L2_SelectIndex = 0;
			//Redraw(NULL);
			((TQuoteFrame*)GetWindow())->AdjustPlate();
			return;
		}

		return;
	}
	if (m_ActivePage && m_ActivePage->IsOption)
		return;
	//����������� ���� ������
	if (pts.y >= 0 && pts.y < L2_HEIGHT)
	{
		//�жϹ�����
		if (wr.right >= SCROLL_WIDTH)
		{
			int pos = DownScrollPos(pts.x);
			switch (pos)
			{
			case -1:	//pos--
				ScrollLeft();
				return;
			case -2:	//��ʼ�϶�
				m_Scroll_Move = true;
				GetCursorPos(&m_Scroll_Begin);
				GetWindow()->SetCapture(this);
				return;
			case -3:	//pos++
				ScrollRight();
				return;
			default:
				if (pos >= 0)
				{
					m_Scroll_Pos = pos;
					Redraw(NULL);
					((TQuoteFrame*)GetWindow())->ScrollGrid();
					return;
				}
				break;
			}

		}
		//�жϲ˵���
		if (m_MenuSubPage.size() > 0 && pts.x >= wr.right - SCROLL_WIDTH - MENU_WIDTH && pts.x < wr.right - SCROLL_WIDTH)
		{
			POINT p = { wr.right - SCROLL_WIDTH, LINE_HEIGHT };
			ClientToScreen(p);

			ShowPopSubPlate(p.x - TDuiPopMenuControl::POPMENU_WIDTH, p.y - m_MenuSubPage.size() * TDuiPopMenuControl::POPMENU_CELL_HEIGHT);

			return;
		}
		//�ж϶������ �� ������
		int index = FindIndexByX(pts.x);
		if (index >= 0)
		{
			m_L2_SelectIndex = index;
			Redraw(NULL);
			if (m_ActivePage&&m_ActivePage->ChildPages.empty())
				((TQuoteFrame*)GetWindow())->AdjustGuide();
			else
				((TQuoteFrame*)GetWindow())->AdjustPlate();
			return;
		}

		return;
	}
}

void TPlateControl::OnLButtonUp(WORD btn, POINTS& pts)
{
	GetWindow()->ReleaseCapture();
	m_Scroll_Move = false;


}

void TPlateControl::OnMouseLeave()
{
	if (m_MenuBtn_Hover)
	{
		m_MenuBtn_Hover = false;
		Redraw(NULL);
		return;
	}
}

void TPlateControl::Draw_L1(HDC mdc, RECT& cr, RECT& ur)
{
	RECT r;
	int nHigth = 0;
	if (m_ActivePage && !m_ActivePage->IsOption)
		nHigth = L2_HEIGHT + LINE_HEIGHT;
	r.top = nHigth;
	r.bottom = r.top + L1_HEIGHT;
	r.left = 0;
	r.right = 0;
	
	SelectObject(mdc, FONT_PLATE);

	for (size_t i = 0; i < m_ShowPages.size(); i++)
	{
		TPlatePage* page = m_ShowPages[i];

		/*if(page->IsOption)
			SelectObject(mdc, FONT_BLOD_PLATE);
		else
			SelectObject(mdc, FONT_PLATE);*/
		//��������
		r.left = r.right;
		r.right = r.left + page->PlateSize.cx + 2 * L1_PADDING;

		SetTextColor(mdc, (m_ActivePage == page) ? COLOR_PLATE_FONT_HOT : COLOR_PLATE_FONT);
		DrawText(mdc, page->PlateName, wcslen(page->PlateName), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

		//����ָ���
		if (m_ActivePage == page)
		{
			if (i != 0)
			{
				MoveToEx(mdc, r.left - 1, r.top, 0);
				LineTo(mdc, r.left - 1, r.bottom);
			}
			MoveToEx(mdc, r.right, r.top, 0);
			LineTo(mdc, r.right, r.bottom);
		}


		//Ĩ�������ǩ��������
		if (m_ActivePage == page)
		{
			RECT rr(r);
			rr.top -= LINE_HEIGHT;
			rr.bottom = rr.top + LINE_HEIGHT;
			FillRect(mdc, &rr, BRUSH_PLATE_BACKGROUND);
		}

		//�������ߵĿ���
		r.right += LINE_WIDTH;
	}
}

void TPlateControl::Draw_MenuBtn(HDC mdc, RECT& cr, RECT& ur)
{
	//�޵���menu�����
	if (m_MenuPages.size() <= 0)
		return;

	SelectObject(mdc, m_MenuBtn_Hover ? PEN_PLATE_MENU_HOVER : PEN_PLATE_MENU);

	RECT r;
	int nHigth = 0;
	if (m_ActivePage && !m_ActivePage->IsOption)
		nHigth = L2_HEIGHT + LINE_HEIGHT;
	r.top = nHigth;
	r.bottom = r.top + L1_HEIGHT;
	r.right = cr.right;
	r.left = r.right - MENU_WIDTH;

	r.top += 6;
	Draw_Arraw(mdc, r, D_UP);
	r.top -= 8;
	Draw_Arraw(mdc, r, D_UP);
}

void TPlateControl::Draw_L2(HDC mdc, RECT& cr, RECT& ur)
{
	//�޼���ҳ���޷���L2
	if (NULL == m_ActivePage)
		return;

	RECT r;
	r.top = 0;
	r.bottom = r.top + L2_HEIGHT;
	r.left = 0;
	r.right = 0;
	m_MenuSubPage.clear();
	if (m_ActivePage->ChildPages.empty())			//��ʾƷ�ֵ���
	{
		for (size_t i = 0; i < m_ActivePage->PlateGuideCount; i++)
		{
			TPlateGuide* guide = &m_ActivePage->PlateGuides[i];
			
			r.left = r.right;
			r.right = r.left + guide->GuideSize.cx + 2 * L2_PADDING;

			//�������޲���
			if (r.right > cr.right - SCROLL_WIDTH - MENU_WIDTH)
			{
				TPopGuide pop;
				pop.Index = i;
				MByteToWChar(guide->Row->Contract->Commodity->CommodityName, pop.PopName, sizeof(pop.PopName) / sizeof(wchar_t));
				m_MenuSubPage.push_back(pop);
				continue;
			}

			SetTextColor(mdc, (m_L2_SelectIndex == i) ? COLOR_PLATE_FONT_HOT2 : COLOR_PLATE_FONT2);
			wchar_t textCName[51];
			MByteToWChar(guide->Row->Contract->Commodity->CommodityName, textCName, sizeof(textCName) / sizeof(wchar_t));
			DrawText(mdc, textCName, wcslen(textCName), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
		}
	}
	else											//��ʾ�Ӱ��
	{
		for (size_t i = 0; i < m_ActivePage->ChildPages.size(); i++)
		{
			TPlatePage* page = m_ActivePage->ChildPages[i];

			r.left = r.right;
			r.right = r.left + page->PlateSize.cx + 2 * L2_PADDING;

			//�������޲���
			if (r.right > cr.right - SCROLL_WIDTH - MENU_WIDTH)
			{
				TPopGuide pop;
				pop.Index = i;
				wcscpy_s(pop.PopName, page->PlateName);
				m_MenuSubPage.push_back(pop);
				continue;
			}

			SetTextColor(mdc, (m_L2_SelectIndex == i) ? COLOR_PLATE_FONT_HOT2 : COLOR_PLATE_FONT2);
			DrawText(mdc, page->PlateName, wcslen(page->PlateName), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
		}
	}
}
void TPlateControl::Draw_SubMenuBtn(HDC mdc, RECT& cr, RECT& ur)
{
	//�޵���menu�����
	if (m_MenuSubPage.size() <= 0)
		return;

	SelectObject(mdc, m_MenuBtn_Hover ? PEN_PLATE_MENU_HOVER : PEN_PLATE_MENU);

	RECT r;
	r.top = LINE_HEIGHT;
	r.bottom = r.top + L2_HEIGHT;
	r.right = cr.right - SCROLL_WIDTH;
	r.left = r.right - MENU_WIDTH;

	r.top += 6;
	Draw_Arraw(mdc, r, D_UP);
	r.top -= 8;
	Draw_Arraw(mdc, r, D_UP);
}
void TPlateControl::Draw_Scroll(HDC mdc, RECT& cr, RECT& ur)
{
	//���Ȳ���������
	if (cr.right < SCROLL_WIDTH)
		return;

	SelectObject(mdc, PEN_SCROLL_GRAPH);

	//��ͷ��
	RECT r;
	r.left = cr.right - SCROLL_WIDTH + SCROLL_SLIDE_PADDING;
	r.right = r.left + SCROLL_BTN_WIDTH;
	r.top = SCROLL_SLIDE_PADDING;
	r.bottom = r.top + SCROLL_HEIGHT;
	FillRect(mdc, &r, BRUSH_SCROLL_BACKGROUND);

	//��ͷ
	Draw_Arraw(mdc, r, D_LEFT);
	r.left -= 2;
	Draw_Arraw(mdc, r, D_LEFT);

	r.left = cr.right - SCROLL_BTN_WIDTH - SCROLL_SLIDE_PADDING;
	r.right = r.left + SCROLL_BTN_WIDTH;
	FillRect(mdc, &r, BRUSH_SCROLL_BACKGROUND);

	Draw_Arraw(mdc, r, D_RIGHT);
	r.right += 2;
	Draw_Arraw(mdc, r, D_RIGHT);

	//������
	r.left = cr.right - SCROLL_WIDTH + SCROLL_SLIDE_PADDING + SCROLL_BTN_WIDTH;
	r.right = r.left + SCROLL_SLIDE_WIDTH + 2 * SCROLL_SLIDE_PADDING;
	r.top = SCROLL_SLIDE_PADDING;
	r.bottom = r.top + SCROLL_HEIGHT;
	FillRect(mdc, &r, BRUSH_SCROLL_FOREGROUND); 

	//����
	r.left += SCROLL_SLIDE_PADDING;
	r.right -= SCROLL_SLIDE_PADDING;

	GetScrollBlock(r.left, r.right);

	FillRect(mdc, &r, BRUSH_SCROLL_BLOCK);

}

void TPlateControl::AssignPages()
{
	RECT wr;
	GetRect(wr);
	wr.right -= (wr.left + MENU_WIDTH);

	int pos(0);

	m_ShowPages.clear();
	m_MenuPages.clear();

	for (size_t i = 0; i < G_QuoteUtils.PlatePages.size(); i++)
	{
		TPlatePage* page = G_QuoteUtils.PlatePages[i];

		pos += page->PlateSize.cx + 2 * L1_PADDING + LINE_WIDTH;

		if (pos < wr.right)
			m_ShowPages.push_back(page);
		else
			m_MenuPages.push_back(page);
	}
}

TPlatePage* TPlateControl::FindPageByX(int x)
{
	int pos(0);

	for (size_t i = 0; i < m_ShowPages.size(); i++)
	{
		TPlatePage* page = m_ShowPages[i];

		if (x >= pos && x < pos + page->PlateSize.cx + 2 * L1_PADDING + LINE_WIDTH)
			return page;

		pos += page->PlateSize.cx + 2 * L1_PADDING + LINE_WIDTH;
	}

	return NULL;
}

int TPlateControl::FindIndexByX(int x)
{
	if (NULL == m_ActivePage)
		return -1;
	
	int pos(0);

	//���ڹ����������жϵģ����Դ˴�������Խ������

	if (m_ActivePage->ChildPages.empty())
	{
		for (size_t i = 0; i < m_ActivePage->PlateGuideCount; i++)
		{
			TPlateGuide* guide = &m_ActivePage->PlateGuides[i];

			if (x >= pos && x < pos + guide->GuideSize.cx + 2 * L2_PADDING)
				return i;

			pos += guide->GuideSize.cx + 2 * L2_PADDING;
		}
	}
	else
	{
		for (size_t i = 0; i < m_ActivePage->ChildPages.size(); i++)
		{
			TPlatePage* page = m_ActivePage->ChildPages[i];

			if (x >= pos && x < pos + page->PlateSize.cx + 2 * L2_PADDING)
				return i;

			pos += page->PlateSize.cx + 2 * L2_PADDING;
		}
	}

	return -1;
}

void TPlateControl::GetScrollBlock(LONG& left, LONG& right)
{
	//�����ж� �޷���ʾ��������״̬

	RECT r;
	GetRect(r);
	r.right -= SCROLL_BTN_WIDTH + 2 * SCROLL_SLIDE_PADDING;
	r.left = r.right - SCROLL_SLIDE_WIDTH;

	LONG width = SCROLL_BTN_WIDTH; //(SCROLL_BTN_WIDTH / 3);
	if (m_Scroll_Count > 0)
		width = (LONG)(1.0 * m_Scroll_Page * (r.right - r.left) / m_Scroll_Count);
	if (width < SCROLL_BTN_WIDTH)	//(width < 0)
		width = SCROLL_BTN_WIDTH; // / 3;
	else if (width > r.right - r.left)
		width = r.right - r.left;

	left = r.left;
	if (m_Scroll_Count - m_Scroll_Page > 0)
		left = r.left + (LONG)(1.0 * m_Scroll_Pos * (r.right - r.left - width) / (m_Scroll_Count - m_Scroll_Page));
	if (left < r.left)
		left = r.left;
	else if (left > r.right - width)
		left = r.right - width;

	right = left + width;
}

int TPlateControl::DownScrollPos(int x)
{
	RECT r;
	GetRect(r);
	r.left = r.right - SCROLL_WIDTH;

	if (x >= r.left && x < r.left + SCROLL_BTN_WIDTH)
		return -1;
	
	if (x >= r.right - SCROLL_BTN_WIDTH && x < r.right)
		return -3;

	LONG left, right;
	GetScrollBlock(left, right);
	if (x >= left && x < right)
		return -2;

	r.left += SCROLL_BTN_WIDTH + SCROLL_SLIDE_PADDING;
	r.right -= SCROLL_BTN_WIDTH + SCROLL_SLIDE_PADDING;

	if ((x >= r.left && x < left)
		|| (x >= right && x < r.right))
	{
		x -= (right - left) / 2;
		if (x < r.left)
			x = r.left;
		else if (x > r.right - (right - left))
			x = r.right - (right - left);

		x -= r.left;
		r.right -= r.left;

		int ret = (LONG)(1.0 * x * (m_Scroll_Count - m_Scroll_Page) / (r.right - (right - left)));
		if (ret < 0)
			ret = 0;
		else if (ret > m_Scroll_Count - m_Scroll_Page)
			ret = m_Scroll_Count - m_Scroll_Page;
		return ret;
	}
	
	return -4;
}

int TPlateControl::MoveScrollPos(int x)
{
	RECT r;
	GetRect(r);
	r.right -= SCROLL_BTN_WIDTH + 2 * SCROLL_SLIDE_PADDING;
	r.left = r.right - SCROLL_SLIDE_WIDTH;

	if (x < r.left || x >= r.right)
		return -1;

	LONG bl, br;
	GetScrollBlock(bl, br);

	x -= (br - bl) / 2;
	if (x < r.left)
		x = r.left;
	else if (x > r.right - (br - bl))
		x = r.right - (br - bl);

	x -= r.left;
	r.right -= r.left;

	int ret = (LONG)(1.0 * x * (m_Scroll_Count - m_Scroll_Page) / (r.right - (br - bl)));
	if (ret < 0)
		ret = 0;
	else if (ret > m_Scroll_Count - m_Scroll_Page)
		ret = m_Scroll_Count - m_Scroll_Page;
	return ret;
}

void TPlateControl::OnPopMenuClick(TDuiPopMenuItem* obj)
{
	if (!m_ActivePage)
		return;
	//����page����������
	if (obj->Index < 100)
	{
		SetActivePage((TPlatePage*)(obj->Value));
		Redraw(NULL);
		((TQuoteFrame*)GetWindow())->AdjustPlate();
	}
	else
	{
		TPopGuide* page = (TPopGuide*)(obj->Value);
		m_L2_SelectIndex = page->Index;
		Redraw(NULL);
		if (m_ActivePage->ChildPages.empty())
			((TQuoteFrame*)GetWindow())->AdjustGuide();
		else
			((TQuoteFrame*)GetWindow())->AdjustPlate();
	}
}

void TPlateControl::ShowPopPlate(int x, int y)
{
	TDuiPopMenuWindow pop;// = new TDuiPopMenuWindow;

	for (size_t i = 0; i < m_MenuPages.size(); i++)
	{
		TPlatePage* page = m_MenuPages[i];

		TDuiPopMenuItem item;
		memset(&item, 0, sizeof(TDuiPopMenuItem));

		item.Index = i;
		wcsncpy_s(item.Text, page->PlateName, sizeof(item.Text) / sizeof(wchar_t));
		item.Value = page;
		pop.AddItem(item);
	}

	pop.SetSpi(this);
	pop.ShowPop(x, y, false,NULL);
}
void TPlateControl::ShowPopSubPlate(int x, int y)
{
	TDuiPopMenuWindow pop;// = new TDuiPopMenuWindow;

	for (size_t i = 0; i < m_MenuSubPage.size(); i++)
	{
		TPopGuide* page = &m_MenuSubPage[i];

		TDuiPopMenuItem item;
		memset(&item, 0, sizeof(TDuiPopMenuItem));

		item.Index = 100+i;
		wcsncpy_s(item.Text, page->PopName, sizeof(item.Text) / sizeof(wchar_t));
		item.Value = page;
		pop.AddItem(item);
	}

	pop.SetSpi(this);
	pop.ShowPop(x, y,false,NULL);
}
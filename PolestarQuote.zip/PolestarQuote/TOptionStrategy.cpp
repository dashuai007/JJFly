﻿#include"PreInclude.h"
#include "OptionCalc.h"
#include <time.h>
#define PI       3.14159265358979323846
#define MAX_VALUE 1e15
#define MIN_VALUE -1e15
//正态分布函数
inline double Normal(double x, double miu, double sigma)
{
	return 1.0 / (sqrt(2 * PI)*sigma) * exp(-1 * (x - miu)*(x - miu) / (2 * sigma*sigma));
}
//标准正态函数
double STNormal(double z)
{
	double temp;
	temp = exp((-1)*z*z / 2) / sqrt(2 * PI);
	return temp;

}
/***************************************************************/
/* 返回标准正态分布的累积函数，该分布的平均值为 0，标准偏差为 1。                           */
/***************************************************************/
double NormSDist(const double z)
{
	// this guards against overflow   
	if (z > 6) return 1;
	if (z < -6) return 0;

	static const double gamma = 0.231641900,
		a1 = 0.319381530,
		a2 = -0.356563782,
		a3 = 1.781477973,
		a4 = -1.821255978,
		a5 = 1.330274429;

	double k = 1.0 / (1 + fabs(z) * gamma);
	double n = k * (a1 + k * (a2 + k * (a3 + k * (a4 + k * a5))));
	n = 1 - STNormal(z) * n;
	if (z < 0)
		return 1.0 - n;

	return n;
}

double Round(double value, int decDigits)
{
	//放大n倍或缩小n倍
	double temp;
	if (decDigits < 0)
		temp = value*pow(0.1, -decDigits);
	else
		temp = value*pow(10.0, decDigits);

	if (temp > 0)
	{
		if (temp - (__int64)temp >= 0.5)
			temp = (double)((__int64)temp + 1);
		else
			temp = (double)((__int64)temp);
	}
	else
	{
		if ((__int64)temp - temp >= 0.5)
			temp = (double)((__int64)temp - 1);
		else
			temp = (double)((__int64)temp);
	}

	//缩小n倍或放大n倍
	if (decDigits < 0)
		return temp*pow(10.0, -decDigits);
	else
		return temp*pow(0.1, decDigits);
}
TOptionStrategy::TOptionStrategy() :m_pContract(NULL), m_OptionSeries(NULL), m_nXueEndRow(0), m_pGride(NULL)
{
	m_fPrice = 0;
	m_fDelta = 0;
	m_fGamma = 0;
	m_fTheta = 0;
	m_fVega = 0;
	m_fRho = 0;
	m_fIV = 0;
	m_CurrentPrice = 0;
	m_CurrentPayoff = 0;
	m_nRowBegin = 0;
	m_nShowRows = 0;
	m_nSelectedRow = -1;
	m_bCheckScroll = false;
	m_bListFocused = false;
	m_bRegToolTip = false;
	m_TargetOpt = TARGET_NONE;
	memset(&m_NormalData, 0, sizeof(m_NormalData));
	memset(&m_CheckedCont, 0, sizeof(CheckedContract));
	m_CheckedCont.ErrorInfo[0] = '/0';
	m_hImageList = ImageList_LoadImage(GetModuleHandle(L"PolestarQuote.dll"), MAKEINTRESOURCE(IDB_BITMAP1), 32, 12, RGB(0, 0, 0), IMAGE_BITMAP, LR_DEFAULTCOLOR);
	InitTactic();
}


TOptionStrategy::~TOptionStrategy()
{
	if (m_gradient)
		FreeLibrary(m_gradient);
	ImageList_Destroy(m_hImageList);
}
void TOptionStrategy::InitTactic()
{
	Tactic tactic;
	tactic.ID = FREESTYLE;
	wcscpy_s(tactic.Name, G_LANG->LangText(TLI_FREESTYLE));
	tactic.Operate1 = OPERATENONE;
	tactic.Operate2 = OPERATENONE;
	tactic.Condition = 0;
	tactic.Type = FREE;
	m_vTactis.push_back(tactic);

	tactic.ID = BUYCALL;
	wcscpy_s(tactic.Name, G_LANG->LangText(TLI_BULLISH));
	tactic.Operate1 = LONGCALL;
	tactic.Operate2 = OPERATENONE;
	tactic.Condition = 0;
	tactic.Type = SINGLE;
	m_vTactis.push_back(tactic);

	tactic.ID = BUYPUT;
	wcscpy_s(tactic.Name, G_LANG->LangText(TLI_BEARISH));
	tactic.Operate1 = LONGPUT;
	tactic.Operate2 = OPERATENONE;
	tactic.Condition = 0;
	tactic.Type = SINGLE;
	m_vTactis.push_back(tactic);

	tactic.ID = SELLPUT;
	wcscpy_s(tactic.Name, G_LANG->LangText(TLI_NOTRISE));
	tactic.Operate1 = SHORTCALL;
	tactic.Operate2 = OPERATENONE;
	tactic.Condition = 0;
	tactic.Type = SINGLE;
	m_vTactis.push_back(tactic);

	tactic.ID = SELLCALL;
	wcscpy_s(tactic.Name, G_LANG->LangText(TLI_NOTFALL));
	tactic.Operate1 = SHORTPUT;
	tactic.Operate2 = OPERATENONE;
	tactic.Condition = 0;
	tactic.Type = SINGLE;
	m_vTactis.push_back(tactic);

	//组合策略
	tactic.ID = BUYSTRADDLE;
	wcscpy_s(tactic.Name, G_LANG->LangText(TLI_BREAK));
	tactic.Operate1 = LONGCALL;
	tactic.Operate2 = LONGPUT;
	tactic.Condition = EQUAL;
	tactic.Type = COMBINE;
	m_vTactis.push_back(tactic);

	tactic.ID = SELLSTRADDLE;
	wcscpy_s(tactic.Name, G_LANG->LangText(TLI_DULL));
	tactic.Operate1 = SHORTCALL;
	tactic.Operate2 = SHORTPUT;
	tactic.Condition = EQUAL;
	tactic.Type = COMBINE;
	m_vTactis.push_back(tactic);

	tactic.ID = BUYSTRANGLE;
	wcscpy_s(tactic.Name, G_LANG->LangText(TLI_BREAKSTRANGLE));
	tactic.Operate1 = LONGCALL;
	tactic.Operate2 = LONGPUT;
	tactic.Condition = GREAT;
	tactic.Type = COMBINE;
	m_vTactis.push_back(tactic);

	tactic.ID = SELLSTRANGLE;
	wcscpy_s(tactic.Name, G_LANG->LangText(TLI_DULLSTRANGLE));
	tactic.Operate1 = SHORTCALL;
	tactic.Operate2 = SHORTPUT;
	tactic.Condition = GREAT;
	tactic.Type = COMBINE;
	m_vTactis.push_back(tactic);

	tactic.ID = BULLCALLSPREAD;
	wcscpy_s(tactic.Name, G_LANG->LangText(TLI_TEMPERATURERISE));
	tactic.Operate1 = LONGCALL;
	tactic.Operate2 = SHORTCALL;
	tactic.Condition = LESS;
	tactic.Type = COMBINE;
	m_vTactis.push_back(tactic);

	tactic.ID = BULLPUTSPREAD;
	wcscpy_s(tactic.Name, G_LANG->LangText(TLI_TEMPERATURERISEPUT));
	tactic.Operate1 = LONGPUT;
	tactic.Operate2 = SHORTPUT;
	tactic.Condition = LESS;
	tactic.Type = COMBINE;
	m_vTactis.push_back(tactic);

	tactic.ID = BEARPUTSPREAD;
	wcscpy_s(tactic.Name, G_LANG->LangText(TLI_TEMPERATUREFALL));
	tactic.Operate1 = LONGPUT;
	tactic.Operate2 = SHORTPUT;
	tactic.Condition = GREAT;
	tactic.Type = COMBINE;
	m_vTactis.push_back(tactic);

	tactic.ID = BEARCALLSPREAD;
	wcscpy_s(tactic.Name, G_LANG->LangText(TLI_TEMPERATUREFALLCALL));
	tactic.Operate1 = LONGCALL;
	tactic.Operate2 = SHORTCALL;
	tactic.Condition = GREAT;
	tactic.Type = COMBINE;
	m_vTactis.push_back(tactic);

	SetTacticType(m_vTactis[0]);
}
void TOptionStrategy::SetOptionContract(SContract* pCon, SStrikePriceType price)
{
	m_pContract = pCon;
	if (m_pContract)
	{
		m_CurrentPrice = 0;
		m_CurrentPayoff = 0;
		strncpy_s(m_StrikePrice, price, sizeof(SStrikePriceType));
		if (m_hwTip == NULL || !IsWindow(m_hwTip))
		{
            m_hwTip = CreateWindowEx(WS_EX_TOPMOST, TOOLTIPS_CLASS, NULL, WS_POPUP | TTS_NOPREFIX | TTS_ALWAYSTIP, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, m_pGride->GetWindow()->GetHwnd(), NULL, GetModuleHandle(NULL), NULL);
		    SetWindowPos(m_hwTip, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
			SendMessage(m_hwTip, TTM_SETMAXTIPWIDTH, 0, 180);
		}
		
	}
}
void TOptionStrategy::OnMouseMove(POINT& pts)
{
	if (!m_OptionSeries)
		return;
	if (m_bCheckScroll)
	{
		int nVSCROLL_WIDTH = 5;
		RECT  r_bot = m_Rects[RBOTTOM_RECT];
		int RowHigth = 23;
		RECT listRc = r_bot;
		InflateRect(&listRc, -10, -5);
		listRc.top += RowHigth;
		POINT p;
		GetCursorPos(&p);
		int movepos = (LONG)(1.0 * (p.y - m_VScrollBegin.y) * ListRows / (listRc.bottom - listRc.top));
		if (0 != movepos && m_nRowBegin + movepos >= 0 && m_nRowBegin + movepos <= ListRows - m_nShowRows)
		{
			m_nRowBegin += movepos;

			m_VScrollBegin = p;
		}
		return;
	}
	RECT cr = m_Rects[RIGHT_PROFITLOSE];
	RECT regionRect = cr;
	regionRect.left = cr.left + 10;
	regionRect.bottom = cr.bottom - 30;
	regionRect.right = cr.right - 10;
	//根据鼠标位置更新当前显示值,四舍五入到指定精度
	m_CurrentPrice = Round((((double)(pts.x - regionRect.left)) /(regionRect.right- regionRect.left))*(m_ProfitData.endPrice - m_ProfitData.startPrice) + m_ProfitData.startPrice, m_OptionSeries->Commodity->PricePrec+1);
	m_CurrentPayoff = CountProfitAndLos(m_CurrentPrice);
	m_point = pts;
}
void TOptionStrategy::OnMouseLeave()
{
	m_point.x = 0;
	m_point.y = 0;
}
bool TOptionStrategy::OnMouseWheel(int nDone)
{
	RECT sr;
	if (!GetListScrollRect(sr)||!m_bListFocused)
		return false;
	if (nDone + m_nRowBegin >= 0 && nDone + m_nRowBegin <= ListRows - m_nShowRows)
	{
		m_nRowBegin += nDone;
		m_pGride->Redraw(NULL);
	}
	return true;
}

void TOptionStrategy::OnLButtonDown(POINT& pt)
{
	RECT item_r(m_Rects[STRATEGY_ITEM_RECT]);
	if (PtInRect(&item_r, pt))
	{
		//弹出菜单
		if (m_vMenuTactis.size() > 0 && pt.x >= item_r.right - MENU_WIDTH && pt.x < item_r.right)
		{
			POINT p = { item_r.right, item_r.bottom };
			m_pGride->ClientToScreen(p);

			ShowPopSubButton(p.x - TDuiPopMenuControl::POPMENU_WIDTH, p.y);
			return;
		}
		int pos(0);
		for (size_t i = 0; i < m_vTactis.size(); i++)
		{
			Tactic tc = m_vTactis[i];

			if (pt.x >= pos && pt.x < pos + tc.NameSize.cx)
			{
				SetTacticType(tc);
				return;
			}
			pos += tc.NameSize.cx;
		}
	}
	else if (GetListScrollRect(item_r) && pt.x >= item_r.left && pt.x < item_r.right && pt.y >= item_r.top && pt.y < item_r.bottom)
	{

		GetCursorPos(&m_VScrollBegin);
		m_bCheckScroll = true;
		return;
	}
	else
	{
		int nVSCROLL_WIDTH = 5;
		RECT  r_bot = m_Rects[RBOTTOM_RECT];
		int RowHigth = 23;
		RECT listRc = r_bot;
		InflateRect(&listRc, -10, -5);
		listRc.top += RowHigth;
		if (PtInRect(&listRc,pt))
		{
			m_bListFocused = true;
			m_nSelectedRow = (pt.y - listRc.top) / RowHigth + m_nRowBegin;
		}
		return;
	}
}
void TOptionStrategy::OnLButtonUp(POINTS& pt)
{
	m_bCheckScroll = false;
}
void TOptionStrategy::HitStrikeRect(int nRow, POINT& pt)
{
	TCheckRect& rect1 = m_CheckList.GetAt(nRow, LONGCALL);
	TCheckRect& rect2 = m_CheckList.GetAt(nRow, SHORTCALL);
	TCheckRect& rect3 = m_CheckList.GetAt(nRow, LONGPUT);
	TCheckRect& rect4 = m_CheckList.GetAt(nRow, SHORTPUT);
	TACTICOPERATE nType = OPERATENONE;
	if (PtInRect(&rect1, pt) && rect1.IsEnable())
		nType = LONGCALL;
	else if (PtInRect(&rect2, pt) && rect2.IsEnable())
		nType = SHORTCALL;
	else if (PtInRect(&rect3, pt) && rect3.IsEnable())
		nType = LONGPUT;
	else if (PtInRect(&rect4, pt) && rect4.IsEnable())
		nType = SHORTPUT;
	if (nType != OPERATENONE)
	{
		if (m_TactisType.Type == FREE)
			m_CheckList.SetFreeCheckRow(nType, nRow);
		else
			m_CheckList.SetCheckRow(nType, nRow);
		if (m_TactisType.Condition == EQUAL)
		{
			if (nType == m_TactisType.Operate1)
			{
				m_CheckList.SetCheckRow(m_TactisType.Operate2, nRow);
			}
			else if (nType == m_TactisType.Operate2)
			{
				m_CheckList.SetCheckRow(m_TactisType.Operate1, nRow);
			}
		}
		if (m_TactisType.Type == FREE&&!m_CheckList.IsAnyCheched())
			m_TargetOpt = TARGET_NONE;
		RefreshCheckListEable();
		FreshStrategyGraph();
		ClickNoticeOrderPanel();
	}
}
void TOptionStrategy::ClickNoticeOrderPanel()
{
	if (!m_pGride)
		return;
	std::stringstream content;
	content << "TYPE&";
	content << m_TactisType.ID;
	content << ";";
	for (int i = 0; i < m_CheckedCont.ContractNum; i++)
	{
		if (m_CheckedCont.operations[i].type == BUYFUTURE || m_CheckedCont.operations[i].type == SELLFUTURE)
			continue;
		content << m_CheckedCont.operations[i].ContractNo;
		content << "&";
		std::string strType = (m_CheckedCont.operations[i].type % 2 == 1 ? "B" : "S");
		content << strType;
		content << ";";
	}
	PolestarQuoteLinkage(m_pGride->GetWindow()->GetHwnd(), "OptionOrder", content.str().c_str());
}
void TOptionStrategy::ClickOptionTacticNotice()
{
	if (!m_pGride)
		return;
	std::stringstream content;
	content << "SeriesNo&";
	content << m_OptionSeries->SeriesNo;
	content << ";";
	content << "TYPE&";
	content << m_TactisType.ID;
	content << ";";
	PolestarQuoteLinkage(m_pGride->GetWindow()->GetHwnd(), "OptionTactic", content.str().c_str());
}
void TOptionStrategy::SetTacticType(Tactic& tac)
{
	m_TactisType = tac;
	m_bInitCheck = false;
	RefreshCheckList();
	//ClickOptionTacticNotice();
}
void TOptionStrategy::RefreshCheckList()
{
	if (m_bInitCheck)
		return;
	SPriceType dTarget = 0;
	if (GetTargetNewPrice(dTarget))
		m_bInitCheck = true;
	m_CheckList.WithoutChecked();
	m_TargetOpt = TARGET_NONE;
	if (m_TactisType.Type == SINGLE)
	{
		m_CheckList.SetCheckRow(m_TactisType.Operate1, m_nXueEndRow + 1);
	}
	else
	{
		if (m_TactisType.Condition == LESS)
		{
			m_CheckList.SetCheckRow(m_TactisType.Operate1, m_nXueEndRow);
			m_CheckList.SetCheckRow(m_TactisType.Operate2, m_nXueEndRow + 1);
		}
		else if (m_TactisType.Condition == GREAT)
		{
			m_CheckList.SetCheckRow(m_TactisType.Operate1, m_nXueEndRow + 1);
			m_CheckList.SetCheckRow(m_TactisType.Operate2, m_nXueEndRow);
		}
		else if (m_TactisType.Condition == EQUAL)
		{
			m_CheckList.SetCheckRow(m_TactisType.Operate1, m_nXueEndRow + 1);
			m_CheckList.SetCheckRow(m_TactisType.Operate2, m_nXueEndRow + 1);
		}

	}
	RefreshCheckListEable();
	FreshStrategyGraph();
	ClickNoticeOrderPanel();
}
void TOptionStrategy::RefreshCheckListEable()
{
	if (!m_pGride || !m_OptionSeries)
		return;
	if (m_TactisType.Type == FREE)
	{
		m_CheckList.EnableAll();
		return;
	}
	m_CheckList.DisableAll();
	int nCount = G_StarApi->GetOptionContractPairCount(m_OptionSeries->SeriesNo);
	for (int i = 0; i < nCount; i++)
	{
		if (m_TactisType.Type == SINGLE)
		{
			TCheckRect& CheckRect = m_CheckList.GetAt(i, m_TactisType.Operate1);
			CheckRect.SetEnable(true);
		}
		else
		{
			int nOpt1Check = m_CheckList.GetCheckListChecked(m_TactisType.Operate1);
			int nOpt2Check = m_CheckList.GetCheckListChecked(m_TactisType.Operate2);
			if (m_TactisType.Condition == LESS)
			{
				if (i < nOpt2Check)
				{
					TCheckRect& CheckRect = m_CheckList.GetAt(i, m_TactisType.Operate1);
					CheckRect.SetEnable(true);
				}
				if (i > nOpt1Check)
				{
					TCheckRect& CheckRect = m_CheckList.GetAt(i, m_TactisType.Operate2);
					CheckRect.SetEnable(true);
				}
			}
			else if (m_TactisType.Condition == GREAT)
			{
				if (i > nOpt2Check)
				{
					TCheckRect& CheckRect = m_CheckList.GetAt(i, m_TactisType.Operate1);
					CheckRect.SetEnable(true);
				}
				if (i < nOpt1Check)
				{
					TCheckRect& CheckRect = m_CheckList.GetAt(i, m_TactisType.Operate2);
					CheckRect.SetEnable(true);
				}
			}
			else if (m_TactisType.Condition == EQUAL)
			{
				TCheckRect& CheckRect = m_CheckList.GetAt(i, m_TactisType.Operate1);
				CheckRect.SetEnable(true);
				TCheckRect& CheckRect1 = m_CheckList.GetAt(i, m_TactisType.Operate2);
				CheckRect1.SetEnable(true);
			}
		}
	}
}
void TOptionStrategy::UpdateXuShiValue()
{
	if (!m_OptionSeries)
		return;
	SPriceType dTargetPrice = 0;
	if (GetTargetNewPrice(dTargetPrice))
	{
		SOptionContractPair* pairs[1024];
		int cnt = G_StarApi->GetOptionContractPairData(m_OptionSeries->SeriesNo, 0, pairs, sizeof(pairs) / sizeof(SOptionContractPair*));
		for (int i = 0; i < cnt; i++)
		{
			SOptionContractPair* cp = pairs[i];
			if (!cp)
				continue;
			SPriceType dStrikePrice = atof(cp->StrikePrice) * m_pContract->Commodity->PriceMultiple;
			if (dStrikePrice - dTargetPrice < 0)
			{
				m_nXueEndRow = i;
			}
		}
	}
	RefreshCheckList();
}
void TOptionStrategy::ShowPopSubButton(int x, int y)
{
	TDuiPopMenuWindow pop;// = new TDuiPopMenuWindow;

	for (size_t i = 0; i < m_vMenuTactis.size(); i++)
	{
		Tactic* tac = &m_vMenuTactis[i];

		TDuiPopMenuItem item;
		memset(&item, 0, sizeof(TDuiPopMenuItem));

		item.Index = 200 + i;
		wcsncpy_s(item.Text, tac->Name, sizeof(item.Text) / sizeof(wchar_t));
		item.Value = tac;
		pop.AddItem(item);
	}

	pop.SetSpi(m_pGride);
	pop.ShowPop(x, y, false, NULL);
}
bool TOptionStrategy::IsCheckedContect(const SContractNoType ConNo)
{
	if (m_CheckedCont.ContractNum <= 0)
		return false;
	for (int i = 0; i < m_CheckedCont.ContractNum; i++)
	{
		if (strcmp(ConNo, m_CheckedCont.operations[i].ContractNo) == 0)
			return true;
	}
	return false;
}
bool TOptionStrategy::CheckData()
{
	for (int i = 0; i < m_CheckedCont.ContractNum; i++)
	{
		if (m_CheckedCont.operations[i].money <= 0 || m_CheckedCont.operations[i].money>MAX_VALUE)
		{
			wcscpy_s(m_CheckedCont.ErrorInfo, G_LANG->LangText(TLI_NODIRECTPRICE));
			return FALSE;
		}
	}
	return TRUE;
}
void TOptionStrategy::FreshStrategyGraph()
{
	memset(&m_CheckedCont, 0, sizeof(CheckedContract));
	m_CheckedCont.ErrorInfo[0] = '/0';
	m_CheckList.GetCheckedContract(m_CheckedCont);
	if (m_CheckedCont.ContractNum >= 5 && m_TactisType.Type == FREE)
	{
		m_CheckList.DisableNoChecked();
	}
	//增删标的处理
	if (m_TargetOpt != TARGET_NONE)
	{
		if (m_TargetOpt == TARGET_DEL)
		{
			m_TargetOpt = TARGET_NONE;
		}
		else
		{
			int nCount = m_CheckedCont.ContractNum;
			if (m_TargetOpt == TARGET_ADD_BUY)
			{
				m_CheckedCont.operations[nCount].type = BUYFUTURE;
				SPriceType dTarget = 0;
				GetTargetPrice(dTarget, true);
				m_CheckedCont.operations[nCount].money = dTarget;
			}
			else if (m_TargetOpt == TARGET_ADD_SELL)
			{
				m_CheckedCont.operations[nCount].type = SELLFUTURE;
				SPriceType dTarget = 0;
				GetTargetPrice(dTarget, false);
				m_CheckedCont.operations[nCount].money = dTarget;
			}
			m_CheckedCont.ContractNum++;
		}	
	}
	CheckData();
	CountKeyPrices();
	CalProfitLossData();
	ReCalLimitInfo();
}
void TOptionStrategy::OptionOrderPanelSync(const char* Content)
{
	if (!m_OptionSeries)
		return;
	if (0 == strcmp(Content, "Reset"))
	{
		//重置
		m_CheckList.WithoutChecked();
		m_TargetOpt = TARGET_NONE;
	}
	else
	{
		const char* pos = strstr(Content, "BackDirect");
		if (pos)
		{
			//买卖反向
			if (strcmp(&pos[11], m_OptionSeries->SeriesNo) != 0)
				return;
			m_CheckList.BackDirect();
		}
		else
		{
			pos = strstr(Content, "AddTarget");
			if (pos)
			{
				//增加标的
				const char* pos1 = strstr(&pos[10], m_OptionSeries->SeriesNo);
				if (pos1)
				{
					pos1 = strchr(pos1, '&');
					const char* pos2 = strstr(pos1, "B");
					if (pos2)
					{
						m_TargetOpt = TARGET_ADD_BUY;
					}
					else
					{
						pos2 = strstr(pos1, "S");
						if (pos2)
						{
							m_TargetOpt = TARGET_ADD_SELL;
						}
					}
				}

			}
			else
			{
				pos = strstr(Content, "DeleteTarget");
				if (pos)
				{
					//删除标的
					const char* pos1 = strstr(&pos[13], m_OptionSeries->SeriesNo);
					if (pos1)
					{
						m_TargetOpt = TARGET_DEL;
					}
				}
			}
		}
	}
	RefreshCheckListEable();
	FreshStrategyGraph();
	//ClickNoticeOrderPanel();
	m_pGride->Redraw(NULL);
}
void TOptionStrategy::CountKeyPrices()
{
	if (m_CheckedCont.ContractNum <= 0)
		return;
	//计算关键价位的pay的值
	m_KeyPrices.zeroNum = 0;
	//
	double prices[10];//关键价格数组
	int i = 0;
	for (i = 0; i < m_CheckedCont.ContractNum; i++)
	{
			prices[i + 1] = m_CheckedCont.operations[i].Strike;
	}
	//需要排序,由小到大
	int j = 1;
	for (j = 1; j < i; j++)
	{
		double min = prices[j];
		int pos = j;
		for (int m = j + 1; m < i + 1; m++)
		{
			if (prices[m] < min)
			{
				pos = m;
				min = prices[m];
				break;
			}
		}
		//交换
		double temp = prices[j];
		prices[j] = prices[pos];
		prices[pos] = temp;
	}
	//不依赖边界值
	//生成步长
	double step;
	if (m_OptionSeries->TargetContract->Commodity->PricePrec < 0)
		step = pow(10.0, -m_OptionSeries->TargetContract->Commodity->PricePrec);
	else
		step = pow(0.1, m_OptionSeries->TargetContract->Commodity->PricePrec);
	prices[0] = prices[1] - step * 100;
	prices[i + 1] = prices[i] + step * 100;

	double payoffs[10];//损益数组
	for (j = 0; j < i + 2; j++)
		payoffs[j] = CountProfitAndLos(prices[j]);

	//计算//////////////////////////
	for (j = 0; j < i + 1; j++)
	{
		//如果要有交点，那么相邻两个pay值的乘值必须小于等于0
		if (payoffs[j] == 0 && payoffs[j + 1] == 0)
		{
		}
		else if (payoffs[j] * payoffs[j + 1] <= 0)//在两边
		{
			double price = prices[j + 1] - ((prices[j + 1] - prices[j])*fabs(payoffs[j + 1])) / (fabs(payoffs[j + 1]) + fabs(payoffs[j]));
			m_KeyPrices.zeroPrices[m_KeyPrices.zeroNum++] = price;
		}
		else if (Round(payoffs[j] - payoffs[j + 1], m_OptionSeries->Commodity->PricePrec + 1) != 0)//在同一边
		{
			double price = (prices[j] * fabs(payoffs[j + 1]) - prices[j + 1] * fabs(payoffs[j])) / (fabs(payoffs[j + 1]) - fabs(payoffs[j]));
			if (j == 0 && price < prices[j + 1])//判断交点在哪个位置
				m_KeyPrices.zeroPrices[m_KeyPrices.zeroNum++] = price;
			if (j == i&&price > prices[j])
				m_KeyPrices.zeroPrices[m_KeyPrices.zeroNum++] = price;
			//
		}
	}
	//把在外面的过滤掉
	if (m_KeyPrices.zeroNum == 1 && m_KeyPrices.zeroPrices[0] <= 0)
	{
		m_KeyPrices.zeroNum = 0;
	}
	else if (m_KeyPrices.zeroNum == 2 && m_KeyPrices.zeroPrices[0] <= 0)
	{
		m_KeyPrices.zeroPrices[0] = m_KeyPrices.zeroPrices[1];
		m_KeyPrices.zeroNum = 1;
	}
}
double TOptionStrategy::CountProfitAndLos(double price)
{
	//计算价格对应的所有曲线的损益值
	double payoff = 0;
	for (int i = 0; i < m_CheckedCont.ContractNum; i++)
	{
		double pay = 0;
		struct ContractOperation opera = m_CheckedCont.operations[i];
		switch (opera.type)
		{
		case BUYFUTURE:
			pay = price  - opera.money;
			break;
		case SELLFUTURE:
			pay =  opera.money - price;
			break;
		case LONGCALL:
		{
			if (price < opera.Strike)
				pay = -opera.money;
			else
				pay = price - opera.Strike - opera.money;
		}
		break;
		case LONGPUT:
		{
			if (price < opera.Strike)
				pay = opera.Strike - opera.money - price;
			else
				pay = -opera.money;
		}
		break;
		case SHORTCALL:
		{
			if (price < opera.Strike)
				pay = opera.money;
			else
				pay = opera.Strike + opera.money - price;
		}
		break;
		case SHORTPUT:
		{
			if (price < opera.Strike)
				pay = price + opera.money - opera.Strike;
			else
				pay = opera.money;
		}
		break;
		default:
			break;
		}
		payoff += pay;
	}
	return payoff;
}
double TOptionStrategy::CounrCurrentProfitAndLos(double price)
{
	double payoff = 0;
	for (int i = 0; i < m_CheckedCont.ContractNum; i++)
	{
		SPriceType dTarget = 0;
		GetTargetNewPrice(dTarget);
		double pay = 0;
		struct ContractOperation opera = m_CheckedCont.operations[i];
		SOptionPriceRet retVal = { 0 }, retNew = { 0 };
		char strikePrice[25];
		sprintf_s(strikePrice, "%f", opera.Strike); 
		G_StarApi->CalcOptionPriceWithParam(m_OptionSeries->SeriesNo, strikePrice, price,0, 0, retVal);
		G_StarApi->CalcOptionPriceWithParam(m_OptionSeries->SeriesNo, strikePrice, dTarget, 0,  0, retNew);
		if (opera.type == LONGCALL || opera.type == SHORTCALL)
			pay = retVal.CallPrice - retNew.CallPrice;
		else
			pay = retVal.PutPrice - retNew.PutPrice;
		if (pay < 0.01&&pay>-0.01)
			pay = 0;
		payoff += pay;
	}
	return payoff* m_pContract->Commodity->TradeDot;
}
void TOptionStrategy::CalProfitLossData()
{
	if (m_CheckedCont.ContractNum <= 0)
		return;
	m_ProfitData.bValit = true;
	if (m_CheckedCont.ContractNum == 1)//1条
	{
		m_ProfitData.startPrice = m_CheckedCont.operations[0].Strike - m_CheckedCont.operations[0].money * 2;
		m_ProfitData.endPrice = m_CheckedCont.operations[0].Strike + m_CheckedCont.operations[0].money * 2;
	}
	else//多条
	{
		double maxPrice = 0;
		double minPrice = MAX_VALUE;//最大的double值,改为15次方
		double maxMoney = 0;
		for (int i = 0; i < m_CheckedCont.ContractNum; i++)
		{
			maxPrice = maxPrice > m_CheckedCont.operations[i].Strike ? maxPrice : m_CheckedCont.operations[i].Strike;
			minPrice = minPrice < m_CheckedCont.operations[i].Strike ? minPrice : m_CheckedCont.operations[i].Strike;
			maxMoney = maxMoney > m_CheckedCont.operations[i].money ? maxMoney : m_CheckedCont.operations[i].money;
		}
		double lastMax = maxPrice;
		double lastMin = minPrice;
		for (int i = 0; i < m_KeyPrices.zeroNum; i++)
		{
			maxPrice = maxPrice > m_KeyPrices.zeroPrices[i] ? maxPrice : m_KeyPrices.zeroPrices[i];
			minPrice = minPrice < m_KeyPrices.zeroPrices[i] ? minPrice : m_KeyPrices.zeroPrices[i];
		}
		//判断最大值和最小值是否相等，是不能相等的，否则不合适
		if (Round(maxPrice - minPrice, m_OptionSeries->TargetContract->Commodity->PricePrec + 1) == 0)
		{
			//计算maxMoney
			m_ProfitData.startPrice = m_CheckedCont.operations[0].Strike - maxMoney * 2;
			m_ProfitData.endPrice = m_CheckedCont.operations[0].Strike + maxMoney * 2;
		}
		else
		{
			//maxPrice和minPrice之间占1/2的大小
			m_ProfitData.startPrice = 2 * minPrice - maxPrice;//minPrice-(maxPrice-minPrice)*1.5;
			m_ProfitData.endPrice = 2 * maxPrice - minPrice;//maxPrice+(maxPrice-minPrice)*1.5;
		}
	}
	/////计算每个履约价位置的值，还有权利金的值
	double pays[16];//记录所有有意义的Pay的值
	int i = 0;
	for (i = 0; i < m_CheckedCont.ContractNum; i++)
	{
		//pays[i*2]=m_Graph.data.operations[i].money;
		pays[i] = CountProfitAndLos(m_CheckedCont.operations[i].Strike);
	}
	pays[i] = CountProfitAndLos(m_ProfitData.startPrice);
	pays[i + 1] = CountProfitAndLos(m_ProfitData.endPrice);
	///选择出来里面最大的pay,注意是绝对值
	double maxPay = 0;
	for (int j = 0; j < i + 2; j++)
		maxPay = maxPay > fabs(pays[j]) ? maxPay : fabs(pays[j]);
	double minPay = 0;
	for (int j = 0; j < i + 2; j++)
		minPay = minPay < pays[j] ? minPay : pays[j];
	//maxPay占9/10的距离
	m_ProfitData.maxMoney = maxPay * 10 / 9;
	m_ProfitData.minMoney = -maxPay * 10 / 9;
	if (m_ProfitData.startPrice < 0)
		m_ProfitData.startPrice = 0;
}
void TOptionStrategy::SetOptionSeries(SOptionSeries* pSeries)
{
	m_OptionSeries = pSeries;
	m_bInitCheck = false;
	m_nXueEndRow = 0;
	m_NormalData.bValid = false;
	m_ProfitData.bValit = false;
	m_CheckList.InitCheckRectData(m_OptionSeries->SeriesNo);
	UpdateXuShiValue();
}
bool TOptionStrategy::GetRoyalty(SPriceType& price)
{
	if (m_pContract)
	{
		if (m_pContract->SnapShot)
		{
			//先改成按最新价算
			SQuoteField* field = &m_pContract->SnapShot->Data[S_FID_LASTPRICE];
			if (S_FIDTYPE_NONE != field->FidAttr)
			{
				price = field->Price;
				return true;
			}
			/*if (m_type == TYPE_BUYCALLOTM || m_type == TYPE_BUYPUTOTM || m_type == TYPE_BUYCALLITM || m_type == TYPE_BUYPUTITM)
			{
				QQuoteField* field = &m_pContract->SnapShot->Data[FidMean_AskPrice_1];
				if (FidAttr_None != field->FidAttr)
				{
					price = field->Price;
					return true;
				}
			}
			if (m_type == TYPE_SELLCALLOTM || m_type == TYPE_SELLPUTOTM)
			{
				QQuoteField* field = &m_pContract->SnapShot->Data[FidMean_BidPrice_1];
				if (FidAttr_None != field->FidAttr)
				{
					price = field->Price;
					return true;
				}
			}*/
		}
	}
	return false;
}
bool TOptionStrategy::GetTargetNewPrice(SPriceType& price)
{
	if (m_OptionSeries&&m_OptionSeries->TargetContract)
	{
		SCommodity* comm(m_OptionSeries->TargetContract->Commodity);
		SQuoteSnapShot* q(m_OptionSeries->TargetContract->SnapShot);
		if (NULL != comm && NULL != q)
		{
			SQuoteField* field = &q->Data[S_FID_LASTPRICE];
			if (S_FIDTYPE_NONE != field->FidAttr)
			{
				price = field->Price;
				return true;
			}
		}
	}
	return false;
}
bool TOptionStrategy::GetTargetPrice(SPriceType& dPrice,bool bBuy)
{
	if (m_OptionSeries&&m_OptionSeries->TargetContract)
	{
		SCommodity* comm(m_OptionSeries->TargetContract->Commodity);
		SQuoteSnapShot* q(m_OptionSeries->TargetContract->SnapShot);
		if (NULL != comm && NULL != q)
		{
			SQuoteField* field = &q->Data[bBuy? S_FID_BESTASKPRICE : S_FID_BESTBIDPRICE];
			if (S_FIDTYPE_NONE != field->FidAttr)
			{
				dPrice = field->Price;
			}
			else
			{
				field = &q->Data[S_FID_LASTPRICE];
				if (S_FIDTYPE_NONE != field->FidAttr)
				{
					dPrice = field->Price;
				}
				else
				{
					field = &q->Data[S_FID_PRESETTLEPRICE];
					if (S_FIDTYPE_NONE != field->FidAttr)
					{
						dPrice = field->Price;
					}
				}
			}
		}
	}
	return false;
}
bool TOptionStrategy::GetTargetPreClosePrice(SPriceType& price)
{
	if (m_OptionSeries&&m_OptionSeries->TargetContract)
	{
		SCommodity* comm(m_OptionSeries->TargetContract->Commodity);
		SQuoteSnapShot* q(m_OptionSeries->TargetContract->SnapShot);
		if (NULL != comm && NULL != q)
		{
			SQuoteField* field = &q->Data[S_FID_PRECLOSINGPRICE];
			if (S_FIDTYPE_NONE != field->FidAttr)
			{
				price = field->Price;
				return true;
			}
		}
	}
	return false;
}

bool TOptionStrategy::GetContractLastPrice(SPriceType& price)
{
	if (m_pContract)
	{
		SQuoteSnapShot* q(m_pContract->SnapShot);
		if (NULL != q)
		{
			SQuoteField* field = &q->Data[S_FID_LASTPRICE];
			if (S_FIDTYPE_NONE != field->FidAttr)
			{
				price = field->Price;
				return true;
			}
		}
	}
	return false;
}
bool TOptionStrategy::GetIntrinsicValue(SPriceType& price)
{
	SPriceType dTarget = 0;
	if (!GetTargetNewPrice(dTarget))
		return false;
	SPriceType dStrikePrice = atof(m_StrikePrice) * m_pContract->Commodity->PriceMultiple;
	if (m_pGride&&!m_pGride->m_RowSelectRight)
		price = max(0, dTarget - dStrikePrice);
	else
		price = max(0, dStrikePrice - dTarget);
	return true;
}
//认购权证溢价率=（行权价+认购权证价格/行权比例-正股价）/正股价 
//认沽权证溢价率 = （正股价 + 认沽权证价格 / 行权比例 - 行权价） / 正股价
bool TOptionStrategy::GetPremiumRatio(SPriceType& price)
{
	SPriceType dTarget = 0;
	if (!GetTargetNewPrice(dTarget))
		return false;
	SPriceType dStrikePrice = atof(m_StrikePrice) * m_pContract->Commodity->PriceMultiple;
	SPriceType dLastPrice = 0;
	if(!GetContractLastPrice(dLastPrice)|| dTarget==0)
		return false;
	if (m_pGride && !m_pGride->m_RowSelectRight)
		price = abs((dStrikePrice + dLastPrice - dTarget)/ dTarget*100);
	else
		price = abs((dTarget + dLastPrice- dStrikePrice) / dTarget * 100);
	return true;
}
bool TOptionStrategy::GetGearing(SPriceType& price)
{
	SPriceType dLastPrice = 0;
	if (!GetContractLastPrice(dLastPrice))
		return false;
	SPriceType dTarget = 0;
	if (!GetTargetNewPrice(dTarget))
		return false;
	if (dLastPrice != 0)
		price = dTarget / dLastPrice;
	return true;
}
bool TOptionStrategy::GetBalancePrice(SPriceType& price)
{
	SPriceType dRoyPrice = 0;
	if (GetRoyalty(dRoyPrice))
	{
		SPriceType dStrikePrice = atof(m_StrikePrice) * m_pContract->Commodity->PriceMultiple;
		if (m_pGride && !m_pGride->m_RowSelectRight)
		{
			price = dStrikePrice + dRoyPrice;
			return true;
		}
		else
		{
			price = dStrikePrice - dRoyPrice;
			return true;
		}

	}
	return false;
}
void TOptionStrategy::PrepareRects(RECT& cr)
{
	if (!m_pGride)
		return;
	const int MARGIN = 30;
	m_Rects[STRATEGY_ITEM_RECT] = m_pGride->m_Rects[TGridControl::STRATEGY_ITEM];
	m_Rects[RIGHT_RECT] = m_pGride->m_Rects[TGridControl::TACTIC_GRAPH];
	RECT& rect_r = m_Rects[RIGHT_RECT];
	//计算左右上部区域
	RECT& r_top_r = m_Rects[RIGHT_TOP];
	r_top_r = rect_r;
	const int nMinHigth = 500;
	/*if ((rect_r.bottom - rect_r.top) * 2 / 3 <= nMinHigth)
	{*/
		r_top_r.bottom = nMinHigth;
	/*}
	else
	{
		r_top_r.bottom = (rect_r.bottom - rect_r.top) * 2 / 3;
	}*/
	RECT& top_Norm = m_Rects[RIGHT_NORMPLOT];
	top_Norm = r_top_r;
	top_Norm.bottom = top_Norm.top + (top_Norm.bottom - top_Norm.top) / 2;
	RECT& top_Pro = m_Rects[RIGHT_PROFITLOSE];
	top_Pro = r_top_r;
	top_Pro.top = top_Norm.bottom;
	RECT& r_bot_r = m_Rects[RBOTTOM_RECT];
	r_bot_r = rect_r;
	r_bot_r.top = r_top_r.bottom;
	//计算左右下部区域
	RECT& r_bot_l_r = m_Rects[RBOTTOM_LEFT];
	r_bot_l_r = rect_r;
	r_bot_l_r.top = r_top_r.bottom;
	r_bot_l_r.right = rect_r.left + (rect_r.right - rect_r.left - MARGIN) / 2;

	RECT& r_bot_r_r = m_Rects[RBOTTOM_RIGHT];
	r_bot_r_r = rect_r;
	r_bot_r_r.top = r_top_r.bottom;
	r_bot_r_r.left = rect_r.left + (rect_r.right - rect_r.left - MARGIN) / 2;
}
void TOptionStrategy::Draw_OptionStrategy(HDC hdc, RECT& wr, HDC mdc, RECT& cr)
{
	PrepareRects(cr);
	DrawTacticTypeSelect(hdc, wr, mdc, cr);
	DrawStrikePrice(hdc, wr, mdc, cr);
	if (m_pGride&&m_pGride->m_bStrategyGraphy)
	{
		const int MARGIN = 3;
		//绘制线条
		RECT r = m_Rects[RIGHT_RECT];
		SelectObject(mdc, PEN_FUTURE_TITLELINE);
		MoveToEx(mdc, r.left, r.top, 0);
		LineTo(mdc, r.left, r.bottom);

		RECT  rtop = m_Rects[RIGHT_TOP];
		//易出界，裁剪区域begin
		HRGN rgn = CreateRectRgnIndirect(&rtop);
		int retr = SelectClipRgn(mdc, rgn);
		DeleteObject(rgn);
		rtop.right -= MARGIN;
		////绘制顶部区域
		DrawTopRect(mdc, rtop);
		//恢复裁剪区域
		SelectClipRgn(mdc, NULL);
		SelectObject(mdc, PEN_KLINE_GRID_DOTLINE);
		MoveToEx(mdc, rtop.left, rtop.bottom, 0);
		LineTo(mdc, rtop.right, rtop.bottom);
		RECT  r_bot = m_Rects[RBOTTOM_RECT];
		DrawBenifitList(mdc, r_bot);
		BitBlt(hdc, wr.left + r.left, wr.top + r.top, r.right - r.left, r.bottom - r.top, mdc, r.left, r.top, SRCCOPY);
	}
}
void TOptionStrategy::DrawTacticTypeSelect(HDC hdc, RECT& wr, HDC mdc, RECT& cr)
{
	RECT r = m_Rects[STRATEGY_ITEM_RECT];
	SelectObject(mdc, PEN_FUTURE_TITLELINE);
	MoveToEx(mdc, r.left, r.bottom - 1, 0);
	LineTo(mdc, r.right, r.bottom - 1);
	SelectFont(mdc, FONT_FUTURE_TITLE);
	m_vMenuTactis.clear();
	//绘制按钮
	RECT rc = r;
	rc.right = r.left;
	for (size_t i = 0; i < m_vTactis.size(); i++)
	{
		Tactic& tactic = m_vTactis[i];
		GetTextExtentPoint(mdc, tactic.Name, wcslen(tactic.Name), &tactic.NameSize);
		if(tactic.ID == FREESTYLE)
			tactic.NameSize.cx += 10;
		else
		    tactic.NameSize.cx += 42;
		rc.left = rc.right;
		rc.right = rc.left + tactic.NameSize.cx;
		//超出界限不画
		if (rc.right > r.right - MENU_WIDTH)
		{
			m_vMenuTactis.push_back(tactic);
			continue;
		}
		SetTextColor(mdc, COLOR_FUTURE_STR);
		RECT rc_text = rc;
		rc_text.bottom -= 1;
		if (tactic.ID == m_TactisType.ID)
		{
			FillSolidRect(mdc, &rc_text, GetLigherColor(COLOR_FUTURE_BACKGROUND, COLOR_FUTURE_BACKGROUND==0 ? 50: -50));
		}
		if (tactic.ID == FREESTYLE)
			rc_text.left += 5;
		else
		    rc_text.left += 37;
		DrawText(mdc, tactic.Name, wcslen(tactic.Name), &rc_text, DT_VCENTER | DT_SINGLELINE | DT_VCENTER);
		DrawButtonIcon(tactic.ID, mdc, rc);
		SelectObject(mdc, PEN_PANEL_DOT_LINE);
		MoveToEx(mdc, rc.right, rc.top, 0);
		LineTo(mdc, rc.right, rc.bottom);
		if(!m_bRegToolTip&&i>0)
			AddRectTool(i, rc, (LPWSTR)G_LANG->LangText(TLI_BULLISH_TIP+i-1));
	}
	m_bRegToolTip = true;
	Draw_MenuBtn(mdc, r);
	BitBlt(hdc, wr.left + r.left, wr.top + r.top, r.right - r.left, r.bottom - r.top, mdc, r.left, r.top, SRCCOPY);
}
void TOptionStrategy::Draw_MenuBtn(HDC mdc, RECT& cr)
{
	//无弹出menu项，不画
	if (m_vMenuTactis.size() <= 0)
		return;

	SelectObject(mdc, PEN_PANEL_ARROW);

	RECT r;
	r = cr;
	r.left = r.right - MENU_WIDTH;

	r.top += 6;
	if (m_pGride)
		m_pGride->Draw_Arraw(mdc, r, D_DOWN);
	r.top -= 8;
	if (m_pGride)
		m_pGride->Draw_Arraw(mdc, r, D_DOWN);
}
void TOptionStrategy::DrawStrikePrice(HDC hdc, RECT& wr, HDC mdc, RECT& cr)
{
	RECT grid_content_middle_r(m_pGride->m_Rects[m_pGride->GRID_CONTENT_MIDDLE]);
	SelectObject(mdc, FONT_FUTURE_CONTENT);
	RECT r = grid_content_middle_r;
	if (r.left < 0 || r.right < 0 || r.right <= r.left)
		return;
	r.bottom = r.top;
	int nCheckWidth = 20;
	int nGap = 8;
	for (size_t ri = 0; ri < m_pGride->m_RowArrayCount; ri++)
	{
		int nBegin = m_pGride->m_RowBegin;
		r.left = grid_content_middle_r.left;
		r.right = grid_content_middle_r.right;
		r.top = r.bottom;
		r.bottom = r.top + m_pGride->ROW_HEIGHT;
		TGridRow& row = m_pGride->m_RowArray[ri];
		SetTextColor(mdc, COLOR_FUTURE_TITLE);
		DrawTextA(mdc, row.StrikePrice, strlen(row.StrikePrice), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
		if (m_pGride->m_bZCEUse)
		{
			r.left += 20;
			r.right -= 20;
			DrawTextA(mdc, " C ", strlen(" C "), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
			DrawTextA(mdc, " P ", strlen(" C "), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
		}
		else
		{
			TCheckRect& buyCallCheck = m_CheckList.GetAt(nBegin + ri, SHORTCALL);
			buyCallCheck.SetRect(r.left + nGap, r.top, r.left + nCheckWidth + nGap, r.bottom);
			buyCallCheck.Draw(mdc);
			TCheckRect& sellCallCheck = m_CheckList.GetAt(nBegin + ri, LONGCALL);
			sellCallCheck.SetRect(r.left + nCheckWidth + nGap, r.top, r.left + 2 * nCheckWidth + nGap, r.bottom);
			sellCallCheck.Draw(mdc);
			TCheckRect& sellPutCheck = m_CheckList.GetAt(nBegin + ri, LONGPUT);
			sellPutCheck.SetRect(r.right - 2 * nCheckWidth - nGap, r.top, r.right - nCheckWidth - nGap, r.bottom);
			sellPutCheck.Draw(mdc);
			TCheckRect& buyPutCheck = m_CheckList.GetAt(nBegin + ri, SHORTPUT);
			buyPutCheck.SetRect(r.right - nCheckWidth - nGap, r.top, r.right - nGap, r.bottom);
			buyPutCheck.Draw(mdc);
		}
	}
	BitBlt(hdc, wr.left + grid_content_middle_r.left, wr.top + grid_content_middle_r.top, grid_content_middle_r.right - grid_content_middle_r.left, grid_content_middle_r.bottom - grid_content_middle_r.top, mdc, grid_content_middle_r.left, grid_content_middle_r.top, SRCCOPY);
}
void TOptionStrategy::DrawButtonIcon(TACTICID id, HDC mdc, RECT& cr)
{
	POINT pt;
	pt.x = cr.left + 3;
	pt.y = cr.top + 3;
	switch (id)
	{
		//大涨
	case BUYCALL:
	{
		ImageList_Draw(m_hImageList, 0, mdc, pt.x, pt.y, ILD_NORMAL);
	}
	break;
	//不跌
	case SELLPUT:
	{
		ImageList_Draw(m_hImageList, 3, mdc, pt.x, pt.y, ILD_TRANSPARENT);
	}
	break;
	//大跌
	case BUYPUT:
	{
		ImageList_Draw(m_hImageList, 1, mdc, pt.x, pt.y, ILD_TRANSPARENT);
	}
	break;
	//不涨
	case SELLCALL:
	{
		ImageList_Draw(m_hImageList, 2, mdc, pt.x, pt.y, ILD_TRANSPARENT);
	}
	break;
	//突破
	case BUYSTRADDLE:
	{
		ImageList_Draw(m_hImageList, 4, mdc, pt.x, pt.y, ILD_TRANSPARENT);
	}
	break;
	//盘整
	case SELLSTRADDLE:
	{
		ImageList_Draw(m_hImageList, 5, mdc, pt.x, pt.y, ILD_TRANSPARENT);
	}
	break;
	//突破（宽）
	case BUYSTRANGLE:
	{
		ImageList_Draw(m_hImageList, 6, mdc, pt.x, pt.y, ILD_TRANSPARENT);
	}
	break;
	//盘整（宽）
	case SELLSTRANGLE:
	{
		ImageList_Draw(m_hImageList, 7, mdc, pt.x, pt.y, ILD_TRANSPARENT);
	}
	break;
	//温涨
	case BULLCALLSPREAD:
	{
		ImageList_Draw(m_hImageList, 8, mdc, pt.x, pt.y, ILD_TRANSPARENT);
	}
	break;
	//温跌
	case BEARPUTSPREAD:
	{
		ImageList_Draw(m_hImageList, 9, mdc, pt.x, pt.y, ILD_TRANSPARENT);
	}
	break;
	//温涨作庄
	case BULLPUTSPREAD:
	{
		ImageList_Draw(m_hImageList, 10, mdc, pt.x, pt.y, ILD_TRANSPARENT);
	}
	break;
	//温跌作庄
	case BEARCALLSPREAD:
	{
		ImageList_Draw(m_hImageList, 11, mdc, pt.x, pt.y, ILD_TRANSPARENT);
	}
	break;
	}
}
void TOptionStrategy::DrawTopRect(HDC mdc, RECT& cr)
{
	if (!m_pContract || !m_OptionSeries || !m_OptionSeries->TargetContract)
		return;
	RECT norml_r = m_Rects[RIGHT_NORMPLOT];
	DrawNormplot(mdc, norml_r);

	SelectObject(mdc, PEN_KLINE_GRID_DOTLINE);
	MoveToEx(mdc,norml_r.left, norml_r.bottom, 0);
	LineTo(mdc, norml_r.right, norml_r.bottom);

	//绘制图表
	RECT benifit_r = m_Rects[RIGHT_PROFITLOSE];
	DrawBenifitChart(mdc, benifit_r);
}
void TOptionStrategy::DrawNormplot(HDC mdc, RECT& cr)
{
	DrawNormBackground(mdc, cr);
	DrawProbabilityCurve(mdc, cr);
	DrawProbabilityCursorLine(mdc, cr);
}
void TOptionStrategy::DrawNormBackground(HDC mdc, RECT& cr)
{
	SetTextColor(mdc, COLOR_FUTURE_STR);
	RECT regionRect = cr;
	regionRect.left = cr.left + 10;
	regionRect.bottom = cr.bottom - 30;
	regionRect.right = cr.right - 10;
	SelectFont(mdc, FONT_FUTURE_TITLE);
	RECT titleRect = cr;
	SIZE size;
	::GetTextExtentPoint32(mdc, G_LANG->LangText(TLI_PROBABILITY), wcslen(G_LANG->LangText(TLI_PROBABILITY)), &size);
	titleRect.top = cr.top + 5;
	titleRect.left = cr.left + 15;
	titleRect.bottom = titleRect.top + size.cy;
	DrawText(mdc, G_LANG->LangText(TLI_PROBABILITY), wcslen(G_LANG->LangText(TLI_PROBABILITY)), &titleRect, DT_LEFT | DT_VCENTER);

	SelectObject(mdc, PEN_OPTION_STRIKE_LINE);
	int nXMark = 6;
	int nYMark = 4;
	//绘制坐标轴
	MoveToEx(mdc, regionRect.left, regionRect.top, 0);
	LineTo(mdc, regionRect.left, regionRect.bottom);
	MoveToEx(mdc, regionRect.left, regionRect.top, 0);
	LineTo(mdc, regionRect.left- nYMark, regionRect.top+ nXMark);
	MoveToEx(mdc, regionRect.left, regionRect.top, 0);
	LineTo(mdc, regionRect.left + nYMark, regionRect.top + nXMark);

	MoveToEx(mdc, regionRect.left, regionRect.bottom, 0);
	LineTo(mdc, cr.right, regionRect.bottom);
	MoveToEx(mdc, cr.right, regionRect.bottom, 0);
	LineTo(mdc, cr.right - nXMark, regionRect.bottom - nYMark);
	MoveToEx(mdc, cr.right, regionRect.bottom, 0);
	LineTo(mdc, cr.right - nXMark, regionRect.bottom + nYMark);
	//绘制刻度线
	RECT yAxisRect;
	wchar_t strText[101] = L"";
	FormatPrice(G_StarApi,m_NormalData.startPrice, m_OptionSeries->TargetContract->Commodity, strText, true);
	::GetTextExtentPoint32(mdc, strText, wcslen(strText), &size);
	yAxisRect.left = cr.left + 3;
	yAxisRect.right = cr.left + size.cx + 3;
	yAxisRect.top = regionRect.bottom + 6;
	yAxisRect.bottom = regionRect.bottom + size.cy + 6;
	DrawText(mdc, strText, wcslen(strText), &yAxisRect, DT_CENTER);
	MoveToEx(mdc, regionRect.left, regionRect.bottom, 0);
	LineTo(mdc, regionRect.left, regionRect.bottom + 4);
	int nSize = m_OptionSeries->TargetContract->Commodity->PriceDeno > 1 ? 2:4;
	int nWidth = (regionRect.right - regionRect.left) / nSize;
	double dPrice = (m_NormalData.endPrice - m_NormalData.startPrice) / nSize;
	for (int i = 1; i < nSize; i++)
	{
		FormatPrice(G_StarApi,m_NormalData.startPrice + i*dPrice, m_OptionSeries->TargetContract->Commodity, strText, true);
		::GetTextExtentPoint32(mdc, strText, wcslen(strText), &size);
		yAxisRect.left = regionRect.left + i*nWidth - size.cx / 2;
		yAxisRect.right = regionRect.left + i*nWidth + size.cx / 2;
		DrawText(mdc, strText, wcslen(strText), &yAxisRect, DT_CENTER);
		MoveToEx(mdc, regionRect.left + i*nWidth, regionRect.bottom, 0);
		LineTo(mdc, regionRect.left + i*nWidth, regionRect.bottom + 4);
	}

	FormatPrice(G_StarApi, m_NormalData.endPrice, m_OptionSeries->TargetContract->Commodity, strText, true);
	::GetTextExtentPoint32(mdc, strText, wcslen(strText), &size);
	yAxisRect.left = cr.right - size.cx - 3;
	yAxisRect.right = cr.right - 3;
	DrawText(mdc, strText, wcslen(strText), &yAxisRect, DT_CENTER);
	MoveToEx(mdc, regionRect.right, regionRect.bottom, 0);
	LineTo(mdc, regionRect.right, regionRect.bottom + 4);
}
void TOptionStrategy::DrawProbabilityCurve(HDC mdc, RECT& cr)
{
	RECT regionRect = cr;
	regionRect.left = cr.left + 11;
	regionRect.bottom = cr.bottom - 31;
	regionRect.right = cr.right - 11;
	double dx = (regionRect.right - regionRect.left)*1.0 / 200.0;
	int nHight = (regionRect.bottom - regionRect.top) - 15; //最高点高度
	if (m_NormalData.sigma == 0)
		return;
	double dy = nHight / Normal(m_NormalData.miu, m_NormalData.miu, m_NormalData.sigma);
	double dPrice = (m_NormalData.endPrice - m_NormalData.startPrice) / 200.0;
	SPriceType preClose;
	if (dPrice == 0 || !GetTargetPreClosePrice(preClose))
		return;
	int yFirstPos = regionRect.bottom -(long)( Normal(log(m_NormalData.startPrice / preClose), m_NormalData.miu, m_NormalData.sigma)*dy);
	POINT FirstPt, LastPt;
	LastPt.x = regionRect.left;
	LastPt.y = yFirstPos;
	std::vector<POINT> FirstReg;
	FirstPt.x = regionRect.left;
	FirstPt.y = regionRect.bottom;
	FirstReg.push_back(FirstPt);
	FirstReg.push_back(LastPt);
	for (int i = 1; i <= 200; i++)
	{
		LastPt.x = regionRect.left + dx*i;
		double dProfit = log((m_NormalData.startPrice + i*dPrice) / preClose);
		LastPt.y = regionRect.bottom - Normal(dProfit, m_NormalData.miu, m_NormalData.sigma)*dy;
		FirstReg.push_back(LastPt);
	}
	LastPt.x = regionRect.right;
	LastPt.y = regionRect.bottom;
	FirstReg.push_back(LastPt);
	COLORREF ColorUp = AlphaColor(COLOR_FUTURE_BACKGROUND, COLOR_FUTURE_UP, 100);
	COLORREF ColorDown = AlphaColor(COLOR_FUTURE_BACKGROUND, COLOR_FUTURE_DOWN, 100);
	SetBkMode(mdc, TRANSPARENT);
	//先分割数组
	std::vector<std::vector<POINT>> arrLine;
	std::vector<POINT> arrLast = FirstReg;
	std::vector<double> vecdPricent;
	double dCurPricent = 0.0;
	for (int i = 0; i < m_KeyPrices.zeroNum; i++)
	{
		std::vector<POINT> arrFirst,arrSecond;
		POINT zeroPnt,tmpPnt;
		zeroPnt.x = regionRect.left + ((m_KeyPrices.zeroPrices[i] - m_NormalData.startPrice) / (m_NormalData.endPrice - m_NormalData.startPrice))*(regionRect.right - regionRect.left);
		double dProfit = log(m_KeyPrices.zeroPrices[i] / preClose);
		zeroPnt.y = regionRect.bottom - Normal(dProfit, m_NormalData.miu, m_NormalData.sigma)*dy;
		tmpPnt.x = zeroPnt.x;
		tmpPnt.y = regionRect.bottom;
		arrSecond.push_back(tmpPnt);
		arrSecond.push_back(zeroPnt);
		//用平衡点分割点组
		for (size_t i = 0; i < arrLast.size(); i++)
		{
			if (arrLast[i].x < zeroPnt.x)
				arrFirst.push_back(arrLast[i]);
			else
				arrSecond.push_back(arrLast[i]);
		}
		arrFirst.push_back(zeroPnt);
		arrFirst.push_back(tmpPnt);
		arrFirst.push_back(arrLast[0]);
		arrLast = arrSecond;
		arrLine.push_back(arrFirst);
		//计算百分比
		dProfit = (log(m_KeyPrices.zeroPrices[i] / preClose) - m_NormalData.miu) / m_NormalData.sigma;
		dCurPricent = NormSDist(dProfit);
		double dLastPricent = 0.0;
		if (i >= 1)
		{
			double dlastProfit = (log(m_KeyPrices.zeroPrices[i-1] / preClose) - m_NormalData.miu) / m_NormalData.sigma;
			dLastPricent = NormSDist(dlastProfit);
		}
		vecdPricent.push_back(dCurPricent - dLastPricent);
		
	}
	arrLine.push_back(arrLast);
	vecdPricent.push_back(1.0- dCurPricent);
	//然后绘图
	for (size_t i = 0; i < arrLine.size(); i++)
	{
		HRGN Rgn = CreatePolygonRgn(arrLine[i].data(), arrLine[i].size(), ALTERNATE);
		if ((CountProfitAndLos(m_ProfitData.startPrice) >= 0&&i%2==0)|| (CountProfitAndLos(m_ProfitData.startPrice) < 0 && i % 2 == 1))
		{
			HBRUSH hBrushUp = CreateSolidBrush(ColorUp);
			FillRgn(mdc, Rgn, hBrushUp);
			DeleteObject(hBrushUp);
		}
		else
		{
			HBRUSH hBrushDown = CreateSolidBrush(ColorDown);
			FillRgn(mdc, Rgn, hBrushDown);
			DeleteObject(hBrushDown);
		}
		DeleteObject(Rgn);
	}
	//最后绘制百分比
	for (size_t i = 0; i < arrLine.size(); i++)
	{
		if ((CountProfitAndLos(m_ProfitData.startPrice) >= 0 && i % 2 == 0) || (CountProfitAndLos(m_ProfitData.startPrice) < 0 && i % 2 == 1))
			SetTextColor(mdc, COLOR_FUTURE_UP);
		else
			SetTextColor(mdc, COLOR_FUTURE_DOWN);
			
		//绘制百分比
		wchar_t strPrisent[101];
		swprintf_s(strPrisent, L"%.2f%%", vecdPricent[i] * 100);
		//计算出绘制位置
		RECT RcPri;
		SIZE size;
		::GetTextExtentPoint32(mdc, strPrisent, wcslen(strPrisent), &size);
		int nXPos = 0;
		if (m_KeyPrices.zeroNum == 0)
		{
			double dMidPrice = preClose*exp(m_NormalData.miu);
			nXPos = regionRect.left + (int)(((dMidPrice - m_NormalData.startPrice) / (m_NormalData.endPrice - m_NormalData.startPrice))*(regionRect.right - regionRect.left));
		}
		else
		{
			int nSize = arrLine[i].size();
			if (nSize > 3)
			{
				if (i == arrLine.size() - 1)
				{
					POINT zeroPntpoint = arrLine[i][1];
					nXPos = zeroPntpoint.x + size.cx / 2;
					nHight = regionRect.bottom - zeroPntpoint.y;
				}
				else if (i % 2 == 0)
				{
					POINT zeroPntpoint = arrLine[i][nSize - 3];
					nXPos = zeroPntpoint.x - size.cx / 2;
					nHight = regionRect.bottom - zeroPntpoint.y;
				}
				else
				{
					POINT zeroPntpoint = arrLine[i][nSize - 3];
					nXPos = zeroPntpoint.x;
					nHight = regionRect.bottom - zeroPntpoint.y - size.cx;
				}

			}
		}
		RcPri.left = nXPos - size.cx / 2;
		RcPri.right = nXPos + size.cx / 2;
		RcPri.top = regionRect.bottom - (nHight + size.cy) / 2;
		RcPri.bottom = regionRect.bottom - (nHight - size.cy) / 2;
		DrawText(mdc, strPrisent, wcslen(strPrisent), &RcPri, DT_CENTER | DT_VCENTER);
	}
}
void TOptionStrategy::DrawProbabilityCursorLine(HDC mdc, RECT& cr)
{
	RECT regionRect = cr;
	regionRect.left = cr.left + 10;
	regionRect.bottom = cr.bottom - 30;
	regionRect.right = cr.right - 10;
	RECT benifit_r = m_Rects[RIGHT_PROFITLOSE];
	benifit_r.left = benifit_r.left + 10;
	benifit_r.bottom = benifit_r.bottom - 30;
	benifit_r.right = benifit_r.right - 10;
	if (PtInRect(&regionRect,m_point)|| PtInRect(&benifit_r, m_point))
	{
		double dPrice = (m_NormalData.endPrice - m_NormalData.startPrice) / 200.0;
		SPriceType preClose;
		if (dPrice == 0 || !GetTargetPreClosePrice(preClose))
			return;
		COLORREF myColor = RGB(197, 197, 197);
		HPEN LinePen = CreatePen(PS_SOLID, 1, myColor);
		SelectObject(mdc, LinePen);
		MoveToEx(mdc, m_point.x, regionRect.top, 0);
		LineTo(mdc, m_point.x, regionRect.bottom);
		DeletePen(LinePen);
		double dPricent = GetProbability(m_CurrentPrice);
		if (dPricent == -1)
			return;
		SetBkMode(mdc,TRANSPARENT);
		//设置字体颜色
		if (CountProfitAndLos(m_ProfitData.startPrice) >= 0)
			SetTextColor(mdc, COLOR_FUTURE_UP);
		else
			SetTextColor(mdc, COLOR_FUTURE_DOWN);
		wchar_t strText[101] = L"";
		swprintf_s(strText, L"%.2f%% ", dPricent * 100);
		SIZE size;
		::GetTextExtentPoint32(mdc, strText, wcslen(strText), &size);
		RECT textRect;
		textRect.top = regionRect.top;
		textRect.left = m_point.x - size.cx;
		textRect.right = m_point.x;
		textRect.bottom = regionRect.top + size.cy;
		DrawText(mdc, strText, wcslen(strText), &textRect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
		if (CountProfitAndLos(m_ProfitData.startPrice) >= 0)
			SetTextColor(mdc, COLOR_FUTURE_DOWN);
		else
			SetTextColor(mdc, COLOR_FUTURE_UP);
		swprintf_s(strText, L"%.2f%% ", (1 - dPricent) * 100);
		::GetTextExtentPoint32(mdc, strText, wcslen(strText), &size);
		textRect.left = m_point.x+4;
		textRect.right = m_point.x + size.cx+4;
		DrawText(mdc, strText, wcslen(strText), &textRect, DT_CENTER | DT_VCENTER| DT_SINGLELINE);
		SetTextColor(mdc, COLOR_FUTURE_STR);
	    FormatPrice(G_StarApi,m_CurrentPrice, m_OptionSeries->TargetContract->Commodity, strText, true);
		::GetTextExtentPoint32(mdc, strText, wcslen(strText), &size);
		textRect.top = regionRect.bottom - size.cy;
		textRect.bottom = regionRect.bottom;
		textRect.left = m_point.x + 4;
		textRect.right = m_point.x + size.cx +4;
		DrawText(mdc, strText, wcslen(strText), &textRect, DT_CENTER);
	}
}
void TOptionStrategy::DrawBenifitChart(HDC mdc, RECT& cr)
{
	DrawBenifitBackground(mdc, cr);
	DrawBenifitCurve(mdc, cr);
	DrswBenifitCursorLine(mdc, cr);
}
void TOptionStrategy::DrawBenifitBackground(HDC mdc, RECT& cr)
{
	SetTextColor(mdc, COLOR_FUTURE_STR);
	RECT regionRect = cr;
	regionRect.left = cr.left + 10;
	regionRect.bottom = cr.bottom - 30;
	regionRect.right = cr.right - 10;
	SelectFont(mdc, FONT_FUTURE_TITLE);
	RECT titleRect = cr;
	SIZE size;
	::GetTextExtentPoint32(mdc, G_LANG->LangText(TLI_PROFITANDLOSS), wcslen(G_LANG->LangText(TLI_PROFITANDLOSS)), &size);
	titleRect.top = cr.top + 5;
	titleRect.left = cr.left + 15;
	titleRect.right = titleRect.left + size.cx;
	titleRect.bottom = titleRect.top + size.cy;
	DrawText(mdc, G_LANG->LangText(TLI_PROFITANDLOSS), wcslen(G_LANG->LangText(TLI_PROFITANDLOSS)), &titleRect, DT_LEFT | DT_VCENTER);
	wchar_t targetTxt[51] = L"\0";
	if (m_TargetOpt == TARGET_ADD_BUY)
	{
		wcscpy_s(targetTxt, G_LANG->LangText(TLI_INCLUDEBUYTARGET));
		SetTextColor(mdc, COLOR_FUTURE_UP);
	}
	else if (m_TargetOpt == TARGET_ADD_SELL)
	{
		wcscpy_s(targetTxt, G_LANG->LangText(TLI_INCLUDESELLTARGET));
		SetTextColor(mdc, COLOR_FUTURE_DOWN);
	}
	SelectFont(mdc, FONT_PANEL_TEXT);
	RECT targetRect = titleRect;
	targetRect.left = titleRect.right;
	targetRect.right = cr.right;
	DrawText(mdc, targetTxt, wcslen(targetTxt), &targetRect, DT_LEFT | DT_SINGLELINE | DT_BOTTOM);

	SetTextColor(mdc, COLOR_FUTURE_STR);
	SelectFont(mdc, FONT_FUTURE_TITLE);
	SelectObject(mdc, PEN_OPTION_STRIKE_LINE);
	int nXMark = 6;
	int nYMark = 4;
	//绘制坐标轴
	MoveToEx(mdc, regionRect.left, regionRect.top, 0);
	LineTo(mdc, regionRect.left, regionRect.bottom);
	MoveToEx(mdc, regionRect.left, regionRect.top, 0);
	LineTo(mdc, regionRect.left - nYMark, regionRect.top + nXMark);
	MoveToEx(mdc, regionRect.left, regionRect.top, 0);
	LineTo(mdc, regionRect.left + nYMark, regionRect.top + nXMark);

	MoveToEx(mdc, regionRect.left, regionRect.bottom, 0);
	LineTo(mdc, cr.right, regionRect.bottom);
	MoveToEx(mdc, cr.right, regionRect.bottom, 0);
	LineTo(mdc, cr.right - nXMark, regionRect.bottom - nYMark);
	MoveToEx(mdc, cr.right, regionRect.bottom, 0);
	LineTo(mdc, cr.right - nXMark, regionRect.bottom + nYMark);

	::GetTextExtentPoint32(mdc, L"0", wcslen(L"0"), &size);
	RECT xRect;
	xRect.left = cr.left + 2;
	xRect.top = regionRect.top + (regionRect.bottom - regionRect.top - size.cy) / 2;
	xRect.right = regionRect.left;
	xRect.bottom = regionRect.top + (regionRect.bottom - regionRect.top + size.cy) / 2;
	DrawText(mdc, L"0", wcslen(L"0"), &xRect, DT_CENTER);
	RECT yAxisRect;
	//绘制刻度线
	wchar_t strText[101] = L"";
	FormatPrice(G_StarApi, m_ProfitData.startPrice, m_OptionSeries->TargetContract->Commodity, strText, true);
	::GetTextExtentPoint32(mdc, strText, wcslen(strText), &size);
	yAxisRect.left = cr.left + 3;
	yAxisRect.right = cr.left + size.cx + 3;
	yAxisRect.top = regionRect.bottom + 6;
	yAxisRect.bottom = regionRect.bottom + size.cy + 6;
	DrawText(mdc, strText, wcslen(strText), &yAxisRect, DT_CENTER);
	MoveToEx(mdc, regionRect.left, regionRect.bottom, 0);
	LineTo(mdc, regionRect.left, regionRect.bottom + 4);

	int nSize = m_OptionSeries->TargetContract->Commodity->PriceDeno > 1 ? 2 : 4;
	int nWidth = (regionRect.right - regionRect.left) / nSize;
	double dPrice = (m_ProfitData.endPrice - m_ProfitData.startPrice) / nSize;
	for (int i = 1; i < nSize; i++)
	{
		FormatPrice(G_StarApi, m_NormalData.startPrice + i*dPrice, m_OptionSeries->TargetContract->Commodity, strText, true);
		::GetTextExtentPoint32(mdc, strText, wcslen(strText), &size);
		yAxisRect.left = regionRect.left + i*nWidth - size.cx / 2;
		yAxisRect.right = regionRect.left + i*nWidth + size.cx / 2;
		DrawText(mdc, strText, wcslen(strText), &yAxisRect, DT_CENTER);
		MoveToEx(mdc, regionRect.left + i*nWidth, regionRect.bottom, 0);
		LineTo(mdc, regionRect.left + i*nWidth, regionRect.bottom + 4);
	}
	FormatPrice(G_StarApi, m_ProfitData.endPrice, m_OptionSeries->TargetContract->Commodity, strText, true);
	::GetTextExtentPoint32(mdc, strText, wcslen(strText), &size);
	yAxisRect.left = cr.right - size.cx - 3;
	yAxisRect.right = cr.right - 3;
	DrawText(mdc, strText, wcslen(strText), &yAxisRect, DT_CENTER);
	MoveToEx(mdc, regionRect.right, regionRect.bottom, 0);
	LineTo(mdc, regionRect.right, regionRect.bottom + 4);
}
void TOptionStrategy::DrawBenifitCurve(HDC mdc, RECT& cr)
{
	if (m_CheckedCont.ContractNum <= 0)
		return;
	RECT regionRect = cr;
	regionRect.left = cr.left + 11;
	regionRect.bottom = cr.bottom - 31;
	regionRect.right = cr.right - 11;
	//绘制提示信息
	if (m_CheckedCont.ErrorInfo[0] != '/0')
	{
		//写字
		SetBkMode(mdc,TRANSPARENT);
		//计算位置(正确)
		RECT msgRect;
		SIZE size;
		::GetTextExtentPoint32(mdc, m_CheckedCont.ErrorInfo, wcslen(m_CheckedCont.ErrorInfo), &size);
		msgRect.left = regionRect.left;
		msgRect.right = regionRect.right;
		msgRect.top = (regionRect.top + regionRect.bottom) / 2 - size.cy / 2;
		msgRect.bottom = (regionRect.top + regionRect.bottom) / 2 + size.cy / 2;
		DrawText(mdc, m_CheckedCont.ErrorInfo, wcslen(m_CheckedCont.ErrorInfo), &msgRect, DT_CENTER);
		return;
	}
	//计算出来price对应的位置,因为这时候缩放的比例已经确定了
	for (int i = 0; i < m_KeyPrices.zeroNum; i++)
		m_KeyPrices.zeroPos[i] = (int)(((m_KeyPrices.zeroPrices[i] - m_ProfitData.startPrice) / (m_ProfitData.endPrice - m_ProfitData.startPrice))*(regionRect.right - regionRect.left) + regionRect.left);
	SetBkMode(mdc, TRANSPARENT);
	//绘制最终曲线，只有到期货执行价格时曲线才会发生变化，所以要找出执行价时的点，然后根据起始点和结束点进行绘制
	double payoff = CountProfitAndLos(m_ProfitData.startPrice);
	if (m_ProfitData.maxMoney == m_ProfitData.minMoney)
		return;
	std::vector<POINT> arrPts; //保存线上的所有点
	POINT left, right, first, end;
	left.x = regionRect.left;
	left.y = (int)Round(((m_ProfitData.maxMoney - payoff) / (m_ProfitData.maxMoney - m_ProfitData.minMoney))*(regionRect.bottom - regionRect.top) + regionRect.top, 0);
	right.x = regionRect.right;
	payoff = CountProfitAndLos(m_ProfitData.endPrice);
	right.y = (int)Round(((m_ProfitData.maxMoney - payoff) / (m_ProfitData.maxMoney - m_ProfitData.minMoney))*(regionRect.bottom - regionRect.top) + regionRect.top, 0);
	double prices[10];//关键价格数组
	int i = 0;
	for (i = 0; i < m_CheckedCont.ContractNum; i++)
		prices[i] = m_CheckedCont.operations[i].Strike;
	first.x = regionRect.left;
	first.y = regionRect.top + (regionRect.bottom - regionRect.top) / 2;
	arrPts.push_back(first);
	arrPts.push_back(left);
	//需要排序,由小到大
	int j = 0;
	for (j = 0; j < i; j++)
	{
		if (i == 1)
			break;
		double min = prices[j];
		int pos = j;
		for (int m = j + 1; m < i; m++)
		{
			if (prices[m] < min)
			{
				pos = m;
				min = prices[m];
				break;
			}
		}
		//交换
		double temp = prices[j];
		prices[j] = prices[pos];
		prices[pos] = temp;
	}
	for (j = 0; j < i; j++)
	{
		POINT NextPnt, NowPnt;
		NowPnt.x = (long)(regionRect.left + (regionRect.right - regionRect.left)*((prices[j] - m_ProfitData.startPrice) / (m_ProfitData.endPrice - m_ProfitData.startPrice)));
		payoff = CountProfitAndLos(prices[j]);
		NowPnt.y = (int)Round(((m_ProfitData.maxMoney - payoff) / (m_ProfitData.maxMoney - m_ProfitData.minMoney))*(regionRect.bottom - regionRect.top) + regionRect.top, 0);
		if (j + 1 < i)
		{
			NextPnt.x = (long)(regionRect.left + (regionRect.right - regionRect.left)*((prices[j + 1] - m_ProfitData.startPrice) / (m_ProfitData.endPrice - m_ProfitData.startPrice)));
			payoff = CountProfitAndLos(prices[j + 1]);
			NextPnt.y = (int)Round(((m_ProfitData.maxMoney - payoff) / (m_ProfitData.maxMoney - m_ProfitData.minMoney))*(regionRect.bottom - regionRect.top) + regionRect.top, 0);
		}
		arrPts.push_back(NowPnt);
	}
	arrPts.push_back(right);
	end.x = regionRect.right;
	end.y = regionRect.top + (regionRect.bottom - regionRect.top) / 2;
	arrPts.push_back(end);
	COLORREF ColorUp = AlphaColor(COLOR_FUTURE_BACKGROUND, COLOR_FUTURE_UP, 100);
	COLORREF ColorDown = AlphaColor(COLOR_FUTURE_BACKGROUND, COLOR_FUTURE_DOWN, 100);
	//先分割数组
	std::vector<std::vector<POINT>> arrLine;
	std::vector<POINT> arrLast = arrPts;
	for (int i = 0; i < m_KeyPrices.zeroNum; i++)
	{
		std::vector<POINT> arrFirst, arrSecond;
		POINT zeroPnt;
		zeroPnt.x = m_KeyPrices.zeroPos[i];
		zeroPnt.y = regionRect.top + (regionRect.bottom - regionRect.top) / 2;
		arrSecond.push_back(zeroPnt);
		//用平衡点分割点组
		for (size_t i = 0; i < arrLast.size(); i++)
		{
			if (arrLast[i].x < zeroPnt.x)
				arrFirst.push_back(arrLast[i]);
			else
				arrSecond.push_back(arrLast[i]);
		}
		if (!arrFirst.empty())
			arrFirst.push_back(zeroPnt);
		arrLast = arrSecond;
		arrLine.push_back(arrFirst);
	}
	arrLine.push_back(arrLast);
	//然后绘图
	for (size_t i = 0; i < arrLine.size(); i++)
	{
		HRGN Rgn = CreatePolygonRgn(arrLine[i].data(), arrLine[i].size(), ALTERNATE);
		if ((CountProfitAndLos(m_ProfitData.startPrice) >= 0 && i % 2 == 0) || (CountProfitAndLos(m_ProfitData.startPrice) < 0 && i % 2 == 1))
		{
			HBRUSH hBrushUp = CreateSolidBrush(ColorUp);
			FillRgn(mdc, Rgn, hBrushUp);
			DeleteObject(hBrushUp);
		}
		else
		{
			HBRUSH hBrushDown = CreateSolidBrush(ColorDown);
			FillRgn(mdc, Rgn, hBrushDown);
			DeleteObject(hBrushDown);
		}
		DeleteObject(Rgn);
	}
	//绘制绘制损益平衡的点/////////////////
	for (int i = 0; i < m_KeyPrices.zeroNum; i++)
	{
		//绘制
		wchar_t text[101] = L"";
		FormatPrice(G_StarApi, m_KeyPrices.zeroPrices[i], m_OptionSeries->TargetContract->Commodity, text, true);
		SIZE size;
		::GetTextExtentPoint32(mdc, text, wcslen(text), &size);
		RECT textRect;
		textRect.left = m_KeyPrices.zeroPos[i];
		textRect.right = m_KeyPrices.zeroPos[i] + size.cx;
		//这里我还要根据线的斜率，计算出来画上面还是下面的问题
		double step;
		if (m_OptionSeries->TargetContract->Commodity->PricePrec < 0)
			step = pow(10.0, -m_OptionSeries->TargetContract->Commodity->PricePrec);
		else
			step = pow(0.1, m_OptionSeries->TargetContract->Commodity->PricePrec);

		double lastPrice = m_KeyPrices.zeroPrices[i] - step;
		double nextPrice = m_KeyPrices.zeroPrices[i] + step;
		if (CountProfitAndLos(lastPrice) < CountProfitAndLos(nextPrice))
		{
			textRect.top = (regionRect.top + regionRect.bottom) / 2;
			textRect.bottom = textRect.top + size.cy;
		}
		else
		{
			textRect.bottom = (regionRect.top + regionRect.bottom) / 2;
			textRect.top = textRect.bottom - size.cy;
		}

		DrawText(mdc, text, wcslen(text), &textRect, DT_LEFT);
	}
}
void TOptionStrategy::DrswBenifitCursorLine(HDC mdc, RECT& cr)
{
	RECT regionRect = cr;
	regionRect.left = cr.left + 10;
	regionRect.bottom = cr.bottom - 30;
	regionRect.right = cr.right - 10;
	RECT norml_r = m_Rects[RIGHT_NORMPLOT];
	norml_r.left = norml_r.left + 10;
	norml_r.bottom = norml_r.bottom - 30;
	norml_r.right = norml_r.right - 10;
	if (PtInRect(&regionRect, m_point)|| PtInRect(&norml_r, m_point))
	{
		SetTextColor(mdc, COLOR_FUTURE_STR);
		COLORREF myColor = RGB(197, 197, 197);
		HPEN LinePen = CreatePen(PS_SOLID, 1, myColor);
		SelectObject(mdc, LinePen);
		MoveToEx(mdc, m_point.x, regionRect.top, 0);
		LineTo(mdc, m_point.x, regionRect.bottom);
		DeletePen(LinePen);
		RECT textRect;
		wchar_t strText[101] = L"";
		FormatPrice(G_StarApi, m_CurrentPrice, m_OptionSeries->TargetContract->Commodity, strText, true);
		SIZE size;
		::GetTextExtentPoint32(mdc, strText, wcslen(strText), &size);
		textRect.top = regionRect.bottom - size.cy;
		textRect.bottom = regionRect.bottom;
		textRect.left = m_point.x + 4;
		textRect.right = m_point.x + size.cx + 4;
		DrawText(mdc, strText, wcslen(strText), &textRect, DT_CENTER);
		int y = (int)Round(((m_ProfitData.maxMoney - m_CurrentPayoff) / (m_ProfitData.maxMoney - m_ProfitData.minMoney))*(regionRect.bottom - regionRect.top) + regionRect.top, 0);
		if (y > regionRect.top&&y < regionRect.bottom)
		{
			MoveToEx(mdc, regionRect.left,y, 0);
			LineTo(mdc, regionRect.right,y);
		}

		FormatPrice(G_StarApi, m_CurrentPayoff, m_OptionSeries->TargetContract->Commodity, strText, true);
		::GetTextExtentPoint32(mdc, strText, wcslen(strText), &size);
		textRect.left = regionRect.left;
		textRect.right = regionRect.left + size.cx;
		textRect.top = y - size.cy;
		textRect.bottom = y;
		DrawText(mdc, strText, wcslen(strText), &textRect, DT_CENTER);
	}
}
void TOptionStrategy::DrawBottomLeft(HDC mdc, RECT& cr)
{
	if (!m_pContract||!m_OptionSeries)
		return;
	const int ROWHIGHT = 20;
	const int MARGIN = 5;
	SelectObject(mdc, FONT_FUTURE_TITLE);
	SetTextColor(mdc, COLOR_FUTURE_STR);
	//绘制名称
	RECT rc_name = cr;
	rc_name.left = cr.left + MARGIN;
	rc_name.right = cr.left + (cr.right - cr.left) / 2;
	rc_name.bottom = rc_name.top + ROWHIGHT;
	DrawText(mdc, G_LANG->LangText(TLI_TIMEVALUE), wcslen(G_LANG->LangText(TLI_TIMEVALUE)), &rc_name, DT_LEFT | DT_SINGLELINE | DT_BOTTOM);

	rc_name.top = rc_name.bottom;
	rc_name.bottom = rc_name.top + ROWHIGHT;
	DrawText(mdc, G_LANG->LangText(TLI_LEVERAGERATIO), wcslen(G_LANG->LangText(TLI_LEVERAGERATIO)), &rc_name, DT_LEFT | DT_SINGLELINE | DT_BOTTOM);

	rc_name.top = rc_name.bottom;
	rc_name.bottom = rc_name.top + ROWHIGHT;
	DrawText(mdc, G_LANG->LangText(TLI_IMPLIEDVOLIATILITY), wcslen(G_LANG->LangText(TLI_IMPLIEDVOLIATILITY)), &rc_name, DT_LEFT | DT_SINGLELINE | DT_BOTTOM);

	rc_name.top = rc_name.bottom;
	rc_name.bottom = rc_name.top + ROWHIGHT;
	DrawText(mdc, G_LANG->LangText(TLI_THEORETICALPRICE), wcslen(G_LANG->LangText(TLI_THEORETICALPRICE)), &rc_name, DT_LEFT | DT_SINGLELINE | DT_BOTTOM);

	rc_name.top = rc_name.bottom;
	rc_name.bottom = rc_name.top + ROWHIGHT;
	DrawText(mdc, L"Gamma", wcslen(L"Gamma"), &rc_name, DT_LEFT | DT_SINGLELINE | DT_BOTTOM);

	rc_name.top = rc_name.bottom;
	rc_name.bottom = rc_name.top + ROWHIGHT;
	DrawText(mdc, L"Vega", wcslen(L"Vega"), &rc_name, DT_LEFT | DT_SINGLELINE | DT_BOTTOM);

	rc_name.top = rc_name.bottom;
	rc_name.bottom = rc_name.top + ROWHIGHT;
	DrawText(mdc, G_LANG->LangText(TLI_EXERCISEDATE), wcslen(G_LANG->LangText(TLI_EXERCISEDATE)), &rc_name, DT_LEFT | DT_SINGLELINE | DT_BOTTOM);

	rc_name.top = rc_name.bottom;
	rc_name.bottom = rc_name.top + ROWHIGHT;
	DrawText(mdc, G_LANG->LangText(TLI_LASTTRADINGDATE), wcslen(G_LANG->LangText(TLI_LASTTRADINGDATE)), &rc_name, DT_LEFT | DT_SINGLELINE | DT_BOTTOM);

	rc_name.top = rc_name.bottom;
	rc_name.bottom = rc_name.top + ROWHIGHT;
	DrawText(mdc, G_LANG->LangText(TLI_OPTIONTYPE), wcslen(G_LANG->LangText(TLI_OPTIONTYPE)), &rc_name, DT_LEFT | DT_SINGLELINE | DT_BOTTOM);

	//绘制数据
	SetTextColor(mdc, COLOR_FUTURE_STR);
	RECT rc_data = cr;
	rc_data.left = cr.left + (cr.right - cr.left) / 2;
	rc_data.right = cr.right - MARGIN;
	rc_data.bottom = rc_data.top + ROWHIGHT;
	wchar_t strText[101] = L"";
	SPriceType dLastPrice = 0;
	GetContractLastPrice(dLastPrice);
	SPriceType dIntrValue = 0;
	GetIntrinsicValue(dIntrValue);
	FormatPrice(G_StarApi, dLastPrice - dIntrValue, m_pContract->Commodity, strText, true);
	DrawText(mdc, strText, wcslen(strText), &rc_data, DT_RIGHT | DT_SINGLELINE | DT_BOTTOM);

	rc_data.top = rc_data.bottom;
	rc_data.bottom = rc_data.top + ROWHIGHT;
	SPriceType dRadio = 0;
	GetGearing(dRadio);
	swprintf_s(strText, L"%.2f", dRadio);
	DrawText(mdc, strText, wcslen(strText), &rc_data, DT_RIGHT | DT_SINGLELINE | DT_BOTTOM);

	rc_data.top = rc_data.bottom;
	rc_data.bottom = rc_data.top + ROWHIGHT;
	if (m_fIV > 100000000 || m_fIV < -100000000)
		wcscpy_s(strText, L"N/A");
	else
		swprintf_s(strText, L"%.2f%%", m_fIV * 100);
	DrawText(mdc, strText, wcslen(strText), &rc_data, DT_RIGHT | DT_SINGLELINE | DT_BOTTOM);

	rc_data.top = rc_data.bottom;
	rc_data.bottom = rc_data.top + ROWHIGHT;
	wchar_t s_format[21] = { 0 };
	swprintf_s(s_format, L"%%.%df", m_pContract->Commodity->PricePrec);
	swprintf_s(strText, s_format, m_fPrice);
	DrawText(mdc, strText, wcslen(strText), &rc_data, DT_RIGHT | DT_SINGLELINE | DT_BOTTOM);

	rc_data.top = rc_data.bottom;
	rc_data.bottom = rc_data.top + ROWHIGHT;
	swprintf_s(strText, L"%.4f", m_fGamma);
	DrawText(mdc, strText, wcslen(strText), &rc_data, DT_RIGHT | DT_SINGLELINE | DT_BOTTOM);

	rc_data.top = rc_data.bottom;
	rc_data.bottom = rc_data.top + ROWHIGHT;
	swprintf_s(strText, L"%.4f", m_fVega);
	DrawText(mdc, strText, wcslen(strText), &rc_data, DT_RIGHT | DT_SINGLELINE | DT_BOTTOM);

	rc_data.top = rc_data.bottom;
	rc_data.bottom = rc_data.top + ROWHIGHT;
	swprintf_s(strText, L"%d", m_OptionSeries->ExpiryDate);
	DrawText(mdc, strText, wcslen(strText), &rc_data, DT_RIGHT | DT_SINGLELINE | DT_BOTTOM);

	rc_data.top = rc_data.bottom;
	rc_data.bottom = rc_data.top + ROWHIGHT;
	swprintf_s(strText, L"%d", m_OptionSeries->ExpiryDate);
	DrawText(mdc, strText, wcslen(strText), &rc_data, DT_RIGHT | DT_SINGLELINE | DT_BOTTOM);

	rc_data.top = rc_data.bottom;
	rc_data.bottom = rc_data.top + ROWHIGHT;
	DrawText(mdc, G_LANG->LangText(TLI_AMERICAN), wcslen(G_LANG->LangText(TLI_AMERICAN)), &rc_data, DT_RIGHT | DT_SINGLELINE | DT_BOTTOM);
}
void TOptionStrategy::DrawBottomRight(HDC mdc, RECT& cr)
{
	if (!m_pContract || !m_OptionSeries)
		return;
	const int ROWHIGHT = 20;
	const int MARGIN = 5;
	SelectObject(mdc, FONT_FUTURE_TITLE);
	SetTextColor(mdc, COLOR_FUTURE_STR);
	//绘制名称
	RECT rc_name = cr;
	rc_name.left = cr.left + MARGIN;
	rc_name.right = cr.left + (cr.right - cr.left) / 2;
	rc_name.bottom = rc_name.top + ROWHIGHT;
	DrawText(mdc, G_LANG->LangText(TLI_INTRINSICVALUE), wcslen(G_LANG->LangText(TLI_INTRINSICVALUE)), &rc_name, DT_LEFT | DT_SINGLELINE | DT_BOTTOM);

	rc_name.top = rc_name.bottom;
	rc_name.bottom = rc_name.top + ROWHIGHT;
	DrawText(mdc, G_LANG->LangText(TLI_PREMIUMRATIO), wcslen(G_LANG->LangText(TLI_PREMIUMRATIO)), &rc_name, DT_LEFT | DT_SINGLELINE | DT_BOTTOM);

	rc_name.top = rc_name.bottom;
	rc_name.bottom = rc_name.top + ROWHIGHT;
	DrawText(mdc, G_LANG->LangText(TLI_EFFECTIVEGEARING), wcslen(G_LANG->LangText(TLI_EFFECTIVEGEARING)), &rc_name, DT_LEFT | DT_SINGLELINE | DT_BOTTOM);

	rc_name.top = rc_name.bottom;
	rc_name.bottom = rc_name.top + ROWHIGHT;
	DrawText(mdc, L"Delta", wcslen(L"Delta"), &rc_name, DT_LEFT | DT_SINGLELINE | DT_BOTTOM);

	rc_name.top = rc_name.bottom;
	rc_name.bottom = rc_name.top + ROWHIGHT;
	DrawText(mdc, L"Theta", wcslen(L"Theta"), &rc_name, DT_LEFT | DT_SINGLELINE | DT_BOTTOM);

	rc_name.top = rc_name.bottom;
	rc_name.bottom = rc_name.top + ROWHIGHT;
	DrawText(mdc, L"Rho", wcslen(L"Rho"), &rc_name, DT_LEFT | DT_SINGLELINE | DT_BOTTOM);

	rc_name.top = rc_name.bottom;
	rc_name.bottom = rc_name.top + ROWHIGHT;
	DrawText(mdc, G_LANG->LangText(TLI_STRIKEPRICE), wcslen(G_LANG->LangText(TLI_STRIKEPRICE)), &rc_name, DT_LEFT | DT_SINGLELINE | DT_BOTTOM);

	rc_name.top = rc_name.bottom;
	rc_name.bottom = rc_name.top + ROWHIGHT;
	DrawText(mdc, G_LANG->LangText(TLI_OPTIONSTARTDATE), wcslen(G_LANG->LangText(TLI_OPTIONSTARTDATE)), &rc_name, DT_LEFT | DT_SINGLELINE | DT_BOTTOM);

	rc_name.top = rc_name.bottom;
	rc_name.bottom = rc_name.top + ROWHIGHT;
	DrawText(mdc, G_LANG->LangText(TLI_EXERCISERATE), wcslen(G_LANG->LangText(TLI_EXERCISERATE)), &rc_name, DT_LEFT | DT_SINGLELINE | DT_BOTTOM);

	//绘制数据
	SetTextColor(mdc, COLOR_FUTURE_STR);
	RECT rc_data = cr;
	rc_data.left = cr.left + (cr.right - cr.left) / 2;
	rc_data.right = cr.right - MARGIN;
	rc_data.bottom = rc_data.top + ROWHIGHT;
	wchar_t strText[101] = L"";
	SPriceType dIntrValue = 0;
	GetIntrinsicValue(dIntrValue);
	swprintf_s(strText, L"%.1f", dIntrValue);
	DrawText(mdc, strText, wcslen(strText), &rc_data, DT_RIGHT | DT_SINGLELINE | DT_BOTTOM);

	rc_data.top = rc_data.bottom;
	rc_data.bottom = rc_data.top + ROWHIGHT;
	SPriceType dPremiumRate = 0;
	GetPremiumRatio(dPremiumRate);
	swprintf_s(strText, L"%.2f", dPremiumRate);
	DrawText(mdc, strText, wcslen(strText), &rc_data, DT_RIGHT | DT_SINGLELINE | DT_BOTTOM);

	rc_data.top = rc_data.bottom;
	rc_data.bottom = rc_data.top + ROWHIGHT;
	//delta*杠杆率
	SPriceType dRadio = 0;
	GetGearing(dRadio);
	SPriceType dGearing = m_fDelta*dRadio;
	swprintf_s(strText, L"%.2f", dGearing);
	DrawText(mdc, strText, wcslen(strText), &rc_data, DT_RIGHT | DT_SINGLELINE | DT_BOTTOM);

	rc_data.top = rc_data.bottom;
	rc_data.bottom = rc_data.top + ROWHIGHT;
	swprintf_s(strText, L"%.4f", m_fDelta);
	DrawText(mdc, strText, wcslen(strText), &rc_data, DT_RIGHT | DT_SINGLELINE | DT_BOTTOM);

	rc_data.top = rc_data.bottom;
	rc_data.bottom = rc_data.top + ROWHIGHT;
	swprintf_s(strText, L"%.4f", m_fTheta);
	DrawText(mdc, strText, wcslen(strText), &rc_data, DT_RIGHT | DT_SINGLELINE | DT_BOTTOM);

	rc_data.top = rc_data.bottom;
	rc_data.bottom = rc_data.top + ROWHIGHT;
	swprintf_s(strText, L"%.4f", m_fRho);
	DrawText(mdc, strText, wcslen(strText), &rc_data, DT_RIGHT | DT_SINGLELINE | DT_BOTTOM);

	rc_data.top = rc_data.bottom;
	rc_data.bottom = rc_data.top + ROWHIGHT;
	SPriceType dStrikePrice = atof(m_StrikePrice) * m_pContract->Commodity->PriceMultiple;
	swprintf_s(strText, L"%.1f", dStrikePrice);
	DrawText(mdc, strText, wcslen(strText), &rc_data, DT_RIGHT | DT_SINGLELINE | DT_BOTTOM);

	rc_data.top = rc_data.bottom;
	rc_data.bottom = rc_data.top + ROWHIGHT;
	swprintf_s(strText, L"%d", m_OptionSeries->ExpiryDate);
	DrawText(mdc, strText, wcslen(strText), &rc_data, DT_RIGHT | DT_SINGLELINE | DT_BOTTOM);

	rc_data.top = rc_data.bottom;
	rc_data.bottom = rc_data.top + ROWHIGHT;
	DrawText(mdc, L"1.0", wcslen(L"1.0"), &rc_data, DT_RIGHT | DT_SINGLELINE | DT_BOTTOM);
}
void TOptionStrategy::DrawBenifitList(HDC mdc, RECT& cr)
{
	if (!m_pContract || !m_OptionSeries)
		return;
	int RowHigth = 23;
	RECT listRc = cr;
	//InflateRect(&listRc, -10, -5);
	HPEN pen = CreatePen(PS_SOLID, 1, RGB(50, 50, 50));
	SelectObject(mdc, pen);
	//绘制列头
	RECT Rowrc = listRc;
	Rowrc.bottom = Rowrc.top + RowHigth;
	int Mid = Rowrc.left+(Rowrc.right - Rowrc.left) / 2;
	//MoveToEx(mdc, Rowrc.left, Rowrc.top, 0);
	//LineTo(mdc, Rowrc.left, Rowrc.bottom);
	//MoveToEx(mdc, Rowrc.left, Rowrc.top, 0);
	//LineTo(mdc, Rowrc.right, Rowrc.top);
	//MoveToEx(mdc, Mid, Rowrc.top, 0);
	//LineTo(mdc, Mid, Rowrc.bottom);
	//MoveToEx(mdc, Rowrc.right, Rowrc.top, 0);
	//LineTo(mdc, Rowrc.right, Rowrc.bottom);
	//MoveToEx(mdc, Rowrc.left, Rowrc.bottom, 0);
	//LineTo(mdc, Rowrc.right, Rowrc.bottom);
	SetTextColor(mdc, COLOR_FUTURE_STR);
	RECT textRect = Rowrc;
	textRect.right = Mid;
	DrawText(mdc, G_LANG->LangText(TLI_EXPIRATIONPRICE), wcslen(G_LANG->LangText(TLI_EXPIRATIONPRICE)), &textRect, DT_CENTER| DT_VCENTER |DT_SINGLELINE);
	textRect = Rowrc;
	textRect.left = Mid;
	DrawText(mdc, G_LANG->LangText(TLI_PROFITANDLOSS), wcslen(G_LANG->LangText(TLI_PROFITANDLOSS)), &textRect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	//绘制列数据
	SPriceType dTarget = 0;
	GetTargetNewPrice(dTarget);
	double dChanged = 0.1; //波动幅度
	double step = dTarget * 2*dChanged/(double)(ListRows-1.0);
	double starPrice = dTarget*(1 + dChanged);
	if(m_nRowBegin == 0)
	    m_nShowRows = ListRows;
	for (int i = m_nRowBegin; i < ListRows; i++)
	{
		if (Rowrc.bottom > listRc.bottom)
		{
			m_nShowRows = i - m_nRowBegin;
			break;
		}
		Rowrc.top = Rowrc.bottom;
		Rowrc.bottom = Rowrc.top + RowHigth;
		/*MoveToEx(mdc, Rowrc.left, Rowrc.top, 0);
		LineTo(mdc, Rowrc.left, Rowrc.bottom);
		MoveToEx(mdc, Mid, Rowrc.top, 0);
		LineTo(mdc, Mid, Rowrc.bottom);
		MoveToEx(mdc, Rowrc.right, Rowrc.top, 0);
		LineTo(mdc, Rowrc.right, Rowrc.bottom);
		MoveToEx(mdc, Rowrc.left, Rowrc.bottom, 0);
		LineTo(mdc, Rowrc.right, Rowrc.bottom);*/
		//画选中行
		if ( m_nSelectedRow == i)
		{
			RECT rr(Rowrc);
			rr.right = Rowrc.right - 5;
			FrameRect(mdc, &rr, BRUSH_FUTURE_SEL);
		}

		SetTextColor(mdc, COLOR_FUTURE_EQUAL);
		wchar_t strText[101] = L"";
		FormatPrice(G_StarApi, starPrice - i*step, m_pContract->Commodity, strText, true);
		if (i == ListRows / 2)
		{
			textRect = Rowrc;
			textRect.right = Mid;
			SQuoteSnapShot* q(m_OptionSeries->TargetContract->SnapShot);
			if (q)
			{
				SQuoteField& ud = q->Data[S_FID_UPDOWN];

				COLORREF ud_color(COLOR_FUTURE_EQUAL);
				if (S_FIDATTR_NONE != ud.FidAttr && 0 != ud.Price)
					ud_color = (ud.Price > 0) ? COLOR_FUTURE_UP : COLOR_FUTURE_DOWN;
				SetTextColor(mdc, ud_color);
			}
			DrawText(mdc, strText, wcslen(strText), &textRect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
		}
		else
		{
			SelectObject(mdc, FONT_FUTURE_CONTENT);
			textRect = Rowrc;
			textRect.right = Rowrc.left + (Mid- Rowrc.left )/2;
			DrawText(mdc, strText, wcslen(strText), &textRect, DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
			SelectObject(mdc, FONT_PANEL_TICK_PRICE);
			SetTextColor(mdc, RGB(90, 90, 90));
			textRect.left = Rowrc.left + (Mid - Rowrc.left) / 2;
			textRect.right = Mid;
			swprintf_s(strText, L" %d%%", (int)(dChanged*100 - (2 * i* dChanged / (double)(ListRows - 1.0)) * 100));
			DrawText(mdc, strText, wcslen(strText), &textRect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
			SelectObject(mdc, FONT_FUTURE_CONTENT);
		}
		
		double payoff = CounrCurrentProfitAndLos(starPrice - i*step);
		FormatPrice(G_StarApi, payoff,2,1, strText, true);
		textRect = Rowrc;
		textRect.left = Mid;
		if(payoff>0)
		     SetTextColor(mdc, COLOR_FUTURE_UP);
		else if(payoff<0)
			SetTextColor(mdc, COLOR_FUTURE_DOWN);
		else
			SetTextColor(mdc, COLOR_FUTURE_EQUAL);
		DrawText(mdc, strText, wcslen(strText), &textRect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	}
	DeletePen(pen);
	RECT sr;
	if (!GetListScrollRect(sr))
		return;
	FillRect(mdc, &sr, BRUSH_FUTURE_VSCROLL);
}
void TOptionStrategy::CalProfitExpectVariance()
{
	TCriticalSection::Lock lock(m_HisData);
	if (m_OptionSeries&&m_OptionSeries->TargetContract)
	{
		SHisQuoteData rdata[100];
		int rsize(sizeof(rdata) / sizeof(SHisQuoteData));
		rsize = G_StarApi->GetHisQuote(m_OptionSeries->TargetContract->ContractNo, S_KLINE_DAY, 1, 1, 0, rdata, rsize);
		if (rsize > 0)
		{
			//计算自然对数收益
			std::vector<double> lnProfits;
			for (int i = 1; i < rsize; i++)
			{
				if (rdata[rsize - i - 1].QLastPrice <= 0)
					return;
				lnProfits.push_back(log(rdata[rsize - i].QLastPrice / rdata[rsize - i - 1].QLastPrice));
			}
			if (lnProfits.size() <= 0)
				return;
			//计算收益均值
			double dAvgValue = 0;
			for (size_t i = 0; i < lnProfits.size(); i++)
				dAvgValue += lnProfits[i];
			dAvgValue /= lnProfits.size();
			m_NormalData.miu = dAvgValue;
			double dWave = 0;
			//计算收益标准差
			for (size_t i = 0; i < lnProfits.size(); i++)
				dWave += pow(lnProfits[i] - dAvgValue, 2);
			dWave = sqrt(dWave / (lnProfits.size() - 1));

			//获得年波动率
			dWave *= sqrt(246.00);//内盘每年大致246个交易日 365-365/7*2-5*2-5 
								  //dWave = dWave/sqrt(2*100)*100;
			m_NormalData.sigma = dWave;
			SPriceType preClose;
			if (GetTargetPreClosePrice(preClose))
			{
				m_NormalData.startPrice = preClose*exp(m_NormalData.miu - 3 * m_NormalData.sigma);
				m_NormalData.endPrice = preClose*exp(m_NormalData.miu + 3 * m_NormalData.sigma);
				m_NormalData.bValid = true;
				ReCalLimitInfo();
			}
		}
	}
}
void TOptionStrategy::ReCalLimitInfo()
{
	if (!m_NormalData.bValid)
	{
		SPriceType preClose;
		if (GetTargetPreClosePrice(preClose))
		{
			m_NormalData.startPrice = preClose*exp(m_NormalData.miu - 3 * m_NormalData.sigma);
			m_NormalData.endPrice = preClose*exp(m_NormalData.miu + 3 * m_NormalData.sigma);
			m_NormalData.bValid = true;
		}
	}
	if (m_NormalData.bValid&&m_ProfitData.bValit)
	{
		double dSPrice = m_ProfitData.startPrice;
		double dEPrice = m_ProfitData.endPrice;
		dSPrice = min(m_NormalData.startPrice, dSPrice);
		dEPrice = max(m_NormalData.endPrice, dEPrice);
		m_NormalData.startPrice = dSPrice;
		m_NormalData.endPrice = dEPrice;
		m_ProfitData.startPrice = dSPrice;
		m_ProfitData.endPrice = dEPrice;
		double maxPay = 0, EndPay, starPay;
		starPay = CountProfitAndLos(dSPrice);
		maxPay = fabs(starPay) > m_ProfitData.maxMoney ? fabs(starPay) : m_ProfitData.maxMoney;
		m_ProfitData.maxMoney = maxPay* 10 / 9;
		m_ProfitData.minMoney = -maxPay * 10 / 9;
		EndPay = CountProfitAndLos(dEPrice);
		maxPay = m_ProfitData.maxMoney > fabs(EndPay) ? m_ProfitData.maxMoney : fabs(EndPay);
		m_ProfitData.maxMoney = maxPay* 10 / 9;
		m_ProfitData.minMoney = -maxPay* 10 / 9;
	}
}
double TOptionStrategy::GetProbability(double price)
{
	if (price <= 0)
		return 0.0;
	double dPricent = 0.0;
	if (m_NormalData.sigma == 0)
		return -1;
	double dPrice = (m_NormalData.endPrice - m_NormalData.startPrice) / 200.0;
	SPriceType preClose;
	if (dPrice == 0 || !GetTargetPreClosePrice(preClose))
		return -1;
	
	double dProfit = (log(price / preClose) - m_NormalData.miu) / m_NormalData.sigma;
	dPricent = NormSDist(dProfit);
	return dPricent;
}
bool TOptionStrategy::GetListScrollRect(RECT& r)
{
	if(m_nShowRows >= ListRows)
		return false;
	int nVSCROLL_WIDTH = 5;
	RECT  r_bot = m_Rects[RBOTTOM_RECT];
	int RowHigth = 23;
	RECT listRc = r_bot;
	//InflateRect(&listRc, -10, -5);
	listRc.top += RowHigth;
	if (listRc.right - listRc.left <= nVSCROLL_WIDTH || listRc.bottom <= listRc.top)
		return false;
	//计算r
	r.right = listRc.right - 1;
	r.left = listRc.right - nVSCROLL_WIDTH;
	LONG all_height = (listRc.bottom - listRc.top);
	size_t pos = m_nRowBegin;
	size_t page = m_nShowRows;
	size_t count = ListRows;
	if (pos >= count)
		pos = count - 1;
	if (page > count)
		page = count;
	r.top = listRc.top + (LONG)(1.0 * pos * all_height / count);
	r.bottom = r.top + (LONG)(1.0 * page * all_height / count);
	return true;
}
void  TOptionStrategy::AddRectTool(int id, RECT rect, LPWSTR szTipText)
{
	TOOLINFO  tti;

	//设置提示窗口的信息  
	memset(&tti, 0, sizeof(TOOLINFO));
	tti.cbSize = TTTOOLINFOA_V2_SIZE;
	tti.uFlags = TTF_SUBCLASS;
	tti.hwnd = m_pGride->GetWindow()->GetHwnd();
	tti.rect = rect;
	tti.uId = id;
	tti.lpszText = szTipText;
	//新增一个提示  
	SendMessage(m_hwTip, TTM_ADDTOOL, 0, (LPARAM)(LPTOOLINFO)&tti);
	SendMessage(m_hwTip, TTM_SETTIPBKCOLOR, COLORREF(RGB(220, 220, 220)), 0);
	::SendMessage(m_hwTip, TTM_SETDELAYTIME, TTDT_AUTOPOP, 8000);//第四参数为毫秒
}
void TOptionStrategy::DelALLRectTool()
{
	RECT r = m_Rects[STRATEGY_ITEM_RECT];
	RECT item_r = r;
	for (size_t i = 0; i < m_vTactis.size(); i++)
	{
		Tactic tc = m_vTactis[i];
		item_r.right = item_r.left + tc.NameSize.cx;
		if (m_bRegToolTip&&i > 0)
		{
			TOOLINFO  tti;

			//设置提示窗口的信息  
			memset(&tti, 0, sizeof(TOOLINFO));
			tti.cbSize = TTTOOLINFOA_V2_SIZE;
			tti.uFlags = TTF_SUBCLASS;
			tti.hwnd = m_pGride->GetWindow()->GetHwnd();
			tti.rect = item_r;
			tti.uId = i;
			tti.lpszText = L"";
			//新增一个提示  
			SendMessage(m_hwTip, TTM_DELTOOL, 0, (LPARAM)(LPTOOLINFO)&tti);
		}
		item_r.left = item_r.right;
	}
	
	m_bRegToolTip = false;
}
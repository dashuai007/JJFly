#include "PreInclude.h"

ShapePen::ShapePen() :m_bOk(false),m_pAxisX(NULL),m_pChart(NULL),m_type(SHAPE_NONE)
{

}
ShapePen::~ShapePen()
{

}
void ShapePen::Create(HWND phwnd, SHAPE_TYPE type, TKLineChart* pChart, TKLineAxisX* pAxisX)
{
	m_Hwnd = phwnd;
	m_pAxisX = pAxisX;
	m_pChart = pChart;
	m_type = type;
}
bool ShapePen::IsOk()
{
	return m_bOk;
}
bool ShapePen::IsDrawing()
{
	return m_arrData.size()>0 && !m_bOk;
}
void ShapePen::Clear()
{
	m_arrData.clear();
	m_arrPixPoint.clear();
}
void ShapePen::GetData(std::vector<ChartDot>& arr)
{
	arr.clear();
	if (!m_arrData.empty())
		std::copy(m_arrData.begin(), m_arrData.end(), std::back_inserter(arr));
}
void ShapePen::OnClick(const POINT& pt)
{
	if (IsOk()) return;
	RECT ccr = m_pChart->CenterChartRect;
	if (pt.x < ccr.left)
		return;
	ChartDot dot;
	int nInd = m_pAxisX->PixelData[pt.x- ccr.left];
	dot.x = (nInd - m_pAxisX->Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	dot.y =m_pChart->YAxis_Pix2Price(pt.y);
	m_arrData.push_back(dot);

	if (m_arrData.size() == GetMaxGriperCount())
	{
		m_bOk = TRUE;
	}
	else
	{
		m_arrPixPoint.push_back(pt);
	}
}

void VertHozPen::Draw(HDC mdc)
{
	if (IsOk()|| !m_pChart) return;
	POINT cp;
	GetCursorPos(&cp);
	ScreenToClient(m_Hwnd, &cp);
	RECT ccr = m_pChart->CenterChartRect;
	if (m_type == HORIZONTAL_LINE)
	{
		DrawLine(mdc, ccr.left, cp.y, ccr.right, cp.y, ColorReverse());
	}
	else
	{
		DrawLine(mdc, cp.x, ccr.top, cp.x, ccr.bottom, ColorReverse());
	}
}

void NoramlLinePen::Draw(HDC mdc)
{
	if (IsOk() || !m_pChart) return;
	POINT cp;
	GetCursorPos(&cp);
	ScreenToClient(m_Hwnd, &cp);
	RECT ccr = m_pChart->CenterChartRect;
	if (m_arrData.size() == 0)
	{
		DrawLine(mdc, ccr.left, cp.y, ccr.right, cp.y, ColorReverse());
	}
	if (m_arrData.size() == 1)
	{
		DotLine(mdc, m_arrPixPoint[0].x, m_arrPixPoint[0].y, ccr.right, m_arrPixPoint[0].y, ColorReverse());
		SetTextColor(mdc, ColorReverse());
		SetBkMode(mdc, TRANSPARENT);
		wchar_t str[21] = { 0 };
		double k = 0;
		POINT& ptLt = m_arrPixPoint[0];
		if (cp.x != ptLt.x)
			k = abs((cp.y - ptLt.y) / (double)(cp.x - ptLt.x));
		double angle = (cp.x == ptLt.x) ? (3.14159 / 2) : atan(k);

		int angle2 = (int)(angle / 3.14159 * 180);
		if (cp.x<ptLt.x)
		{
			//��2��3����
			angle2 = 180 - angle2;
		}
		else
		{
			if (cp.y>ptLt.y)
			{
				//��������
				angle2 = -angle2;
			}
		}
		swprintf_s(str, L"%d", angle2);
		RECT rtText = { 0 };
		rtText.left = m_arrPixPoint[0].x - 30;
		rtText.top = m_arrPixPoint[0].y - 20;
		rtText.right = m_arrPixPoint[0].x + 30;
		rtText.bottom = m_arrPixPoint[0].y + 20;
		DrawText(mdc, str, wcslen(str), &rtText, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
		if (m_type == LEADER_LINE)
			DrawArrowLine(mdc, m_arrPixPoint[0], cp, ColorReverse());
		else if (m_type == TREND_LINE)
		{
			DrawZhiXian(mdc, m_arrPixPoint[0], cp, ColorReverse(), 1, ccr.left, ccr.right);
		}
		else
			DrawLine(mdc, m_arrPixPoint[0], cp, ColorReverse());
	}
}

void PXXPen::Draw(HDC mdc)
{
	if (IsOk() || !m_pChart) return;
	POINT cp;
	GetCursorPos(&cp);
	ScreenToClient(m_Hwnd, &cp);
	RECT ccr = m_pChart->CenterChartRect;
	if (m_arrData.size() == 0)
	{
		DrawLine(mdc, ccr.left, cp.y, ccr.right, cp.y, ColorReverse());
	}
	else if (m_arrData.size() == 1)
	{
		DrawZhiXian(mdc, m_arrPixPoint[0], cp, ColorReverse(), 1, ccr.left, ccr.right);
	}
	else
	{
		int nWidth = ccr.right - ccr.left;
		int nHigth = ccr.bottom - ccr.top;
		DrawZhiXian(mdc, m_arrPixPoint[0], m_arrPixPoint[1], ColorReverse(), 2, ccr.left, ccr.right);
		POINT ptCuiZu = Getplumb(m_arrPixPoint[0], m_arrPixPoint[1], cp);

		int maxDistance = (int)sqrt((double)(nWidth*nWidth + nHigth * nHigth));

		int perDistance = PointToLine(cp, m_arrPixPoint[0], m_arrPixPoint[1]);
		if (perDistance<5) return;

		int offX = cp.x - ptCuiZu.x;
		int offY = cp.y - ptCuiZu.y;

		int nStep = maxDistance / perDistance;
		for (int i = 1; i<nStep; i++)
		{
			POINT pt1, pt2;
			pt1.x = m_arrPixPoint[0].x + offX*i;
			pt1.y = m_arrPixPoint[0].y + offY*i;
			pt2.x = m_arrPixPoint[1].x + offX*i;
			pt2.y = m_arrPixPoint[1].y + offY*i;
			DrawZhiXian(mdc,pt1, pt2, ColorReverse(), 1, ccr.left, ccr.right);
			pt1.x = m_arrPixPoint[0].x - offX*i;
			pt1.y = m_arrPixPoint[0].y - offY*i;
			pt2.x = m_arrPixPoint[1].x - offX*i;
			pt2.y = m_arrPixPoint[1].y - offY*i;
			DrawZhiXian(mdc, pt1, pt2, ColorReverse(), 1, ccr.left, ccr.right);

		}
	}
}

void TrianglePen::Draw(HDC mdc)
{
	if (IsOk() || !m_pChart) return;
	POINT cp;
	GetCursorPos(&cp);
	ScreenToClient(m_Hwnd, &cp);
	RECT ccr = m_pChart->CenterChartRect;
	if (m_arrData.size() == 0)
		DrawLine(mdc, ccr.left, cp.y, ccr.right, cp.y, ColorReverse());
	else if (m_arrData.size() == 1)
	{
		DrawLine(mdc, m_arrPixPoint[0], cp, ColorReverse());
	}
	else
	{
		DrawLine(mdc, m_arrPixPoint[0], m_arrPixPoint[1], ColorReverse());
		DrawLine(mdc, m_arrPixPoint[0], cp, ColorReverse());
		DrawLine(mdc, m_arrPixPoint[1], cp, ColorReverse());
	}
}
void RectPen::Draw(HDC mdc)
{
	if (IsOk() || !m_pChart) return;
	POINT cp;
	GetCursorPos(&cp);
	ScreenToClient(m_Hwnd, &cp);
	RECT ccr = m_pChart->CenterChartRect;
	if (m_arrData.size() == 0)
		DrawLine(mdc, ccr.left, cp.y, ccr.right, cp.y, ColorReverse());
	else
	{
		DrawRect(mdc, m_arrPixPoint[0].x, m_arrPixPoint[0].y, cp.x, cp.y, ColorReverse(), 1);
	}
}
void ArcPen::Draw(HDC mdc)
{
	if (IsOk() || !m_pChart) return;
	POINT cp;
	GetCursorPos(&cp);
	ScreenToClient(m_Hwnd, &cp);
	RECT ccr = m_pChart->CenterChartRect;
	if (m_arrData.size() == 0)
		DrawLine(mdc, ccr.left, cp.y, ccr.right, cp.y, ColorReverse());
	else
	{
		POINT &ptPix1 = m_arrPixPoint[0];
		POINT &ptPix2 = cp;

		int width = abs(2 * (ptPix2.x - ptPix1.x));
		int height = abs(2 * (ptPix2.y - ptPix1.y));

		int x = ptPix2.x> ptPix1.x ? ptPix1.x : (ptPix1.x - width);
		int y = ptPix2.y< ptPix1.y ? ptPix2.y : (ptPix2.y - height);

		DotLine(mdc, x, y + height / 2, x + width, y + height / 2, ColorReverse());
		DotLine(mdc, ptPix2.x, ptPix2.y, x + width / 2, y + height / 2, ColorReverse());

		if (ptPix2.y>ptPix1.y)
		{
			DrawArc(mdc, ColorReverse(), x, y, x+width, y + height, x, y + height / 2, x + width, y + height / 2);
		}
		else
		{
			DrawArc(mdc, ColorReverse(), x, y, x + width, y + height, x + width, y + height / 2, x, y + height / 2);
		}
	}
}

void CirclePen::Draw(HDC mdc)
{
	if (IsOk() || !m_pChart) return;
	POINT cp;
	GetCursorPos(&cp);
	ScreenToClient(m_Hwnd, &cp);
	RECT ccr = m_pChart->CenterChartRect;
	if (m_arrData.size() == 0)
		DrawLine(mdc, ccr.left, cp.y, ccr.right, cp.y, ColorReverse());
	else
	{
		POINT &ptPix1 = m_arrPixPoint[0];

		POINT &ptCenter = cp;
		DotLine(mdc, ptPix1.x, ptPix1.y, ptCenter.x, ptCenter.y, ColorReverse());
		//�뾶
		int nBJ = (int)sqrt((double)(ptCenter.x - ptPix1.x)*(ptCenter.x - ptPix1.x) + (ptCenter.y - ptPix1.y)*(ptCenter.y - ptPix1.y));

		if (nBJ<10) return;

		int nCurBJ = nBJ / 3;
		int nAddBJ = nBJ / 8;

		for (int i = 0; i<3; i++)
		{
			if (ptPix1.y<ptCenter.y)
			{
				DrawArc(mdc, ColorReverse(), ptCenter.x - nCurBJ, ptCenter.y - nCurBJ, ptCenter.x + nCurBJ, ptCenter.y + nCurBJ, ptCenter.x - nCurBJ, ptCenter.y, ptCenter.x + nCurBJ, ptCenter.y);
			}
			else
			{
				DrawArc(mdc, ColorReverse(), ptCenter.x - nCurBJ, ptCenter.y - nCurBJ, ptCenter.x + nCurBJ, ptCenter.y + nCurBJ, ptCenter.x + nCurBJ, ptCenter.y, ptCenter.x - nCurBJ, ptCenter.y);
			}

			nCurBJ += nAddBJ;
		}
	}
}
void ZQXPen::Draw(HDC mdc)
{
	if (IsOk() || !m_pChart) return;
	POINT cp;
	GetCursorPos(&cp);
	ScreenToClient(m_Hwnd, &cp);
	RECT ccr = m_pChart->CenterChartRect;
	if (m_arrData.size() == 0)
		DrawLine(mdc, cp.x, ccr.top, cp.x, ccr.bottom, ColorReverse());
	else
	{
		int nFirst = (int)m_arrData[0].x;
		int nStep = (int)m_pAxisX->Pix2Value(cp.x - ccr.left) - nFirst;

		if (nStep == 0) return;

		int nBarWid = m_pAxisX->DataWidth[0];
		int nCount = 0;
		for (int i = nFirst;abs(i)< m_pAxisX->KData.Size(); i += nStep)
		{
			int pixX = ccr.left + m_pAxisX->Value2Pix(i) + nBarWid / 2;
			if (pixX>ccr.right) break;
			if (nCount<2)
			{
				DrawLine(mdc, pixX, ccr.top, pixX, ccr.bottom, ColorReverse());
			}
			else
				DotLine(mdc, pixX, ccr.top, pixX, ccr.bottom, ColorReverse());

			nCount++;
		}
	}
}
void HJF_BFBGPen::Draw(HDC mdc)
{
	if (IsOk() || !m_pChart) return;
	POINT cp;
	GetCursorPos(&cp);
	ScreenToClient(m_Hwnd, &cp);
	RECT ccr = m_pChart->CenterChartRect;
	if (m_arrData.size() == 0)
		DrawLine(mdc, ccr.left, cp.y, ccr.right, cp.y, ColorReverse());
	else
	{
		POINT &ptPix1 = m_arrPixPoint[0];

		int nDiff = cp.y - ptPix1.y;
		//if (nDiff<10) return;

		DrawLine(mdc, ccr.left, ptPix1.y, ccr.right, ptPix1.y, ColorReverse());
		DrawLine(mdc, ccr.left, cp.y, ccr.right, cp.y, ColorReverse());

		SelectObject(mdc, FONT_KLINE_NUMBER);
		SetBkMode(mdc,TRANSPARENT);
		SetTextColor(mdc, ColorReverse());

		std::vector<double> arrPixY;

		if (m_type == GOLDEN_SECTION)
		{
			arrPixY.push_back(0.382);
			arrPixY.push_back(0.618);
			arrPixY.push_back(1.382);
			arrPixY.push_back(1.618);
		}
		else if (m_type == PERCENTAGE_LINE)
		{
			arrPixY.push_back(0.25);
			arrPixY.push_back(0.5);
			arrPixY.push_back(0.75);
		}
		SIZE sz;
		GetTextExtentPoint32(mdc, L"0.618", wcslen(L"0.618"), &sz);

		wchar_t str[21];
		RECT rcLabel;
		for (int i = 0; i<arrPixY.size(); i++)
		{
			DotLine(mdc, ccr.left, (int)(ptPix1.y + arrPixY[i] * nDiff), ccr.right, (int)(ptPix1.y + arrPixY[i] * nDiff), ColorReverse());
			swprintf_s(str,L"%.3f", arrPixY[i]);
			rcLabel.left = ccr.right - sz.cx - 10;
			rcLabel.top = (int)(ptPix1.y + arrPixY[i] * nDiff);
			rcLabel.right = ccr.right;
			rcLabel.bottom = (int)(ptPix1.y + arrPixY[i] * nDiff + 40);
			DrawText(mdc,str,wcslen(str),&rcLabel, DT_LEFT | DT_SINGLELINE);
		}
	}
}
void FBLQPen::Draw(HDC mdc)
{
	if (IsOk() || !m_pChart) return;
	POINT cp;
	GetCursorPos(&cp);
	ScreenToClient(m_Hwnd, &cp);
	RECT ccr = m_pChart->CenterChartRect;
	if (m_arrData.size() == 0)
		DrawLine(mdc, cp.x, ccr.top, cp.x, ccr.bottom, ColorReverse());
}
void SZX_GSXPen::Draw(HDC mdc)
{
	if (IsOk() || !m_pChart) return;
	POINT cp;
	GetCursorPos(&cp);
	ScreenToClient(m_Hwnd, &cp);
	RECT ccr = m_pChart->CenterChartRect;
	if (m_arrData.size() == 0)
		DrawLine(mdc, ccr.left, cp.y, ccr.right, cp.y, ColorReverse());
	else
	{
		POINT& ptFrom = m_arrPixPoint[0];
		DrawRect(mdc, ptFrom.x, ptFrom.y, cp.x, cp.y,ColorReverse(), 1);
		if (cp.x<ptFrom.x) return;

		DrawSheXian(mdc, ptFrom, cp, ColorReverse(), 1);

		std::vector<double> arrPixAdd;
		if (m_type == RESISTANCE_LINE)
		{
			arrPixAdd.push_back(1.0 / 3);
			arrPixAdd.push_back(2.0 / 3);
			for (int i = 0; i<arrPixAdd.size(); i++)
			{
				int curPixY = (int)(ptFrom.y + (cp.y-ptFrom.y) *  arrPixAdd[i]);
				POINT pt;
				pt.x = cp.x;
				pt.y = curPixY;
				DrawSheXian(mdc, ptFrom, pt, ColorReverse(), 1);
			}
		}
		else
		{
			//������
			arrPixAdd.push_back(0.125);
			arrPixAdd.push_back(0.25);
			arrPixAdd.push_back(0.33);
			arrPixAdd.push_back(0.5);
			for (size_t i = 0; i<arrPixAdd.size(); i++)
			{
				int curPixY = (int)(ptFrom.y + (cp.y - ptFrom.y)* arrPixAdd[i]);
				POINT pt;
				pt.x = cp.x;
				pt.y = curPixY;
				DrawSheXian(mdc, ptFrom, pt, ColorReverse(), 1);

				int curPixX = (int)(ptFrom.x + (cp.x - ptFrom.x) * arrPixAdd[i]);
				pt.x = curPixX;
				pt.y = cp.y;
				DrawSheXian(mdc, ptFrom, pt, ColorReverse(), 1);
			}
		}
	}
}
void XXHG_Pen::Draw(HDC mdc)
{
	if (IsOk() || !m_pChart) return;
	POINT cp;
	GetCursorPos(&cp);
	ScreenToClient(m_Hwnd, &cp);
	RECT ccr = m_pChart->CenterChartRect;
	if (m_arrData.size() == 0)
		DrawLine(mdc, cp.x, ccr.top, cp.x, ccr.bottom, ColorReverse());
	else
	{
		DrawLine(mdc, m_arrPixPoint[0].x, ccr.top, m_arrPixPoint[0].x, ccr.bottom, ColorReverse());
		DrawLine(mdc, cp.x, ccr.top, cp.x, ccr.bottom, ColorReverse());

		int xFrom = (int)m_arrData[0].x;
		int xTo = (int)m_pAxisX->Pix2Value(cp.x-ccr.left);
		if (xFrom == xTo) return;

		if (xFrom >xTo)
		{
			int tmpX = xFrom;
			xFrom = xTo;
			xTo = tmpX;
		}


		std::vector<double> arrData;
		for (int i = xFrom; i<xTo; i++)
		{
			arrData.push_back(ccr.left + m_pAxisX->Value2Pix(i));
			double yValue = m_pChart->YAxis_Price2Pix(m_pAxisX->KData.GetData(i + m_pAxisX->Begin).QLastPrice);
			arrData.push_back(yValue);
		}

		double a = 0, b = 0, other[4] = { 0 };
		//�����Իع�
		if (LinearRegression(arrData.data(), arrData.size() / 2, &b, &a, other) == 0)
		{
			//y = ax + b
			POINT ptA, ptB;
			ptA.x = ccr.left + m_pAxisX->Value2Pix(xFrom);
			ptA.y = (LONG)(ptA.x * a + b);
			ptB.x = ccr.left + m_pAxisX->Value2Pix(xTo);
			ptB.y = (LONG)(ptB.x * a + b);

			DrawZhiXian(mdc, ptA, ptB, ColorReverse(), 1, ccr.left, ccr.right);

			int maxPixY = 0;
			int curPPP = 0;
			for (int i = xFrom; i<xTo; i++)
			{
				double curYPix = arrData[curPPP + 1];
				double curHGYPix = arrData[curPPP] * a + b;
				maxPixY = (int)max(abs(curYPix - curHGYPix), maxPixY);
				curPPP += 2;
			}
			POINT pt1, pt2;
			pt1.x = ptA.x;
			pt1.y = ptA.y - maxPixY;
			pt2.x = ptB.x;
			pt2.y = ptB.y - maxPixY;
			DrawZhiXian(mdc, pt1, pt2, ColorReverse(), 1, ccr.left, ccr.right);
			pt1.x = ptA.x;
			pt1.y = ptA.y + maxPixY;
			pt2.x = ptB.x;
			pt2.y = ptB.y + maxPixY;
			DrawZhiXian(mdc, pt1, pt2, ColorReverse(), 1, ccr.left, ccr.right);
		}
	}
}

ShapeFactory::ShapeFactory()
{
}


ShapeFactory::~ShapeFactory()
{
}
ShapePen* ShapeFactory::CreatePen(HWND phwnd, SHAPE_TYPE type, TKLineChart* pChart, TKLineAxisX* pAxisX)
{
	ShapePen *pPen = NULL;
	switch (type)
	{
	case HORIZONTAL_LINE:
	case VERTICAL_LINE:
		pPen = new VertHozPen();
		break;
	case TREND_LINE:
	case LINE_SEGMENT:
	case LEADER_LINE:
		pPen = new NoramlLinePen();
		break;
	case PARALLEL_LINE:
		pPen = new PXXPen();
		break;
	case TRIANGLE:
		pPen = new TrianglePen();
		break;
	case RECTANGLE:
		pPen = new RectPen();
		break;
	case ARC_LINE:
		pPen = new ArcPen();
		break;
	case SEMICIRCLE:
		pPen = new CirclePen();
		break;
	case PERIODIC_LINE:
		pPen = new ZQXPen();
		break;
	case GOLDEN_SECTION:
	case PERCENTAGE_LINE:
		pPen = new HJF_BFBGPen();
		break;
	case FIBONACCI_LINE:
		pPen = new FBLQPen();
		break;
	case RESISTANCE_LINE:
	case GANN_LINE:
		pPen = new SZX_GSXPen();
		break;
	case REGRESSION_CHANNEL:
		pPen = new XXHG_Pen();
		break;
	}
	if(pPen)
	   pPen->Create(phwnd,type, pChart, pAxisX);
	return pPen;
}

TShape* ShapeFactory::CreateShape(SHAPE_TYPE type, TKLineChart* pChart, TKLineAxisX* pAxisX, const std::vector<ChartDot>& data, COLORREF clr, int penWid)
{
	TShape *pShape = NULL;
	switch (type)
	{
	case HORIZONTAL_LINE:
	case VERTICAL_LINE:
		pShape = new THorizVertLine();
		break;
	case TREND_LINE:
	case LINE_SEGMENT:
	case LEADER_LINE:
		pShape = new TNormalLine();
		break;
	case PARALLEL_LINE:
		pShape = new TPXX();
		break;
	case TRIANGLE:
		pShape = new TTriangle();
		break;
	case RECTANGLE:
		pShape = new TRectShape();
		break;
	case ARC_LINE:
		pShape = new TArcShape();
		break;
	case SEMICIRCLE:
		pShape = new TCircleShape();
		break;
	case PERIODIC_LINE:
		pShape = new TZQXShape();
		break;
	case GOLDEN_SECTION:
	case PERCENTAGE_LINE:
		pShape = new THJFG_BFBShape();
		break;
	case FIBONACCI_LINE:
		pShape = new TFBLQShape();
		break;
	case RESISTANCE_LINE:
	case GANN_LINE:
		pShape = new TSZX_GSXShape();
		break;
	case REGRESSION_CHANNEL:
		pShape = new TXXHG_Shape();
		break;
	}
	if(pShape)
	   pShape->Create(type, pChart, pAxisX, data, clr, penWid);

	return pShape;
}

ShapeFactory* G_ShapeFactory()
{
	return ShapeFactory::GetInstance();
}
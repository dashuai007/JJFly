#include "PreInclude.h"


//if the current token is not in the token list, flag it as an error, 
// then skip tokens until one that is in the token list.
TOKEN_CODE StatementStartEndList[] = { tVARIABLE, tSEMICOLON, tLPAREN, tINNERFNC, tQUOTE, tPARAM, tNUMBER, tMINUS, 0 };
TOKEN_CODE LogicOpList[] = { tAND, tOR, 0 };
TOKEN_CODE RelationOpList[] = { tEQU, tLTN, tGTN, tNEQ,tGEQ,tLEQ, 0 };
TOKEN_CODE AddOpList[] = { tPLUS, tMINUS, 0 };
TOKEN_CODE MultiOpList[] = { tSTAR, tSLASH, 0 };
TOKEN_CODE DrawFncList[] = { tDRAWICON,tDRAWLINE,tPOLYLINE,tVERTLINE,tPARTLINE,tDRAWGBK,tSTICKLINE,tDRAWTEXT,tDRAWNUMBER, 0 };

TOKEN_CODE PeriodList[] = { tPERIODMIN1,tPERIODMIN3,tPERIODMIN5,tPERIODMIN15,tPERIODMIN30,tPERIODMIN60,tPERIODMIN120,tPERIODMIN240,tPERIODMINX,tPERIODDAY,tPERIODWEEK,tPERIODMONTH,0 };
TOKEN_CODE StkDataList[] = { tSTKOPEN,tSTKHIGH,tSTKLOW,tSTKCLOSE,tSTKVOL,tSTKAMOUNT,0 };
TOKEN_CODE StyleList[] = { tSTICK,tCOLORSTICK,tVOLSTICK,tLINESTICK,tCROSSDOT,tCIRCLEDOT,tPOINTDOT,0 };

//TOKEN_CODE FutureDataList[] = {tZIG, tPEAK, tPEAKBARS, tTROUGH, tTROUGHBARS, tCOST, tWINNER, 0};


BOOL TokenIn(TOKEN_CODE token, TOKEN_CODE* tokenList)
{
	TOKEN_CODE*	pToken;
	for (pToken = tokenList; *pToken; pToken++)
		if (token == *pToken) return true;
	return false;
}
#define IF_TOKEN_GET_ELSE_ERROR(TokenCode,ErrorCode)	\
	if (m_Token == TokenCode) GetToken(); else error(ErrorCode);

CFncParser::CFncParser()
{
	// Initialize the char code table
	int ch;
	for (ch = 1; ch<256; ch++) 		m_CharCode[ch] = ccSPECIAL;
	for (ch = '0'; ch <= '9'; ch++)		m_CharCode[ch] = ccDIGIT;

	for (ch = 'A'; ch <= 'Z'; ch++)		m_CharCode[ch] = ccLETTER;
	for (ch = 'a'; ch <= 'z'; ch++)		m_CharCode[ch] = ccLETTER;
	for (ch = 0xB0; ch <= 0xD8; ch++)	m_CharCode[ch] = ccLETTER;

	m_CharCode['_'] = ccLETTER;
	m_CharCode['&'] = ccLETTER;
	m_CharCode['%'] = ccLETTER;
	m_CharCode['\''] = ccQUOTE1;
	m_CharCode[0] = ccEOF_CODE;
}


CFncParser::~CFncParser()
{
	delete[] m_pBuf;
}
void CFncParser::GetToken()
{
	SkipBlanks();
	m_pToken = m_szTokenString;
	switch (m_CharCode[m_Char])
	{
	case ccLETTER:
		GetWord();
		break;
	case ccDIGIT:
		GetNumber();
		break;
	/*case ccQUOTE1:
		GetString();
		break;*/
	case ccEOF_CODE:
		m_Token = tEND_OF_TOKEN;
		break;
	default:
		GetSpecial();
		break;
	}
}
void CFncParser::SetIndex(CIndex* pIndex)
{
	CParser::SetIndex(pIndex);

	m_nStrIndex = 0;
	m_strVarNames = "";
	m_Char = ' ';
	m_nLineNumber = 0;
	m_nLineOffset = 0;

	m_pToken = m_szTokenString;

	int nLen = pIndex->m_strFnc.length();
	if (m_pBuf)
		delete[] m_pBuf;
	m_pBuf = new char[nLen + 1];
	strncpy_s(m_pBuf, nLen, pIndex->m_strFnc.c_str(), nLen);
	m_pBuf[nLen] = '\0';

}
int	CFncParser::Parse(int& nLine, int& nOffset)
{
	m_pIndex->ClearArrays();
	m_nCodeSize = 0;
	m_Code.fValue = 0;

	m_nErrCode = eNoError;
	GetToken();
	while (m_Token != tEND_OF_TOKEN)
	{
		ParseStatement();
		if (m_nErrCode != eNoError)
		{
			nLine = m_nErrLine;
			nOffset = m_nErrOffset;
			break;
		}
		while (m_Token == tSEMICOLON)
			GetToken();
		Synchronize();
	}
	CreateResult();
	SaveCode();

	return m_nErrCode;
}
void CFncParser::SkipComment()
{
	do
	{
		GetChar();
	} while ((m_Char != '}') && (m_Char != EOF_CHAR));
}
void CFncParser::SkipBlanks()
{
	while (m_Char == ' ')
	{
		GetChar();
		m_nLineOffset++;
	}
}
TOKEN_CODE CFncParser::NextToken()
{
	char* pBuf = m_pBuf;
	int   nLine = m_nLineNumber;
	int   nOffset = m_nLineOffset;
	char  ch = m_Char;
	char  szWordString[80];
	strncpy_s(szWordString, m_szWordString, 80);
	TOKEN_CODE tcOld = m_Token, tc;

	GetToken();
	tc = m_Token;

	m_pBuf = pBuf;
	m_nLineNumber = nLine;
	m_nLineOffset = nOffset;
	m_Char = ch;
	m_Token = tcOld;
	strncpy_s(m_szWordString, szWordString, 80);
	return tc;

}
void CFncParser::GetChar()
{
	if (*m_pBuf == '\0')
	{
		m_Char = EOF_CHAR; return;
	}
	m_Char = *m_pBuf++;

	// special character processing
	switch (m_Char)
	{
	case '\t':
		m_nLineOffset += TAB_SIZE - m_nLineOffset%TAB_SIZE;
		m_Char = ' ';
		break;
	case '\r':
		m_Char = ' ';
		break;
	case '\n':
		m_nLineNumber++;
		m_nLineOffset = 0;
		m_Char = ' ';
		break;
	case '{':
		m_nLineOffset++;
		SkipComment();
		m_Char = ' ';
		break;
	default:
		m_nLineOffset++;
	}
}
void CFncParser::GetWord()
{
	while (m_CharCode[m_Char] == ccLETTER || m_CharCode[m_Char] == ccDIGIT || (m_Char>0xA0 && m_Char <= 0xFF))
	{
		*m_pToken++ = m_Char;
		GetChar();
	}
	*m_pToken = '\0';
	UpShiftWord();

	if (!g_KeyWordMgr.IsInnerFnc(m_szWordString, m_Token, m_fncType) && !g_KeyWordMgr.IsReservedWord(m_szWordString, m_Token) && !IsParamWord())
	{
		m_nSymtabIndex = SearchAndEnterVariable();
		m_Token = tVARIABLE;
	}
}
void CFncParser::UpShiftWord()
{
	int offset = 'a' - 'A';
	char* pw = m_szWordString;
	char* pt = m_szTokenString;
	do
	{
		*pw++ = ((*pt >= 'a') && (*pt <= 'z')) ? *pt - offset : *pt;
		pt++;
	} while (*pt != '\0');
	*pw = '\0';
}
BOOL CFncParser::IsParamWord()
{
	m_nSymtabIndex = SearchSymtab(m_szWordString, itPARAM);
	if (m_nSymtabIndex >= 0)
	{
		m_Token = tPARAM;
		return true;
	}
	return false;
}
int CFncParser::SearchAndEnterVariable()
{
	int nIndex = SearchSymtab(m_szWordString, itVARIABLE);
	if (nIndex >= 0)
		return nIndex;
	CSymtabNode* pNode = new CSymtabNode;
	strcpy_s(pNode->m_strName , m_szWordString);
	pNode->m_itType = itUNASSIGNED;

	m_vSymtabs.push_back(pNode);
	return m_vSymtabs.size() - 1;
}
void CFncParser::GetNumber()
{
	int nWholeCount = 0;
	int	nDecimalOffset = 0;
	float fValue = 0.0;
	m_nDigitCount = 0;
	m_bCountError = false;
	//	m_Token = tEND_OF_TOKEN;

	AccumulateValue(&fValue);
	if (m_Token == tERROR) return;
	nWholeCount = m_nDigitCount;

	if (m_Char == '.')
	{
		GetChar();
		*m_pToken++ = '.';
		AccumulateValue(&fValue);
		if (m_Token == tERROR) return;
		nDecimalOffset = nWholeCount - m_nDigitCount;
	}
	if (m_bCountError)
	{
		error(eInvalidNumber);
		m_Token = tERROR;
		return;
	}


	*m_pToken = '\0';
	m_fNumber = (float)atof(m_szTokenString);
	m_Token = tNUMBER;

}
void CFncParser::AccumulateValue(float* pValue)
{
	float fValue = *pValue;

	if (m_CharCode[m_Char] != ccDIGIT)
	{
		error(eInvalidNumber);
		m_Token = tERROR;
		return;
	}
	do
	{
		*m_pToken++ = m_Char;
		if (++m_nDigitCount <= MAX_DIGIT_COUNT)
			fValue = 10 * fValue + (m_Char - '0');
		else m_bCountError = true;
		GetChar();
	} while (m_CharCode[m_Char] == ccDIGIT);
	*pValue = fValue;

}
void CFncParser::GetSpecial()
{
	*m_pToken++ = m_Char;
	switch (m_Char)
	{
	case '\"':
		m_Token = tQUOTE;	GetChar(); break;
	case '.':
		m_Token = tDOT;		GetChar(); break;
	case '$':
		m_Token = tDOLLAR;	GetChar(); break;
	case '#':
		m_Token = tWELL;	GetChar(); break;
	case '@':
		m_Token = tAT;		GetChar(); break;

	case '+':
		m_Token = tPLUS;	GetChar(); break;
	case '-':
		m_Token = tMINUS;	GetChar(); break;
	case '*':
		m_Token = tSTAR;	GetChar(); break;
	case '/':
		m_Token = tSLASH;	GetChar(); break;
	case '(':
		m_Token = tLPAREN;	GetChar(); break;
	case ')':
		m_Token = tRPAREN;	GetChar(); break;
	case ',':
		m_Token = tCOMMA;	GetChar(); break;
	case ';':
		m_Token = tSEMICOLON;	GetChar(); break;
	case '=':
		m_Token = tEQU;	GetChar(); break;
	case ':':
		GetChar();
		if (m_Char == '=')
		{
			*m_pToken++ = '=';
			m_Token = tCOLONEQU;
			GetChar();
		}
		else m_Token = tCOLON;
		break;
	case '<':
		GetChar();
		if (m_Char == '=')
		{
			*m_pToken++ = '=';
			m_Token = tLEQ;
			GetChar();
		}
		else if (m_Char == '>')
		{
			*m_pToken++ = '>';
			m_Token = tNEQ;
			GetChar();
		}
		else
			m_Token = tLTN;
		break;
	case '>':
		GetChar();
		if (m_Char == '=')
		{
			*m_pToken++ = '=';
			m_Token = tGEQ;
			GetChar();
		}
		else m_Token = tGTN;
		break;
	default:
		m_Token = tERROR;
		GetChar();
		break;
	}
	*m_pToken = '\0';
}
void CFncParser::error(int errorCode)
{
	m_nErrCode = errorCode;
	m_nErrLine = m_nLineNumber;
	m_nErrOffset = m_nLineOffset;
}
void CFncParser::Synchronize()
{
	BOOL bErrorFlag = !TokenIn(m_Token, StatementStartEndList);
	if (bErrorFlag)
	{
		if (m_Token == tEND_OF_TOKEN)
			return;
		else error(eSyntaxError);
		while (!TokenIn(m_Token, StatementStartEndList) && m_Token != tEND_OF_TOKEN)
			GetToken();
	}
}
void CFncParser::ParseStatement()
{
	int nIndex;
	CSymtabNode* pId = NULL;
	TOKEN_CODE tc = 0;
	if (m_Token != tQUOTE)
		tc = NextToken();
	int nSize = m_vSymtabs.size();
	if (m_Token != tVARIABLE && (tc == tCOLONEQU || tc == tCOLON))
	{
		error(eInvalidVarName);
		return;
	}
	if (m_Token == tVARIABLE && (tc == tCOLONEQU || tc == tCOLON))
	{
		nIndex = SearchSymtab(m_szWordString, itVARIABLE);
		pId = m_vSymtabs[nIndex];

		if (pId->m_itType != itUNASSIGNED)
			error(eRedefinedIdentifier);
		else
		{
			pId->m_itType = itVARIABLE;
		}
		if (tc == tCOLON)
			pId->m_bOutput = TRUE;
		else
		{
			if (nIndex == m_vSymtabs.size() - 1)
			{
				m_strVarNames += pId->m_strName;
				char ch = (char)255;
				m_strVarNames += ch;
			}
		}
		GetToken();

		ParseAssignmentStatement(pId);
	}
	else
	{
		//		CString str;
		nIndex = EnterSymtab("", itVARIABLE);
		pId = m_vSymtabs[nIndex];
		pId = m_vSymtabs[m_vSymtabs.size() - 1];
		pId->m_itType = itVARIABLE;
		pId->m_bOutput = TRUE;
		ParseExpression();
	}

	m_Code.nOperator = tASSIGN;
	m_Code.byte1 = (BYTE)nIndex;
	if (pId->m_bOutput)
		m_Code.byte3 = 0;
	else
		m_Code.byte3 = 1;
	PushCode();


	while (m_Token == tCOMMA)
	{
		GetToken();
		if (m_Token >= tSTICK && m_Token <= tHIDDEN)
		{
			pId->m_nStyle = m_Token - tSTICK + 2;
		}
		else
		{
			switch (m_Token)
			{
			case tCOLOR:
				pId->m_nColor = (int)m_fNumber;
				break;
			case tLINETHICK:
				pId->m_nLineThick = (int)(m_fNumber * 2);
				break;
			}
		}

		GetToken();
	}
	Synchronize();
	//	if ( m_Token == tVARIABLE) 
	if (m_Token != tSEMICOLON && m_Token != tEND_OF_TOKEN)
		error(eMissingSemicolon);
}
void CFncParser::ParseAssignmentStatement(CSymtabNode* pId)
{
	GetToken();
	pId->m_DataType = ParseExpression();
}
// p.142
DWORD CFncParser::ParseExpression()
{
	DWORD typeResult, type2;
	TOKEN_CODE op;

	typeResult = ParseLogicExpression();	//first simple expr
	while (TokenIn(m_Token, LogicOpList))
	{
		op = m_Token;
		GetToken();
		type2 = ParseLogicExpression();
		/*
		if ( (typeResult == dtNUMBER) && (type2 == dtNUMBER) )
		typeResult = dtNUMBER;
		else
		*/
		typeResult = dtARRAY;
		m_Code.nOperator = op;
		PushCode();
	}
	return typeResult;
}

DWORD CFncParser::ParseLogicExpression()
{
	DWORD typeResult, type2;
	TOKEN_CODE op;

	typeResult = ParseSimpleExpression();	//first simple expr
	if (TokenIn(m_Token, RelationOpList))
	{
		op = m_Token;
		GetToken();
		type2 = ParseSimpleExpression();
		/*
		if ( (typeResult == dtNUMBER) && (type2 == dtNUMBER) )
		typeResult = dtNUMBER;
		else
		*/
		typeResult = dtARRAY;
		m_Code.nOperator = op;
		PushCode();
	}
	return typeResult;
}

DWORD CFncParser::ParseSimpleExpression()
{
	DWORD typeResult, type2;
	TOKEN_CODE op;
	TOKEN_CODE unary_op = tPLUS;
	BOOL	bSawUnaryOp = false;

	if ((m_Token == tPLUS) || (m_Token == tMINUS))
	{
		unary_op = m_Token;
		bSawUnaryOp = true;
		if (m_Token == tMINUS)
		{
			m_Code.nOperator = tNUMBER;
			m_Code.fValue = 0;
			PushCode();
		}
		GetToken();
	}
	typeResult = ParseTerm();	// first term

	if (bSawUnaryOp && (typeResult != dtNUMBER) && (typeResult != dtARRAY))
		error(eInvalidDataType);
	else if (unary_op == tMINUS)
	{
		m_Code.nOperator = tMINUS;
		PushCode();
	}

	while (TokenIn(m_Token, AddOpList))
	{
		op = m_Token;
		GetToken();
		type2 = ParseTerm();
		switch (op)
		{
		case tPLUS:
		case tMINUS:
			if ((typeResult == dtNUMBER) && (type2 == dtNUMBER))
				typeResult = dtNUMBER;
			else if ((typeResult == dtARRAY) && (type2 == dtNUMBER) ||
				(typeResult == dtNUMBER) && (type2 == dtARRAY) ||
				(typeResult == dtARRAY) && (type2 == dtARRAY))
				typeResult = dtARRAY;
			else
			{
				error(eInvalidDataType); typeResult = dtDUMMY;
			}
			break;
		}
		m_Code.nOperator = op;
		PushCode();
	}
	return typeResult;
}

DWORD CFncParser::ParseTerm()
{
	DWORD typeResult, type2;
	TOKEN_CODE op;

	typeResult = ParseFactor();
	while (TokenIn(m_Token, MultiOpList))
	{
		op = m_Token;
		GetToken();
		type2 = ParseFactor();

		switch (op)
		{
		case tSTAR:
		case tSLASH:
			if ((typeResult == dtNUMBER) && (type2 == dtNUMBER))
				typeResult = dtNUMBER;
			else if ((typeResult == dtARRAY) && (type2 == dtNUMBER) ||
				(typeResult == dtNUMBER) && (type2 == dtARRAY) ||
				(typeResult == dtARRAY) && (type2 == dtARRAY))
				typeResult = dtARRAY;
			else
			{
				error(eInvalidDataType); typeResult = dtDUMMY;
			}
			break;
		}
		m_Code.nOperator = op;
		PushCode();
	}
	return typeResult;
}
DWORD CFncParser::ParseFactor()
{
	DWORD type;
	int nIndex;
	CSymtabNode* pId;

	switch (m_Token)
	{
	case tVARIABLE:
		nIndex = SearchSymtab(m_szWordString, itVARIABLE);
		pId = m_vSymtabs[nIndex];
		if (pId->m_itType != itVARIABLE)
		{
			error(eUndefinedIdentifier);
			type = dtARRAY;
		}
		else
			type = pId->m_DataType;
		m_Code.nOperator = tVARIABLE;
		m_Code.byte1 = (BYTE)nIndex;
		PushCode();
		GetToken();
		break;
	case tPARAM:
		type = dtNUMBER;
		m_Code.nOperator = tPARAM;
		m_Code.byte1 = (BYTE)m_nSymtabIndex;
		PushCode();
		GetToken();
		break;
	case tINNERFNC:
	{
		TOKEN_CODE fnc = m_fncType;
		type = ParseInnerFnc();
		m_Code.nOperator = fnc;
		PushCode();
	}
	//		GetToken(); 
	break;
	case tNUMBER:
		type = dtNUMBER;
		m_Code.nOperator = tNUMBER;
		m_Code.fValue = m_fNumber;
		PushCode();
		GetToken();
		break;
	case tLPAREN:
		GetToken();
		type = ParseExpression();
		IF_TOKEN_GET_ELSE_ERROR(tRPAREN, eUnmatchBracket);
		break;
	case tSTRING:
		type = dtSTRING;
		m_Code.nOperator = tSTRING;
		m_Code.byte1 = (BYTE)m_nStrIndex++;
		PushCode();
		GetToken();
		break;
	default:
		error(eSyntaxError);
		type = dtDUMMY;
		break;
	}
	return type;
}

void CFncParser::PushCode()
{
	m_Codes[m_nCodeSize].nOperator = m_Code.nOperator;
	m_Codes[m_nCodeSize].fValue = m_Code.fValue;
	m_nCodeSize++;
	m_Code.fValue = 0;
}
DWORD CFncParser::ParseInnerFnc()
{
	DWORD type;
	switch (m_fncType)
	{
	case tOPEN: case tCLOSE: case tHIGH: case tLOW: case tVOL: case tAMOUNT:
	case tDATE: case tHOUR: case tYEAR: case tMONTH: case tWEEKDAY: case tDAY: case tTIME: case tMINUTE:
	case tISDOWN: case tISEQUAL: case tISUP:
		type = dtARRAY;
		GetToken();
		break;
	case tBUYVOL: case tSELLVOL: case tISBUYORDER:
		type = dtNUMBER;
		GetToken();
		break;
	case tBIDPRICE: case tBIDVOL: case tASKPRICE: case tASKVOL:
    case tEXTDATA:
		type = ParseFncParams(1, dtNUMBER);
		break;
	case tATAN: case tACOS: case tASIN: case tTAN: case tCOS: case tSIN:
	case tSQRT: case tEXP: case tLN: case tLOG: case tSGN: case tABS: case tREVERSE:
	case tNOT:
	case tINTPART: case tCEILING: case tFLOOR:
		type = ParseFncParams(1, dtARRAY | dtNUMBER);
		break;
	case tBARSLAST: case tBARSSINCE: case tBARSCOUNT:
		type = ParseFncParams(1, dtARRAY);
		break;
	case tZIG:
		type = ParseFncParams(2, dtARRAY | dtNUMBER, dtNUMBER);
		break;
	case tEMA: case tMA:
	case tSLOPE: case tFORCAST: case tDEVSQ: case tAVEDEV: case tVARP: case tVAR: case tSTDP: case tSTD:
	case tFILTER:
		type = ParseFncParams(2, dtARRAY | dtNUMBER, dtNUMBER);
		break;
	case tPOW:
	case tSUMBARS: case tLLVBARS: case tHHVBARS:
	case tLLV: case tHHV: case tBACKSET:
	case tREF: case tREFX: case tSUM: case tCOUNT:
	case tMIN: case tMAX: case tMOD: case tDMA: case tCROSS:
		type = ParseFncParams(2, dtARRAY | dtNUMBER, dtARRAY | dtNUMBER);
		break;
	case tCOLORRGB://--cjw add new
	case tTROUGHBARS: case tTROUGH: case tPEAKBARS: case tPEAK:
		type = ParseFncParams(3, dtARRAY | dtNUMBER, dtNUMBER, dtNUMBER);
		break;
	case tSARTURN: case tSAR:
	case tIF:
	case tBETWEEN: case tRANGE:
		type = ParseFncParams(3, dtARRAY | dtNUMBER, dtARRAY | dtNUMBER, dtARRAY | dtNUMBER);
		break;
	case tSMA:
		type = ParseFncParams(3, dtARRAY, dtNUMBER, dtNUMBER);
		break;
	case tLONGCROSS:
		type = ParseFncParams(3, dtARRAY | dtNUMBER, dtARRAY | dtNUMBER, dtARRAY | dtNUMBER);
		break;
		////Draw Fnc
	case tDRAWICON:
		type = ParseFncParams(3, dtARRAY | dtNUMBER, dtARRAY | dtNUMBER, dtNUMBER);
		break;
	case tDRAWLINE:
		type = ParseFncParams(5, dtARRAY | dtNUMBER, dtARRAY | dtNUMBER, dtARRAY, dtARRAY | dtNUMBER, dtNUMBER);
		break;
	case tPOLYLINE:
		type = ParseFncParams(2, dtARRAY | dtNUMBER, dtARRAY | dtNUMBER);
		break;
		//--cjw add
	case tVERTLINE:
		type = ParseFncParams(1, dtARRAY | dtNUMBER);
		break;
	case tPARTLINE:
		type = ParseFncParams(2, dtARRAY | dtNUMBER, dtARRAY | dtNUMBER);
		break;
	case tDRAWGBK:
		type = ParseFncParams(4, dtARRAY | dtNUMBER, dtARRAY | dtNUMBER, dtARRAY | dtNUMBER, dtARRAY | dtNUMBER);
		break;
		//--cjw end
	case tSTICKLINE:
		type = ParseFncParams(5, dtARRAY | dtNUMBER, dtARRAY | dtNUMBER, dtARRAY | dtNUMBER, dtARRAY | dtNUMBER, dtNUMBER);
		break;
	case tDRAWTEXT:
		type = ParseFncParams(3, dtARRAY | dtNUMBER, dtARRAY | dtNUMBER, dtSTRING);
		break;
	case tDRAWNUMBER:
		type = ParseFncParams(4, dtARRAY | dtNUMBER, dtARRAY | dtNUMBER, dtARRAY | dtNUMBER, dtNUMBER);
		break;
	}

	return type;
}
DWORD CFncParser::ParseFncParams(int nParamNum, DWORD dt1, DWORD dt2, DWORD dt3, DWORD dt4, DWORD dt5, DWORD dt6)
{
	DWORD dtParam, dt;
	GetToken();
	if (m_Token == tLPAREN)
	{
		GetToken();
		dtParam = ParseExpression();
		if (!(dtParam & dt1))
			error(eInvalidDataType);

		for (int i = 2; i <= nParamNum; i++)
		{
			if (m_Token == tCOMMA)
			{
				GetToken();
				dtParam = ParseExpression();
				if (i == 2) dt = dt2;
				else if (i == 3) dt = dt3;
				else if (i == 4) dt = dt4;
				else if (i == 5) dt = dt5;
				else if (i == 6) dt = dt6;
				if (!(dtParam & dt))
				{
					error(eInvalidDataType);
				}
			}
			else
			{
				error(eParamNumError);
			}
		}
		//		if ( m_Token == tSTRING )
		//			GetToken();
		if (m_Token == tRPAREN) GetToken();
		else	error(eUnmatchBracket);
	}
	else
	{
		error(eParamNumError);
	}
	if (nParamNum == 2 && m_fncType == tCOUNT)
		return dtNUMBER;
	else if (nParamNum == 1 && m_fncType == tBARSLAST)
		return dtNUMBER;
	else
		return dtARRAY;
}
void CFncParser::CreateResult()
{
	CFormulaResultItem* pResultItem;
	CSymtabNode* pNode;
	for (int i = PARAM_NUM; i<m_vSymtabs.size(); i++)
	{
		pNode = m_vSymtabs[i];
		if (pNode->m_bOutput)
		{
			pResultItem = new CFormulaResultItem;
			strcpy_s(pResultItem->m_strName ,pNode->m_strName);
			pResultItem->m_nStyle = (WORD)(pNode->m_nStyle);
			pResultItem->m_nLineThick = (WORD)(pNode->m_nLineThick);
			pResultItem->m_nColor = pNode->m_nColor;
			m_pIndex->m_ResultItems.push_back(pResultItem);
		}
	}
	m_pIndex->m_strVarNames = m_strVarNames;
}
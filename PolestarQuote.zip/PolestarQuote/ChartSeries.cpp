#include "PreInclude.h"



TChartSeries::TChartSeries()
{
	m_PenId = 0;
	m_bAutoColor = true;
	m_type = CHART_TYPE;
}


TChartSeries::~TChartSeries()
{
	m_pKLineCtl = NULL;
	m_pLeftAxisY = NULL;
}
bool TChartSeries::GetVisibleMinMaxYValues(float& fMinValue, float& fMaxValue)
{
	bool isget(false);
	int curr = m_pKLineCtl->m_AxisX.Begin;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		double value = m_Data[curr];
		if (!isnan(value) && !isinf(value))
		{
			if (!isget)
			{
				fMinValue = value;
				fMaxValue = value;
				isget = true;
			}
			else
			{
				if (value > fMaxValue)
					fMaxValue = value;
				if (value < fMinValue)
					fMinValue = value;
			}
		}

		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	return false;
}

void TChartSeries::Draw(HDC mdc)
{
	if (!m_pKLineCtl)
		return;
	/*if (m_pLeftAxisY->MaxValue == m_pLeftAxisY->MinValue)
		return;*/
	//����
	SelectObject(mdc, PEN_SPEC_LINE[m_PenId]);

	bool move(false);
	int curr(m_pKLineCtl->m_AxisX.Begin);
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		double value = m_Data[curr];

		int i = (curr - m_pKLineCtl->m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		if (MAIN_CHART_TLINE == m_pKLineCtl->m_Contract.MainChart)
			i = curr;
		int pos = m_pKLineCtl->m_AxisX.DataPos[i];
		int width = m_pKLineCtl->m_AxisX.DataWidth[i];

		//�����������
		if (m_pKLineCtl->m_AxisX.Curr == curr&&!isnan(value))
		{
			wchar_t wPre[21] = {};
			swprintf_s(wPre, L"%%.%df", m_nParamPre);
			wchar_t wFormat[128] = {};
			swprintf_s(wFormat, L"%s %s", m_ParamName, wPre);
			swprintf_s(m_ParamValue, wFormat, value);
		}

		curr = (curr + 1) % MAX_SHOW_KLINE_X;
		if (isnan(value))
			continue;
		int x = m_ChartRect.left + pos + width / 2;
		double tmpValue = m_bPow ? value * m_pLeftAxisY->PrecPow : value;
		int y = 0;
		if (m_pLeftAxisY->MaxValue == m_pLeftAxisY->MinValue)
		{
			y = m_ChartRect.top + (m_ChartRect.bottom - m_ChartRect.top - 1) / 2;
		}
		else
		{
			y = m_ChartRect.top + (int)((m_pLeftAxisY->MaxValue - tmpValue)
				* (m_ChartRect.bottom - m_ChartRect.top - 1) / (m_pLeftAxisY->MaxValue - m_pLeftAxisY->MinValue));	//�߶ȼ�1�����߲��ܻ���bottom
		}

		if (!move)
		{
			MoveToEx(mdc, x, y, 0);
			move = true;
		}
		else
		{
			LineTo(mdc, x, y);
		}
	}//while
}

TKLineSeries::TKLineSeries()
{
	m_bAutoColor = false;
	m_type = KLINE_TYPE;
}

void TKLineSeries::Draw(HDC mdc)
{
	if (!m_pKLineCtl)
		return;
	if (m_nStyle == csTWR)
	{
		DrawTower(mdc);
		return;
	}
	RECT cbr = m_BottomRect;
	cbr.left += TKLineControl::PADDING_X;
	int curr(m_pKLineCtl->m_AxisX.Begin);
	TKLineShapeType& ks = G_QuoteUtils.KLineShapes[m_pKLineCtl->m_Contract.KLineShape];
	bool bFind = false;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		//�ײ��������-------------------------------------------------------
		if (m_pKLineCtl->m_AxisX.Curr == curr && cbr.bottom > cbr.top)
		{
			SHisQuoteData& pre_data = m_pKLineCtl->m_AxisX.KData.GetData(curr-1);
			DrawBottom(mdc, d, pre_data, cbr);
		}
		int i = (curr - m_pKLineCtl->m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		int pos = m_pKLineCtl->m_AxisX.DataPos[i];
		int width = m_pKLineCtl->m_AxisX.DataWidth[i];
		curr = (curr + 1) % MAX_SHOW_KLINE_X;

		if (m_nStyle == csPRICE)
		{
			SelectObject(mdc, PEN_TLINE_PRICE);
			int x = m_ChartRect.left + pos + width / 2;
			int y = m_pKLineCtl->m_Chart[0].YAxis_Price2Pix(d.QLastPrice);

			if (0 == i)
				MoveToEx(mdc, x, y, 0);
			else
				LineTo(mdc, x, y);
			continue;
		}
		//ѡ��ˢ�ͻ���
		HBRUSH brush(BRUSH_KLINE_BACKGROUND);
		bool drawline(false);
		if (abs(d.QOpeningPrice - d.QLastPrice) < m_pKLineCtl->m_Contract.Tick / 2)
		{
			SelectObject(mdc, PEN_KLINE_WHITE_BAR);
			drawline = true;
		}
		else
		{
			SelectObject(mdc, (d.QOpeningPrice < d.QLastPrice) ? PEN_KLINE_RED_BAR : PEN_KLINE_GREEN_BAR);
			brush = (d.QOpeningPrice < d.QLastPrice) ? BRUSH_KLINE_RED_BAR : BRUSH_KLINE_GREEN_BAR;
		}

		//�Ȼ������ͼ�����
		int x = m_ChartRect.left + pos + width / 2;
		int h = m_pKLineCtl->m_Chart[0].YAxis_Price2Pix(d.QHighPrice);
		int l = m_pKLineCtl->m_Chart[0].YAxis_Price2Pix(d.QLowPrice);
		
		if (m_nStyle == csUSA)
		{
			int nHalfBarWid = width / 2;
			if (nHalfBarWid>2)
				nHalfBarWid *= 0.9;
			if (nHalfBarWid == 0) nHalfBarWid = 1;
			//������
			if (h == l) l++;
			MoveToEx(mdc, x, h, 0);
			LineTo(mdc, x, l);

			int o = m_pKLineCtl->m_Chart[0].YAxis_Price2Pix(d.QOpeningPrice);
			int c = m_pKLineCtl->m_Chart[0].YAxis_Price2Pix(d.QLastPrice);

			MoveToEx(mdc, x - nHalfBarWid, o, 0);
			LineTo(mdc, x,o);
			MoveToEx(mdc, x, c, 0);
			LineTo(mdc, x+nHalfBarWid, c);
		}
		else
		{
			//������
			if (h < l)
			{
				MoveToEx(mdc, x, h, 0);
				LineTo(mdc, x, l);
			}

			//����
			if (ks.HasRect)
			{
				RECT r;
				r.left = m_ChartRect.left + pos + ks.LeftPadding;
				r.right = m_ChartRect.left + pos + width - ks.RightPadding;
				SPriceType top_price;
				SPriceType bottom_price;
				if (d.QOpeningPrice < d.QLastPrice)
				{
					top_price = d.QLastPrice;
					bottom_price = d.QOpeningPrice;
				}
				else
				{
					top_price = d.QOpeningPrice;
					bottom_price = d.QLastPrice;
				}
				r.top = m_pKLineCtl->m_Chart[0].YAxis_Price2Pix(top_price);
				r.bottom = m_pKLineCtl->m_Chart[0].YAxis_Price2Pix(bottom_price);

				if (drawline || r.top == r.bottom)	//ʮ����
				{
					MoveToEx(mdc, r.left, r.top, 0);
					LineTo(mdc, r.right, r.top);
				}
				else
				{
					if (d.QOpeningPrice < d.QLastPrice) //���ĺ�ɫ
					{
						FillRect(mdc, &r, BRUSH_KLINE_BACKGROUND);
						FrameRect(mdc, &r, brush);
					}
					else
					{
						FillRect(mdc, &r, brush);
					}
				}

			}//ks.HasRect
		}

		 //���ƽ���/����ָ���
		if(!bFind)
		    bFind = DrawTodayYestodayLine(mdc,d,pos);
	}
	//�������¼ۺ���
	DrawLastPriceLine(mdc);
	//������߼ۺ���ͼ�----------------------------------------------------------------------------------------------
	DrawScreenHighLowPrice(mdc);
}
void TKLineSeries::DrawTower(HDC mdc)
{
	RECT cbr = m_BottomRect;
	cbr.left += TKLineControl::PADDING_X;
	int yClose, nX;
	RECT rBar;   //������������
	double fLastHigh, fLastLow;
	int curr(m_pKLineCtl->m_AxisX.Begin);
	bool bFind = false;
	SHisQuoteData data = m_pKLineCtl->m_AxisX.KData.GetData(curr);

	bool bLastUp = data.QLastPrice > data.QOpeningPrice;
	if (bLastUp)
	{
		fLastHigh = data.QLastPrice;
		fLastLow = data.QOpeningPrice;
	}
	else
	{
		fLastLow = data.QLastPrice;
		fLastHigh = data.QOpeningPrice;
	}
	rBar.top = m_pKLineCtl->m_Chart[0].YAxis_Price2Pix(fLastHigh);
	rBar.bottom = m_pKLineCtl->m_Chart[0].YAxis_Price2Pix(fLastLow);
	/*SelectObject(bLastUp ? &penUp : &penDown);
	SelectObject(bLastUp ? &brushUp : &brushDown);
	Rectangle(nX - nBarWid*0.4, yHigh, nX + nBarWid*0.4 + 1, yLow);*/
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		//�ײ��������-------------------------------------------------------
		if (m_pKLineCtl->m_AxisX.Curr == curr && cbr.bottom > cbr.top)
		{
			SHisQuoteData& pre_data = m_pKLineCtl->m_AxisX.KData.GetData(curr-1);
			DrawBottom(mdc, d, pre_data, cbr);
		}
		int i = (curr - m_pKLineCtl->m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		int pos = m_pKLineCtl->m_AxisX.DataPos[i];
		int width = m_pKLineCtl->m_AxisX.DataWidth[i];
		curr = (curr + 1) % MAX_SHOW_KLINE_X;

		nX = m_ChartRect.left + pos + width / 2;
		rBar.left = nX - width*0.4;
		rBar.right = nX + width*0.4 + 1;

		yClose = m_pKLineCtl->m_Chart[0].YAxis_Price2Pix(d.QLastPrice);
		if (bLastUp)   //��һ������
		{
			if (d.QLastPrice > fLastHigh)
			{
				//������
				fLastLow = fLastHigh;	
				fLastHigh = d.QLastPrice;
				rBar.bottom = rBar.top;
				rBar.top = yClose;
			}
			else
			{
				if (d.QLastPrice >= fLastLow)
				{
					fLastLow = d.QLastPrice;
					rBar.bottom = yClose;
				}
				else
				{
					//����������͵�
					if (rBar.top == rBar.bottom)
					{
						MoveToEx(mdc, rBar.left, rBar.top,0);
						LineTo(mdc, rBar.right, rBar.bottom);
					}
					else
					{
						FillRect(mdc, &rBar, BRUSH_KLINE_BACKGROUND);
						FrameRect(mdc, &rBar, BRUSH_KLINE_RED_BAR);
					}
					bLastUp = FALSE;
					fLastHigh = fLastLow;	
					fLastLow = d.QLastPrice;
					rBar.top = rBar.bottom;
					rBar.bottom = yClose;
					SelectObject(mdc, PEN_KLINE_GREEN_BAR);
					SelectObject(mdc, BRUSH_KLINE_GREEN_BAR);
				}
			}
		}
		else
		{
			//��һ���µ�
			if (d.QLastPrice < fLastLow)
			{
				fLastHigh = fLastLow;
				fLastLow = d.QLastPrice;
				rBar.top = rBar.bottom;
				rBar.bottom = yClose;
			}
			else
			{
				if (d.QLastPrice <= fLastHigh)
				{
					fLastHigh = d.QLastPrice;
					rBar.top = yClose;
				}
				else
				{
					if (rBar.top == rBar.bottom)
					{
						MoveToEx(mdc, rBar.left, rBar.top,0);
						LineTo(mdc, rBar.right, rBar.bottom);
					}
					else
						FillRect(mdc, &rBar, BRUSH_KLINE_GREEN_BAR);
					bLastUp = TRUE;
					fLastLow = fLastHigh;
					fLastHigh = d.QLastPrice;
					rBar.bottom = rBar.top;
					rBar.top = yClose;
					SelectObject(mdc, PEN_KLINE_RED_BAR);
					SelectObject(mdc, BRUSH_KLINE_RED_BAR);
				}
			}
		}
		if (rBar.top == rBar.bottom)
		{
			MoveToEx(mdc, rBar.left, rBar.top, 0);
			LineTo(mdc, rBar.right, rBar.bottom);
		}
		else
		{
			if(bLastUp)//��
			{
				FillRect(mdc, &rBar, BRUSH_KLINE_BACKGROUND);
				FrameRect(mdc, &rBar, BRUSH_KLINE_RED_BAR);
			}
			else
			{
				FillRect(mdc, &rBar, BRUSH_KLINE_GREEN_BAR);
			}
		}
		//���ƽ���/����ָ���
		if (!bFind)
			bFind = DrawTodayYestodayLine(mdc, d, pos);
	}
	//�������¼ۺ���
	DrawLastPriceLine(mdc);
	//������߼ۺ���ͼ�----------------------------------------------------------------------------------------------
	DrawScreenHighLowPrice(mdc);
}
bool TKLineSeries::DrawTodayYestodayLine(HDC mdc, SHisQuoteData& d,int pos)
{
	bool bFind = false;
	if (m_pKLineCtl->m_bShowDevision)
	{
		SHisQuoteData dTail;
		if (G_StarApi->GetHisQuote(m_pKLineCtl->m_Contract.Cont->ContractNo, m_pKLineCtl->m_Contract.KLineType, m_pKLineCtl->m_Contract.KLineSlice, 1, 0, &dTail, 1) > 0)
		{
			if (d.TradeDate == dTail.TradeDate)
			{
				bFind = true;
				SelectObject(mdc, PEN_KLINE_GRAY_DOT);
				MoveToEx(mdc, m_ChartRect.left + pos, m_ChartRect.top, 0);
				LineTo(mdc, m_ChartRect.left + pos, m_ChartRect.bottom);
			}
		}
	}
	return bFind;
}
void TKLineSeries::DrawLastPriceLine(HDC mdc)
{
	//�ü�����begin
	HRGN rgn = CreateRectRgnIndirect(&m_ChartRect);
	int retr = SelectClipRgn(mdc, rgn);
	DeleteObject(rgn);
	SQuoteSnapShot* rq = m_pKLineCtl->m_Contract.Cont->SnapShot;
	if (rq&& m_pLeftAxisY->MinValue != m_pLeftAxisY->MaxValue)
	{
		SQuoteField* udLastPrice = &rq->Data[S_FID_LASTPRICE];

		SelectObject(mdc, PEN_KLINE_CYCLE);
		int h = m_pKLineCtl->m_Chart[0].YAxis_Price2Pix(udLastPrice->Price);
		MoveToEx(mdc, m_ChartRect.right - TKLineControl::LAST_PRICE_LINE_WIDTH, h, 0);
		LineTo(mdc, m_ChartRect.right, h);
	}
	SelectClipRgn(mdc, NULL);
}
void TKLineSeries::DrawScreenHighLowPrice(HDC mdc)
{
	SelectObject(mdc, FONT_KLINE_NUMBER);
	wchar_t wtext[128];
	SIZE size;
	RECT r;

	if (m_pKLineCtl->m_AxisX.Max != m_pKLineCtl->m_AxisX.End)
	{
		SetTextColor(mdc, COLOR_KLINE_RED_BAR);
		SelectObject(mdc, PEN_KLINE_RED_BAR_DOT);

		SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(m_pKLineCtl->m_AxisX.Max);
		FormatPrice(G_StarApi, d.QHighPrice, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, wtext, true);
		GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);

		int i = (m_pKLineCtl->m_AxisX.Max - m_pKLineCtl->m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		int pos = m_pKLineCtl->m_AxisX.DataPos[i];
		int width = m_pKLineCtl->m_AxisX.DataWidth[i];
		if (m_pLeftAxisY->MinValue == m_pLeftAxisY->MaxValue)
		{
			r.bottom = (m_ChartRect.top + m_ChartRect.bottom) / 2;
			r.top = r.bottom - TKLineControl::CHART_TEXT_HEIGHT;
		}
		else
		{
			r.bottom = m_ChartRect.top + (int)((m_pLeftAxisY->MaxValue - (long long)(d.QHighPrice * m_pLeftAxisY->PrecPow))
				* (m_ChartRect.bottom - m_ChartRect.top) / (m_pLeftAxisY->MaxValue - m_pLeftAxisY->MinValue));
			r.top = r.bottom - TKLineControl::CHART_TEXT_HEIGHT;
		}

		if (size.cx + TKLineControl::TEXT_GAP + 2 * TKLineControl::PADDING_X + TKLineControl::LINE_WIDTH < pos + width / 2)
		{
			r.right = m_ChartRect.left + pos + width / 2 - TKLineControl::TEXT_GAP - TKLineControl::LINE_WIDTH;
			r.left = r.right - size.cx - 2 * TKLineControl::PADDING_X;
			MoveToEx(mdc, r.right, (r.top + r.bottom) / 2, 0);
			LineTo(mdc, r.right + TKLineControl::TEXT_GAP, r.bottom);
		}
		else
		{
			r.left = m_ChartRect.left + pos + width / 2 + TKLineControl::TEXT_GAP + TKLineControl::LINE_WIDTH;
			r.right = r.left + size.cx + 2 * TKLineControl::PADDING_X;
			MoveToEx(mdc, r.left, (r.top + r.bottom) / 2, 0);
			LineTo(mdc, r.left - TKLineControl::TEXT_GAP,  r.bottom);
		}

		DrawText(mdc, wtext, wcslen(wtext), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
	}

	if (m_pKLineCtl->m_AxisX.Min != m_pKLineCtl->m_AxisX.End)
	{
		SetTextColor(mdc, COLOR_KLINE_GREEN_BAR);
		SelectObject(mdc, PEN_KLINE_GREEN_BAR_DOT);

		SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(m_pKLineCtl->m_AxisX.Min);
		FormatPrice(G_StarApi, d.QLowPrice, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, wtext, true);
		GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);

		int i = (m_pKLineCtl->m_AxisX.Min - m_pKLineCtl->m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		int pos = m_pKLineCtl->m_AxisX.DataPos[i];
		int width = m_pKLineCtl->m_AxisX.DataWidth[i];
		if (m_pLeftAxisY->MinValue == m_pLeftAxisY->MaxValue)
		{
			r.top = (m_ChartRect.top + m_ChartRect.bottom) / 2;
			r.bottom = r.top + TKLineControl::CHART_TEXT_HEIGHT;
		}
		else
		{
			r.top = m_ChartRect.top + (int)((m_pLeftAxisY->MaxValue - (long long)(d.QLowPrice * m_pLeftAxisY->PrecPow))
				* (m_ChartRect.bottom - m_ChartRect.top) / (m_pLeftAxisY->MaxValue - m_pLeftAxisY->MinValue));
			r.bottom = r.top + TKLineControl::CHART_TEXT_HEIGHT;
		}

		if (size.cx + TKLineControl::TEXT_GAP + 2 * TKLineControl::PADDING_X + TKLineControl::LINE_WIDTH < pos + width / 2)
		{
			r.right = m_ChartRect.left + pos + width / 2 - TKLineControl::TEXT_GAP - TKLineControl::LINE_WIDTH;
			r.left = r.right - size.cx - 2 * TKLineControl::PADDING_X;
			MoveToEx(mdc, r.right, (r.top + r.bottom) / 2, 0);
			LineTo(mdc, r.right + TKLineControl::TEXT_GAP, r.top);
		}
		else
		{
			r.left = m_ChartRect.left + pos + width / 2 + TKLineControl::TEXT_GAP + TKLineControl::LINE_WIDTH;
			r.right = r.left + size.cx + 2 * TKLineControl::PADDING_X;
			MoveToEx(mdc, r.left, (r.top + r.bottom) / 2, 0);
			LineTo(mdc, r.left - TKLineControl::TEXT_GAP, r.top);
		}

		DrawText(mdc, wtext, wcslen(wtext), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
	}

}
void TKLineSeries::DrawBottom(HDC mdc, SHisQuoteData& d, SHisQuoteData& pre_d, RECT& r)
{
	SIZE size;
	wchar_t wtext[128];

	//ʱ��
	SelectObject(mdc, FONT_KLINE_NUMBER);
	SetTextColor(mdc, COLOR_KLINE_WHITE_BAR);
	if (S_KLINE_DAY == m_pKLineCtl->m_Contract.KLineType)
		swprintf_s(wtext, L"%04d/%02d/%02d", d.TradeDate / 10000, d.TradeDate / 100 % 100, d.TradeDate % 100);
	else
	{
		SDateType date = (SDateType)(d.DateTimeStamp / 1000000000LL);
		STimeType time = (STimeType)(d.DateTimeStamp / 1000LL % 1000000LL);
		swprintf_s(wtext, L"%04d/%02d/%02d %02d:%02d:%02d", date / 10000, date / 100 % 100, date % 100,
			time / 10000, time / 100 % 100, time % 100);
	}

	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;

	//����
	r.left += TKLineControl::TEXT_GAP;
	SelectObject(mdc, FONT_KLINE_TEXT);
	SetTextColor(mdc, COLOR_KLINE_MENU_TEXT);
	wcsncpy_s(wtext, G_LANG->LangText(TLI_OPENING_TEXT), sizeof(wtext) / sizeof(wchar_t) - 1);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx + TKLineControl::PADDING_X;

	SelectObject(mdc, FONT_KLINE_NUMBER);
	FormatPrice(G_StarApi, d.QOpeningPrice, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, wtext, true);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;

	//���
	r.left += TKLineControl::TEXT_GAP;
	SelectObject(mdc, FONT_KLINE_TEXT);
	SetTextColor(mdc, COLOR_KLINE_RED_BAR);
	wcsncpy_s(wtext, G_LANG->LangText(TLI_HIGH_TEXT), sizeof(wtext) / sizeof(wchar_t) - 1);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx + TKLineControl::PADDING_X;

	SelectObject(mdc, FONT_KLINE_NUMBER);
	FormatPrice(G_StarApi, d.QHighPrice, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, wtext, true);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;

	//���
	r.left += TKLineControl::TEXT_GAP;
	SelectObject(mdc, FONT_KLINE_TEXT);
	SetTextColor(mdc, COLOR_KLINE_GREEN_BAR);
	wcsncpy_s(wtext, G_LANG->LangText(TLI_LOW_TEXT), sizeof(wtext) / sizeof(wchar_t) - 1);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx + TKLineControl::PADDING_X;

	SelectObject(mdc, FONT_KLINE_NUMBER);
	FormatPrice(G_StarApi, d.QLowPrice, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, wtext, true);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;

	//����
	r.left += TKLineControl::TEXT_GAP;
	SelectObject(mdc, FONT_KLINE_TEXT);
	if (abs(d.QLastPrice - d.QOpeningPrice) < m_pKLineCtl->m_Contract.Tick / 2)
		SetTextColor(mdc, COLOR_KLINE_WHITE_BAR);
	else
		SetTextColor(mdc, (d.QLastPrice > d.QOpeningPrice ? COLOR_KLINE_RED_BAR : COLOR_KLINE_GREEN_BAR));
	wcsncpy_s(wtext, G_LANG->LangText(TLI_NEW_TEXT), sizeof(wtext) / sizeof(wchar_t) - 1);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx + TKLineControl::PADDING_X;

	SelectObject(mdc, FONT_KLINE_NUMBER);
	FormatPrice(G_StarApi, d.QLastPrice, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, wtext, true);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;

	//�ɽ���
	r.left += TKLineControl::TEXT_GAP;
	SelectObject(mdc, FONT_KLINE_TEXT);
	SetTextColor(mdc, COLOR_KLINE_MENU_TEXT);
	wcsncpy_s(wtext, G_LANG->LangText(TLI_VOL_TEXT), sizeof(wtext) / sizeof(wchar_t) - 1);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx + TKLineControl::PADDING_X;

	SelectObject(mdc, FONT_KLINE_NUMBER);
	_i64tow_s(d.QKLineQty, wtext, sizeof(wtext) / sizeof(wchar_t), 10);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;

	//�ֲ���
	r.left += TKLineControl::TEXT_GAP;
	SelectObject(mdc, FONT_KLINE_TEXT);
	SetTextColor(mdc, COLOR_KLINE_MENU_TEXT);
	wcsncpy_s(wtext, G_LANG->LangText(TLI_POSITION_TEXT), sizeof(wtext) / sizeof(wchar_t) - 1);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx + TKLineControl::PADDING_X;

	SelectObject(mdc, FONT_KLINE_NUMBER);
	_i64tow_s(d.QPositionQty, wtext, sizeof(wtext) / sizeof(wchar_t), 10);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;

	//�ǵ�
	SPriceType priceDif = 0.0;
	if (m_pKLineCtl->m_AxisX.Curr != m_pKLineCtl->m_AxisX.KData.ReadIndex)
		priceDif = d.QLastPrice - pre_d.QLastPrice;
	r.left += TKLineControl::TEXT_GAP;
	SelectObject(mdc, FONT_KLINE_TEXT);
	if (abs(priceDif) < m_pKLineCtl->m_Contract.Tick / 2)
		SetTextColor(mdc, COLOR_KLINE_WHITE_BAR);
	else
		SetTextColor(mdc, (priceDif > 0 ? COLOR_KLINE_RED_BAR : COLOR_KLINE_GREEN_BAR));
	wcsncpy_s(wtext, G_LANG->LangText(TLI_UPDOWN_TEXT), sizeof(wtext) / sizeof(wchar_t) - 1);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx + TKLineControl::PADDING_X;

	SelectObject(mdc, FONT_KLINE_NUMBER);
	FormatPrice(G_StarApi, priceDif, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, wtext, true);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;
	//�Ƿ�
	r.left += TKLineControl::TEXT_GAP;
	SelectObject(mdc, FONT_KLINE_TEXT);
	if (abs(priceDif) < m_pKLineCtl->m_Contract.Tick / 2)
		SetTextColor(mdc, COLOR_KLINE_WHITE_BAR);
	else
		SetTextColor(mdc, (priceDif > 0 ? COLOR_KLINE_RED_BAR : COLOR_KLINE_GREEN_BAR));
	wcsncpy_s(wtext, G_LANG->LangText(TLI_UPRATE_TEXT), sizeof(wtext) / sizeof(wchar_t) - 1);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx + TKLineControl::PADDING_X;

	SelectObject(mdc, FONT_KLINE_NUMBER);
	if (pre_d.QLastPrice == 0)
	{
		wcsncpy_s(wtext, L"--", sizeof(wtext) / sizeof(wchar_t) - 1);
	}
	else
	{
		SPriceType pUprate = (priceDif) / pre_d.QLastPrice * 100;
		swprintf_s(wtext, L"%.2f%%", pUprate);
	}
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;
}
TTLineSeries::TTLineSeries() :TKLineSeries()
{
	m_type = TLINE_TYPE;
}
void TTLineSeries::Draw(HDC mdc)
{
	if (!m_pKLineCtl || m_pKLineCtl->m_Contract.IsSpread)
		return;
	if (/*m_pLeftAxisY->MaxValue <= 0 || */m_pLeftAxisY->MinValue == m_pLeftAxisY->MaxValue)	//�������Сֵ
		return;
	RECT ccr = m_ChartRect;
	RECT ctr = m_TopRect;
	ctr.left += TKLineControl::PADDING_X;
	RECT cbr = m_BottomRect;
	cbr.left += TKLineControl::PADDING_X;

	//�����������-------------------------------------------------------------------------
	if (ctr.bottom > ctr.top)
	{
		SelectObject(mdc, FONT_KLINE_TEXT);
		SetTextColor(mdc, COLOR_KLINE_WHITE_BAR);

		wchar_t wtext[128];
		wcsncpy_s(wtext, G_LANG->LangText(TLI_TRADING_DATE), sizeof(wtext) / sizeof(wchar_t));
		if (m_pKLineCtl->m_AxisX.TradeDate > 0)
			_ultow_s(m_pKLineCtl->m_AxisX.TradeDate, &wtext[wcslen(wtext)], 21, 10);

		DrawText(mdc, wtext, wcslen(wtext), &ctr, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	}

	//���Ƽ۸���-----------------------------------------------------------------------------------
	{
		SelectObject(mdc, PEN_TLINE_PRICE);

		int curr = m_pKLineCtl->m_AxisX.Begin;
		while (curr != m_pKLineCtl->m_AxisX.End)
		{
			SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);

			int i = (curr - m_pKLineCtl->m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
			int x = ccr.left + m_pKLineCtl->m_AxisX.DataPos[curr] + m_pKLineCtl->m_AxisX.DataWidth[curr] / 2;

			int y = ccr.top + (int)((ccr.bottom - ccr.top)
				* (m_pLeftAxisY->MaxValue - (long long)(d.QLastPrice * m_pLeftAxisY->PrecPow)) / (m_pLeftAxisY->MaxValue - m_pLeftAxisY->MinValue));

			if (0 == i)
				MoveToEx(mdc, x, y, 0);
			else
				LineTo(mdc, x, y);

			curr = (curr + 1) % MAX_SHOW_KLINE_X;
		}
	}


	//���ƾ���-------------------------------------------------------------------------------------
	{
		SelectObject(mdc, PEN_TLINE_AVG_PRICE);

		int curr = m_pKLineCtl->m_AxisX.Begin;
		SPriceType turnover(0);
		SQtyType qty(0);

		while (curr != m_pKLineCtl->m_AxisX.End)
		{
			SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
			int i = (curr - m_pKLineCtl->m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
			int x = ccr.left + m_pKLineCtl->m_AxisX.DataPos[curr] + m_pKLineCtl->m_AxisX.DataWidth[curr] / 2;

			if (d.QKLineQty > 0)
			{
				turnover += d.QLastPrice * d.QKLineQty;
				qty += d.QKLineQty;
			}
			d.QSettlePrice = turnover / qty;

			//����ײ�����------------------------------------------------------
			if (m_pKLineCtl->m_AxisX.Curr == curr && cbr.top < cbr.bottom)
			{
			     DrawBottom(mdc, d, cbr);
			}

			int y = ccr.top + (int)((ccr.bottom - ccr.top)
				* (m_pLeftAxisY->MaxValue - (long long)(d.QSettlePrice * m_pLeftAxisY->PrecPow)) / (m_pLeftAxisY->MaxValue - m_pLeftAxisY->MinValue));

			if (0 == i)
				MoveToEx(mdc, x, y, 0);
			else
				LineTo(mdc, x, y);

			curr = (curr + 1) % MAX_SHOW_KLINE_X;
		}
	}

}
void TTLineSeries::DrawRGBar(HDC mdc, TKChartSpec* pSpec)
{
	if (!m_pKLineCtl || m_pKLineCtl->m_Contract.IsSpread)
		return;
	if (pSpec&&pSpec->Visible && pSpec->Params[0].Value > 0 && pSpec->Params[1].Value > 0)
	{
		int param2 = pSpec->Params[0].Value;
		int param6 = pSpec->Params[1].Value;

		int middle = m_ChartRect.top + (m_ChartRect.bottom - m_ChartRect.top) / 2;

		//int i(0);
		int curr(m_pKLineCtl->m_AxisX.Begin);
		while (curr != m_pKLineCtl->m_AxisX.End)
		{
			int back(curr);
			SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
			int pos = m_pKLineCtl->m_AxisX.DataPos[curr];
			int width = m_pKLineCtl->m_AxisX.DataWidth[curr];
			//i++;
			curr = (curr + 1) % MAX_SHOW_KLINE_X;
			SPriceType turnover2(0);
			SQtyType qty2(0);
			SPriceType turnover6(0);
			SQtyType qty6(0);
			for (int j = 0; j < param6; j++)
			{
				SHisQuoteData& bd = m_pKLineCtl->m_AxisX.KData.GetData(back);

				if (j < param2)
				{
					turnover2 += bd.QLastPrice * bd.QKLineQty;
					qty2 += bd.QKLineQty;
				}

				turnover6 += bd.QLastPrice * bd.QKLineQty;
				qty6 += bd.QKLineQty;

				if (back == m_pKLineCtl->m_AxisX.KData.ReadIndex)
					break;

				back = (back + MAX_SHOW_KLINE_X - 1) % MAX_SHOW_KLINE_X;
			}

			int x = m_ChartRect.left + pos + width / 2;
			int y(middle);

			if (qty2 > 0 && qty6 > 0)
			{
				SPriceType s2(turnover2 / qty2);
				SPriceType s6(turnover6 / qty6);
				y += (int)(((m_ChartRect.bottom - m_ChartRect.top) * 2 * (s6 - s2) * m_pLeftAxisY->PrecPow) / (m_pLeftAxisY->MaxValue - m_pLeftAxisY->MinValue));
			}

			if (y < m_ChartRect.top)
				y = m_ChartRect.top;
			if (y > m_ChartRect.bottom)
				y = m_ChartRect.bottom;

			if (y != middle)
			{
				SelectObject(mdc, (y < middle) ? PEN_TLINE_RED_BAR : PEN_TLINE_GREEN_BAR);
				MoveToEx(mdc, x, middle, 0);
				LineTo(mdc, x, y);
			}
		}
	}
}
void TTLineSeries::DrawBottom(HDC mdc, SHisQuoteData& d,RECT& r)
{
	SIZE size;
	wchar_t wtext[128];

	//ʱ��
	SelectObject(mdc, FONT_KLINE_NUMBER);
	SetTextColor(mdc, COLOR_KLINE_WHITE_BAR);
	STimeType time = (STimeType)(d.DateTimeStamp / 1000LL % 1000000LL);
	swprintf_s(wtext, L"%02d:%02d:%02d", time / 10000, time / 100 % 100, time % 100);

	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;

	//����
	r.left += TKLineControl::TEXT_GAP;
	SelectObject(mdc, FONT_KLINE_TEXT);
	SetTextColor(mdc, COLOR_KLINE_WHITE_BAR);
	wcsncpy_s(wtext, G_LANG->LangText(TLI_TLINE_PRICE), sizeof(wtext) / sizeof(wchar_t) - 1);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx + TKLineControl::PADDING_X;

	SelectObject(mdc, FONT_KLINE_NUMBER);
	FormatPrice(G_StarApi, d.QLastPrice, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, wtext, true);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;

	//����
	r.left += TKLineControl::TEXT_GAP;
	SelectObject(mdc, FONT_KLINE_TEXT);
	SetTextColor(mdc, COLOR_TLINE_AVG_PRICE);
	wcsncpy_s(wtext, G_LANG->LangText(TLI_TLINE_AVG_PRICE), sizeof(wtext) / sizeof(wchar_t) - 1);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx + TKLineControl::PADDING_X;

	SelectObject(mdc, FONT_KLINE_NUMBER);
	FormatPrice(G_StarApi, d.QSettlePrice, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, wtext, true);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;

	//�ɽ���
	r.left += TKLineControl::TEXT_GAP;
	SelectObject(mdc, FONT_KLINE_TEXT);
	SetTextColor(mdc, COLOR_KLINE_MENU_TEXT);
	wcsncpy_s(wtext, G_LANG->LangText(TLI_VOL_TEXT), sizeof(wtext) / sizeof(wchar_t) - 1);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx + TKLineControl::PADDING_X;

	SelectObject(mdc, FONT_KLINE_NUMBER);
	_i64tow_s(d.QKLineQty, wtext, sizeof(wtext) / sizeof(wchar_t), 10);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;

	//�ֲ���
	r.left += TKLineControl::TEXT_GAP;
	SelectObject(mdc, FONT_KLINE_TEXT);
	SetTextColor(mdc, COLOR_KLINE_MENU_TEXT);
	wcsncpy_s(wtext, G_LANG->LangText(TLI_POSITION_TEXT), sizeof(wtext) / sizeof(wchar_t) - 1);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx + TKLineControl::PADDING_X;

	SelectObject(mdc, FONT_KLINE_NUMBER);
	_i64tow_s(d.QPositionQty, wtext, sizeof(wtext) / sizeof(wchar_t), 10);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;
	//�ǵ�
	SQuoteSnapShot* q(m_pKLineCtl->m_Contract.Cont->SnapShot);
	SPriceType preSetting = 0.0;
	if (q)
	{
		SQuoteField& field = q->Data[S_FID_PRESETTLEPRICE];
		if (S_FIDTYPE_NONE != field.FidAttr && field.Price > 0)
			preSetting = field.Price;
	}

	r.left += TKLineControl::TEXT_GAP;
	if (abs(d.QLastPrice - preSetting) < m_pKLineCtl->m_Contract.Tick / 2)
		SetTextColor(mdc, COLOR_KLINE_WHITE_BAR);
	else
		SetTextColor(mdc, (d.QLastPrice > preSetting ? COLOR_KLINE_RED_BAR : COLOR_KLINE_GREEN_BAR));
	wcsncpy_s(wtext, G_LANG->LangText(TLI_UPDOWN_TEXT), sizeof(wtext) / sizeof(wchar_t) - 1);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx + TKLineControl::PADDING_X;

	SelectObject(mdc, FONT_KLINE_NUMBER);
	FormatPrice(G_StarApi, d.QLastPrice - preSetting, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, wtext, true);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;
	//�Ƿ�
	r.left += TKLineControl::TEXT_GAP;
	if (abs(d.QLastPrice - preSetting) < m_pKLineCtl->m_Contract.Tick / 2)
		SetTextColor(mdc, COLOR_KLINE_WHITE_BAR);
	else
		SetTextColor(mdc, (d.QLastPrice > preSetting ? COLOR_KLINE_RED_BAR : COLOR_KLINE_GREEN_BAR));
	wcsncpy_s(wtext, G_LANG->LangText(TLI_UPRATE_TEXT), sizeof(wtext) / sizeof(wchar_t) - 1);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx + TKLineControl::PADDING_X;

	SelectObject(mdc, FONT_KLINE_NUMBER);
	if (preSetting == 0)
	{
		wcsncpy_s(wtext, L"--", sizeof(wtext) / sizeof(wchar_t) - 1);
	}
	else
	{
		SPriceType pUprate = (d.QLastPrice - preSetting) / preSetting * 100;
		swprintf_s(wtext, L"%.2f%%", pUprate);
	}
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;
}
TTickSeries::TTickSeries():TKLineSeries()
{
	m_type = TICK_TYPE;
}
void TTickSeries::Draw(HDC mdc)
{
	if (!m_pKLineCtl)
		return;
	SelectObject(mdc, PEN_TLINE_PRICE);
	RECT cbr = m_BottomRect;
	cbr.left += TKLineControl::PADDING_X;
	int curr = m_pKLineCtl->m_AxisX.Begin;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);

		int i = (curr - m_pKLineCtl->m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		int x = m_ChartRect.left + m_pKLineCtl->m_AxisX.DataPos[i] + m_pKLineCtl->m_AxisX.DataWidth[i]/2;

		int y = 0;
		if (m_pLeftAxisY->MaxValue != m_pLeftAxisY->MinValue)
			y = m_ChartRect.top + (int)((m_ChartRect.bottom - m_ChartRect.top) * (m_pLeftAxisY->MaxValue - (long long)(d.QLastPrice * m_pLeftAxisY->PrecPow)) / (m_pLeftAxisY->MaxValue - m_pLeftAxisY->MinValue));
		else
			y = (m_ChartRect.bottom + m_ChartRect.top) / 2;

		if (0 == i)
			MoveToEx(mdc, x, y, 0);
		else
			LineTo(mdc, x, y);
		//����ײ�����------------------------------------------------------
		if (m_pKLineCtl->m_AxisX.Curr == curr && cbr.top < cbr.bottom)
		{
			SHisQuoteData& pre_data = m_pKLineCtl->m_AxisX.KData.GetData(curr-1);
			DrawBottom(mdc, d, pre_data, cbr);
		}
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	//�������¼ۺ���
	DrawLastPriceLine(mdc);
}
void TTickSeries::DrawBottom(HDC mdc, SHisQuoteData& d, SHisQuoteData& pre_d, RECT& r)
{
	if (!m_pKLineCtl)
		return;
	SIZE size;
	wchar_t wtext[128];

	//ʱ��
	SelectObject(mdc, FONT_KLINE_NUMBER);
	SetTextColor(mdc, COLOR_KLINE_WHITE_BAR);
	SDateType date = (SDateType)(d.DateTimeStamp / 1000000000LL);
	STimeType time = (STimeType)(d.DateTimeStamp / 1000LL % 1000000LL);
	swprintf_s(wtext, L"%04d/%02d/%02d %02d:%02d:%02d", date / 10000, date / 100 % 100, date % 100,
		time / 10000, time / 100 % 100, time % 100);

	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;

	//����
	r.left += TKLineControl::TEXT_GAP;
	SelectObject(mdc, FONT_KLINE_TEXT);
	SetTextColor(mdc, COLOR_KLINE_WHITE_BAR);
	wcsncpy_s(wtext, G_LANG->LangText(TLI_TICK_PRICE), sizeof(wtext) / sizeof(wchar_t) - 1);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx + TKLineControl::PADDING_X;

	SelectObject(mdc, FONT_KLINE_NUMBER);
	SCommodityPrecType	Prec = m_pKLineCtl->m_Contract.Prec;
	if (m_pKLineCtl->m_Contract.IsSpread)
		Prec = m_pKLineCtl->m_Contract.SpreadPrec;
	FormatPrice(G_StarApi, d.QLastPrice, Prec, m_pKLineCtl->m_Contract.Deno, wtext, true);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;

	if (!m_pKLineCtl->m_Contract.IsSpread)
	{
		//����
		r.left += TKLineControl::TEXT_GAP;
		SelectObject(mdc, FONT_KLINE_TEXT);
		SetTextColor(mdc, COLOR_KLINE_MENU_TEXT);
		wcsncpy_s(wtext, G_LANG->LangText(TLI_TLINE_AVG_PRICE), sizeof(wtext) / sizeof(wchar_t) - 1);
		DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
		GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
		r.left += size.cx + TKLineControl::PADDING_X;

		SelectObject(mdc, FONT_KLINE_NUMBER);
		FormatPrice(G_StarApi, d.QSettlePrice, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, wtext, true);
		DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
		GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
		r.left += size.cx;
	}
	//����
	r.left += TKLineControl::TEXT_GAP;
	SelectObject(mdc, FONT_KLINE_TEXT);
	SetTextColor(mdc, COLOR_KLINE_WHITE_BAR);
	wcsncpy_s(wtext, G_LANG->LangText(TLI_NEWVOL_TEXT), sizeof(wtext) / sizeof(wchar_t) - 1);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx + TKLineControl::PADDING_X;

	SelectObject(mdc, FONT_KLINE_NUMBER);
	_ultow_s(d.QLastQty, wtext, sizeof(wtext) / sizeof(wchar_t), 10);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;

	//����
	r.left += TKLineControl::TEXT_GAP;
	SelectObject(mdc, FONT_KLINE_TEXT);
	SetTextColor(mdc, COLOR_KLINE_MENU_TEXT);
	wcsncpy_s(wtext, G_LANG->LangText(TLI_TICK_HOLDCHG), sizeof(wtext) / sizeof(wchar_t) - 1);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx + TKLineControl::PADDING_X;

	SelectObject(mdc, FONT_KLINE_NUMBER);
	_itow_s(d.QPositionChg, wtext, sizeof(wtext) / sizeof(wchar_t), 10);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;
	//�ǵ�
	r.left += TKLineControl::TEXT_GAP;
	SelectObject(mdc, FONT_KLINE_TEXT);
	if (abs(d.QLastPrice - pre_d.QLastPrice) < m_pKLineCtl->m_Contract.Tick / 2)
		SetTextColor(mdc, COLOR_KLINE_WHITE_BAR);
	else
		SetTextColor(mdc, (d.QLastPrice > pre_d.QLastPrice ? COLOR_KLINE_RED_BAR : COLOR_KLINE_GREEN_BAR));
	wcsncpy_s(wtext, G_LANG->LangText(TLI_UPDOWN_TEXT), sizeof(wtext) / sizeof(wchar_t) - 1);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx + TKLineControl::PADDING_X;

	SelectObject(mdc, FONT_KLINE_NUMBER);
	FormatPrice(G_StarApi, d.QLastPrice - pre_d.QLastPrice, m_pKLineCtl->m_Contract.Prec, m_pKLineCtl->m_Contract.Deno, wtext, true);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;
	//�Ƿ�
	r.left += TKLineControl::TEXT_GAP;
	SelectObject(mdc, FONT_KLINE_TEXT);
	if (abs(d.QLastPrice - pre_d.QLastPrice) < m_pKLineCtl->m_Contract.Tick / 2)
		SetTextColor(mdc, COLOR_KLINE_WHITE_BAR);
	else
		SetTextColor(mdc, (d.QLastPrice > pre_d.QLastPrice ? COLOR_KLINE_RED_BAR : COLOR_KLINE_GREEN_BAR));
	wcsncpy_s(wtext, G_LANG->LangText(TLI_UPRATE_TEXT), sizeof(wtext) / sizeof(wchar_t) - 1);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx + TKLineControl::PADDING_X;

	SelectObject(mdc, FONT_KLINE_NUMBER);
	if (pre_d.QLastPrice == 0)
	{
		wcsncpy_s(wtext, L"--", sizeof(wtext) / sizeof(wchar_t) - 1);
	}
	else
	{
		SPriceType pUprate = (d.QLastPrice - pre_d.QLastPrice) / pre_d.QLastPrice * 100;
		swprintf_s(wtext, L"%.2f%%", pUprate);
	}
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
	r.left += size.cx;
}
TSpreadSeries::TSpreadSeries():TTickSeries()
{
}
void TSpreadSeries::Draw(HDC mdc)
{
	if (!m_pKLineCtl)
		return;
	SelectObject(mdc, PEN_TLINE_PRICE);
	RECT cbr = m_BottomRect;
	cbr.left += TKLineControl::PADDING_X;
	int curr = m_pKLineCtl->m_AxisX.Begin;
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);

		int i = (curr - m_pKLineCtl->m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		int x = m_ChartRect.left + m_pKLineCtl->m_AxisX.DataPos[i] + m_pKLineCtl->m_AxisX.DataWidth[i];
		//����ײ�����------------------------------------------------------
		if (m_pKLineCtl->m_AxisX.Curr == curr && cbr.top < cbr.bottom)
		{
			SHisQuoteData& pre_data = m_pKLineCtl->m_AxisX.KData.GetData(curr - 1);
			DrawBottom(mdc, d, pre_data, cbr);
		}
		int y = 0;
		if (m_pLeftAxisY->MaxValue != m_pLeftAxisY->MinValue)
			y = m_ChartRect.top + (int)((m_ChartRect.bottom - m_ChartRect.top) * (m_pLeftAxisY->MaxValue - (long long)(d.QLastPrice * m_pLeftAxisY->PrecPow)) / (m_pLeftAxisY->MaxValue - m_pLeftAxisY->MinValue));
		else
			y = (m_ChartRect.bottom + m_ChartRect.top) / 2;

		if (0 == i)
			MoveToEx(mdc, x, y, 0);
		else
			LineTo(mdc, x, y);

		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
}
TBarSeries::TBarSeries()
{
	m_bAutoColor = false;
}
void TBarSeries::Draw(HDC mdc)
{
	TKLineTagLine& tag = m_pLeftAxisY->TagLine[0];
	if (!tag.ShowDotLine)
	   return;
	if (m_pLeftAxisY->MaxValue == m_pLeftAxisY->MinValue)
	   return;
	int curr(m_pKLineCtl->m_AxisX.Begin);
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		double value = m_Data[curr];
		int i = (curr - m_pKLineCtl->m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		if (MAIN_CHART_TLINE == m_pKLineCtl->m_Contract.MainChart)
			i = curr;
		int pos = m_pKLineCtl->m_AxisX.DataPos[i];
		int width = m_pKLineCtl->m_AxisX.DataWidth[i];

		//�����������
		if (m_pKLineCtl->m_AxisX.Curr == curr)
		{
			m_Color = value > 0 ? COLOR_KLINE_RED_BAR : COLOR_KLINE_GREEN_BAR;
			wchar_t wPre[21] = {};
			swprintf_s(wPre, L"%%.%df", m_nParamPre);
			wchar_t wFormat[128] = {};
			swprintf_s(wFormat, L"%s %s", m_ParamName, wPre);
			swprintf_s(m_ParamValue, wFormat, value);	
		}

		curr = (curr + 1) % MAX_SHOW_KLINE_X;

		SelectObject(mdc, (value > 0 ? PEN_KLINE_RED_BAR : PEN_KLINE_GREEN_BAR));
		//�Ȼ������ͼ�����
		int x = m_ChartRect.left + pos + width / 2;
		double tmpValue = m_bPow ? value * m_pLeftAxisY->PrecPow : value;
		int y = m_ChartRect.top + (int)((m_pLeftAxisY->MaxValue - tmpValue)
			* (m_ChartRect.bottom - m_ChartRect.top) / (m_pLeftAxisY->MaxValue - m_pLeftAxisY->MinValue));

		MoveToEx(mdc, x, m_ChartRect.top + tag.Pixel, 0);
		LineTo(mdc, x, y);
	}//while
}

TVolumeSeries::TVolumeSeries()
{
	m_bAutoColor = false;
}
void TVolumeSeries::Draw(HDC mdc)
{
	/*if (m_pLeftAxisY->MaxValue <= 0)
		return;*/
	bool istick = m_pKLineCtl->m_Contract.IsTick();
	TKLineShapeType& ks = G_QuoteUtils.KLineShapes[m_pKLineCtl->m_Contract.KLineShape];
	int pre(m_pKLineCtl->m_AxisX.Begin);
	int curr(m_pKLineCtl->m_AxisX.Begin);
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		SHisQuoteData& pd = m_pKLineCtl->m_AxisX.KData.GetData(pre);
		SHisQuoteData& d = m_pKLineCtl->m_AxisX.KData.GetData(curr);
		int i = (curr - m_pKLineCtl->m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		if (MAIN_CHART_TLINE == m_pKLineCtl->m_Contract.MainChart)
			i = curr;
		int pos = m_pKLineCtl->m_AxisX.DataPos[i];
		int width = m_pKLineCtl->m_AxisX.DataWidth[i];

		//�����������
		if (m_pKLineCtl->m_AxisX.Curr == curr)
		{
			if (istick)
			{
				m_Color = d.QLastPrice >= pd.QLastPrice ? COLOR_KLINE_RED_BAR : COLOR_KLINE_GREEN_BAR;
				swprintf_s(m_ParamValue, L"VOL %u", d.QLastQty);
			}
			else
			{
				m_Color = d.QLastPrice >= d.QOpeningPrice ? COLOR_KLINE_RED_BAR : COLOR_KLINE_GREEN_BAR;
				swprintf_s(m_ParamValue, L"VOL %lld", d.QKLineQty);
			}
		}
		pre = curr;
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
		HBRUSH brush(BRUSH_KLINE_BACKGROUND);
		if (istick)
		{
			SelectObject(mdc, (d.QLastPrice >= pd.QLastPrice ? PEN_KLINE_RED_BAR : PEN_KLINE_GREEN_BAR));
			brush = (d.QLastPrice >= pd.QLastPrice) ? BRUSH_KLINE_RED_BAR : BRUSH_KLINE_GREEN_BAR;
		}
		else
		{
            SelectObject(mdc, (d.QLastPrice >= d.QOpeningPrice ? PEN_KLINE_RED_BAR : PEN_KLINE_GREEN_BAR));
			brush = (d.QOpeningPrice <= d.QLastPrice) ? BRUSH_KLINE_RED_BAR : BRUSH_KLINE_GREEN_BAR;
		}
			

		//�Ȼ������ͼ�����
		int x = m_ChartRect.left + pos + width / 2;
		int y = m_ChartRect.top + (int)((m_pLeftAxisY->MaxValue - (istick ? d.QLastQty : d.QKLineQty))
			* (m_ChartRect.bottom - m_ChartRect.top) / m_pLeftAxisY->MaxValue);

		MoveToEx(mdc, x, y, 0);
		LineTo(mdc, x, m_ChartRect.bottom);
		//����
		if (ks.HasRect&&MAIN_CHART_TLINE != m_pKLineCtl->m_Contract.MainChart&&!istick)
		{
			RECT r;
			r.left = m_ChartRect.left + pos + ks.LeftPadding;
			r.right = m_ChartRect.left + pos + width - ks.RightPadding;
			r.top = y;
			r.bottom = m_ChartRect.bottom;

			if (d.QLastPrice>=  d.QOpeningPrice) //���ĺ�ɫ
			{
				FillRect(mdc, &r, BRUSH_KLINE_BACKGROUND);
				FrameRect(mdc, &r, brush);
			}
			else
			{
				FillRect(mdc, &r, brush);
			}

		}//ks.HasRect
	}//while
}

TPointSeries::TPointSeries()
{
}

void  TPointSeries::Draw(HDC mdc)
{
	int curr(m_pKLineCtl->m_AxisX.Begin);
	while (curr != m_pKLineCtl->m_AxisX.End)
	{
		int i = (curr - m_pKLineCtl->m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		int pos = m_pKLineCtl->m_AxisX.DataPos[i];
		int width = m_pKLineCtl->m_AxisX.DataWidth[i];
		int nRadio = width / 2;
		double value = m_Data[curr];
		int x = m_ChartRect.left + pos + width / 2;

		if (m_pKLineCtl->m_AxisX.Curr == curr)
		{
			wchar_t wPre[21] = {};
			swprintf_s(wPre, L"%%.%df", m_nParamPre);
			wchar_t wFormat[128] = {};
			swprintf_s(wFormat, L"%s %s", m_ParamName, wPre);
			swprintf_s(m_ParamValue, wFormat, value);
		}
		int y = 0;
		if (m_pLeftAxisY->MinValue != m_pLeftAxisY->MaxValue)
			y = m_ChartRect.top + (int)((m_pLeftAxisY->MaxValue - (m_pLeftAxisY->PrecPow * value)) * (m_ChartRect.bottom - m_ChartRect.top) / (m_pLeftAxisY->MaxValue - m_pLeftAxisY->MinValue));
		else
			y = (m_ChartRect.bottom + m_ChartRect.top) / 2;
		HPEN hPen = CreatePen(PS_SOLID, 1, m_ArrColor[curr]);
		HBRUSH hBrush = CreateSolidBrush(m_ArrColor[curr]);
		SelectObject(mdc, hPen);
		SelectObject(mdc, hBrush);
		if (nRadio < 3)
			Ellipse(mdc, x - 1, y - 1, x + 1, y + 1);
		else
			Ellipse(mdc, x - nRadio, y - nRadio / 3, x + nRadio, y + nRadio / 3);
		DeleteBrush(hBrush);
		DeletePen(hPen);
		curr = (curr + 1) % MAX_SHOW_KLINE_X;

	}//while
}

TKChartSpec::TKChartSpec():m_pIndex(NULL)
{

}

TKChartSpec::~TKChartSpec()
{

}

void TKChartSpec::Draw(HDC mdc)
{
	for (size_t i = 0; i < m_VSeries.size(); i++)
	{
		TChartSeries* pSeries = m_VSeries[i];
		if (pSeries)
		{
			if (pSeries->m_type != CHART_TYPE)
			{
				pSeries->Draw(mdc);
				if (pSeries->m_type == TLINE_TYPE)
				{
					TTLineSeries* pTLine = dynamic_cast<TTLineSeries*>(pSeries);
					if (pTLine)
						pTLine->DrawRGBar(mdc, this);
				}
			}
			else
			{
				//�ü�����begin
				HRGN rgn = CreateRectRgnIndirect(&pSeries->m_ChartRect);
				int retr = SelectClipRgn(mdc, rgn);
				DeleteObject(rgn);
				pSeries->Draw(mdc);
				//�ָ��ü�����
				SelectClipRgn(mdc, NULL);
			}
			
		}
	}
}
void TKChartSpec::ClearAllSeries()
{
	for (size_t i = 0; i<m_VSeries.size(); i++)
		delete m_VSeries[i];
	m_VSeries.clear();
}

bool TKChartSpec::CalcVisibleMinMaxYValues()
{
	float fMin, fMax;
	m_fVisibleMinYValue = FLT_MAX;
	m_fVisibleMaxYValue = -FLT_MAX;//����������ֵ����Сֵû�б�ָ�������û���ߴ��ڵĻ�
	BOOL result = false;
	for (size_t i = 0; i<m_VSeries.size(); i++)
	{
		if (m_VSeries[i]->GetVisibleMinMaxYValues(fMin, fMax))
		{
			if (fMin<m_fVisibleMinYValue) m_fVisibleMinYValue = fMin;
			if (fMax>m_fVisibleMaxYValue) m_fVisibleMaxYValue = fMax;
			result = true;
		}
	}
	return result;
}

void TKChartSpec::DrawLegend(HDC mdc, RECT& rc)
{
	for (size_t i = 0; i < m_VSeries.size(); i++)
	{
		TChartSeries* pSeries = m_VSeries[i];
		if (pSeries)
		{
			//�����������
			if (L'\0' != pSeries->m_ParamValue[0])
			{
				SelectObject(mdc, FONT_KLINE_NUMBER);
				if(pSeries->m_bAutoColor)
				    SetTextColor(mdc, COLOR_SPEC_LINE[pSeries->m_PenId]);
				else
					SetTextColor(mdc, pSeries->m_Color);
				DrawText(mdc, pSeries->m_ParamValue, wcslen(pSeries->m_ParamValue), &rc, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
				SIZE size;
				GetTextExtentPoint(mdc, pSeries->m_ParamValue, wcslen(pSeries->m_ParamValue), &size);
				rc.left += size.cx + TKLineControl::TEXT_GAP;
			}
		}
	}
}

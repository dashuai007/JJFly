#include "PreInclude.h"



TShapeChart::TShapeChart():m_pCurShapePen(NULL), m_pKLine(NULL),m_clrPen(RGB(255, 255, 0)),m_penWid(1),m_pCurShape(NULL), m_nSelShap(-1)
{
}


TShapeChart::~TShapeChart()
{
	DeleteAlleShape();
}
void TShapeChart::SelectDrawTool(SHAPE_TYPE type, TKLineChart* pChart, TKLineAxisX* pAxisX)
{
	if (m_pCurShapePen&&m_pCurShapePen->GetType() == type)
		return;
	DeleteShapePen();
	m_pCurShapePen = G_ShapeFactory()->CreatePen(m_pKLine->GetWindow()->GetHwnd(), type,pChart,pAxisX);
	if (m_pKLine)
		m_pKLine->TrackMouseLeave();
}
void TShapeChart::DrawChart(HDC mdc)
{
	if (!m_pKLine)
		return;
	RECT rtCent = m_pKLine->m_Chart[0].CenterChartRect;
	HRGN rgn = CreateRectRgnIndirect(&rtCent);
	int retr = SelectClipRgn(mdc, rgn);
	DeleteObject(rgn);
	for (int i = 0; i < m_arrShape.size(); i++)
	{
		m_arrShape[i]->ResetAxis();
		m_arrShape[i]->BeginDraw(mdc);
		m_arrShape[i]->Draw(mdc);
		m_arrShape[i]->EndDraw(mdc);
	}
	//����Ƥ��
	if (m_pCurShapePen)
	{
		m_pCurShapePen->Draw(mdc);
	}
	//�ָ��ü�����
	SelectClipRgn(mdc, NULL);
}
bool TShapeChart::OnMouseMove(POINTS& pts)
{
	POINT pt;
	POINTSTOPOINT(pt, pts);
	if (m_pCurShapePen)
	{
		m_pKLine->SetCurrCursor(CURSOR_LINE);
		return true;
	}
	if (m_pCurShape)
	{
		if (m_pCurShape->IsSizing())
			m_pKLine->SetCurrCursor(CURSOR_ESW);
		else
			m_pKLine->SetCurrCursor(CURSOR_ALL);
		m_pCurShape->OnMove(pt);
		return true;
	}
	else
	{
		bool bRefrush = false;
		int cnt = m_arrShape.size();
		for (int i = 0; i<cnt; i++)
		{
			int ret = m_arrShape[i]->HitTest(pt);
			if (ret != -1)
			{
				if (ret == -2)
				{
					m_pKLine->SetCurrCursor(CURSOR_HAND_POINT);
				}
				else if (ret >= 0)
				{
					m_pKLine->SetCurrCursor(CURSOR_HAND_MOVE);
				}
				m_arrShape[i]->SetHot(TRUE);
				bRefrush = true;
			}
			else
			{
				m_arrShape[i]->SetHot(FALSE);
			}
		}
		if (bRefrush)
			return true;
	}
	return false;
}
bool TShapeChart::OnLButtonDown(POINTS& pts)
{
	POINT pt;
	POINTSTOPOINT(pt, pts);
	if (m_pCurShapePen)
	{
		if (m_pKLine&&GetShapeSize() >= 10)
		{
			MessageBox(m_pKLine->GetWindow()->GetHwnd(), G_LANG->LangText(TLI_MAX_SHAPES_NUMBER), G_LANG->LangText(TLI_TIPINFO), MB_ICONINFORMATION);
			DeleteShapePen();
			if (g_pDrawTool)
				g_pDrawTool->SetSelectedShape(SHAPE_NONE);
			return true;
		}
		m_pCurShapePen->OnClick(pt);
		AfterShapePenClick();
		return true;
	}
	if (m_pCurShape != NULL)
	{
		m_pCurShape->OnClick(pt);
		m_pCurShape = NULL;
		return true;
	}
	else
	{
		int cnt = m_arrShape.size();
		for (int i = cnt - 1; i >= 0; i--)
		{
			m_arrShape[i]->OnClick(pt);
			if (m_arrShape[i]->IsSelected())
			{
				/*if (m_curPen == doDELETE)
				{
					if (m_pCurShape == m_arrShape[i])
					{
						m_pCurShape = NULL;
					}
					delete m_arrShape[i];
					m_arrShape.RemoveAt(i);
				}
				else*/
				{
					m_pCurShape = m_arrShape[i];
				}

				return true;
			}
		}
	}
	return false;
}
bool TShapeChart::OnRButtonDown(POINTS& pts)
{
	POINT pt;
	POINTSTOPOINT(pt, pts);
	int cnt = m_arrShape.size();
	for (int i = 0; i<cnt; i++)
	{
		int ret = m_arrShape[i]->HitTest(pt);
		if (ret != -1)
		{
			m_nSelShap = i;
			return true;
		}
	}
	return false;
}
void TShapeChart::ResetShape()
{
	for (int i = 0; i < m_arrShape.size(); i++)
	{
		m_arrShape[i]->ResetXAxis();
	}
}
void TShapeChart::AfterShapePenClick()
{
	if (m_pCurShapePen)
	{
		if (m_pCurShapePen->IsOk())
		{
			{
				std::vector<ChartDot> arr;
				m_pCurShapePen->GetData(arr);
				TShape *pShape = G_ShapeFactory()->CreateShape(m_pCurShapePen->GetType(), &m_pKLine->m_Chart[0], &m_pKLine->m_AxisX, arr, m_clrPen, m_penWid);
				m_arrShape.push_back(pShape);
				DeleteShapePen();
				((TQuoteFrame*)m_pKLine->GetWindow())->SaveCfg();
				m_pKLine->SetCurrCursor(CURSOR_ARROW);
				if (g_pDrawTool)
				{
					g_pDrawTool->SetSelectedShape(SHAPE_NONE);
				}
			}
		}
	}
}

void TShapeChart::DeleteShapePen()
{
	if (m_pCurShapePen != NULL)
	{
		delete m_pCurShapePen;
		m_pCurShapePen = NULL;
	}
}
void TShapeChart::DeleteSingleShape()
{
	if (m_nSelShap < 0 || m_nSelShap >= m_arrShape.size())
		return;
	if (m_pCurShape == m_arrShape[m_nSelShap])
	{
		m_pCurShape = NULL;
	}
	delete m_arrShape[m_nSelShap];
	m_arrShape.erase(m_arrShape.begin()+ m_nSelShap);
}
void TShapeChart::GetShapeArray(std::vector<TShape*>& arr)
{
	arr.clear();
	std::copy(m_arrShape.begin(), m_arrShape.end(), std::back_inserter(arr));
	m_arrShape.clear();
}
void TShapeChart::SetArrShape(std::vector<TShape*>& arrShape)
{
	m_arrShape.clear();
	std::copy(arrShape.begin(), arrShape.end(), std::back_inserter(m_arrShape));
	ResetShape();
	arrShape.clear();
}
void TShapeChart::DeleteAlleShape()
{
	for (size_t i = 0; i<m_arrShape.size(); i++)
	{
		delete m_arrShape[i];
		m_arrShape[i] = NULL;
	}
	m_arrShape.clear();

	if (m_pCurShapePen)
	{
		delete m_pCurShapePen;
		m_pCurShapePen = NULL;
	}
	if(m_pCurShape)
		m_pCurShape = NULL;
}
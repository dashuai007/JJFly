#ifndef _TSTATICBUTTON_H
#define _TSTATICBUTTON_H

typedef UINT(CALLBACK* LPGNDLLFUNC)(HDC, CONST PTRIVERTEX, DWORD, CONST PVOID, DWORD, DWORD);
class TStaticButton : public TIxFrm
{
public:
	TStaticButton(int nstyle = BTN_NORMAL);
	~TStaticButton();
	enum{BTN_NORMAL = 0,BTN_ROUND};
public:
	bool			Create(HWND hparent, int nindex = 0);
	void			MoveWindow(const int& x, const int& y, const int& cx, const int& cy);
	bool			IsButtonEnable(){ return m_benable; }
	void			EnableButton(bool benable = true);
public:
	void			SetButtonText(const wchar_t* ptext);
	void			SetBkColor(COLORREF clrbk);
	void			SetOverColor(COLORREF clrover){ m_clrover = clrover; }
	void			SetFont(HFONT hfont);
protected:
	virtual		LRESULT		WndProc(UINT message, WPARAM wParam, LPARAM lParam);
protected:
	void				OnPaint();
	void				OnLButtonDown();
	void				OnLButtonUp();
	void				OnMouseMove(WPARAM wParam, LPARAM lParam);
	void				OnMouseLeave(WPARAM wParam, LPARAM lParam);
	void				OnSetFocus();
	void				OnKillFocus();
protected:
	void				DrawBtnBk(TMemDC* pmemdc,const RECT& rect);
private:
	int					m_nstyle;
	int					m_nindex;
	bool				m_btnclick;
	bool				m_bmouseover;
	bool				m_bmousetrack;
	bool				m_benable;
	bool				m_bfocus;
private:
	HFONT				m_font;
	COLORREF			m_clrbk;
	COLORREF			m_clrover;
	std::wstring			m_sztext;
	HINSTANCE			m_gradient;
	LPGNDLLFUNC			_GradientFill;
protected:
	void				DrawNormal(TMemDC* pmdc, RECT rect);
	void				DrawRound(TMemDC* pmdc, RECT rect);
};
#endif
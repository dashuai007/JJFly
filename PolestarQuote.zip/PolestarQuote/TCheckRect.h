#pragma once
class TCheckRect :public RECT
{
public:
	TCheckRect();
	TCheckRect(int nType, SPriceType dPrice, SContract* pCon = NULL, bool bEnable = true);
	~TCheckRect();
	void SetRect(int nLf, int nTp, int nRt, int nBt);
	void SetType(int nType) { m_nType = nType; }
	void SetChecked(bool bChecked);
	void SetEnable(bool bEnable) { m_bEnable = bEnable; }
	bool IsEnable() { return m_bEnable; }
	bool GetIsChecked() { return m_bChecked; }
	void SetStrikePrice(SPriceType dPrice) { m_StrikePrice = dPrice; }
	SPriceType GetStrikePrice() { return m_StrikePrice; }
	SPriceType GetPremium();
	SContract* GetContract(){ return m_Contract;}
	void Draw(HDC mdc);
private:
	int m_nType; //0 ��  1��
	bool m_bChecked; //�Ƿ�ѡ��
	bool m_bEnable; //�Ƿ����
	SPriceType m_StrikePrice;
	SContract* m_Contract;
};
typedef std::vector<TCheckRect> CheckRectVectorType;
class TCheckList
{
public:
	TCheckList();
	~TCheckList() {}
	void InitCheckRectData(SOptionSeriesNoType SeriesNo);
	TCheckRect& GetAt(int nIndex, TACTICOPERATE opt);
	void SetCheckRow(TACTICOPERATE opt, int nRow);
	void SetFreeCheckRow(TACTICOPERATE opt, int nRow);
	int GetCheckListChecked(TACTICOPERATE opt);
	void DisableAll();
	void EnableAll();
	void DisableNoChecked();
	void WithoutChecked();
	void RemoveAll();
	void BackDirect();
	void GetCheckedContract(CheckedContract& Checked);
	bool IsAnyCheched();
private:
	CheckRectVectorType m_CallBuyChecks;
	CheckRectVectorType m_CallSellChecks;
	CheckRectVectorType m_PutBuyChecks;
	CheckRectVectorType m_PutSellChecks;
	int m_nRows;
	int m_nCallBuyChecked; //ѡ����
	int m_nCallSellChecked; //ѡ����
	int m_nPutBuyChecked; //ѡ����
	int m_nPutSellChecked; //ѡ����
};

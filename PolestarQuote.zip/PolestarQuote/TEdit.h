#ifndef _TEDIT_H
#define _TEDIT_H

class TEdit : public TIxFrm
{
public:
	TEdit();
	~TEdit();
	enum{TES_LEFT = 0,TES_RIGHT,TES_NORMAL};
public:
	bool				Create(HWND hparent, DWORD specialstyle = 0,int nindex = 0,int ngapsize = 7);
	void				MoveWindow(const int& x, const int& y, const int& cx, const int& cy);
	void				EnableEdit(bool benable = true);
	void				SetEditBmp(int nposstyle, HBITMAP hbmp = NULL);
public:
	void				SetFont(HFONT hfont);
	void				SetDefText(const wchar_t* ptext){ m_sztext = ptext; }
	void				SetWindowText(const wchar_t* ptext);
	void				SetEditStyle(bool bupper);
public:
	HWND				GetEditHwnd(){ return m_edit; }
	void				GetWindowText(wchar_t* ptext, int nmaxcount);
protected:
	virtual		LRESULT			WndProc(UINT message, WPARAM wParam, LPARAM lParam);
	static		LRESULT	CALLBACK	EditProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData);
protected:
	void				OnPaint();
	virtual void		OnSize();
	virtual void		OnLbuttonUp();
	virtual void		OnLbuttonDown(WPARAM wParam, LPARAM lParam);
	virtual void		OnMouseMove(WPARAM wParam, LPARAM lParam);
	virtual void		OnMouseLeave(WPARAM wParam, LPARAM lParam);
	void				OnKillFocus(WPARAM wParam, LPARAM lParam);
	void				OnCommand(WPARAM wParam, LPARAM lParam);
protected:
	virtual	  void	DrawMain(TMemDC* pmemdc, const RECT& rect, HBRUSH framebrush){}
private:
	bool				m_bmouseover;
	bool				m_bmousetrack;
	bool				m_blbtndown;
	bool				m_benable;
protected:
	HWND				m_edit;
	std::wstring		m_sztext;
private:
	RECT				m_rcedit;
protected:
	int				m_gapsize = 7;
	int				m_nid;
	int				m_editstyle;
	HBITMAP			m_hbmp;
};
#endif
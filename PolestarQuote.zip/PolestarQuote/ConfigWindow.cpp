#include "PreInclude.h"

TColumnConfigWindow::TColumnConfigWindow(TPlatePage* plate) :
	m_ListView(*this), m_Label(*this), m_UpBtn(*this), m_DownBtn(*this), m_OkBtn(*this), m_CancelBtn(*this),
	m_Plate(plate), m_ReturnOk(false),m_TopBtn(*this), m_BottomBtn(*this)
{
	m_Label.SetText(G_LANG->LangText(TLI_CONFIG_COLUMN));
	m_UpBtn.SetText(G_LANG->LangText(TLI_MOVEUP));
	m_UpBtn.SetSpi(this);
	m_DownBtn.SetText(G_LANG->LangText(TLI_MOVEDOWN));
	m_DownBtn.SetSpi(this);
	m_TopBtn.SetText(G_LANG->LangText(TLI_MOVE_TOP));
	m_TopBtn.SetSpi(this);
	m_BottomBtn.SetText(G_LANG->LangText(TLI_MOVE_BOTTOM));
	m_BottomBtn.SetSpi(this);
	m_OkBtn.SetText(G_LANG->LangText(TLI_BTN_OK));
	m_OkBtn.SetSpi(this);
	m_CancelBtn.SetText(G_LANG->LangText(TLI_BTN_CANCEL));
	m_CancelBtn.SetSpi(this);

	TDuiListViewCol col;
	col.Align = DT_CENTER;
	col.Type = DUI_LISTVIEW_CHECK;
	col.PixelWidth = 50;
	wchar_t* text = (wchar_t*)G_LANG->LangText(TLI_COL_VISIBLE);
	wcsncpy_s(col.Text, text, sizeof(col.Text) / sizeof(wchar_t) - 1);
	col.Visible = true;
	m_ListView.AddCol(col);

	col.Align = DT_CENTER;
	col.Type = DUI_LISTVIEW_WSTR;
	col.PixelWidth = 140;
	text = (wchar_t*)G_LANG->LangText(TLI_COL_NAME);
	wcsncpy_s(col.Text, text, sizeof(col.Text) / sizeof(wchar_t) - 1);
	col.Visible = true;
	m_ListView.AddCol(col);

	col.Align = DT_CENTER;
	col.Type = DUI_LISTVIEW_COMBO;
	col.PixelWidth = 80;
	text = (wchar_t*)G_LANG->LangText(TLI_COL_ALIGN);
	wcsncpy_s(col.Text, text, sizeof(col.Text) / sizeof(wchar_t) - 1);
	wcsncpy_s(col.ComboValue, G_LANG->LangText(TLI_ALIGN_ALL), sizeof(col.ComboValue) / sizeof(wchar_t) - 1);
	col.Visible = true;
	m_ListView.AddCol(col);

	col.Type = DUI_LISTVIEW_INT;
	col.Visible = false;
	m_ListView.AddCol(col);

	col.Type = DUI_LISTVIEW_INT;
	col.Visible = false;
	m_ListView.AddCol(col);

	LoadData();
}

bool TColumnConfigWindow::ShowColumnConfigWindow()
{
	G_MainFrame->DisableFrames();

	RECT r = { 0, 0, 0, 0 };
	GetCurrScreenRect(r);
	r.right -= r.left;
	r.bottom -= r.top;
	ShowModal(WS_POPUP | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, WS_EX_TOOLWINDOW | WS_EX_TOPMOST,
		BRUSH_CONFIGWINDOW_BACKGROUND, r.left + (r.right - WINDOW_WIDTH) / 2, r.top + (r.bottom - WINDOW_HEIGHT) / 2, WINDOW_WIDTH, WINDOW_HEIGHT);

	G_MainFrame->EnableFrames();
	return m_ReturnOk;
}

void TColumnConfigWindow::OnButtonClick(TDuiButtonControl* obj)
{
	if (obj == &m_UpBtn)
	{
		m_ListView.MoveUp();
	}
	else if (obj == &m_DownBtn)
	{
		m_ListView.MoveDown();
	}
	else if(obj == &m_TopBtn)
	{
		m_ListView.MoveTop();
	}
	else if (obj == &m_BottomBtn)
	{
		m_ListView.MoveBottom();
	}
	else if (obj == &m_OkBtn)
	{
		m_ReturnOk = true;
		SaveData();
		Destroy();
		Quit();
	}
	else if (obj == &m_CancelBtn)
	{
		Destroy();
		Quit();
	}
}
LRESULT TColumnConfigWindow::OnMessage(UINT message, WPARAM wParam, LPARAM lParam)
{
	if (message == WM_CREATE)
	{
		m_AllPlate.Create(GetHwnd());
		m_AllPlate.MoveWindow(BTN_HEIGHT, WINDOW_HEIGHT - 23, 180, BTN_HEIGHT);
		m_AllPlate.SetBkColor(COLOR_CONFIGWINDOW_BACKGROUND);
		m_AllPlate.SetColor(COLOR_PLATE_FONT_HOT);
		m_AllPlate.SetText(G_LANG->LangText(TLI_APPLIED_ALL_PLATES));
		m_AllPlate.SetCheck(false);
		return 0;
	}
	return -1;
}
void TColumnConfigWindow::OnSize(WPARAM wParam, LPARAM lParam)
{
	const POINTS& pts = *(POINTS*)&lParam;

	POINT p = { WINDOW_BORDER, WINDOW_BORDER };
	SIZE s = { pts.x - 2 * WINDOW_BORDER, CAPTION_HEIGHT };
	m_Label.MoveAndSize(&p, &s);

	p = { WINDOW_BORDER, WINDOW_BORDER + CAPTION_HEIGHT };
	s = { LISTVIEW_WIDTH, pts.y - 2 * WINDOW_BORDER - CAPTION_HEIGHT- BOTTOM_HEIGHT };
	m_ListView.MoveAndSize(&p, &s);

	p = { WINDOW_BORDER + LISTVIEW_WIDTH + (WINDOW_WIDTH - LISTVIEW_WIDTH - BTN_WIDTH) / 2, pts.y - 14 * BTN_HEIGHT };
	s = { BTN_WIDTH, BTN_HEIGHT };
	m_TopBtn.MoveAndSize(&p, &s);

	p = { WINDOW_BORDER + LISTVIEW_WIDTH + (WINDOW_WIDTH - LISTVIEW_WIDTH - BTN_WIDTH) / 2, pts.y - 12 * BTN_HEIGHT };
	s = { BTN_WIDTH, BTN_HEIGHT };
	m_BottomBtn.MoveAndSize(&p, &s);

	p = { WINDOW_BORDER + LISTVIEW_WIDTH + (WINDOW_WIDTH - LISTVIEW_WIDTH - BTN_WIDTH) / 2, pts.y - 10 * BTN_HEIGHT };
	s = { BTN_WIDTH, BTN_HEIGHT };
	m_UpBtn.MoveAndSize(&p, &s);

	p = { WINDOW_BORDER + LISTVIEW_WIDTH + (WINDOW_WIDTH - LISTVIEW_WIDTH - BTN_WIDTH) / 2, pts.y - 8 * BTN_HEIGHT };
	s = { BTN_WIDTH, BTN_HEIGHT };
	m_DownBtn.MoveAndSize(&p, &s);

	p = { WINDOW_BORDER + LISTVIEW_WIDTH + (WINDOW_WIDTH - LISTVIEW_WIDTH - BTN_WIDTH) / 2, pts.y - 4 * BTN_HEIGHT };
	s = { BTN_WIDTH, BTN_HEIGHT };
	m_OkBtn.MoveAndSize(&p, &s);

	p = { WINDOW_BORDER + LISTVIEW_WIDTH + (WINDOW_WIDTH - LISTVIEW_WIDTH - BTN_WIDTH) / 2, pts.y - 2 * BTN_HEIGHT };
	m_CancelBtn.MoveAndSize(&p, &s);
}

void TColumnConfigWindow::LoadData()
{
	//�Ӱ���ж�ȡ��
	//�����ñ������޸�����
	//���������д�ᵽ����У���ͬʱ������������ϵ���
	if (!m_Plate)
		return;
	for (int i = 0; i < m_Plate->PlateColCount; i++)
	{
		TPlateCol& col = m_Plate->PlateCols[i];
		m_ListView.SetCheck(i, 0, col.Visible);
		m_ListView.SetWStr(i, 1, col.Name);
		m_ListView.SetCombo(i, 2, G_LANG->LangText(TLI_ALIGN_LEFT + col.Align));
		m_ListView.SetInt(i, 3, col.Width);
		m_ListView.SetInt(i, 4, col.Field);
	}
}
void TColumnConfigWindow::ApplayOnePlate(TPlatePage* p)
{
	if (p)
	{
		p->PlateColCount = 0;

		for (size_t j = 0; j < m_ListView.GetRowCount(); j++)
		{
			bool check(false);
			if (!m_ListView.GetCheck(j, 0, check))
				continue;

			TPlateCol& col = p->PlateCols[p->PlateColCount++];
			col.Visible = check;
			m_ListView.GetWStr(j, 1, col.Name, sizeof(col.Name) / sizeof(wchar_t));

			int fid;
			m_ListView.GetInt(j, 4, fid);
			col.Field = (SFidMeanType)fid;

			int width;
			m_ListView.GetInt(j, 3, width);
			col.Width = width;

			wchar_t align[51];
			m_ListView.GetCombo(j, 2, align, sizeof(align) / sizeof(wchar_t));
			if (align[0] == G_LANG->LangText(TLI_ALIGN_LEFT)[0])
				col.Align = DT_LEFT;
			else if (align[0] == G_LANG->LangText(TLI_ALIGN_RIGHT)[0])
				col.Align = DT_RIGHT;
			else
				col.Align = DT_CENTER;
		}
		p->SaveCols();
	}
}
void TColumnConfigWindow::SaveData()
{
	//�޸��У����б����������˽�����ݣ�������񱻴򿪶����ѡ��ͬһ����������£��ᵼ������һ�����е�������ʧЧ
	//�޸�����Ϣͬ���� ȫ�ְ�������ݻ���
	//Reload��ǰ��������
	if (m_AllPlate.GetCheck())
	{
		for (size_t i = 0; i < G_QuoteUtils.PlatePages.size(); i++)
		{
			TPlatePage* p = G_QuoteUtils.PlatePages[i];
			if (p)
			{
				if (p->ChildPages.size() > 0)
				{
					for (size_t j = 0; j < p->ChildPages.size(); j++)
					{
						TPlatePage* cpage = p->ChildPages[j];
						ApplayOnePlate(cpage);
					}
				}
				else
				{
					ApplayOnePlate(p);
				}		
			}
		}

	}
	else
	{
		if (!m_Plate)
			return;
		ApplayOnePlate(m_Plate);
	}
}

//��ѡ����----------------------------------------------------------------------------------------------------
TSelectContractWindow::TSelectContractWindow(TPlatePage* plate) :m_Plate(plate), m_Label(*this), m_TreeView(*this),
m_ContractView(*this, true), m_SelectView(*this, true), m_InBtn(*this), m_OutBtn(*this), m_UpBtn(*this), m_DownBtn(*this), m_OkBtn(*this), m_CancelBtn(*this)
, m_SelAllBtn(*this), m_ClearAllBtn(*this), m_TipLabe(*this)
{
	m_Label.SetText(G_LANG->LangText(TLI_SELECT_CONTRACT));
	m_TipLabe.SetFont(FONT_TIP_TEXT);
	if (G_STYLE == BLACK_STYLE)
		m_TipLabe.SetBackground(BRUSH_DUICONTROL_BACKGROUND);
	m_TipLabe.SetTextFormat(DT_LEFT | DT_WORDBREAK | DT_VCENTER);
	m_TipLabe.SetLeftMargin(5);
	TDuiListViewCol col;
	col.Align = DT_LEFT;
	col.Type = DUI_LISTVIEW_VOID;
	col.PixelWidth = (LEFT_LISTVIEW_WIDTH - 10);
	col.Text[0] = L'\0';
	col.Visible = true;
	m_TreeView.AddCol(col);


	col.Align = DT_LEFT;
	col.Type = DUI_LISTVIEW_WSTR;
	col.PixelWidth = (LEFT_LISTVIEW_WIDTH - 10);
	wcsncpy_s(col.Text, (wchar_t*)G_LANG->LangText(TLI_CONTRACT), sizeof(col.Text) / sizeof(wchar_t) - 1);
	col.Visible = true;
	m_ContractView.AddCol(col);

	col.Type = DUI_LISTVIEW_VOID;
	col.Visible = false;
	m_ContractView.AddCol(col);

	col.Type = DUI_LISTVIEW_STR;
	col.Visible = false;

	m_ContractView.AddCol(col);

	col.Align = DT_LEFT;
	col.Type = DUI_LISTVIEW_WSTR;
	col.PixelWidth = (LISTVIEW_WIDTH - 10);
	wcsncpy_s(col.Text, (wchar_t*)G_LANG->LangText(TLI_SELECTED_CONTRACT), sizeof(col.Text) / sizeof(wchar_t) - 1);
	col.Visible = true;
	m_SelectView.AddCol(col);

	col.Type = DUI_LISTVIEW_VOID;
	col.Visible = false;
	m_SelectView.AddCol(col);

	col.Type = DUI_LISTVIEW_STR;
	col.Visible = false;
	m_SelectView.AddCol(col);

	col.Type = DUI_LISTVIEW_CHECK;
	col.Visible = false;
	m_SelectView.AddCol(col);

	m_TreeView.SetSpi(this);
	m_ContractView.SetSpi(this);
	m_SelectView.SetSpi(this);

	m_InBtn.SetText(L">>>");
	m_InBtn.SetSpi(this);
	m_OutBtn.SetText(L"<<<");
	m_OutBtn.SetSpi(this);
	m_SelAllBtn.SetText(G_LANG->LangText(TLI_SELECTED_ALL));
	m_SelAllBtn.SetSpi(this);
	m_ClearAllBtn.SetText(G_LANG->LangText(TLI_CLEAR_ALL));
	m_ClearAllBtn.SetSpi(this);
	m_UpBtn.SetText(G_LANG->LangText(TLI_MOVEUP));
	m_UpBtn.SetSpi(this);
	m_DownBtn.SetText(G_LANG->LangText(TLI_MOVEDOWN));
	m_DownBtn.SetSpi(this);
	m_OkBtn.SetText(G_LANG->LangText(TLI_BTN_OK));
	m_OkBtn.SetSpi(this);
	m_CancelBtn.SetText(G_LANG->LangText(TLI_BTN_CANCEL));
	m_CancelBtn.SetSpi(this);
	LoadTreeDate();
	LoadContract();
	LoadSelect();

}

bool TSelectContractWindow::ShowSelectContractWindow()
{
	G_MainFrame->DisableFrames();

	RECT r = { 0, 0, 0, 0 };
	GetCurrScreenRect(r);
	r.right -= r.left;
	r.bottom -= r.top;
	ShowModal(WS_POPUP | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, WS_EX_TOOLWINDOW | WS_EX_TOPMOST,
		BRUSH_CONFIGWINDOW_BACKGROUND, r.left + (r.right - WINDOW_WIDTH) / 2, r.top + (r.bottom - WINDOW_HEIGHT) / 2, WINDOW_WIDTH, WINDOW_HEIGHT);

	G_MainFrame->EnableFrames();
	return true;
}

void TSelectContractWindow::OnButtonClick(TDuiButtonControl* obj)
{
	if (&m_InBtn == obj)
	{
		if (SelectIn())
			m_SelectView.Redraw(NULL);
	}
	else if (&m_OutBtn == obj)
	{
		if (SelectOut())
			m_SelectView.Redraw(NULL);
	}
	else if (&m_SelAllBtn == obj)
	{
		if (SelectAll())
			m_SelectView.Redraw(NULL);
	}
	else if (&m_ClearAllBtn == obj)
	{
		if (ClearAll())
			m_SelectView.Redraw(NULL);
	}
	else if (&m_UpBtn == obj)
	{
		m_SelectView.MoveUp();
	}
	else if (&m_DownBtn == obj)
	{
		m_SelectView.MoveDown();
	}
	else if (&m_OkBtn == obj)
	{
		ApplySelect();
		Destroy();
		Quit();
	}
	else if (&m_CancelBtn == obj)
	{
		Destroy();
		Quit();
	}

}
bool TSelectContractWindow::RefushTipWindow()
{
	if (m_ContractView.GetSelectIndex() >= 0)
	{
		char cExcNo[51];
		m_TreeView.GetExtrnStr(m_TreeView.GetSelectIndex(), cExcNo, sizeof(SCommodityNoType));
		const char* pos1 = strchr(cExcNo, '|');
		if (pos1&&pos1 > cExcNo)
		{
			cExcNo[pos1 - cExcNo] = '\0';
		}
		if (strcmp(cExcNo, SpreadNo) == 0 || strcmp(cExcNo, "SPD") == 0)
		{
			WCHAR tempTxt[501];
			WCHAR cname[51];
			SContractNoType cno;
			m_ContractView.GetWStr(m_ContractView.GetSelectIndex(), 0, cname, sizeof(cname) / sizeof(wchar_t));
			void* cref(NULL);
			m_ContractView.GetVoid(m_ContractView.GetSelectIndex(), 1, (void*)cref);
			if (cref)
			{
				SContract* pCon = (SContract*)cref;
				strcpy_s(cno, pCon->ContractNo);
			}
			else
			{
				m_ContractView.GetStr(m_ContractView.GetSelectIndex(), 2, cno, sizeof(SContractNoType));
			}
			wchar_t Rate[101]=L"";
			GetSpreadRatio(cno, Rate, sizeof(Rate) / sizeof(wchar_t));
			swprintf_s(tempTxt, L"%s��%s��", cname,/* G_LANG->LangText(TLI_PRICE_COEF),*/Rate);
			m_TipLabe.SetText(tempTxt);
			POINT p;
			SIZE s;
			p = { 3 * WINDOW_BORDER + LEFT_LISTVIEW_WIDTH + WINDOW_BORDER, WINDOW_BORDER + CAPTION_HEIGHT + 1 };
			s = { LEFT_LISTVIEW_WIDTH, WINDOW_HEIGHT - 2 * WINDOW_BORDER - 2 * CAPTION_HEIGHT - 1 + 5 };
			m_ContractView.MoveAndSize(&p, &s);

			p = { 3 * WINDOW_BORDER + LEFT_LISTVIEW_WIDTH + WINDOW_BORDER, WINDOW_HEIGHT - CAPTION_HEIGHT + 5 };
			s = { LEFT_LISTVIEW_WIDTH, CAPTION_HEIGHT - 5 };
			m_TipLabe.MoveAndSize(&p, &s);
			m_TipLabe.Redraw(NULL);
			m_ContractView.Redraw(NULL);
			return true;
		}
	}
	m_TipLabe.SetText(L"");

	POINT p;
	SIZE s;
	p = { 3 * WINDOW_BORDER + LEFT_LISTVIEW_WIDTH + WINDOW_BORDER, WINDOW_BORDER + CAPTION_HEIGHT + 1 };
	s = { LEFT_LISTVIEW_WIDTH, WINDOW_HEIGHT - 2 * WINDOW_BORDER - CAPTION_HEIGHT - 1 };
	m_ContractView.MoveAndSize(&p, &s);

	p = { 3 * WINDOW_BORDER + LEFT_LISTVIEW_WIDTH + WINDOW_BORDER, WINDOW_HEIGHT - CAPTION_HEIGHT + 5 };
	s = { 0, 0 };
	m_TipLabe.MoveAndSize(&p, &s);
	m_TipLabe.Redraw(NULL);
	m_ContractView.Redraw(NULL);
	return false;
}
void TSelectContractWindow::OnListViewClick(TDuiListViewControl* obj)
{
	if (&m_ContractView == obj)
	{	
		RefushTipWindow();
	}
	else if (&m_TreeView == obj)
	{
		//LoadCommodity();
		//m_CommodityView.Redraw(NULL);
		LoadContract();
		RefushTipWindow();
	}
}

void TSelectContractWindow::OnListViewDbClick(TDuiListViewControl* obj)
{
	if (&m_ContractView == obj)
	{
		if (SelectIn())
			m_SelectView.Redraw(NULL);
	}
	else if (&m_SelectView == obj)
	{
		if (SelectOut())
			m_SelectView.Redraw(NULL);
	}
}

void TSelectContractWindow::OnSize(WPARAM wParam, LPARAM lParam)
{
	const POINTS& pts = *(POINTS*)&lParam;

	POINT p = { WINDOW_BORDER, WINDOW_BORDER };
	SIZE s = { pts.x - 2 * WINDOW_BORDER, CAPTION_HEIGHT };
	m_Label.MoveAndSize(&p, &s);

	p = { WINDOW_BORDER, WINDOW_BORDER + CAPTION_HEIGHT + 1 };
	s = { LEFT_LISTVIEW_WIDTH, pts.y - 2 * WINDOW_BORDER - CAPTION_HEIGHT - 1 };
	m_TreeView.MoveAndSize(&p, &s);

	//p = { WINDOW_BORDER, WINDOW_BORDER + CAPTION_HEIGHT + BTN_HEIGHT + s.cy + 8 };
	//s.cy -= 5;
	//m_CommodityView.MoveAndSize(&p, &s);

	p = { 3 * WINDOW_BORDER + LEFT_LISTVIEW_WIDTH + WINDOW_BORDER, WINDOW_BORDER + CAPTION_HEIGHT + 1 };
	s = { LEFT_LISTVIEW_WIDTH, pts.y - 2 * WINDOW_BORDER - CAPTION_HEIGHT - 1 };
	m_ContractView.MoveAndSize(&p, &s);

	/*p = { 3 * WINDOW_BORDER + LEFT_LISTVIEW_WIDTH + WINDOW_BORDER, pts.y - CAPTION_HEIGHT+6 };
	s = { LEFT_LISTVIEW_WIDTH, CAPTION_HEIGHT-6};
	m_TipLabe.MoveAndSize(&p, &s);*/

	p = { pts.x - WINDOW_BORDER - LISTVIEW_WIDTH, WINDOW_BORDER + CAPTION_HEIGHT + 1 };
	s = { LISTVIEW_WIDTH, pts.y - 2 * WINDOW_BORDER - CAPTION_HEIGHT - 1 };
	m_SelectView.MoveAndSize(&p, &s);

	p = { 2 * WINDOW_BORDER + 2 * LEFT_LISTVIEW_WIDTH + (pts.x - 2 * LEFT_LISTVIEW_WIDTH - LISTVIEW_WIDTH - BTN_WIDTH) / 2, pts.y / 6 };
	s = { BTN_WIDTH, BTN_HEIGHT };
	m_InBtn.MoveAndSize(&p, &s);

	p.y = pts.y / 6 + 2 * BTN_HEIGHT;
	m_OutBtn.MoveAndSize(&p, &s);

	p.y = pts.y / 3;
	m_SelAllBtn.MoveAndSize(&p, &s);

	p.y = pts.y / 3 + 2 * BTN_HEIGHT;
	m_ClearAllBtn.MoveAndSize(&p, &s);

	p.y = pts.y * 2 / 3;
	m_UpBtn.MoveAndSize(&p, &s);

	p.y = pts.y * 2 / 3 + 2 * BTN_HEIGHT;
	m_DownBtn.MoveAndSize(&p, &s);

	p.y = pts.y * 5 / 6;
	m_OkBtn.MoveAndSize(&p, &s);

	p.y = pts.y * 5 / 6 + 2 * BTN_HEIGHT;
	m_CancelBtn.MoveAndSize(&p, &s);

}

const char* FIRST_EXCHANGE_ARRAY[] = {
	"SPD","ZCE", "DCE", "SHFE","INE", "CFFEX", "SSE", "SZSE", "SGE",
	"CBOT", "CME", "COMEX", "NYMEX",
	"ICUS", "ICEU", "HKEX", "LME",
	"EUREX", "SGX", "TOCOM"
};
const char* END_EXCHANGE_ARRAY[] = { "ASX","BMD","KRX","EURONEXT","ICCA","ICSG","TFEX","OSE","DGCX","DME","ESUNNY" };
void TSelectContractWindow::LoadTreeDate()
{
	//�Ƚ�����������
	std::set<std::string> exchanges;

	for (int i = 0; i < sizeof(FIRST_EXCHANGE_ARRAY) / sizeof(char*); i++)
	{
		SExchange* e;
		if (G_StarApi->GetExchangeData(FIRST_EXCHANGE_ARRAY[i], &e, 1, false) <= 0)
			continue;
		if (strcmp(e->ExchangeNo, "SPD") != 0&&G_StarApi->GetCommodityCount(FIRST_EXCHANGE_ARRAY[i]) <= 0)
			continue;
		exchanges.insert(FIRST_EXCHANGE_ARRAY[i]);
		size_t index = m_TreeView.GetRowCount();

		wchar_t ename[128];
		if (strcmp(e->ExchangeNo, "SPD") == 0)
		{
			wcscpy_s(ename, (wchar_t*)G_LANG->LangText(TLI_SYSTEM_SPREAD));
		}
		else
		{
			MByteToWChar(e->ExchangeName, ename, sizeof(ename) / sizeof(wchar_t));
			wcsncat_s(ename, L" ", 1);
			MultiByteToWideChar(1252, 0, e->ExchangeNo, -1, &ename[wcslen(ename)], sizeof(ename) / sizeof(wchar_t) - wcslen(ename));
		}

		Node* pExcNode = m_TreeView.AddNode(index, ename, e->ExchangeNo);
		//���ӽ�����Ʒ��
		if (pExcNode)
		{
			LoadCommodity(e->ExchangeNo, pExcNode);
		}
	}


	//���Զ�������
	SExchange* array[128];
	int count = G_StarApi->GetExchangeData(NULL, array, sizeof(array) / sizeof(SExchange*), true);
	for (int i = 0; i < count; i++)
	{
		SExchange* e = array[i];
		bool bContinue = false;
		for (int j = 0; j < sizeof(END_EXCHANGE_ARRAY) / sizeof(char*); j++)
		{
			if (strcmp(e->ExchangeNo, END_EXCHANGE_ARRAY[j]) == 0)
				bContinue = true;
		}
		if (bContinue)
			continue;
		if (exchanges.end() == exchanges.find(e->ExchangeNo))
		{
			if (G_StarApi->GetCommodityCount(e->ExchangeNo) <= 0)
				continue;
			size_t index = m_TreeView.GetRowCount();

			wchar_t ename[128];
			MByteToWChar(e->ExchangeName, ename, sizeof(ename) / sizeof(wchar_t));
			wcsncat_s(ename, L" ", 1);
			MultiByteToWideChar(1252, 0, e->ExchangeNo, -1, &ename[wcslen(ename)], sizeof(ename) / sizeof(wchar_t) - wcslen(ename));

			Node* pExcNode = m_TreeView.AddNode(index, ename, e->ExchangeNo);
			//���ӽ�����Ʒ��
			if (pExcNode)
			{
				LoadCommodity(e->ExchangeNo, pExcNode);
			}
		}
	}

	//�������Esunnyָ��
	size_t index = m_TreeView.GetRowCount();
	Node* pOExchangeNode = m_TreeView.AddNode(index, (wchar_t*)G_LANG->LangText(TLI_OTHER_EXCHANGE), (char*)OTHER_EXCHANGE_No);

	for (int k = 0; k < sizeof(END_EXCHANGE_ARRAY) / sizeof(char*); k++)
	{
		SExchange* e;
		if (G_StarApi->GetExchangeData(END_EXCHANGE_ARRAY[k], &e, 1, false) > 0 && G_StarApi->GetCommodityCount(END_EXCHANGE_ARRAY[k]) > 0)
		{
			size_t index = m_TreeView.GetRowCount();

			wchar_t ename[128];
			MByteToWChar(e->ExchangeName, ename, sizeof(ename) / sizeof(wchar_t));
			wcsncat_s(ename, L" ", 1);
			MultiByteToWideChar(1252, 0, e->ExchangeNo, -1, &ename[wcslen(ename)], sizeof(ename) / sizeof(wchar_t) - wcslen(ename));

			Node* pExcNode = NULL;
			if (strcmp(END_EXCHANGE_ARRAY[k], "ESUNNY") == 0)
				pExcNode = m_TreeView.AddNode(index, ename, e->ExchangeNo);
			else
				pExcNode = m_TreeView.AddNode(index, ename, e->ExchangeNo, pOExchangeNode);
			//���ӽ�����Ʒ��
			if (pExcNode)
			{
				LoadCommodity(e->ExchangeNo, pExcNode);
			}
		}
	}


	if (m_TreeView.GetRowCount() > 0)
		m_TreeView.SetSelectIndex(0);
	m_TreeView.SetFocus();
}
string GetKey(const SCommodity* pCommodity, char nIndexExNo)
{
	char sKey[40] = { 0 };
	if (S_COMMODITYTYPE_SPDMON == pCommodity->CommodityType)
		sprintf_s(sKey, "%d$%d$%s", nIndexExNo, 0, pCommodity->CommodityNo);
	else if (S_COMMODITYTYPE_SPDCOM == pCommodity->CommodityType)
		sprintf_s(sKey, "%d$%d$%s", nIndexExNo, 1, pCommodity->CommodityNo);
	else
		sprintf_s(sKey, "%d$%d$%s", nIndexExNo, 2, pCommodity->CommodityNo);
	return sKey;
}
class Less_Commodity
{
public:
	Less_Commodity()
	{
		m_ex.insert(std::map<string, char>::value_type("ZCE", 0));
		m_ex.insert(std::map<string, char>::value_type("DCE", 1));
		m_ex.insert(std::map<string, char>::value_type("SHFE", 2));
		m_ex.insert(std::map<string, char>::value_type("INE", 3));
		m_ex.insert(std::map<string, char>::value_type("CFFEX", 4));
		m_ex.insert(std::map<string, char>::value_type("SGE", 5));
	}
	bool operator ()(SCommodity* p1, SCommodity* p2)
	{
		if (p1->TargetCommodity[0] && p2->TargetCommodity[0])
		{
			char nIndex = p1->TargetCommodity[0]->Exchange->ExchangeNo[0];
			char nIndex2 = p2->TargetCommodity[0]->Exchange->ExchangeNo[0];
			std::map<string, int>::iterator it1 = m_ex.find(p1->TargetCommodity[0]->Exchange->ExchangeNo);
			std::map<string, int>::iterator it2 = m_ex.find(p2->TargetCommodity[0]->Exchange->ExchangeNo);
			if (it1 != m_ex.end())
				nIndex = it1->second;
			if (it2 != m_ex.end())
				nIndex2 = it2->second;
			return GetKey(p1, nIndex) < GetKey(p2, nIndex2);
		}
		else
			return string(p1->Exchange->ExchangeNo) < string(p2->Exchange->ExchangeNo);
	}
	std::map<string, int> m_ex;
};
void TSelectContractWindow::LoadCommodity(SExchangeNoType eno, Node* pExcNode)
{
	if (strcmp(eno, "SPD") == 0)
	{
		//���ӱ�������
		size_t index = m_TreeView.GetRowCount();
		Node* pSpreadNode = m_TreeView.AddNode(index, (wchar_t*)G_LANG->LangText(TLI_LOCAL_SPREAD), (char*)SpreadNo, pExcNode);
	}
	SCommodity* array[1024];
	int cnt = G_StarApi->GetCommodityData(eno, NULL, array, sizeof(array) / sizeof(SCommodity*), true);
	if (strcmp(eno, "SPD") == 0)
	{
		std::vector<SCommodity*> SpdCommodityVec(array, array+cnt);
		std::sort((SpdCommodityVec.begin()), (SpdCommodityVec.end()), Less_Commodity());
		memcpy(array, SpdCommodityVec.data(), sizeof(SCommodity*)*cnt);
	}	
	for (int i = 0; i < cnt; i++)
	{
		SCommodity* c = array[i];

		if (c->CommodityType == S_COMMODITYTYPE_STD || c->CommodityType == S_COMMODITYTYPE_STG)
			continue;
		const char* pos = strchr(c->CommodityNo, '|');
		if (NULL != pos)
		{
			wchar_t cname[61];
			if (!MByteToWChar(c->CommodityName, cname, sizeof(cname) / sizeof(wchar_t)))
				continue;
			switch (pos[1])
			{
			case 'F':
				wcsncat_s(cname, G_LANG->LangText(TLI_SEL_FUTURES), sizeof(cname) / sizeof(wchar_t) - 1);
				break;
			case 'O':
				wcsncat_s(cname, G_LANG->LangText(TLI_SEL_OPTIONS), sizeof(cname) / sizeof(wchar_t) - 1);
				break;
			case 'Z':
				wcsncat_s(cname, G_LANG->LangText(TLI_SEL_INDEX), sizeof(cname) / sizeof(wchar_t) - 1);
				break;
			case 'S':
				wcsncat_s(cname, G_LANG->LangText(TLI_SEL_SPREAD), sizeof(cname) / sizeof(wchar_t) - 1);
				break;
			case 'M':
				wcsncat_s(cname, G_LANG->LangText(TLI_SEL_SPREAD2), sizeof(cname) / sizeof(wchar_t) - 1);
				break;
			case 'T':
				wcsncat_s(cname, G_LANG->LangText(TLI_SEL_SPOT), sizeof(cname) / sizeof(wchar_t) - 1);
				break;
			default:
				break;
			}
			size_t index = m_TreeView.GetRowCount();
			m_TreeView.AddNode(index, cname, c->CommodityNo, pExcNode);
		}
	}
}
bool TSelectContractWindow::IsThreeLevel(Node* pNode)
{
	Node* pParent = pNode->GetParent();
	if (pParent&&pParent->isVisiable())
	{
		if (strcmp(pParent->data()._extrnData, OTHER_EXCHANGE_No) == 0)
			return true;
	}
	return false;
}
void TSelectContractWindow::LoadContract()
{
	m_ContractView.Clear();

	if (m_TreeView.GetSelectIndex() >= 0 && m_TreeView.GetSelectIndex() < (int)m_TreeView.GetRowCount())		//��ǰƷ��
	{
		Node* pSelNode = m_TreeView.GetSelNode();
		if (!pSelNode || !pSelNode->isVisiable())
			return;
		char cno[51];
		m_TreeView.GetExtrnStr(m_TreeView.GetSelectIndex(), cno, sizeof(SCommodityNoType));
		if (pSelNode->data()._level == 0 || IsThreeLevel(pSelNode)) // ���������к�Լ
		{
			int nCount = 0;
			if (strcmp(cno, "SPD") == 0)
			{
				//���ӱ�������
				LoadSpreadContract();
				nCount = m_ContractView.GetRowCount();
			}
			SCommodity* array[1024];
			int cnt = G_StarApi->GetCommodityData(cno, NULL, array, sizeof(array) / sizeof(SCommodity*), true);
			
			for (int i = 0; i < cnt; i++)
			{
				SCommodity* com = array[i];
				if (com->CommodityType == S_COMMODITYTYPE_STD || com->CommodityType == S_COMMODITYTYPE_STG)
					continue;
				char* pos = strchr(com->CommodityNo, '|');
				if (pos&&pos[1] == 'O')
					continue;
				SContractNoType begin;
				begin[0] = '\0';
				SContract* array[1024];
				while (true)
				{
					int cnt = G_StarApi->GetContractData(com->CommodityNo, begin, array, sizeof(array) / sizeof(SContract*), true);

					for (int j = 0; j < cnt; j++)
					{
						SContract* c = array[j];

						wchar_t cname[101];
						GetContractName(G_StarApi, c->ContractNo, cname);
						m_ContractView.SetWStr(nCount, 0, cname);
						m_ContractView.SetVoid(nCount, 1, (void*)c);
						nCount++;
					}

					if (cnt < sizeof(array) / sizeof(SContract*))
						break;
					strcpy_s(begin, array[cnt - 1]->ContractNo);
				}
			}
		}
		else
		{
			if (strcmp(cno, SpreadNo) == 0)
			{
				LoadSpreadContract();
			}
			else
			{
				SContractNoType begin;
				begin[0] = '\0';

				SContract* array[1024];

				int nCount = 0;
				while (true)
				{
					int cnt = G_StarApi->GetContractData(cno, begin, array, sizeof(array) / sizeof(SContract*), true);

					for (int i = 0; i < cnt; i++)
					{
						SContract* c = array[i];

						wchar_t cname[101];
						GetContractName(G_StarApi, c->ContractNo, cname);
						m_ContractView.SetWStr(nCount, 0, cname);
						m_ContractView.SetVoid(nCount, 1, (void*)c);
						nCount++;
					}

					if (cnt < sizeof(array) / sizeof(SContract*))
						break;
					strcpy_s(begin, array[cnt - 1]->ContractNo);
				}
			}
		}
		if (m_ContractView.GetRowCount() > 0)
			m_ContractView.SetSelectIndex(0);
	}
}

void TSelectContractWindow::LoadSpreadContract()
{
	SSpreadContract array[1024];
	while (true)
	{
		int cnt = G_StarApi->GetSpreadInfo("", array, sizeof(array) / sizeof(SSpreadContract), true, S_SPREADSRC_SELF);
		for (int i = 0; i < cnt; i++)
		{
			SSpreadContract c = array[i];
			SContractNoType cno;
			G_QuoteUtils.GetSpreadContractNo(&c, cno);
			wchar_t cname[101];
			GetContractName(G_StarApi, cno, cname);
			m_ContractView.SetWStr(i, 0, cname);
			m_ContractView.SetVoid(i, 1, NULL);
			m_ContractView.SetStr(i, 2, cno);
		}
		if (cnt < sizeof(array) / sizeof(SSpreadContract))
			break;
	}
}
void TSelectContractWindow::LoadSelect()
{
	if (!m_Plate)
		return;
	m_SelectView.Clear();
	int t = 0;
	for (size_t i = 0; i < m_Plate->PlateRows.size(); i++)
	{
		TPlateRow& r = m_Plate->PlateRows[i];
		if (r.IsSpread)
		{
			SSpreadContract SpreadContract;
			if (!G_QuoteUtils.GetSpreadContract(r.ContractNo, SpreadContract))
			{
				continue;
			}
			wchar_t cname[101];
			GetContractName(G_StarApi, r.ContractNo, cname);
			m_SelectView.SetWStr(t, 0, cname);
			m_SelectView.SetVoid(t, 1, NULL);
			m_SelectView.SetStr(t, 2, r.ContractNo);
			m_SelectView.SetCheck(t, 3, true);
			t++;
		}
		else
		{
			wchar_t cname[101];
			GetContractName(G_StarApi, r.Contract->ContractNo, cname);
			m_SelectView.SetWStr(t, 0, cname);
			m_SelectView.SetVoid(t, 1, (void*)r.Contract);
			m_SelectView.SetStr(t, 2, r.Contract->ContractNo);
			m_SelectView.SetCheck(t, 3, false);
			t++;
		}
		m_SelectVec.push_back(r);
	}
}

bool TSelectContractWindow::SelectIn()
{
	//����SelectView����ͬ��Լ
	char cno[51];
	m_TreeView.GetExtrnStr(m_TreeView.GetSelectIndex(), cno, sizeof(SCommodityNoType));
	const char* pos1 = strchr(cno, '|');
	if (pos1&&pos1 > cno)
	{
		cno[pos1 - cno] = '\0';
	}
	if (strcmp(cno, SpreadNo) == 0 || strcmp(cno, "SPD") == 0)
	{
		int nSize = m_ContractView.GetMulSelIndexs(NULL, 0);
		int* pSelRows = new int[nSize];
		m_ContractView.GetMulSelIndexs(pSelRows, nSize);
		for (int j = 0; j < nSize; j++)
		{
			int nIndex = pSelRows[j];
			if (nIndex < 0 || nIndex >= (int)m_ContractView.GetRowCount())
				return false;
			wchar_t cname[51];
			m_ContractView.GetWStr(nIndex, 0, cname, sizeof(cname) / sizeof(wchar_t));
			void* cref(NULL);
			m_ContractView.GetVoid(nIndex, 1, (void*)cref);
			TPlateRow row;
			SContractNoType cno;
			if (cref)
			{
				row.Contract = (SContract*)cref;
				strcpy_s(cno, row.Contract->ContractNo);
				row.IsSpread = false;
			}
			else
			{
				m_ContractView.GetStr(nIndex, 2, row.ContractNo, sizeof(SContractNoType));
				strcpy_s(cno, row.ContractNo);
				row.IsSpread = true;
			}
			bool bContinue = false;
			for (size_t i = 0; i < m_SelectVec.size(); i++)
			{
				if (m_SelectVec[i].IsSpread)
				{
					if (strcmp(m_SelectVec[i].ContractNo, cno) == 0)
					{
						bContinue = true;
						break;
					}
				}
				else
				{
					if (strcmp(m_SelectVec[i].Contract->ContractNo, cno) == 0)
					{
						bContinue = true;
						break;
					}
				}
			
			}
			if (bContinue)
				continue;
			m_SelectVec.push_back(row);
			nIndex = m_SelectView.GetRowCount();

			m_SelectView.SetWStr(nIndex, 0, cname);
			m_SelectView.SetVoid(nIndex, 1, cref);
			m_SelectView.SetStr(nIndex, 2, row.ContractNo);
			m_SelectView.SetCheck(nIndex, 3, row.IsSpread);
		}
		delete pSelRows;
	}
	else
	{
		int nSize = m_ContractView.GetMulSelIndexs(NULL, 0);
		int* pSelRows = new int[nSize];
		m_ContractView.GetMulSelIndexs(pSelRows, nSize);
		for (int j = 0; j < nSize; j++)
		{
			int cindex = pSelRows[j];
			if (cindex < 0 || cindex >= (int)m_ContractView.GetRowCount())
				return false;

			wchar_t cname[51];
			m_ContractView.GetWStr(cindex, 0, cname, sizeof(cname) / sizeof(wchar_t));
			void* cref(NULL);
			m_ContractView.GetVoid(cindex, 1, cref);
			bool bContinue = false;
			for (size_t i = 0; i < m_SelectVec.size(); i++)
			{
				if (m_SelectVec[i].IsSpread)
					continue;
				if (m_SelectVec[i].Contract == cref)
				{
					bContinue = true;
					break;
				}
			}
			if (bContinue)
				continue;
			TPlateRow row;
			row.IsSpread = false;
			row.Contract = (SContract*)cref;
			m_SelectVec.push_back(row);

			cindex = m_SelectView.GetRowCount();

			m_SelectView.SetWStr(cindex, 0, cname);
			m_SelectView.SetVoid(cindex, 1, cref);
			m_SelectView.SetStr(cindex, 2, "");
			m_SelectView.SetCheck(cindex, 3, false);
		}
		delete pSelRows;
	}
	return true;
}

bool TSelectContractWindow::SelectOut()
{
	int nSize = m_SelectView.GetMulSelIndexs(NULL, 0);
	int* pSelRows = new int[nSize];
	m_SelectView.GetMulSelIndexs(pSelRows, nSize);
	int nDelRows = 0;
	for (int j = 0; j < nSize; j++)
	{
		int cindex = pSelRows[j] - nDelRows;
		if (cindex < 0 || cindex >= (int)m_SelectView.GetRowCount())
			return false;
		for (auto it = m_SelectVec.begin(); it != m_SelectVec.end();)
		{
			if ((*it).IsSpread)
			{
				SContractNoType	Cno;
				m_SelectView.GetStr(cindex, 2, Cno, sizeof(SContractNoType));
				if (strcmp((*it).ContractNo, Cno) == 0)
					it = m_SelectVec.erase(it);
				else
					it++;
			}
			else
			{
				void* cref(NULL);
				m_SelectView.GetVoid(cindex, 1, cref);
				if ((*it).Contract == cref)
					it = m_SelectVec.erase(it);
				else
					it++;
			}
		}
		if (m_SelectView.Remove(cindex))
			nDelRows++;
	}
	return true;
}
bool TSelectContractWindow::SelectAll()
{
	char cno[51];
	m_TreeView.GetExtrnStr(m_TreeView.GetSelectIndex(), cno, sizeof(SCommodityNoType));
	const char* pos1 = strchr(cno, '|');
	if (pos1&&pos1 > cno)
	{
		cno[pos1 - cno] = '\0';
	}
	if (strcmp(cno, SpreadNo) == 0 || strcmp(cno, "SPD") == 0)
	{
		std::vector<TPlateRow> CmpVector(m_SelectVec);
		for (size_t idx = 0; idx < m_ContractView.GetRowCount(); idx++)
		{

			wchar_t cname[51];
			m_ContractView.GetWStr(idx, 0, cname, sizeof(cname) / sizeof(wchar_t));
			void* cref(NULL);
			m_ContractView.GetVoid(idx, 1, (void*)cref);
			TPlateRow row;
			SContractNoType cno;
			if (cref)
			{
				row.Contract = (SContract*)cref;
				strcpy_s(cno, row.Contract->ContractNo);
				row.IsSpread = false;
			}
			else
			{
				m_ContractView.GetStr(idx, 2, row.ContractNo, sizeof(SContractNoType));
				strcpy_s(cno, row.ContractNo);
				row.IsSpread = true;
			}
			bool bContinue = false;
			for (size_t i = 0; i < CmpVector.size(); i++)
			{
				if (CmpVector[i].IsSpread)
				{
					if (strcmp(CmpVector[i].ContractNo, cno) == 0)
					{
						bContinue = true;
						break;
					}
				}
				else
				{
					if (strcmp(CmpVector[i].Contract->ContractNo, cno) == 0)
					{
						bContinue = true;
						break;
					}
				}
				
			}
			if (bContinue)
				continue;
			m_SelectVec.push_back(row);
			int cindex = m_SelectView.GetRowCount();

			m_SelectView.SetWStr(cindex, 0, cname);
			m_SelectView.SetVoid(cindex, 1, cref);
			m_SelectView.SetStr(cindex, 2, row.ContractNo);
			m_SelectView.SetCheck(cindex, 3, row.IsSpread);
			if (m_SelectVec.size() >= MAX_SELF_CONTRACT_NUM)
				break;
		}

	}
	else
	{
		std::vector<TPlateRow> CmpVector(m_SelectVec);
		for (size_t idx = 0; idx < m_ContractView.GetRowCount(); idx++)
		{
			wchar_t cname[51];
			m_ContractView.GetWStr(idx, 0, cname, sizeof(cname) / sizeof(wchar_t));
			void* cref(NULL);
			m_ContractView.GetVoid(idx, 1, cref);
			bool bContinue = false;
			for (size_t i = 0; i < CmpVector.size(); i++)
			{
				if (CmpVector[i].IsSpread)
					continue;
				if (CmpVector[i].Contract == cref)
				{
					bContinue = true;
					break;
				}
			}
			if (bContinue)
				continue;
			TPlateRow row;
			row.IsSpread = false;
			row.Contract = (SContract*)cref;
			m_SelectVec.push_back(row);

			int cindex = m_SelectView.GetRowCount();

			m_SelectView.SetWStr(cindex, 0, cname);
			m_SelectView.SetVoid(cindex, 1, cref);
			m_SelectView.SetStr(cindex, 2, "");
			m_SelectView.SetCheck(cindex, 3, false);
			if (m_SelectVec.size() >= MAX_SELF_CONTRACT_NUM)
				break;
		}

	}
	return true;
}
bool TSelectContractWindow::ClearAll()
{
	m_SelectView.Clear();
	m_SelectVec.clear();
	return true;
}
void TSelectContractWindow::ApplySelect()
{
	//��鱣��� �� �� �� ���ݶ���ָ���Ϊ��ֵ��ʽ
	if (!m_Plate)
		return;
	m_Plate->PlateRows.clear();

	for (size_t i = 0; i < m_SelectView.GetRowCount(); i++)
	{
		bool bSpread = false;
		m_SelectView.GetCheck(i, 3, bSpread);
		TPlateRow row;
		memset(&row, 0, sizeof(TPlateRow));
		if (bSpread)
		{
			m_SelectView.GetStr(i, 2, row.ContractNo, sizeof(SContractNoType));
			row.IsSpread = true;
			row.RowIndex = i;
		}
		else
		{
			void* cref(NULL);
			m_SelectView.GetVoid(i, 1, cref);
			row.Contract = (SContract*)cref;
			row.IsSpread = false;
			row.RowIndex = i;
		}
		m_Plate->PlateRows.push_back(row);
	}

	m_Plate->SaveRows();
}

//��ѡ��Լ����----------------------------------------------------------------------------------------------------
TSingleSelectContractWindow::TSingleSelectContractWindow() : m_Label(*this), m_TreeView(*this),
m_ContractView(*this, false), m_OkBtn(*this), m_CancelBtn(*this), m_Ret(false)
{
	m_Label.SetText(G_LANG->LangText(TLI_SELECT_CONTRACT));
	m_SelectCNo[0] = '\0';
	TDuiListViewCol col;
	col.Align = DT_LEFT;
	col.Type = DUI_LISTVIEW_VOID;
	col.PixelWidth = (LEFT_LISTVIEW_WIDTH - 10);
	col.Text[0] = L'\0';
	col.Visible = true;
	m_TreeView.AddCol(col);


	col.Align = DT_LEFT;
	col.Type = DUI_LISTVIEW_WSTR;
	col.PixelWidth = (LISTVIEW_WIDTH - 10);
	wcsncpy_s(col.Text, (wchar_t*)G_LANG->LangText(TLI_CONTRACT), sizeof(col.Text) / sizeof(wchar_t) - 1);
	col.Visible = true;
	m_ContractView.AddCol(col);

	col.Type = DUI_LISTVIEW_VOID;
	col.Visible = false;
	m_ContractView.AddCol(col);

	col.Type = DUI_LISTVIEW_STR;
	col.Visible = false;

	m_ContractView.AddCol(col);

	m_TreeView.SetSpi(this);
	m_ContractView.SetSpi(this);
	m_OkBtn.SetText(G_LANG->LangText(TLI_BTN_OK));
	m_OkBtn.SetSpi(this);
	m_CancelBtn.SetText(G_LANG->LangText(TLI_BTN_CANCEL));
	m_CancelBtn.SetSpi(this);
	LoadTreeDate();
	LoadContract();
}

bool TSingleSelectContractWindow::ShowSelectContractWindow()
{
	G_MainFrame->DisableFrames();

	RECT r = { 0, 0, 0, 0 };
	GetCurrScreenRect(r);
	r.right -= r.left;
	r.bottom -= r.top;
	ShowModal(WS_POPUP | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, WS_EX_TOOLWINDOW | WS_EX_TOPMOST,
		BRUSH_CONFIGWINDOW_BACKGROUND, r.left + (r.right - WINDOW_WIDTH) / 2, r.top + (r.bottom - WINDOW_HEIGHT) / 2, WINDOW_WIDTH, WINDOW_HEIGHT);

	G_MainFrame->EnableFrames();
	return m_Ret;
}
void TSingleSelectContractWindow::GetSelContractNo(SContractNoType& sno)
{
	strcpy_s(sno, m_SelectCNo);
}
void TSingleSelectContractWindow::OnButtonClick(TDuiButtonControl* obj)
{
	if (&m_OkBtn == obj)
	{
		m_Ret = true;
		LoadSelContract();
		Destroy();
		Quit();
	}
	else if (&m_CancelBtn == obj)
	{
		Destroy();
		Quit();
	}

}

void TSingleSelectContractWindow::OnListViewClick(TDuiListViewControl* obj)
{
	if (&m_TreeView == obj)
	{
		LoadContract();
		m_ContractView.Redraw(NULL);
	}
}

void TSingleSelectContractWindow::OnListViewDbClick(TDuiListViewControl* obj)
{
	if (&m_ContractView == obj)
	{
		m_Ret = true;
		LoadSelContract();
		Destroy();
		Quit();
	}
}

void TSingleSelectContractWindow::OnSize(WPARAM wParam, LPARAM lParam)
{
	const POINTS& pts = *(POINTS*)&lParam;

	POINT p = { WINDOW_BORDER, WINDOW_BORDER };
	SIZE s = { pts.x - 2 * WINDOW_BORDER, CAPTION_HEIGHT };
	m_Label.MoveAndSize(&p, &s);

	p = { WINDOW_BORDER, WINDOW_BORDER + CAPTION_HEIGHT + 1 };
	s = { LEFT_LISTVIEW_WIDTH, pts.y - 2 * WINDOW_BORDER - CAPTION_HEIGHT - 1 };
	m_TreeView.MoveAndSize(&p, &s);

	p = { 3 * WINDOW_BORDER + LEFT_LISTVIEW_WIDTH + WINDOW_BORDER, WINDOW_BORDER + CAPTION_HEIGHT + 1 };
	s = { LISTVIEW_WIDTH, pts.y - 2 * WINDOW_BORDER - CAPTION_HEIGHT - 1 };
	m_ContractView.MoveAndSize(&p, &s);

	p = { 3 * WINDOW_BORDER + 2 * LEFT_LISTVIEW_WIDTH + WINDOW_BORDER , pts.y / 2 - BTN_HEIGHT };
	s = { BTN_WIDTH, BTN_HEIGHT };
	m_OkBtn.MoveAndSize(&p, &s);

	p.y = pts.y / 2 + BTN_HEIGHT;
	m_CancelBtn.MoveAndSize(&p, &s);

}

void TSingleSelectContractWindow::LoadTreeDate()
{
	//�Ƚ�����������
	std::set<std::string> exchanges;

	for (int i = 0; i < sizeof(FIRST_EXCHANGE_ARRAY) / sizeof(char*); i++)
	{
		SExchange* e;
		if (G_StarApi->GetExchangeData(FIRST_EXCHANGE_ARRAY[i], &e, 1, false) <= 0)
			continue;

		exchanges.insert(FIRST_EXCHANGE_ARRAY[i]);
		size_t index = m_TreeView.GetRowCount();

		wchar_t ename[128];
		MByteToWChar(e->ExchangeName, ename, sizeof(ename) / sizeof(wchar_t));
		wcsncat_s(ename, L" ", 1);
		MultiByteToWideChar(1252, 0, e->ExchangeNo, -1, &ename[wcslen(ename)], sizeof(ename) / sizeof(wchar_t) - wcslen(ename));

		Node* pExcNode = m_TreeView.AddNode(index, ename, e->ExchangeNo);
		//���ӽ�����Ʒ��
		if (pExcNode)
		{
			LoadCommodity(e->ExchangeNo, pExcNode);
		}
	}


	//���Զ�������
	SExchange* array[128];
	int count = G_StarApi->GetExchangeData(NULL, array, sizeof(array) / sizeof(SExchange*), true);
	for (int i = 0; i < count; i++)
	{
		SExchange* e = array[i];
		if (exchanges.end() == exchanges.find(e->ExchangeNo))
		{
			size_t index = m_TreeView.GetRowCount();

			wchar_t ename[128];
			MByteToWChar(e->ExchangeName, ename, sizeof(ename) / sizeof(wchar_t));
			wcsncat_s(ename, L" ", 1);
			MultiByteToWideChar(1252, 0, e->ExchangeNo, -1, &ename[wcslen(ename)], sizeof(ename) / sizeof(wchar_t) - wcslen(ename));

			Node* pExcNode = m_TreeView.AddNode(index, ename, e->ExchangeNo);
			//���ӽ�����Ʒ��
			if (pExcNode)
			{
				LoadCommodity(e->ExchangeNo, pExcNode);
			}
		}
	}

	//���ӱ�������
	//size_t index = m_TreeView.GetRowCount();
	//Node* pSpreadNode = m_TreeView.AddNode(index, (wchar_t*)G_LANG->LangText(TLI_LOCAL_SPREAD), (char*)SpreadNo);
	if (m_TreeView.GetRowCount() > 0)
		m_TreeView.SetSelectIndex(0);
	m_TreeView.SetFocus();
}

void TSingleSelectContractWindow::LoadCommodity(SExchangeNoType eno, Node* pExcNode)
{
	SCommodity* array[1024];
	int cnt = G_StarApi->GetCommodityData(eno, NULL, array, sizeof(array) / sizeof(SCommodity*), true);

	for (int i = 0; i < cnt; i++)
	{
		SCommodity* c = array[i];

		const char* pos = strchr(c->CommodityNo, '|');
		if (NULL != pos)
		{
			wchar_t cname[51];
			MByteToWChar(c->CommodityName, cname, sizeof(cname) / sizeof(wchar_t));
			switch (pos[1])
			{
			case 'F':
				wcsncat_s(cname, G_LANG->LangText(TLI_SEL_FUTURES), sizeof(cname) / sizeof(wchar_t) - 1);
				break;
			case 'O':
				wcsncat_s(cname, G_LANG->LangText(TLI_SEL_OPTIONS), sizeof(cname) / sizeof(wchar_t) - 1);
				break;
			case 'Z':
				wcsncat_s(cname, G_LANG->LangText(TLI_SEL_INDEX), sizeof(cname) / sizeof(wchar_t) - 1);
				break;
			case 'S':
				wcsncat_s(cname, G_LANG->LangText(TLI_SEL_SPREAD), sizeof(cname) / sizeof(wchar_t) - 1);
				break;
			case 'M':
				wcsncat_s(cname, G_LANG->LangText(TLI_SEL_SPREAD2), sizeof(cname) / sizeof(wchar_t) - 1);
				break;
			case 'T':
				wcsncat_s(cname, G_LANG->LangText(TLI_SEL_SPOT), sizeof(cname) / sizeof(wchar_t) - 1);
				break;
			default:
				break;
			}
			size_t index = m_TreeView.GetRowCount();
			m_TreeView.AddNode(index, cname, c->CommodityNo, pExcNode);
		}
	}
}
bool TSingleSelectContractWindow::IsThreeLevel(Node* pNode)
{
	Node* pParent = pNode->GetParent();
	if (pParent&&pParent->isVisiable())
	{
		if (strcmp(pParent->data()._extrnData, OTHER_EXCHANGE_No) == 0)
			return true;
	}
	return false;
}
void TSingleSelectContractWindow::LoadContract()
{
	m_ContractView.Clear();

	if (m_TreeView.GetSelectIndex() >= 0 && m_TreeView.GetSelectIndex() < (int)m_TreeView.GetRowCount())		//��ǰƷ��
	{
		Node* pSelNode = m_TreeView.GetSelNode();
		if (!pSelNode || !pSelNode->isVisiable())
			return;
		char cno[51];
		m_TreeView.GetExtrnStr(m_TreeView.GetSelectIndex(), cno, sizeof(SCommodityNoType));
		if (pSelNode->data()._level == 0 || IsThreeLevel(pSelNode)) // ���������к�Լ
		{
			if (strcmp(cno, SpreadNo) == 0)
			{
				LoadSpreadContract();
			}
			else
			{
				SCommodity* array[1024];
				int cnt = G_StarApi->GetCommodityData(cno, NULL, array, sizeof(array) / sizeof(SCommodity*), true);
				int nCount = 0;
				for (int i = 0; i < cnt; i++)
				{
					SCommodity* com = array[i];
					char* pos = strchr(com->CommodityNo, '|');
					if (pos&&pos[1] == 'O')
						continue;
					SContractNoType begin;
					begin[0] = '\0';
					SContract* array[1024];
					while (true)
					{
						int cnt = G_StarApi->GetContractData(com->CommodityNo, begin, array, sizeof(array) / sizeof(SContract*), true);

						for (int j = 0; j < cnt; j++)
						{
							SContract* c = array[j];

							wchar_t cname[101];
							GetContractName(G_StarApi, c->ContractNo, cname);
							m_ContractView.SetWStr(nCount, 0, cname);
							m_ContractView.SetVoid(nCount, 1, (void*)c);
							nCount++;
						}

						if (cnt < sizeof(array) / sizeof(SContract*))
							break;
						strcpy_s(begin, array[cnt - 1]->ContractNo);
					}
				}
			}
		}
		else
		{
			SContractNoType begin;
			begin[0] = '\0';

			SContract* array[1024];

			int nCount = 0;
			while (true)
			{
				int cnt = G_StarApi->GetContractData(cno, begin, array, sizeof(array) / sizeof(SContract*), true);

				for (int i = 0; i < cnt; i++)
				{
					SContract* c = array[i];

					wchar_t cname[101];
					GetContractName(G_StarApi, c->ContractNo, cname);
					m_ContractView.SetWStr(nCount, 0, cname);
					m_ContractView.SetVoid(nCount, 1, (void*)c);
					nCount++;
				}

				if (cnt < sizeof(array) / sizeof(SContract*))
					break;
				strcpy_s(begin, array[cnt - 1]->ContractNo);
			}
		}

	}
}

void TSingleSelectContractWindow::LoadSpreadContract()
{
	SSpreadContract array[1024];
	while (true)
	{
		int cnt = G_StarApi->GetSpreadInfo("", array, sizeof(array) / sizeof(SSpreadContract), true, S_SPREADSRC_SELF);
		for (int i = 0; i < cnt; i++)
		{
			SSpreadContract c = array[i];
			SContractNoType cno;
			G_QuoteUtils.GetSpreadContractNo(&c, cno);
			wchar_t cname[101];
			GetContractName(G_StarApi, cno, cname);
			m_ContractView.SetWStr(i, 0, cname);
			m_ContractView.SetStr(i, 2, cno);
		}
		if (cnt < sizeof(array) / sizeof(SSpreadContract))
			break;
	}
}
bool TSingleSelectContractWindow::LoadSelContract()
{
	char cno[51];
	m_TreeView.GetExtrnStr(m_TreeView.GetSelectIndex(), cno, sizeof(SCommodityNoType));
	int nIndex = m_ContractView.GetSelectIndex();
	if (nIndex < 0 || nIndex >= (int)m_ContractView.GetRowCount())
		return false;
	if (strcmp(cno, SpreadNo) == 0)
	{
		m_ContractView.GetStr(nIndex, 2, m_SelectCNo, sizeof(SContractNoType));
	}
	else
	{
		void* cref(NULL);
		m_ContractView.GetVoid(nIndex, 1, cref);
		if (cref)
		{
			SContract* pContract = (SContract*)cref;
			strcpy_s(m_SelectCNo, pContract->ContractNo);
		}
	}
	return true;
}

//����MA��ϴ���----------------------------------------------------------------------------------------------------------
TMaConfigWindow::TMaConfigWindow(TKChartSpec* linespace) : m_LineSpace(linespace), m_Label(*this),
m_Label_1(*this), m_Label_2(*this), m_Label_3(*this), m_Label_4(*this), m_Label_5(*this), m_Label_6(*this),
m_Edit_1(*this), m_Edit_2(*this), m_Edit_3(*this), m_Edit_4(*this), m_Edit_5(*this), m_Edit_6(*this),
m_Btn_Clear(*this), m_Btn_Ok(*this), m_Btn_Cancel(*this), m_Btn_Restore(*this), m_Ret(false)
{
	wchar_t title[51];
	swprintf_s(title, G_LANG->LangText(TLI_MA_CONFIG), linespace->SpecName);
	m_Label.SetText(title);

	m_Label_1.DisableMove();
	m_Label_1.SetFontColor(COLOR_SPEC_LINE[0]);
	m_Label_1.SetText(linespace->Params[0].Name);

	m_Label_2.DisableMove();
	m_Label_2.SetFontColor(COLOR_SPEC_LINE[1]);
	m_Label_2.SetText(linespace->Params[1].Name);

	m_Label_3.DisableMove();
	m_Label_3.SetFontColor(COLOR_SPEC_LINE[2]);
	m_Label_3.SetText(linespace->Params[2].Name);

	m_Label_4.DisableMove();
	m_Label_4.SetFontColor(COLOR_SPEC_LINE[3]);
	m_Label_4.SetText(linespace->Params[3].Name);

	m_Label_5.DisableMove();
	m_Label_5.SetFontColor(COLOR_SPEC_LINE[4]);
	m_Label_5.SetText(linespace->Params[4].Name);

	m_Label_6.DisableMove();
	m_Label_6.SetFontColor(COLOR_SPEC_LINE[5]);
	m_Label_6.SetText(linespace->Params[5].Name);

	ClearEdit();

	SetEditText(linespace->Params);

	m_Btn_Restore.SetText(G_LANG->LangText(TLI_RESTORE_DEFAULT_PARAM));
	m_Btn_Restore.SetSpi(this);
	m_Btn_Clear.SetText(G_LANG->LangText(TLI_BTN_CLEAR));
	m_Btn_Clear.SetSpi(this);
	m_Btn_Ok.SetText(G_LANG->LangText(TLI_BTN_OK));
	m_Btn_Ok.SetSpi(this);
	m_Btn_Cancel.SetText(G_LANG->LangText(TLI_BTN_CANCEL));
	m_Btn_Cancel.SetSpi(this);

	m_Edit_1.SetFocus();
}

bool TMaConfigWindow::ShowMaConfigWindow()
{
	G_MainFrame->DisableFrames();

	RECT r = { 0, 0, 0, 0 };
	GetCurrScreenRect(r);
	r.right -= r.left;
	r.bottom -= r.top;
	ShowModal(WS_POPUP | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, WS_EX_TOOLWINDOW | WS_EX_TOPMOST,
		BRUSH_CONFIGWINDOW_BACKGROUND, r.left + (r.right - WINDOW_WIDTH) / 2, r.top + (r.bottom - WINDOW_HEIGHT) / 2, WINDOW_WIDTH, WINDOW_HEIGHT);

	G_MainFrame->EnableFrames();
	return m_Ret;
}

void TMaConfigWindow::OnButtonClick(TDuiButtonControl* obj)
{
	if (&m_Btn_Restore == obj)
	{
		CIndex* pSpace = CIndexMgr::GetInstance()->GetIndexByName(m_LineSpace->SpecName);
		if (pSpace)
			SetEditText(pSpace->GetParamAddr());
		IndexParams::GetInstance()->EraseParam(m_LineSpace->SpecName);
		Redraw(NULL);
	}
	else if (&m_Btn_Clear == obj)
	{
		ClearEdit();
		Redraw(NULL);
	}
	else if (&m_Btn_Ok == obj)
	{
		m_Ret = true;
		SaveEdit();
		Destroy();
		Quit();
	}
	else
	{
		Destroy();
		Quit();
	}

}

void TMaConfigWindow::OnSize(WPARAM wParam, LPARAM lParam)
{
	const POINTS& pts = *(POINTS*)&lParam;

	POINT p = { WINDOW_BORDER, WINDOW_BORDER };
	SIZE s = { pts.x - 2 * WINDOW_BORDER, CAPTION_HEIGHT };
	m_Label.MoveAndSize(&p, &s);

	p.x = 20;
	p.y += CAPTION_HEIGHT + LABEL_GAP;
	s.cx = LABEL_WIDTH;
	s.cy = LABEL_HEIGHT;
	m_Label_1.MoveAndSize(&p, &s);

	POINT p1 = p;
	p1.x += LABEL_WIDTH + LABEL_GAP;
	SIZE s1 = { EDIT_WIDTH, LABEL_HEIGHT };
	m_Edit_1.MoveAndSize(&p1, &s1);

	p.y += LABEL_HEIGHT + LABEL_GAP;
	m_Label_2.MoveAndSize(&p, &s);

	p1.y = p.y;
	m_Edit_2.MoveAndSize(&p1, &s1);

	p.y += LABEL_HEIGHT + LABEL_GAP;
	m_Label_3.MoveAndSize(&p, &s);

	p1.y = p.y;
	m_Edit_3.MoveAndSize(&p1, &s1);

	p.y += LABEL_HEIGHT + LABEL_GAP;
	m_Label_4.MoveAndSize(&p, &s);

	p1.y = p.y;
	m_Edit_4.MoveAndSize(&p1, &s1);

	p.y += LABEL_HEIGHT + LABEL_GAP;
	m_Label_5.MoveAndSize(&p, &s);

	p1.y = p.y;
	m_Edit_5.MoveAndSize(&p1, &s1);

	p.y += LABEL_HEIGHT + LABEL_GAP;
	m_Label_6.MoveAndSize(&p, &s);

	p1.y = p.y;
	m_Edit_6.MoveAndSize(&p1, &s1);


	//
	p.x = pts.x - 2 * BTN_WIDTH - 20;
	p.y = pts.y - 2 * BTN_HEIGHT - LABEL_GAP - 10;
	s.cx = 2 * BTN_WIDTH;
	s.cy = BTN_HEIGHT;
	m_Btn_Restore.MoveAndSize(&p, &s);

	p.x = pts.x - 3 * BTN_WIDTH - 3 * LABEL_GAP;
	p.y = pts.y - BTN_HEIGHT - LABEL_GAP;
	s.cx = BTN_WIDTH;
	s.cy = BTN_HEIGHT;
	m_Btn_Clear.MoveAndSize(&p, &s);

	p.x += BTN_WIDTH + LABEL_GAP;
	m_Btn_Ok.MoveAndSize(&p, &s);

	p.x += BTN_WIDTH + LABEL_GAP;
	m_Btn_Cancel.MoveAndSize(&p, &s);
}

void TMaConfigWindow::ClearEdit()
{
	m_Edit_1.SetText(L"\0");
	m_Edit_2.SetText(L"\0");
	m_Edit_3.SetText(L"\0");
	m_Edit_4.SetText(L"\0");
	m_Edit_5.SetText(L"\0");
	m_Edit_6.SetText(L"\0");
}
void TMaConfigWindow::SetEditText(TKLineSpecParam Params[6])
{
	wchar_t text[21];

	if (Params[0].Value > 0)
	{
		_itow_s(Params[0].Value, text, 10);
		m_Edit_1.SetText(text);
	}

	if (Params[1].Value > 0)
	{
		_itow_s(Params[1].Value, text, 10);
		m_Edit_2.SetText(text);
	}

	if (Params[2].Value > 0)
	{
		_itow_s(Params[2].Value, text, 10);
		m_Edit_3.SetText(text);
	}

	if (Params[3].Value > 0)
	{
		_itow_s(Params[3].Value, text, 10);
		m_Edit_4.SetText(text);
	}

	if (Params[4].Value > 0)
	{
		_itow_s(Params[4].Value, text, 10);
		m_Edit_5.SetText(text);
	}

	if (Params[5].Value > 0)
	{
		_itow_s(Params[5].Value, text, 10);
		m_Edit_6.SetText(text);
	}
}
void TMaConfigWindow::SaveEdit()
{
	wchar_t text[21];

	m_Edit_1.GetText(text);
	m_LineSpace->Params[0].Value = _wtoi(text);

	m_Edit_2.GetText(text);
	m_LineSpace->Params[1].Value = _wtoi(text);

	m_Edit_3.GetText(text);
	m_LineSpace->Params[2].Value = _wtoi(text);

	m_Edit_4.GetText(text);
	m_LineSpace->Params[3].Value = _wtoi(text);

	m_Edit_5.GetText(text);
	m_LineSpace->Params[4].Value = _wtoi(text);

	m_Edit_6.GetText(text);
	m_LineSpace->Params[5].Value = _wtoi(text);
}
#include "PreInclude.h"

CLine DrawZhiXian(HDC hDC, const POINT& pt1, const POINT& pt2, COLORREF clr, int nWid, int left, int right)
{
	POINT out1, out2;
	if (pt1.x == pt2.x)
	{
		out1.y = -10000;
		out2.y = 10000;
		out1.x = pt1.x;
		out2.x = pt1.x;
	}
	else if (pt1.y == pt2.y)
	{
		out1.y = out2.y = pt1.y;
		out1.x = left;
		out2.x = right;
	}
	else
	{
		out1.x = left;
		out2.x = right;
		out1.y = pt1.y + (left - pt1.x)*(pt2.y - pt1.y) / (pt2.x - pt1.x);
		out2.y = pt1.y + (right - pt1.x)*(pt2.y - pt1.y) / (pt2.x - pt1.x);
	}

	DrawLine(hDC, out1, out2, clr, nWid);
	return CLine(out1, out2);
}
CLine DrawSheXian(HDC hDC, const POINT& ptOrigin, const POINT& pt2, COLORREF clr, int nPenWid)
{
	float yy = pt2.y - ptOrigin.y;
	float xx = pt2.x - ptOrigin.x;

	if (xx == 0 && yy == 0)
	{
		return CLine(ptOrigin, ptOrigin);
	}
	POINT ptDes;
	POINT ptfrom = ptOrigin;
	if (xx == 0)
	{
		int desY = (yy < 0 ? 0 : 10000);
		ptDes.x = ptOrigin.x;
		ptDes.y = desY;
		//��ֱ��
		DrawLine(hDC, ptfrom, ptDes, clr, nPenWid);
	}
	else
	{
		int desX = (xx > 0 ? 10000 : 0);
		int desY = ptOrigin.y + (desX - ptOrigin.x)*(yy / xx);
		ptDes.x = desX;
		ptDes.y = desY;

		DrawLine(hDC, ptfrom, ptDes, clr, nPenWid);
	}
	return CLine(ptOrigin, ptDes);
}

TShape::TShape() :m_pAxisX(NULL), m_pChart(NULL), m_type(SHAPE_NONE), m_nPenWid(1), m_clr(0), m_bSelected(FALSE), m_bFocus(FALSE), m_curMovingGripperIdx(-1)
, m_bResetAxis(false),m_nIcon(0)
{
}


TShape::~TShape()
{
}
void TShape::Create(SHAPE_TYPE type, TKLineChart* pChart, TKLineAxisX* pAxisX, const std::vector<ChartDot>& data, COLORREF clr, int penWid)
{
	m_type = type;
	m_clr = clr;
	m_nPenWid = penWid;
	m_pChart = pChart;
	m_pAxisX = pAxisX;
	m_Gripers.clear();
	std::copy(data.begin(), data.end(), std::back_inserter(m_Gripers));
	if (pAxisX == NULL) return;
	for (size_t i = 0; i < m_Gripers.size(); i++)
	{
		if (m_Gripers[i].tm > 0)
		{

			//m_Gripers[i].x = pAxisX->GetXValueByTime(m_Gripers[i].tm);
		}
		else if (m_Gripers[i].x >= 0)
		{
			//if (m_Gripers[i].x < pAxisX->KData.Size())
			{
				m_Gripers[i].tm = pAxisX->KData.GetData(m_Gripers[i].x + m_pAxisX->Begin).DateTimeStamp;
			}
		}
	}
}
void TShape::BeginDraw(HDC mdc)
{
	m_clrNormal = m_clr;
	m_arrLines.clear();
	if (m_bSelected)
	{
		m_clr = ColorReverse();
	}
}
void TShape::EndDraw(HDC mdc)
{
	if (m_bSelected || m_bFocus)
	{
		DrawGripers(mdc);
	}
	m_clr = m_clrNormal;
}

void TShape::DrawGripers(HDC mdc)
{
	int cnt = m_Gripers.size();
	POINT ptCur;
	for (int i = 0; i < cnt; i++)
	{
		ptCur = Griper2Pix(m_Gripers[i]);
		DrawMaoDian(mdc, ptCur, m_clr);
	}
}
int TShape::HitTest(const POINT& pt)
{
	int cnt = m_Gripers.size();
	POINT ptPix;

	for (int i = 0; i < cnt; i++)
	{
		ptPix = Griper2Pix(m_Gripers[i]);

		if (abs(ptPix.x - pt.x) < 5 && abs(ptPix.y - pt.y) < 5) return i;
	}
	cnt = m_arrLines.size();
	for (int i = 0; i < cnt; i++)
	{
		if (PtInLine(pt, m_arrLines[i].pt1, m_arrLines[i].pt2))
			return -2;
	}
	return -1;
}

POINT TShape::Griper2Pix(const ChartDot& dot)
{
	POINT pt = { 0 ,0 };
	if (!m_pChart || !m_pAxisX)
		return pt;
	RECT ccr = m_pChart->CenterChartRect;
	int nBarWid = m_pAxisX->DataWidth[0];
	pt.x = ccr.left + (LONG)m_pAxisX->Value2Pix(dot.x)+ nBarWid/2;
	pt.y = m_pChart->YAxis_Price2Pix(dot.y);
	return pt;
}
void TShape::OnClick(const POINT& pt)
{
	if (m_bSelected)
	{
		Select(FALSE);
	}
	else
	{
		int ret = HitTest(pt);
		if (ret != -1)
		{
			m_PointOrigin = pt;
			Select(TRUE, ret);
		}
	}
}
void TShape::OnMove(const POINT& pt)
{
	int offsetX = pt.x - m_PointOrigin.x;
	int offsetY = pt.y - m_PointOrigin.y;

	if (m_curMovingGripperIdx == -1)
		m_Gripers.clear();
	RECT ccr = m_pChart->CenterChartRect;
	POINT curPt;
	ChartDot curDot;
	for (size_t i = 0; i < m_PointsOrigin.size(); i++)
	{
		if (m_curMovingGripperIdx != -1)
		{
			if (i == m_curMovingGripperIdx)
			{
				curPt.x = m_PointsOrigin[i].x + offsetX;
				curPt.y = m_PointsOrigin[i].y + offsetY;
				curDot.x = m_pAxisX->Pix2Value(curPt.x-ccr.left);
				curDot.y = m_pChart->YAxis_Pix2Price(curPt.y);
				curDot.tm = m_pAxisX->KData.GetData(curDot.x + m_pAxisX->Begin).DateTimeStamp;
				m_Gripers[i] = curDot;
			}
		}
		else
		{
			curPt.x = m_PointsOrigin[i].x + offsetX;
			curPt.y = m_PointsOrigin[i].y + offsetY;
			curDot.x = m_pAxisX->Pix2Value(curPt.x - ccr.left);
			curDot.y = m_pChart->YAxis_Pix2Price(curPt.y);
			curDot.tm = m_pAxisX->KData.GetData(curDot.x + m_pAxisX->Begin).DateTimeStamp;
			m_Gripers.push_back(curDot);
		}

	}
}
void TShape::Select(bool bSel, int nGripper)
{
	m_bSelected = bSel;
	if (bSel)
	{
		m_PointsOrigin.clear();
		for (size_t i = 0; i < m_Gripers.size(); i++)
		{
			m_PointsOrigin.push_back(Griper2Pix(m_Gripers[i]));
		}
		if (nGripper >= 0)
		{
			m_curMovingGripperIdx = nGripper;
		}
	}
	else
	{
		m_curMovingGripperIdx = -1;
	}
}
void TShape::ResetAxis()
{
	if (m_Gripers.empty())
		return;
	if (!m_pChart || !m_pAxisX)
		return;
	if (m_bResetAxis)
	{
		int nIndex = 0, nPos = 0;
		for (size_t i = 0; i < m_Gripers.size(); i++)
		{
			if (m_Gripers[i].tm > 0)
			{
				int ret = m_pAxisX->GetXValueByTime(m_Gripers[i].tm);
				if (ret != 0)
				{
					nIndex = m_Gripers[i].x;
					nPos = i;
					break;
				}
			}
		}
		//����Ϊ�������
		for (size_t i = 0; i < m_Gripers.size(); i++)
		{
			m_Gripers[i].x = m_Gripers[i].x - nIndex;
		}
		if (m_Gripers[nPos].tm > 0)
		{
			int nPosX = m_pAxisX->GetXValueByTime(m_Gripers[nPos].tm);
			if (nPosX == 0)
				nPosX = (m_pAxisX->KData.WriteIndex - m_pAxisX->Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X + 10;
			for (size_t i = 0; i < m_Gripers.size(); i++)
			{
				m_Gripers[i].x = m_Gripers[i].x + nPosX;
			}
		}
		m_bResetAxis = false;
	}
}

void TShape::ResetXAxis()
{
	if (m_Gripers.empty())
		return;
	if (!m_pChart || !m_pAxisX)
		return;
	TCriticalSection::Lock lock(m_Crit);
	m_bResetAxis = true;
}
void TShape::GetStoreinfo(char* pStr, int len)
{
	memset(pStr, 0, len);
	Object_Info* pInfo = (Object_Info*)pStr;
	pInfo->Vertion = Version;
	pInfo->Type = m_type;
	pInfo->Clr = m_clr;
	pInfo->Icon = m_nIcon;
	pInfo->PenWid = m_nPenWid;
	pInfo->Count = m_Gripers.size();
	for (size_t i = 0; i < m_Gripers.size(); i++)
	{
		Griper_Info* pGriper = (Griper_Info*)(pStr + sizeof(Object_Info) + i * sizeof(Griper_Info));
		pGriper->Tm = m_Gripers[i].tm;
		pGriper->Y = m_Gripers[i].y;
		pGriper->X = m_Gripers[i].x;
	}
}
void TShape::SetStoreinfo(char* pStr,int len)
{
	Object_Info* pInfo = (Object_Info*)pStr;
	int nVersion = pInfo->Vertion;
	m_type = pInfo->Type;
	m_clr  = pInfo->Clr;
	m_nIcon = pInfo->Icon;
	m_nPenWid = pInfo->PenWid;
	int ncount = pInfo->Count;   //ê�����
	for (int i = 0; i < ncount; i++)
	{
		ChartDot griper;
		Griper_Info* pGriper = (Griper_Info*)(pStr + sizeof(Object_Info) + i * sizeof(Griper_Info));
		griper.y = pGriper->Y;
		griper.x = pGriper->X;
		griper.tm = pGriper->Tm;
		m_Gripers.push_back(griper);
	}

}
int TShape::GetStoreSize()
{
	return sizeof(Object_Info) + m_Gripers.size() * sizeof(Griper_Info);
}
void TShape::GetGripers(std::vector<ChartDot>& ogripers)
{
	ogripers.clear();
	std::copy(m_Gripers.begin(), m_Gripers.end(), std::back_inserter(ogripers));
}
void THorizVertLine::Draw(HDC pDC)
{
	if (m_Gripers.size() != 1)
		return;
	if (!m_pChart || !m_pAxisX)
		return;
	POINT ptPix = Griper2Pix(m_Gripers[0]);
	RECT ccr = m_pChart->CenterChartRect;
	if (GetType() == HORIZONTAL_LINE)
	{
		DrawLine(pDC, ccr.left, ptPix.y, ccr.right, ptPix.y, m_clr);
		m_arrLines.push_back(CLine(ccr.left, ptPix.y, ccr.right, ptPix.y));
	}
	else
	{
		DrawLine(pDC, ptPix.x, ccr.top, ptPix.x, ccr.bottom, m_clr);
		m_arrLines.push_back(CLine(ptPix.x, ccr.top, ptPix.x, ccr.bottom));
	}
}

void TNormalLine::Draw(HDC pDC)
{
	if (m_Gripers.size() != 2)
		return;
	if (!m_pChart || !m_pAxisX)
		return;
	POINT ptPix1 = Griper2Pix(m_Gripers[0]);
	POINT ptPix2 = Griper2Pix(m_Gripers[1]);
	RECT ccr = m_pChart->CenterChartRect;
	if (GetType() == LEADER_LINE)
	{
		DrawArrowLine(pDC, ptPix1, ptPix2, m_clr, m_nPenWid);
		m_arrLines.push_back(CLine(ptPix1, ptPix2));
	}
	else if (GetType() == TREND_LINE)
	{
		CLine tmpLine = DrawZhiXian(pDC, ptPix1, ptPix2, m_clr, m_nPenWid, ccr.left, ccr.right);
		m_arrLines.push_back(tmpLine);
	}
	else
	{
		DrawLine(pDC, ptPix1, ptPix2, m_clr, m_nPenWid);
		m_arrLines.push_back(CLine(ptPix1, ptPix2));
	}
}

void TPXX::Draw(HDC pDC)
{
	if (m_Gripers.size() != 3)
		return;
	if (!m_pChart || !m_pAxisX)
		return;
	POINT ptPix1 = Griper2Pix(m_Gripers[0]);
	POINT ptPix2 = Griper2Pix(m_Gripers[1]);
	POINT ptPix3 = Griper2Pix(m_Gripers[2]);
	RECT ccr = m_pChart->CenterChartRect;
	DrawZhiXian(pDC, ptPix1, ptPix2, m_clr, m_nPenWid, ccr.left, ccr.right);
	m_arrLines.push_back(CLine(ptPix1, ptPix2));
	POINT ptCuiZu = Getplumb(ptPix1, ptPix2, ptPix3);
	int nWidth = ccr.right - ccr.left;
	int nHigth = ccr.bottom - ccr.top;
	int maxDistance = sqrt((double)(nWidth*nWidth + nHigth * nHigth));

	int perDistance = PointToLine(ptPix3, ptPix1, ptPix2);
	if (perDistance < 5) return;

	int offX = ptPix3.x - ptCuiZu.x;
	int offY = ptPix3.y - ptCuiZu.y;

	int nStep = maxDistance / perDistance;

	for (int i = 1; i < nStep; i++)
	{
		POINT pt1, pt2;
		pt1.x = ptPix1.x + offX*i;
		pt1.y = ptPix1.y + offY*i;
		pt2.x = ptPix2.x + offX*i;
		pt2.y = ptPix2.y + offY*i;
		CLine tmpLine = DrawZhiXian(pDC, pt1, pt2, m_clr, m_nPenWid, ccr.left, ccr.right);
		m_arrLines.push_back(tmpLine);
		pt1.x = ptPix1.x - offX*i;
		pt1.y = ptPix1.y - offY*i;
		pt2.x = ptPix2.x - offX*i;
		pt2.y = ptPix2.y - offY*i;
		tmpLine = DrawZhiXian(pDC, pt1, pt2, m_clr, m_nPenWid, ccr.left, ccr.right);
		m_arrLines.push_back(tmpLine);
	}
}

void TTriangle::Draw(HDC pDC)
{
	if (m_Gripers.size() != 3)
		return;
	if (!m_pChart || !m_pAxisX)
		return;
	POINT ptPix1 = Griper2Pix(m_Gripers[0]);
	POINT ptPix2 = Griper2Pix(m_Gripers[1]);
	POINT ptPix3 = Griper2Pix(m_Gripers[2]);

	DrawLine(pDC, ptPix1, ptPix2, m_clr, m_nPenWid);
	DrawLine(pDC, ptPix1, ptPix3, m_clr, m_nPenWid);
	DrawLine(pDC, ptPix3, ptPix2, m_clr, m_nPenWid);
	m_arrLines.push_back(CLine(ptPix1, ptPix2));
	m_arrLines.push_back(CLine(ptPix1, ptPix3));
	m_arrLines.push_back(CLine(ptPix3, ptPix2));
}
void TRectShape::Draw(HDC pDC)
{
	if (m_Gripers.size() != 2)
		return;
	if (!m_pChart || !m_pAxisX)
		return;
	POINT ptPix1 = Griper2Pix(m_Gripers[0]);
	POINT ptPix2 = Griper2Pix(m_Gripers[1]);
	DrawRect(pDC, ptPix1.x, ptPix1.y, ptPix2.x, ptPix2.y, m_clr, m_nPenWid);
	m_arrLines.push_back(CLine(ptPix1.x, ptPix1.y, ptPix2.x, ptPix1.y));
	m_arrLines.push_back(CLine(ptPix1.x, ptPix1.y, ptPix1.x, ptPix2.y));
	m_arrLines.push_back(CLine(ptPix1.x, ptPix2.y, ptPix2.x, ptPix2.y));
	m_arrLines.push_back(CLine(ptPix2.x, ptPix1.y, ptPix2.x, ptPix2.y));
}
int  TArcShape::HitTest(const POINT&  pt)
{
	int cnt = m_Gripers.size();
	POINT ptPix;

	for (int i = 0; i < cnt; i++)
	{
		ptPix = Griper2Pix(m_Gripers[i]);

		if (abs(ptPix.x - pt.x) < 5 && abs(ptPix.y - pt.y) < 5) return i;
	}

	return PtInEllips(pt, m_circleRect, m_bUp) ? -2 : -1;
}
void TArcShape::Draw(HDC pDC)
{
	if (m_Gripers.size() != 2)
		return;
	if (!m_pChart || !m_pAxisX)
		return;
	POINT ptPix1 = Griper2Pix(m_Gripers[0]);
	POINT ptPix2 = Griper2Pix(m_Gripers[1]);
	int width = abs(2 * (ptPix2.x - ptPix1.x));
	int height = abs(2 * (ptPix2.y - ptPix1.y));

	int x = ptPix2.x > ptPix1.x ? ptPix1.x : (ptPix1.x - width);
	int y = ptPix2.y < ptPix1.y ? ptPix2.y : (ptPix2.y - height);


	if (ptPix2.y > ptPix1.y)
	{
		DrawArc(pDC, m_clr, x, y, x + width, y + height, x, y + height / 2, x + width, y + height / 2, m_nPenWid);
		m_bUp = TRUE;
	}
	else
	{
		DrawArc(pDC, m_clr, x, y, x + width, y + height, x + width, y + height / 2, x, y + height / 2, m_nPenWid);
		m_bUp = FALSE;
	}
	SetRect(&m_circleRect, x, y, x + width, y + height);
}
int  TCircleShape::HitTest(const POINT&  pt)
{
	int cnt = m_Gripers.size();
	POINT ptPix;

	for (int i = 0; i < cnt; i++)
	{
		ptPix = Griper2Pix(m_Gripers[i]);
		if (abs(ptPix.x - pt.x) < 5 && abs(ptPix.y - pt.y) < 5)
			return i;
	}

	for (size_t i = 0; i < m_circleRects.size(); i++)
	{
		if (PtInEllips(pt, m_circleRects[i], m_bUp))
		{
			return -2;
		}
	}
	return -1;
}
void TCircleShape::Draw(HDC pDC)
{
	if (m_Gripers.size() != 2)
		return;
	if (!m_pChart || !m_pAxisX)
		return;
	m_circleRects.clear();
	POINT ptPix1 = Griper2Pix(m_Gripers[0]);
	POINT ptCenter = Griper2Pix(m_Gripers[1]);
	//�뾶
	int nBJ = sqrt((double)(ptCenter.x - ptPix1.x)*(ptCenter.x - ptPix1.x) + (ptCenter.y - ptPix1.y)*(ptCenter.y - ptPix1.y));

	if (nBJ < 10) return;

	int nCurBJ = nBJ / 3;
	int nAddBJ = nBJ / 8;

	for (int i = 0; i < 3; i++)
	{
		if (ptPix1.y < ptCenter.y)
		{
			DrawArc(pDC, m_clr, ptCenter.x - nCurBJ, ptCenter.y - nCurBJ, ptCenter.x + nCurBJ, ptCenter.y + nCurBJ, ptCenter.x - nCurBJ, ptCenter.y, ptCenter.x + nCurBJ, ptCenter.y, m_nPenWid);
			m_bUp = TRUE;
		}
		else
		{
			DrawArc(pDC, m_clr, ptCenter.x - nCurBJ, ptCenter.y - nCurBJ, ptCenter.x + nCurBJ, ptCenter.y + nCurBJ, ptCenter.x + nCurBJ, ptCenter.y, ptCenter.x - nCurBJ, ptCenter.y, m_nPenWid);
			m_bUp = FALSE;
		}
		RECT rc;
		SetRect(&rc, ptCenter.x - nCurBJ, ptCenter.y - nCurBJ, ptCenter.x + nCurBJ, ptCenter.y + nCurBJ);
		m_circleRects.push_back(rc);
		nCurBJ += nAddBJ;
	}
}

void TZQXShape::Draw(HDC pDC)
{
	int nFirst = m_Gripers[0].x;
	int nStep = m_Gripers[1].x - nFirst;

	if (nStep == 0) return;
	int nBarWid = m_pAxisX->DataWidth[0];
	int nCount = 0;
	RECT ccr = m_pChart->CenterChartRect;
	for (int i = nFirst; abs(i) < m_pAxisX->KData.Size(); i += nStep)
	{
		int pixX = ccr.left + m_pAxisX->Value2Pix(i) + nBarWid / 2;

		if (pixX > ccr.right) break;
		if (nCount < 2)
		{
			DrawLine(pDC, pixX, ccr.top, pixX, ccr.bottom, m_clr, m_nPenWid);
			m_arrLines.push_back(CLine(pixX, ccr.top, pixX, ccr.bottom));
		}
		else
		{
			DotLine(pDC, pixX, ccr.top, pixX, ccr.bottom, m_clr);
			m_arrLines.push_back(CLine(pixX, ccr.top, pixX, ccr.bottom));
		}
		nCount++;
	}
}
void THJFG_BFBShape::Draw(HDC pDC)
{
	if (m_Gripers.size() != 2)
		return;
	if (!m_pChart || !m_pAxisX)
		return;
	POINT ptPix1 = Griper2Pix(m_Gripers[0]);
	POINT ptPix2 = Griper2Pix(m_Gripers[1]);
	int nDiff = ptPix2.y - ptPix1.y;
	//if (nDiff < 10) return;
	RECT ccr = m_pChart->CenterChartRect;
	DrawLine(pDC, ccr.left, ptPix1.y, ccr.right, ptPix1.y, m_clr, m_nPenWid);
	DrawLine(pDC, ccr.left, ptPix2.y, ccr.right, ptPix2.y, m_clr, m_nPenWid);
	m_arrLines.push_back(CLine(ccr.left, ptPix2.y, ccr.right, ptPix2.y));
	m_arrLines.push_back(CLine(ccr.left, ptPix1.y, ccr.right, ptPix1.y));

	SelectObject(pDC, FONT_KLINE_NUMBER);
	SetBkMode(pDC, TRANSPARENT);
	SetTextColor(pDC, m_clr);

	std::vector<double> arrPixY;

	if (m_type == GOLDEN_SECTION)
	{
		arrPixY.push_back(0.382);
		arrPixY.push_back(0.618);
		arrPixY.push_back(1.382);
		arrPixY.push_back(1.618);
	}
	else if (m_type == PERCENTAGE_LINE)
	{
		arrPixY.push_back(0.25);
		arrPixY.push_back(0.5);
		arrPixY.push_back(0.75);
	}
	SIZE sz;
	GetTextExtentPoint32(pDC, L"0.618", wcslen(L"0.618"), &sz);

	wchar_t str[21];
	RECT rcLabel;
	for (size_t i = 0; i < arrPixY.size(); i++)
	{
		DotLine(pDC, ccr.left, (int)(ptPix1.y + arrPixY[i] * nDiff), ccr.right, (int)(ptPix1.y + arrPixY[i] * nDiff), m_clr);
		m_arrLines.push_back(CLine(ccr.left, ptPix1.y + arrPixY[i] * nDiff, ccr.right, ptPix1.y + arrPixY[i] * nDiff));

		swprintf_s(str, L"%.3f", arrPixY[i]);
		rcLabel.left = ccr.right - sz.cx - 10;
		rcLabel.top = (int)(ptPix1.y + arrPixY[i] * nDiff);
		rcLabel.right = ccr.right;
		rcLabel.bottom = (int)(ptPix1.y + arrPixY[i] * nDiff + 40);
		DrawText(pDC, str, wcslen(str), &rcLabel, DT_LEFT | DT_SINGLELINE);
	}
}
void TFBLQShape::Draw(HDC pDC)
{
	if (m_Gripers.size() != 1)
		return;
	if (!m_pChart || !m_pAxisX)
		return;
	POINT ptPix1 = Griper2Pix(m_Gripers[0]);
	int nBarWid = m_pAxisX->DataWidth[0];
	RECT ccr = m_pChart->CenterChartRect;
	int curIdx = 0;
	int lastN = 0;
	int lastN2 = 0;

	for (int i = 0; i < 10000; i++)
	{
		curIdx = (i == 1) ? 1 : (lastN + lastN2);

		int nCurPixX = ptPix1.x + curIdx*nBarWid;

		if (nCurPixX > ccr.right) break;

		DrawLine(pDC, nCurPixX, ccr.top, nCurPixX, ccr.bottom, m_clr, m_nPenWid);
		m_arrLines.push_back(CLine(nCurPixX, ccr.top, nCurPixX, ccr.bottom));
		lastN2 = lastN;
		lastN = curIdx;

	}
}
void TSZX_GSXShape::Draw(HDC pDC)
{
	if (m_Gripers.size() != 2)
		return;
	if (!m_pChart || !m_pAxisX)
		return;
	POINT ptFrom = Griper2Pix(m_Gripers[0]);
	POINT ptCursor = Griper2Pix(m_Gripers[1]);
	if (ptCursor.x < ptFrom.x) return;
	DrawRect(pDC, ptFrom.x, ptFrom.y, ptCursor.x, ptCursor.y, m_clr, 1);
	DrawSheXian(pDC, ptFrom, ptCursor, m_clr, 1);
	std::vector<double> arrPixAdd;
	if (m_type == RESISTANCE_LINE)
	{
		arrPixAdd.push_back(1.0 / 3);
		arrPixAdd.push_back(2.0 / 3);
		for (size_t i = 0; i < arrPixAdd.size(); i++)
		{
			int curPixY = (int)(ptFrom.y + (ptCursor.y - ptFrom.y) *  arrPixAdd[i]);
			POINT pt;
			pt.x = ptCursor.x;
			pt.y = curPixY;
			m_arrLines.push_back(DrawSheXian(pDC, ptFrom, pt, m_clr, m_nPenWid));
		}
	}
	else
	{
		//������
		arrPixAdd.push_back(0.125);
		arrPixAdd.push_back(0.25);
		arrPixAdd.push_back(0.33);
		arrPixAdd.push_back(0.5);
		for (size_t i = 0; i < arrPixAdd.size(); i++)
		{
			int curPixY = (int)(ptFrom.y + (ptCursor.y - ptFrom.y)* arrPixAdd[i]);
			POINT pt;
			pt.x = ptCursor.x;
			pt.y = curPixY;
			m_arrLines.push_back(DrawSheXian(pDC, ptFrom, pt, m_clr, m_nPenWid));

			int curPixX = (int)(ptFrom.x + (ptCursor.x - ptFrom.x) * arrPixAdd[i]);
			pt.x = curPixX;
			pt.y = ptCursor.y;
			m_arrLines.push_back(DrawSheXian(pDC, ptFrom, pt, m_clr, m_nPenWid));
		}
	}
}
void TXXHG_Shape::Draw(HDC pDC)
{
	if (m_Gripers.size() != 2)
		return;
	if (!m_pChart || !m_pAxisX)
		return;
	int xFrom = m_Gripers[0].x;
	int xTo = m_Gripers[1].x;
	if (xFrom == xTo) return;

	POINT ptPix1 = Griper2Pix(m_Gripers[0]);
	POINT ptPix2 = Griper2Pix(m_Gripers[1]);
	RECT ccr = m_pChart->CenterChartRect;
	DrawLine(pDC, ptPix1.x, ccr.top, ptPix1.x, ccr.bottom, m_clr);
	m_arrLines.push_back(CLine(ptPix1.x, ccr.top, ptPix1.x, ccr.bottom));
	DrawLine(pDC, ptPix2.x, ccr.top, ptPix2.x, ccr.bottom, m_clr);
	m_arrLines.push_back(CLine(ptPix2.x, ccr.top, ptPix2.x, ccr.bottom));
	if (xFrom > xTo)
	{
		int tmpX = xFrom;
		xFrom = xTo;
		xTo = tmpX;
	}
	std::vector<double> arrData;
	for (int i = xFrom; i < xTo; i++)
	{
		arrData.push_back(ccr.left + m_pAxisX->Value2Pix(i));
		double yValue = m_pChart->YAxis_Price2Pix(m_pAxisX->KData.GetData(i + m_pAxisX->Begin).QLastPrice);
		arrData.push_back(yValue);
	}

	double a = 0, b = 0, other[4] = { 0 };
	//�����Իع�
	if (LinearRegression(arrData.data(), arrData.size() / 2, &b, &a, other) == 0)
	{
		//y = ax + b
		POINT ptA, ptB;
		ptA.x = ccr.left + m_pAxisX->Value2Pix(xFrom);
		ptA.y = (LONG)(ptA.x * a + b);
		ptB.x = ccr.left + m_pAxisX->Value2Pix(xTo);
		ptB.y = (LONG)(ptB.x * a + b);

		m_arrLines.push_back(DrawZhiXian(pDC, ptA, ptB, m_clr, m_nPenWid, ccr.left, ccr.right));

		int maxPixY = 0;
		int curPPP = 0;
		for (int i = xFrom; i < xTo; i++)
		{
			double curYPix = arrData[curPPP + 1];
			double curHGYPix = arrData[curPPP] * a + b;
			maxPixY = (int)max(abs(curYPix - curHGYPix), maxPixY);
			curPPP += 2;
		}
		POINT pt1, pt2;
		pt1.x = ptA.x;
		pt1.y = ptA.y - maxPixY;
		pt2.x = ptB.x;
		pt2.y = ptB.y - maxPixY;
		m_arrLines.push_back(DrawZhiXian(pDC, pt1, pt2, m_clr, m_nPenWid, ccr.left, ccr.right));
		pt1.x = ptA.x;
		pt1.y = ptA.y + maxPixY;
		pt2.x = ptB.x;
		pt2.y = ptB.y + maxPixY;
		m_arrLines.push_back(DrawZhiXian(pDC, pt1, pt2, m_clr, m_nPenWid, ccr.left, ccr.right));
	}
}

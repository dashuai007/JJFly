﻿#include "PreInclude.h"

void DrawLine(HDC hDC, int x1, int y1, int x2, int y2, COLORREF clr, int nWid)
{
	POINT ptFrom, ptTo;
	ptFrom.x = x1;
	ptFrom.y = y1;
	ptTo.x = x2;
	ptTo.y = y2;
	DrawLine(hDC, ptFrom, ptTo, clr, nWid);
}
void DrawLine(HDC hDC, POINT& from, POINT& to, COLORREF clr, int nWid)
{
	HPEN hPen = CreatePen(PS_SOLID, nWid, clr);
	SelectPen(hDC, hPen);
	MoveToEx(hDC, from.x, from.y, 0);
	LineTo(hDC, to.x, to.y);
	DeleteObject(hPen);
}
void DrawArrowLine(HDC hDC, const POINT& ptFrom, const POINT& ptTo, COLORREF clr, int nWid)
{
	HPEN hPen = CreatePen(PS_SOLID, nWid, clr);
	SelectPen(hDC, hPen);
	// 画带箭头的三角形：先画直线，再画箭头处的三角形
	double slopy = 0, cosy = 0, siny = 0;
	double par = 8.0; //length of Arrow (>)
	slopy = atan2(double(ptFrom.y - ptTo.y), double(ptFrom.x - ptTo.x));
	cosy = cos(slopy);
	siny = sin(slopy);

	// 画起点到终点的直线
	MoveToEx(hDC, ptFrom.x, ptFrom.y, 0);
	LineTo(hDC, ptTo.x, ptTo.y);

	// 计算出三角箭头的两端点的坐标
	POINT pt1,pt2;
	pt1.x = ptTo.x + int(par*cosy - (par / 2.0*siny));
	pt1.y = ptTo.y + int(par*siny + (par / 2.0*cosy));
	pt2.x = ptTo.x + int(par*cosy + par / 2.0*siny);
	pt2.y = ptTo.y - int(par / 2.0*cosy - par*siny);
	MoveToEx(hDC, pt1.x, pt1.y, 0);
	LineTo(hDC, ptTo.x, ptTo.y);

	MoveToEx(hDC, pt2.x, pt2.y, 0);
	LineTo(hDC, ptTo.x, ptTo.y);

	DeleteObject(hPen);
}
void DotLine(HDC hDC, int x1, int y1, int x2, int y2, COLORREF clr, int nPenWid, int nStyle)
{
	HPEN hPen = CreatePen(nStyle, nPenWid, clr);
	SelectPen(hDC, hPen);
	MoveToEx(hDC, x1, y1, 0);
	LineTo(hDC, x2, y2);
	DeleteObject(hPen);
}
void DrawRect(HDC hDC, int x1, int y1, int x2, int y2, COLORREF clr, int nWid)
{
	POINT aptRectangle[5];
	HPEN hPen = CreatePen(PS_SOLID, nWid, clr);
	SelectPen(hDC, hPen);
	aptRectangle[0].x = x1;
	aptRectangle[0].y = y1;
	aptRectangle[1].x = x2;
	aptRectangle[1].y = y1;
	aptRectangle[2].x = x2;
	aptRectangle[2].y = y2;
	aptRectangle[3].x = x1;
	aptRectangle[3].y = y2;
	aptRectangle[4].x = x1;
	aptRectangle[4].y = y1;
	Polyline(hDC, aptRectangle, 5);
	DeleteObject(hPen);
}
void DrawArc(HDC hDC, COLORREF clr, int nLeft, int nTop, int nRight, int nBottom, int nXStart, int nYStart, int nXEnd,int nYEnd, int nPenWid)
{
	HPEN hPen = CreatePen(PS_SOLID, nPenWid, clr);
	SelectPen(hDC, hPen);
	Arc(hDC, nLeft, nTop, nRight, nBottom, nXStart, nYStart, nXEnd, nYEnd);
	DeleteObject(hPen);
}
// 求线性回归方程：Y = a + bx
// dada[rows*2]数组：X, Y；rows：数据行数；a, b：返回回归系数
// SquarePoor[4]：返回方差分析指标: 回归平方和，剩余平方和，回归平方差，剩余平方差
// 返回值：0求解成功，-1错误
int LinearRegression(double *data, int rows, double *a, double *b, double *SquarePoor)
{
	int m;
	double *p, Lxx = 0.0, Lxy = 0.0, xa = 0.0, ya = 0.0;
	if (data == 0 || a == 0 || b == 0 || rows < 1)
		return -1;
	for (p = data, m = 0; m < rows; m++)
	{
		xa += *p++;
		ya += *p++;
	}
	xa /= rows;                                     // X平均值
	ya /= rows;                                     // Y平均值
	for (p = data, m = 0; m < rows; m++, p += 2)
	{
		Lxx += ((*p - xa) * (*p - xa));             // Lxx = Sum((X - Xa)平方)
		Lxy += ((*p - xa) * (*(p + 1) - ya));       // Lxy = Sum((X - Xa)(Y - Ya))
	}
	*b = Lxy / Lxx;                                 // b = Lxy / Lxx
	*a = ya - *b * xa;                              // a = Ya - b*Xa
	if (SquarePoor == 0)
		return 0;
	// 方差分析
	SquarePoor[0] = SquarePoor[1] = 0.0;
	for (p = data, m = 0; m < rows; m++, p++)
	{
		Lxy = *a + *b * *p++;
		SquarePoor[0] += ((Lxy - ya) * (Lxy - ya)); // U(回归平方和)
		SquarePoor[1] += ((*p - Lxy) * (*p - Lxy)); // Q(剩余平方和)
	}
	SquarePoor[2] = SquarePoor[0];                  // 回归方差
	SquarePoor[3] = SquarePoor[1] / (rows - 2);     // 剩余方差
	return 0;
}
//功能：已知一点，一条直线求垂足  
//参数：  
//CPoint pt1，直线起始点  
//CPoint pt2，直线终止点  
//CPoint pt3,直线外一点  
//输出垂足 
POINT Getplumb(const POINT& pt1, const POINT& pt2, const POINT& ptOut)
{
	double dba, dbb;
	POINT ptPlum;

	//a = sqr( (x2 - x1)^2 +(y2 - y1)^2 )  
	dba = sqrt((long double)((pt2.x - pt1.x) * (pt2.x - pt1.x) + (pt2.y - pt1.y) * (pt2.y - pt1.y)));
	//b = (x2-x1) * (x3-x1) +(y2 -y1) * (y3 -y1)  
	dbb = ((pt2.x - pt1.x) * (ptOut.x - pt1.x) + (pt2.y - pt1.y) * (ptOut.y - pt1.y));
	//a = b / (a*a)  
	dba = dbb / (dba * dba);
	//x4 = x1 +(x2 - x1)*a  
	ptPlum.x = (LONG)(pt1.x + (pt2.x - pt1.x) * dba);
	//y4 = y1 +(y2 - y1)*a  
	ptPlum.y = (LONG)(pt1.y + (pt2.y - pt1.y) * dba);

	return ptPlum;
}
//求点到直线的距离
int PointToLine(const POINT& pt, const POINT& linePt1, const POINT& linePt2)
{
	double x1 = (double)linePt1.x, y1 = (double)linePt1.y;
	double x2 = (double)linePt2.x, y2 = (double)linePt2.y;

	double l = (y2 - y1) / (x2 - x1);

	double x = (double)pt.x, y = (double)pt.y;

	return (int)fabs(l*x - y + y1 - l*x1) / sqrt(l*l + 1);
}
COLORREF AlphaColor(COLORREF clr1, COLORREF clr2, int nAlpha)
{
	if (nAlpha <= 0) return clr1;
	if (nAlpha >= 255) return clr2;

	int r = (GetRValue(clr1)*(255 - nAlpha) + GetRValue(clr2)*(nAlpha)) / 255;
	int g = (GetGValue(clr1)*(255 - nAlpha) + GetGValue(clr2)*(nAlpha)) / 255;
	int b = (GetBValue(clr1)*(255 - nAlpha) + GetBValue(clr2)*(nAlpha)) / 255;

	return RGB(r, g, b);
}

void FillSolidRect(HDC hDC, CONST RECT *lprc, COLORREF clr)
{
	::SetBkColor(hDC, clr);
	::ExtTextOut(hDC, 0, 0, ETO_OPAQUE, lprc, NULL, 0, NULL);
}

void LigherColor(COLORREF& lColor, int lScale)
{

	if (lScale>0)
	{
		long lR = MulDiv(255 - GetRValue(lColor), lScale, 255) + GetRValue(lColor);
		long lG = MulDiv(255 - GetGValue(lColor), lScale, 255) + GetGValue(lColor);
		long lB = MulDiv(255 - GetBValue(lColor), lScale, 255) + GetBValue(lColor);
		lColor = RGB(lR, lG, lB);
	}
	else
	{
		lScale *= -1;
		long red = MulDiv(GetRValue(lColor), (255 - lScale), 255);
		long green = MulDiv(GetGValue(lColor), (255 - lScale), 255);
		long blue = MulDiv(GetBValue(lColor), (255 - lScale), 255);
		lColor = RGB(red, green, blue);
	}
}

COLORREF GetLigherColor(COLORREF clr, int nLevel)
{
	LigherColor(clr, nLevel);
	return clr;
}
void DrawMaoDian(HDC hDC, const POINT& pt, COLORREF clr)
{
	RECT rc;
	rc.left = pt.x - 3;
	rc.top = pt.y - 3;
	rc.right = pt.x + 3;
	rc.bottom = pt.y + 3;
	FillSolidRect(hDC,&rc, clr);
}
DWORD ColorReverse()
{
	return 0xFFFFFF - COLOR_KLINE_BACKGROUND;
}
bool     PtInLine(const POINT& pt, const POINT& start, const POINT& end)
{
	if (end.x == start.x)
	{

		return ((pt.y >= start.y && pt.y <= end.y) || (pt.y <= start.y && pt.y >= end.y)) && abs(pt.x - start.x)<5;
	}
	else if (end.y == start.y)
	{
		return ((pt.x >= start.x && pt.x <= end.x) || (pt.x <= start.x && pt.x >= end.x)) && abs(pt.y - start.y)<5;
	}
	else
	{
		double rate = (end.y - start.y) / (double)(end.x - start.x);

		if ((pt.x<start.x && pt.x<end.x) || (pt.x>start.x && pt.x>end.x))
		{
			return false;
		}

		int lineY = (int)(start.y + rate*(pt.x - start.x));

		return abs(lineY - pt.y) <= 10;
	}
}
bool PtInEllips(const POINT& pt, const RECT& rc, BOOL bTop)
{
	POINT ptCenter;
	ptCenter.x = (rc.left + rc.right) / 2;
	ptCenter.y = (rc.top + rc.bottom) / 2;
	int nWidth = rc.right - rc.left;
	int nHigth = rc.bottom - rc.top;
	if (abs(pt.x - ptCenter.x)<5)
	{
		return bTop ? (abs(pt.y - rc.top)<5) : (abs(pt.y - rc.bottom)<5);
	}

	if (abs(pt.y - ptCenter.y)<5)
	{
		return pt.x<ptCenter.x ? (abs(pt.x - rc.left)<5) : (abs(pt.x - rc.right)<5);
	}


	if (nWidth == nHigth) //圆形
	{
		int r2 = (pt.x - ptCenter.x) * (pt.x - ptCenter.x) + (pt.y - ptCenter.y)*(pt.y - ptCenter.y);
		int r = pow(r2, 0.5);
		if (bTop)
		{
			return pt.y<ptCenter.y && abs(r - nWidth / 2)<5;
		}
		else
		{
			return pt.y>ptCenter.y && abs(r - nWidth / 2)<5;
		}
	}

	double A = ptCenter.x;
	double B = ptCenter.y;
	double x = pt.x;
	double sss = 0;
	if (nWidth>nHigth)
	{
		double a = nWidth / 2;
		double b = nHigth / 2;
		sss = pow((b*b - (b*b)*(x - A)*(x - A) / (a*a)), 0.5);
	}
	else
	{
		double a = nHigth / 2;
		double b = nWidth / 2;
		sss = pow((a*a - (a*a)*(x - A)*(x - A) / (b*b)), 0.5);
	}

	if (bTop)
	{
		return abs(pt.y - (B + sss))<5;
	}
	else
	{
		return abs(pt.y - (B - sss))<5;
	}
}
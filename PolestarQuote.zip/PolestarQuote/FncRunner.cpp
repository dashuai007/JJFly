#include "PreInclude.h"


#define Pop()	m_pTopOfStack--

CFncRunner::CFncRunner()
{
}


CFncRunner::~CFncRunner()
{
	RemoveResults();
}
int CFncRunner::Execute()
{
	RemoveResults();
	RemoveVariableSymtab();
	m_pTopOfStack = &m_Stack[0];
	TOKEN_CODE op;
	int nIndexVar = 0, nIndexOutVar = 0;
	int nCodeSize = m_pIndex->m_nCodeSize;
	if (nCodeSize == 0) 
		return FALSE;
	m_pCode = m_pIndex->m_pCode;
	CSymtabNode* pId;
	while (nCodeSize--)
	{
		op = m_pCode->nOperator;
		//		TOKEN_CODE tc = (TOKEN_CODE)op;
		switch (op)
		{
		case tASSIGN:
		{
			if (TokenIn((m_pCode - 1)->nOperator, DrawFncList))
			{
				pId = new CSymtabNode;
				m_vSymtabs.push_back(pId);
				pId->m_bOutput = true;
				pId->m_nDrawType = 1;
				pId->m_nIndex = m_FncDrawArray.size() - 1;
			}
			else
			{
				if (m_pCode->byte1 < m_vSymtabs.size())
					pId = m_vSymtabs[m_pCode->byte1];
				else
				{
					pId = new CSymtabNode;
					m_vSymtabs.push_back(pId);
				}
				if (m_pCode->byte3 == 0)
				{
					pId->m_bOutput = true;
					strcpy_s(pId->m_strName , m_pIndex->m_ResultItems[nIndexOutVar++]->m_strName);
				}
				else
				{
				/*	if (m_pIndex->m_strVarNames.empty())
					{
						pId->m_strName.Format("Var%d", ++nIndexVar);
					}
					else
						pId->m_strName = m_pFormula->GetVarName(nIndexVar++);*/
				}

				if (m_pTopOfStack->m_DataType == dtNUMBER)
				{
					if (pId->m_bOutput)
					{
						pId->m_pDataArray = new CDataArray(m_CalcInfo.m_nNumData, 0);
						pId->m_pDataArray->CopyFrom(m_pTopOfStack->m_fValue);
						pId->m_DataType = dtARRAY;
					}
					else
					{
						pId->m_fValue = m_pTopOfStack->m_fValue;
						pId->m_DataType = dtNUMBER;
					}
				}
				else
				{
					pId->m_pDataArray = m_pTopOfStack->m_pDataArray;
					pId->m_DataType = dtARRAY;
				}
			}
			Pop();
		}
		break;
		case tAND:
		case tOR:
		case tEQU:
		case tNEQ:
		case tLTN:
		case tGTN:
		case tLEQ:
		case tGEQ:
		case tPLUS:
		case tMINUS:
		case tSTAR:
		case tSLASH:
			ExecOperator(op);
			break;
		case tVARIABLE:
		{
			pId = m_vSymtabs[m_pCode->byte1];
			if (pId->m_DataType == dtARRAY)
			{
				CDataArray* pArr = new CDataArray(m_CalcInfo.m_nNumData, 0);
				pArr->CopyFrom(pId->m_pDataArray);
				PushAddress(pArr);
			}
			else
			{
				PushNumber(pId->m_fValue);
			}
		}
		break;
		case tPARAM:
			pId = m_vSymtabs[m_pCode->byte1];
			PushNumber(pId->m_fValue);
			break;
		case tSTRING:
			PushNumber(m_pCode->byte1);
			break;
		case tNUMBER:
			PushNumber(m_pCode->fValue);
			break;
		default:
			ExecInnerFnc(op);
			break;
		}

		if (m_nErrCode != eNoError)
			break;
		m_pCode++;
	}
	CreateResult();
}

void CFncRunner::SetParams(int nNum, TKLineSpecParam* pParam)
{
	for (int i = 0; i<nNum; i++)
		m_vSymtabs[i]->m_fValue = pParam[i].Value;
}
void CFncRunner::SetIndex(CIndex* pIndex)
{
	CParser::SetIndex(pIndex);

	for (size_t i = 0; i<m_FncDrawArray.size(); i++)
	{
		delete m_FncDrawArray[i];
	}
	m_FncDrawArray.clear();
}
void CFncRunner::SetCalcInfo(TKLineData* pStkHisData)
{
	m_pStkHisData = pStkHisData;
	if (m_pStkHisData == NULL) return;
	//m_CalcInfo.m_pData = pStkHisData->Data;
	//m_CalcInfo.m_nNumData = pStkHisData->m_nNumData;
	int nNum = 0;
	int curr = pStkHisData->ReadIndex;
	while (curr != pStkHisData->WriteIndex)
	{
		m_CalcInfo.m_pData[nNum] = pStkHisData->GetData(curr);
		nNum++;
		curr = (curr + 1) % MAX_SHOW_KLINE_X;

	}
	m_CalcInfo.m_nNumData = nNum;
	m_CalcInfo.m_nNumParam = 0;
	m_CalcInfo.m_pCalcParam = NULL;
}
void CFncRunner::RemoveResults()
{
	for (size_t i = 0; i<m_vArrResults.size(); i++)
	{
		if (m_vArrResults[i]->m_nDrawType == 1)
			delete m_vArrResults[i]->m_pDataArray;
		delete m_vArrResults[i];
	}
	m_vArrResults.clear();
}
void CFncRunner::RemoveVariableSymtab()
{
	for (size_t i = m_vSymtabs.size() - 1; i >= PARAM_NUM; i--)
	{
		delete m_vSymtabs[i];
		m_vSymtabs.pop_back();
	}
}
void CFncRunner::ExecOperator(TOKEN_CODE op)
{
	DWORD typeResult, type2;
	STACK_ITEM *pOperand1, *pOperand2;
	float* ptr1;
	float* ptr2;
	int nCount;

	pOperand1 = m_pTopOfStack - 1;
	pOperand2 = m_pTopOfStack;
	typeResult = pOperand1->m_DataType;
	type2 = pOperand2->m_DataType;

	if (typeResult == dtNUMBER && type2 == dtNUMBER)
	{
		switch (op)
		{
		case tAND:
			pOperand1->m_fValue = (float)((BOOL)(pOperand1->m_fValue) && (BOOL)(pOperand2->m_fValue));  break;
		case tOR:
			pOperand1->m_fValue = (float)((BOOL)(pOperand1->m_fValue) || (BOOL)(pOperand2->m_fValue));  break;

		case tEQU:
			pOperand1->m_fValue = (float)((int)(pOperand1->m_fValue * 10000) == (int)(pOperand2->m_fValue * 10000));	break;
		case tNEQ:
			pOperand1->m_fValue = (float)((int)(pOperand1->m_fValue * 10000) != (int)(pOperand2->m_fValue * 10000));	break;
		case tLTN:
			pOperand1->m_fValue = (float)(pOperand1->m_fValue < pOperand2->m_fValue);	break;
		case tGTN:
			pOperand1->m_fValue = (float)(pOperand1->m_fValue > pOperand2->m_fValue);	break;
		case tLEQ:
			pOperand1->m_fValue = (float)(pOperand1->m_fValue <= pOperand2->m_fValue);	break;
		case tGEQ:
			pOperand1->m_fValue = (float)(pOperand1->m_fValue >= pOperand2->m_fValue);	break;

		case tPLUS:
			pOperand1->m_fValue += pOperand2->m_fValue; break;
		case tMINUS:
			pOperand1->m_fValue -= pOperand2->m_fValue; break;

		case tSTAR:
			pOperand1->m_fValue *= pOperand2->m_fValue; break;
		case tSLASH:
			if (fabs(pOperand2->m_fValue) < FLT_MIN)
				pOperand1->m_fValue = 0;
			else
				pOperand1->m_fValue /= pOperand2->m_fValue;
			break;

		}
		if (TokenIn(op, RelationOpList) || TokenIn(op, LogicOpList))
		{
		}
	}
	else if (typeResult == dtARRAY && type2 == dtNUMBER)
	{
		if (pOperand1->m_pDataArray->m_nStartIndex >= 0)
		{
			float fValue = pOperand2->m_fValue;
			ptr1 = pOperand1->m_pDataArray->m_pData + pOperand1->m_pDataArray->m_nStartIndex;
			nCount = pOperand1->m_pDataArray->m_nNumData - pOperand1->m_pDataArray->m_nStartIndex;
			switch (op)
			{
			case tAND:
				while (nCount--) { *ptr1 = (float)((BOOL)(*ptr1) && (BOOL)fValue);	ptr1++; } break;
			case tOR:
				while (nCount--) { *ptr1 = (float)((BOOL)(*ptr1) || (BOOL)fValue);	ptr1++; } break;

			case tEQU:
				while (nCount--) { *ptr1 = (float)((int)(*ptr1 * 10000) == (int)(fValue * 10000));	ptr1++; } break;
			case tNEQ:
				while (nCount--) { *ptr1 = (float)((int)(*ptr1 * 10000) != (int)(fValue * 10000));	ptr1++; } break;
			case tLTN:
				while (nCount--) { *ptr1 = (float)(*ptr1 < fValue);	ptr1++; } break;
			case tGTN:
				while (nCount--) { *ptr1 = (float)(*ptr1 > fValue);	ptr1++; } break;
			case tLEQ:
				while (nCount--) { *ptr1 = (float)(*ptr1 <= fValue);	ptr1++; } break;
			case tGEQ:
				while (nCount--) { *ptr1 = (float)(*ptr1 >= fValue);	ptr1++; } break;

			case tPLUS:
				while (nCount--) { *ptr1 += fValue;	ptr1++; } break;
			case tMINUS:
				while (nCount--) { *ptr1 -= fValue;	ptr1++; } break;

			case tSTAR:
				while (nCount--) { *ptr1 *= fValue;	ptr1++; } break;
			case tSLASH:
				while (nCount--)
				{
					if (fabs(fValue) < FLT_MIN)
						*ptr1 = 0;
					else
						*ptr1 /= fValue;
					ptr1++;
				}
				break;
			}
		}
	}
	else if (typeResult == dtNUMBER && type2 == dtARRAY)
	{
		if (pOperand2->m_pDataArray->m_nStartIndex >= 0)
		{
			float fValue = pOperand1->m_fValue;
			ptr1 = pOperand2->m_pDataArray->m_pData + pOperand2->m_pDataArray->m_nStartIndex;
			nCount = pOperand2->m_pDataArray->m_nNumData - pOperand2->m_pDataArray->m_nStartIndex;
			switch (op)
			{
			case tAND:
				while (nCount--) { *ptr1 = (float)((BOOL)fValue && (BOOL)(*ptr1));	ptr1++; } break;
			case tOR:
				while (nCount--) { *ptr1 = (float)((BOOL)fValue || (BOOL)(*ptr1));	ptr1++; } break;

			case tEQU:
				while (nCount--) { *ptr1 = (float)((int)(fValue * 10000) == (int)(*ptr1 * 10000));	ptr1++; } break;
			case tNEQ:
				while (nCount--) { *ptr1 = (float)((int)(fValue * 10000) != (int)(*ptr1 * 10000));	ptr1++; } break;
			case tLTN:
				while (nCount--) { *ptr1 = (float)(fValue < *ptr1);	ptr1++; } break;
			case tGTN:
				while (nCount--) { *ptr1 = (float)(fValue > *ptr1);	ptr1++; } break;
			case tLEQ:
				while (nCount--) { *ptr1 = (float)(fValue <= *ptr1);	ptr1++; } break;
			case tGEQ:
				while (nCount--) { *ptr1 = (float)(fValue >= *ptr1);	ptr1++; } break;

			case tPLUS:
				while (nCount--) { *ptr1 += fValue;	ptr1++; } break;
			case tMINUS:
				while (nCount--) { *ptr1 = fValue - *ptr1;	ptr1++; } break;

			case tSTAR:
				while (nCount--) { *ptr1 *= fValue;	ptr1++; } break;
			case tSLASH:
				while (nCount--)
				{
					if (fabs(*ptr1) < FLT_MIN)
						*ptr1 = 0;
					else
						*ptr1 = fValue / (*ptr1);
					ptr1++;
				}
				break;
			}
		}
		float fValue = pOperand1->m_fValue;
		pOperand1->m_pDataArray = pOperand2->m_pDataArray;
		pOperand2->m_fValue = fValue;
		typeResult = dtARRAY;
	}
	else if (typeResult == dtARRAY && type2 == dtARRAY)
	{
		if (pOperand1->m_pDataArray->m_nStartIndex >= 0 && pOperand2->m_pDataArray->m_nStartIndex >= 0)
		{
			if (pOperand2->m_pDataArray->m_nStartIndex > pOperand1->m_pDataArray->m_nStartIndex)
				pOperand1->m_pDataArray->m_nStartIndex = pOperand2->m_pDataArray->m_nStartIndex;
			ptr1 = pOperand1->m_pDataArray->m_pData + pOperand1->m_pDataArray->m_nStartIndex;
			ptr2 = pOperand2->m_pDataArray->m_pData + pOperand1->m_pDataArray->m_nStartIndex;
			int nCount = pOperand1->m_pDataArray->m_nNumData - pOperand1->m_pDataArray->m_nStartIndex;
			switch (op)
			{
			case tAND:
				while (nCount--) { *ptr1 = (float)((BOOL)(*ptr1) && (BOOL)(*ptr2));	ptr1++;	 ptr2++; } break;
			case tOR:
				while (nCount--) { *ptr1 = (float)((BOOL)(*ptr1) || (BOOL)(*ptr2));	ptr1++;	 ptr2++; } break;
			case tEQU:
				while (nCount--) { *ptr1 = (float)((int)(*ptr1 * 10000) == (int)(*ptr2 * 10000));	ptr1++;	ptr2++; } break;
			case tNEQ:
				while (nCount--) { *ptr1 = (float)((int)(*ptr1 * 10000) != (int)(*ptr2 * 10000));	ptr1++;	ptr2++; } break;
			case tLTN:
				while (nCount--) { *ptr1 = (float)(*ptr1 < *ptr2);	ptr1++;	ptr2++; } break;
			case tGTN:
				while (nCount--) { *ptr1 = (float)(*ptr1 > *ptr2);	ptr1++;	ptr2++; } break;
			case tLEQ:
				while (nCount--) { *ptr1 = (float)(*ptr1 <= *ptr2);	ptr1++;	ptr2++; } break;
			case tGEQ:
				while (nCount--) { *ptr1 = (float)(*ptr1 >= *ptr2);	ptr1++;	ptr2++; } break;

			case tPLUS:
				while (nCount--) { *ptr1 += *ptr2;	ptr1++;	ptr2++; } break;
			case tMINUS:
				while (nCount--) { *ptr1 -= *ptr2;	ptr1++;	ptr2++; } break;

			case tSTAR:
				while (nCount--) { *ptr1 *= *ptr2;	ptr1++;	ptr2++; } break;
			case tSLASH:
				while (nCount--) {
					if (fabs(*ptr2) < FLT_MIN)
						*ptr1 = 0;
					else
						*ptr1 /= *ptr2;
					ptr1++;	ptr2++;
				} break;
			}
		}
		else
		{
			pOperand1->m_pDataArray->m_nStartIndex = -1;
		}
		delete m_pTopOfStack->m_pDataArray;
	}
	pOperand1->m_DataType = typeResult;
	Pop();
}
void CFncRunner::PushNumber(float fValue)
{
	m_pTopOfStack++;
	m_pTopOfStack->m_fValue = fValue;
	m_pTopOfStack->m_DataType = dtNUMBER;
}

void CFncRunner::PushAddress(CDataArray* pAddress)
{
	m_pTopOfStack++;
	m_pTopOfStack->m_pDataArray = pAddress;
	m_pTopOfStack->m_DataType = dtARRAY;
}
void CFncRunner::ExecInnerFnc(TOKEN_CODE op)
{
	switch (op)
	{
	case tOPEN: case tCLOSE: case tHIGH: case tLOW: case tVOL: case tAMOUNT:
	case tDATE: case tHOUR: case tYEAR: case tMONTH: case tWEEKDAY: case tDAY: case tTIME: case tMINUTE:
	case tISDOWN: case tISEQUAL: case tISUP:
	case tBUYVOL: case tSELLVOL: case tISBUYORDER:	//
		ExecFnc0Params();
		break;
	case tATAN: case tACOS: case tASIN: case tTAN: case tCOS: case tSIN:
	case tSQRT: case tEXP: case tLN: case tLOG: case tSGN: case tABS: case tREVERSE:
	case tNOT:
	case tBARSLAST: case tBARSSINCE: case tBARSCOUNT:
	case tBIDPRICE: case tBIDVOL: case tASKPRICE: case tASKVOL: case tEXTDATA: //
	case tINTPART: case tCEILING: case tFLOOR:
		ExecFnc1Params();
		break;
	case tZIG: case tPOW:
	case tSLOPE: case tFORCAST: case tDEVSQ: case tAVEDEV: case tVARP: case tVAR: case tSTDP: case tSTD:
	case tMIN: case tMAX: case tMOD:
	case tSUMBARS: case tLLVBARS: case tHHVBARS:
	case tDMA: case tEMA: case tMA:
	case tLLV: case tHHV: case tBACKSET:
	case tREF: case tREFX: case tSUM: case tCOUNT:
	case tCROSS:	case tFILTER:
		ExecFnc2Params();
		break;
	case tTROUGHBARS: case tTROUGH: case tPEAKBARS: case tPEAK:
	case tSARTURN: case tSAR:
	case tIF:	case tSMA:
	case tBETWEEN: case tRANGE:
	case tLONGCROSS:
	case tCOLORRGB://--cjw add new
		ExecFnc3Params();
		break;
	case tDRAWICON: case tDRAWLINE: case tPOLYLINE:  case tVERTLINE: case tPARTLINE: case tDRAWGBK: case tSTICKLINE: case tDRAWTEXT:
		ExecDrawFnc();
		break;
	}
}
void CFncRunner::ExecFnc0Params()
{
		m_pTopOfStack++;
	m_fncType = m_pCode->nOperator;

	switch (m_fncType)
	{
	case tISBUYORDER:
		PushNumber(1);			
		break;
	default:
		CDataArray* pDataArray = new CDataArray(m_CalcInfo.m_nNumData, 0);
		m_CalcInfo.m_nFncType = m_fncType;
		m_CalcInfo.m_pResultBuf = pDataArray->m_pData;
		pDataArray->m_nStartIndex = InnerFnc0(&m_CalcInfo);
		PushAddress(pDataArray);
		break;
	}
}

void CFncRunner::ExecFnc1Params()
{
	m_fncType = m_pCode->nOperator;
	DWORD dtParam = m_pTopOfStack->m_DataType;
    if (dtParam == dtARRAY)
	{
		STACK_ITEM *	pOperand1 = m_pTopOfStack;
		m_CalcInfo.m_nFncType = m_fncType;

		CDataArray* pResultArr = new CDataArray(m_CalcInfo.m_nNumData, 0);

		m_CalcInfo.m_pfParam1 = pOperand1->m_pDataArray->m_pData;
		m_CalcInfo.m_nParam1Start = pOperand1->m_pDataArray->m_nStartIndex;
		m_CalcInfo.m_pfParam2 = NULL;

		m_CalcInfo.m_pResultBuf = pResultArr->m_pData;

		pResultArr->m_nStartIndex = InnerFnc1Arr(&m_CalcInfo);
		delete pOperand1->m_pDataArray;
		pOperand1->m_pDataArray = pResultArr;
		m_pTopOfStack->m_DataType = dtARRAY;
		return;
	}
	else
	{
		int nIndex;
		switch (m_fncType)
		{
		case tATAN:
			m_pTopOfStack->m_fValue = (float)atan(m_pTopOfStack->m_fValue); break;
		case tACOS:
			m_pTopOfStack->m_fValue = (float)acos(m_pTopOfStack->m_fValue); break;
		case tASIN:
			m_pTopOfStack->m_fValue = (float)asin(m_pTopOfStack->m_fValue); break;
		case tTAN:
			m_pTopOfStack->m_fValue = (float)tan(m_pTopOfStack->m_fValue); break;
		case tCOS:
			m_pTopOfStack->m_fValue = (float)cos(m_pTopOfStack->m_fValue); break;
		case tSIN:
			m_pTopOfStack->m_fValue = (float)sin(m_pTopOfStack->m_fValue); break;
		case tSQRT:
			m_pTopOfStack->m_fValue = (float)sqrt(m_pTopOfStack->m_fValue); break;
		case tEXP:
			m_pTopOfStack->m_fValue = (float)exp(m_pTopOfStack->m_fValue); break;
		case tLN:
			m_pTopOfStack->m_fValue = (float)log(m_pTopOfStack->m_fValue); break;
		case tLOG:
			m_pTopOfStack->m_fValue = (float)log10(m_pTopOfStack->m_fValue); break;
		case tSGN:
			m_pTopOfStack->m_fValue = (float)(m_pTopOfStack->m_fValue>0 ? 1 : (m_pTopOfStack->m_fValue<0 ? -1 : 0)); break;
		case tABS:
			m_pTopOfStack->m_fValue = (float)fabs(m_pTopOfStack->m_fValue); break;
		case tREVERSE:
			m_pTopOfStack->m_fValue = -m_pTopOfStack->m_fValue; break;
		case tNOT:
			m_pTopOfStack->m_fValue = (float)((int)m_pTopOfStack->m_fValue == 0 ? 1 : 0); break;

		case tCEILING:
			m_pTopOfStack->m_fValue = (float)ceil(m_pTopOfStack->m_fValue); break;
		case tFLOOR:
			m_pTopOfStack->m_fValue = (float)floor(m_pTopOfStack->m_fValue); break;
		case tINTPART:
			m_pTopOfStack->m_fValue = (float)(int(m_pTopOfStack->m_fValue)); break;

		//case tBIDPRICE:
		//	nIndex = (int)m_pTopOfStack->m_fValue + INDEX_BJ1 - 1;
		//	if (m_pStk->m_pfDynaData && m_pStk->m_pfDynaData[nIndex] > -9999)
		//		m_pTopOfStack->m_fValue = m_pStk->m_pfDynaData[nIndex];
		//	else
		//		m_pTopOfStack->m_fValue = 10;
		//	break;
		//case tBIDVOL:
		//	nIndex = (int)m_pTopOfStack->m_fValue + INDEX_BL1 - 1;
		//	if (m_pStk->m_pfDynaData && m_pStk->m_pfDynaData[nIndex] > -9999)
		//		m_pTopOfStack->m_fValue = m_pStk->m_pfDynaData[nIndex];
		//	else
		//		m_pTopOfStack->m_fValue = 10;
		//	break;
		//case tASKPRICE:
		//	nIndex = (int)m_pTopOfStack->m_fValue + INDEX_SJ1 - 1;
		//	if (m_pStk->m_pfDynaData && m_pStk->m_pfDynaData[nIndex] > -9999)
		//		m_pTopOfStack->m_fValue = m_pStk->m_pfDynaData[nIndex];
		//	else
		//		m_pTopOfStack->m_fValue = 10;
		//	break;
		//case tASKVOL:
		//	nIndex = (int)m_pTopOfStack->m_fValue + INDEX_SL1 - 1;
		//	if (m_pStk->m_pfDynaData && m_pStk->m_pfDynaData[nIndex] > -9999)
		//		m_pTopOfStack->m_fValue = m_pStk->m_pfDynaData[nIndex];
		//	else
		//		m_pTopOfStack->m_fValue = 10;
		//	break;
		case tEXTDATA: //
			m_pTopOfStack->m_fValue = 10; 
			break;
		}
		m_pTopOfStack->m_DataType = dtNUMBER;
		return;
	}

}

void CFncRunner::ExecFnc2Params()
{
	FUNCTION_TYPE fncType = m_pCode->nOperator;

	STACK_ITEM *	pOperand1 = m_pTopOfStack - 1;
	STACK_ITEM *	pOperand2 = m_pTopOfStack;
	DWORD dtParam1 = pOperand1->m_DataType;
	DWORD dtParam2 = pOperand2->m_DataType;

	if ((dtParam1 == dtNUMBER && dtParam2 == dtNUMBER) &&fncType == tMOD)
	{
		float fValue;
		if (fncType == tMOD)
			fValue = (float)((int)pOperand1->m_fValue % (int)pOperand2->m_fValue);
		pOperand1->m_fValue = fValue;
		pOperand1->m_DataType = dtNUMBER;
		Pop();
		return;
	}
	CDataArray* pResultArr = new CDataArray(m_CalcInfo.m_nNumData, 0);
	m_CalcInfo.m_nFncType = fncType;
	m_CalcInfo.m_pfParam3 = NULL;
	m_CalcInfo.m_pResultBuf = pResultArr->m_pData;
	if ((dtParam1 == dtNUMBER && dtParam2 == dtNUMBER) && fncType == tZIG)
	{
		m_CalcInfo.m_pfParam1 = &(pOperand1->m_fValue);
		m_CalcInfo.m_pfParam2 = &(pOperand2->m_fValue);
		pResultArr->m_nStartIndex = InnerFnc2Int(&m_CalcInfo);
	}
	else
	{
		if (dtParam1 == dtNUMBER)
		{
			ChangeValue2Array(pOperand1);
			dtParam1 = dtARRAY;
		}
		m_CalcInfo.m_pfParam1 = pOperand1->m_pDataArray->m_pData;
		m_CalcInfo.m_nParam1Start = pOperand1->m_pDataArray->m_nStartIndex;
		if (dtParam2 == dtNUMBER)
		{
			m_CalcInfo.m_pfParam2 = &(pOperand2->m_fValue);
			pResultArr->m_nStartIndex = InnerFnc1Arr1Int(&m_CalcInfo);
		}
		else
		{
			if (pOperand2->m_pDataArray->m_nStartIndex > m_CalcInfo.m_nParam1Start)
				m_CalcInfo.m_nParam1Start = pOperand2->m_pDataArray->m_nStartIndex;
			m_CalcInfo.m_pfParam2 = pOperand2->m_pDataArray->m_pData;
			pResultArr->m_nStartIndex = InnerFnc2Arr(&m_CalcInfo);
			delete pOperand2->m_pDataArray;
		}
		delete pOperand1->m_pDataArray;
	}

	pOperand1->m_pDataArray = pResultArr;
	pOperand1->m_DataType = dtARRAY;
	Pop();
}

void CFncRunner::ExecFnc4Params()
{
	FUNCTION_TYPE fncType = m_pCode->nOperator;

	STACK_ITEM *	pOperand1 = m_pTopOfStack - 3;
	STACK_ITEM *	pOperand2 = m_pTopOfStack - 2;
	STACK_ITEM *	pOperand3 = m_pTopOfStack - 1;
	STACK_ITEM *	pOperand4 = m_pTopOfStack;
	DWORD dtParam1 = pOperand1->m_DataType;
	DWORD dtParam2 = pOperand2->m_DataType;
	DWORD dtParam3 = pOperand3->m_DataType;
	DWORD dtParam4 = pOperand4->m_DataType;

	m_CalcInfo.m_nFncType = fncType;
	CDataArray* pResultArr = new CDataArray(m_CalcInfo.m_nNumData, 0);
	m_CalcInfo.m_pResultBuf = pResultArr->m_pData;

	if (dtParam1 == dtNUMBER)
	{
		ChangeValue2Array(pOperand1);
		dtParam1 = dtARRAY;
	}
	if (dtParam2 == dtNUMBER)
	{
		ChangeValue2Array(pOperand2);
		dtParam2 = dtARRAY;
	}
	if (dtParam3 == dtNUMBER)
	{
		ChangeValue2Array(pOperand3);
		dtParam3 = dtARRAY;
	}
	if (dtParam4 == dtNUMBER)
	{
		ChangeValue2Array(pOperand4);
		dtParam4 = dtARRAY;
	}

	m_CalcInfo.m_pfParam1 = pOperand1->m_pDataArray->m_pData;
	m_CalcInfo.m_pfParam2 = pOperand2->m_pDataArray->m_pData;
	m_CalcInfo.m_pfParam3 = pOperand3->m_pDataArray->m_pData;
	m_CalcInfo.m_pfParam4 = pOperand4->m_pDataArray->m_pData;

	m_CalcInfo.m_nParam1Start = pOperand1->m_pDataArray->m_nStartIndex;
	if (pOperand2->m_pDataArray->m_nStartIndex > m_CalcInfo.m_nParam1Start)
		m_CalcInfo.m_nParam1Start = pOperand2->m_pDataArray->m_nStartIndex;
	if (pOperand3->m_pDataArray->m_nStartIndex > m_CalcInfo.m_nParam1Start)
		m_CalcInfo.m_nParam1Start = pOperand3->m_pDataArray->m_nStartIndex;
	if (pOperand4->m_pDataArray->m_nStartIndex > m_CalcInfo.m_nParam1Start)
		m_CalcInfo.m_nParam1Start = pOperand4->m_pDataArray->m_nStartIndex;
	pResultArr->m_nStartIndex = InnerFnc4Arr(&m_CalcInfo);
	delete pOperand1->m_pDataArray;
	delete pOperand2->m_pDataArray;
	delete pOperand3->m_pDataArray;
	delete pOperand4->m_pDataArray;
	pOperand1->m_pDataArray = pResultArr;
	pOperand1->m_DataType = dtARRAY;
	Pop();
	Pop();
	Pop();
}
void CFncRunner::ExecFnc3Params()
{
	FUNCTION_TYPE fncType = m_pCode->nOperator;

	STACK_ITEM *	pOperand1 = m_pTopOfStack - 2;
	STACK_ITEM *	pOperand2 = m_pTopOfStack - 1;
	STACK_ITEM *	pOperand3 = m_pTopOfStack;
	DWORD dtParam1 = pOperand1->m_DataType;
	DWORD dtParam2 = pOperand2->m_DataType;
	DWORD dtParam3 = pOperand3->m_DataType;

	m_CalcInfo.m_nFncType = fncType;
	m_CalcInfo.m_pfParam4 = NULL;
	CDataArray* pResultArr = new CDataArray(m_CalcInfo.m_nNumData, 0);
	m_CalcInfo.m_pResultBuf = pResultArr->m_pData;

	if (dtParam1 == dtNUMBER && dtParam2 == dtNUMBER && dtParam3 == dtNUMBER &&
		!(fncType == tIF || fncType == tBETWEEN || fncType == tRANGE))
	{
		m_CalcInfo.m_pfParam1 = &(pOperand1->m_fValue);
		m_CalcInfo.m_pfParam2 = &(pOperand2->m_fValue);
		m_CalcInfo.m_pfParam3 = &(pOperand3->m_fValue);
		pResultArr->m_nStartIndex = InnerFnc3Int(&m_CalcInfo);
	}
	else
	{
		m_CalcInfo.m_pfParam1 = pOperand1->m_pDataArray->m_pData;
		m_CalcInfo.m_nParam1Start = pOperand1->m_pDataArray->m_nStartIndex;


		if (fncType == tIF || fncType == tLONGCROSS || fncType == tBETWEEN || fncType == tRANGE)
		{
			if (dtParam1 == dtNUMBER)
			{
				ChangeValue2Array(pOperand1);
				dtParam1 = dtARRAY;
			}
			if (dtParam2 == dtNUMBER)
			{
				ChangeValue2Array(pOperand2);
				dtParam2 = dtARRAY;
			}
			if (dtParam3 == dtNUMBER)
			{
				ChangeValue2Array(pOperand3);
				dtParam3 = dtARRAY;
			}
			if (pOperand2->m_pDataArray->m_nStartIndex > m_CalcInfo.m_nParam1Start)
				m_CalcInfo.m_nParam1Start = pOperand2->m_pDataArray->m_nStartIndex;
			if (pOperand3->m_pDataArray->m_nStartIndex > m_CalcInfo.m_nParam1Start)
				m_CalcInfo.m_nParam1Start = pOperand3->m_pDataArray->m_nStartIndex;
			m_CalcInfo.m_pfParam2 = pOperand2->m_pDataArray->m_pData;
			m_CalcInfo.m_pfParam3 = pOperand3->m_pDataArray->m_pData;
			pResultArr->m_nStartIndex = InnerFnc3Arr(&m_CalcInfo);
			delete pOperand2->m_pDataArray;
			delete pOperand3->m_pDataArray;
		}
		else
		{
			m_CalcInfo.m_pfParam2 = &(pOperand2->m_fValue);
			m_CalcInfo.m_pfParam3 = &(pOperand3->m_fValue);
			pResultArr->m_nStartIndex = InnerFnc1Arr2Int(&m_CalcInfo);
		}

		delete pOperand1->m_pDataArray;
	}
	pOperand1->m_pDataArray = pResultArr;
	pOperand1->m_DataType = dtARRAY;

	Pop();
	Pop();
}

void CFncRunner::ExecDrawFnc()
{
	FUNCTION_TYPE fncType = m_pCode->nOperator;
	CFncDrawItem* pItem = new CFncDrawItem;
	/*if (fncType == tDRAWNUMBER)
	{
		pItem->m_nType = fdtDRAWYITEXT + (fncType - tDRAWYITEXT);
	}
	else*/
		pItem->m_nType = fncType - tDRAWICON + 1;

	STACK_ITEM*	pOperand1 = NULL;//--cjw add tVERTLINE
	STACK_ITEM*	pOperand2 = NULL;
	STACK_ITEM*	pOperand3 = NULL;
	STACK_ITEM*	pOperand4 = NULL;
	STACK_ITEM*	pOperand5 = NULL;
	DWORD dtParam1, dtParam2, dtParam3, dtParam4, dtParam5;

	switch (fncType)
	{
	case tPOLYLINE:						//2 params
		pOperand1 = m_pTopOfStack - 1;
		pOperand2 = m_pTopOfStack;
		break;
	case tVERTLINE:
		pOperand1 = m_pTopOfStack;
		break;
	case tPARTLINE:						//2 params
		pOperand1 = m_pTopOfStack - 1;
		pOperand2 = m_pTopOfStack;
		break;
	case tDRAWICON:	case tDRAWTEXT:		//3 params
		pOperand1 = m_pTopOfStack - 2;
		pOperand2 = m_pTopOfStack - 1;
		pOperand3 = m_pTopOfStack;
		dtParam3 = pOperand3->m_DataType;
		break;
	case tDRAWGBK://--cjw add
    case tDRAWNUMBER:		//4 params
		pOperand1 = m_pTopOfStack - 3;
		pOperand2 = m_pTopOfStack - 2;
		pOperand3 = m_pTopOfStack - 1;
		pOperand4 = m_pTopOfStack;
		dtParam3 = pOperand3->m_DataType;
		dtParam4 = pOperand4->m_DataType;
		break;
	case tDRAWLINE:	case tSTICKLINE:	//5 params
		pOperand1 = m_pTopOfStack - 4;
		pOperand2 = m_pTopOfStack - 3;
		pOperand3 = m_pTopOfStack - 2;
		pOperand4 = m_pTopOfStack - 1;
		pOperand5 = m_pTopOfStack;
		dtParam3 = pOperand3->m_DataType;
		dtParam4 = pOperand4->m_DataType;
		dtParam5 = pOperand5->m_DataType;
		break;
	}
	dtParam1 = pOperand1->m_DataType;
	if (pOperand2 != NULL)//--cjw add 
		dtParam2 = pOperand2->m_DataType;

	if (dtParam1 == dtNUMBER)
	{
		pItem->m_DataArray1.SetSize(m_CalcInfo.m_nNumData, 0);
		pItem->m_DataArray1.CopyFrom(pOperand1->m_fValue);
	}
	else
	{
		pItem->m_DataArray1.CopyFrom(pOperand1->m_pDataArray);
		delete pOperand1->m_pDataArray;
	}
	if (pOperand2 != NULL)//--cjw add
	{
		if (dtParam2 == dtNUMBER)
		{
			pItem->m_DataArray2.SetSize(m_CalcInfo.m_nNumData, 0);
			pItem->m_DataArray2.CopyFrom(pOperand2->m_fValue);
		}
		else
		{
			pItem->m_DataArray2.CopyFrom(pOperand2->m_pDataArray);
			delete pOperand2->m_pDataArray;
		}
	}
	switch (fncType)
	{
	case tDRAWICON:
		pItem->m_fVar1 = pOperand3->m_fValue;
		break;
	case tDRAWTEXT:
	//	pItem->m_strDraw = m_pIndex->GetDrawString((int)(pOperand3->m_fValue));
		break;
	case tDRAWGBK://--cjw add
    case tDRAWNUMBER:
		if (dtParam3 == dtNUMBER)
		{
			pItem->m_DataArray3.SetSize(m_CalcInfo.m_nNumData, 0);
			pItem->m_DataArray3.CopyFrom(pOperand3->m_fValue);
		}
		else
		{
			pItem->m_DataArray3.CopyFrom(pOperand3->m_pDataArray);
			delete pOperand3->m_pDataArray;
		}
		pItem->m_fVar1 = pOperand4->m_fValue;
		break;
	case tDRAWLINE:	case tSTICKLINE:
		if (dtParam3 == dtNUMBER)
		{
			pItem->m_DataArray3.SetSize(m_CalcInfo.m_nNumData, 0);
			pItem->m_DataArray3.CopyFrom(pOperand3->m_fValue);
		}
		else
		{
			pItem->m_DataArray3.CopyFrom(pOperand3->m_pDataArray);
			delete pOperand3->m_pDataArray;
		}
		if (dtParam4 == dtNUMBER)
		{
			pItem->m_DataArray4.SetSize(m_CalcInfo.m_nNumData, 0);
			pItem->m_DataArray4.CopyFrom(pOperand4->m_fValue);
		}
		else
		{
			pItem->m_DataArray4.CopyFrom(pOperand4->m_pDataArray);
			delete pOperand4->m_pDataArray;
		}
		pItem->m_fVar1 = pOperand5->m_fValue;
		break;
	}
	Pop();
	switch (fncType)
	{
	case tDRAWICON:	case tDRAWTEXT:		//3 params
		Pop();
		break;
	case tDRAWLINE:	case tSTICKLINE:	//5 params
		Pop();
		Pop();
		Pop();
		break;
	}
	m_FncDrawArray.push_back(pItem);
}
void CFncRunner::ChangeValue2Array(STACK_ITEM *pOperand)
{
	pOperand->m_pDataArray = new CDataArray(m_CalcInfo.m_nNumData, 0);
	pOperand->m_pDataArray->CopyFrom(pOperand->m_fValue);
	pOperand->m_DataType = dtARRAY;
}
void CFncRunner::CreateResult()
{
	CFormulaResultItem* pResultItem;
	CSymtabNode* pNode;

	RemoveResults();

	if (m_nErrCode != eNoError)
	{
		for (int i = PARAM_NUM; i<m_vSymtabs.size(); i++)
		{
			pNode = m_vSymtabs[i];
			if (pNode->m_bOutput)
			{
				delete pNode->m_pDataArray;
			}
		}
	}
	else
	{
		for (int i = PARAM_NUM; i<m_vSymtabs.size(); i++)
		{
			pNode = m_vSymtabs[i];
			if (pNode->m_bOutput)
			{
				{
					pResultItem = new CFormulaResultItem;
					if (pNode->m_nDrawType)
					{
						pResultItem->m_nDrawType = 1;
						pResultItem->m_pFncDrawItem = (CDataArray*)(m_FncDrawArray.at(pNode->m_nIndex));
						pResultItem->m_pDataArray = new CDataArray(1, -1);
					}
					else
					{
						strcpy_s(pResultItem->m_strName , pNode->m_strName);
						pResultItem->m_nStyle = pNode->m_nStyle;
						pResultItem->m_pDataArray = pNode->m_pDataArray;
					}
					m_ResultItems.push_back(pResultItem);
				}
			}
		}
	}
}
#include "PreInclude.h"
#include <time.h>
//�ؼ�-----------------------------------------------------------------------------------------------------------------------
int TGridControl::OPTION_MIDDLE_WIDTH = 160;
int TGridControl::ROW_HEIGHT = 26;
int TGridControl::HEAD_HEIGHT = 28;
TGridControl::TGridControl(TDuiWindow& window) : TDuiControl(window), m_Plate(NULL), m_ColChg(false), m_ColBegin(0), m_RowChg(false), m_RowBegin(0), m_RowSelectIndex(0), m_RowSelectRight(false),
m_LastTick(0), m_AdjustCol(NULL), m_MouseMoveType(MOUSEMOVE_NONE), m_ColArrayCount(0), m_RowArrayCount(0), m_OptionSeries(NULL), m_NeedResume(false), m_TargetChg(false), m_updwonType(TYPE_LASTSETTLE)
,m_bStrategyGraphy(true),m_bColMirror(true),m_bZCEUse(false), m_bOutFresh(false), m_bEnterTLine(false)
{
	memset(m_ColOrder, 0, sizeof(m_ColOrder));
	memset(m_Data, 0, sizeof(m_Data));
	memset(m_Color, 0, sizeof(m_Color));

	G_StarApi->GetOptionSeriesData(NULL, NULL, &m_OptionSeries, 1, false);	//��ȡ��һ����Ȩ����
	if (m_OptionSeries != NULL)
		G_QuoteCenter.Sub_Quote(m_OptionSeries->TargetContract->ContractNo);
	G_QuoteCenter.Add_GridControl(this);
	m_OptStrategy.RegistGridContrl(this);
}

TGridControl::~TGridControl()
{
	G_QuoteCenter.Del_GridControl(this);
}

//��������--------------------------------------------------------------------------------------------------------------------
void TGridControl::Load_Plate(TPlatePage* plate)
{
	m_Plate = plate;
	m_RowSelectIndex = 0;
}

void TGridControl::Load_Cols(int cx)
{
	//1.begin��Ҫת��Ϊ����ƫ��������Ϊ���ؽ����沿����
	//2.�����ڻ�����Ȩ���Ų���ʽ��ͬ���ڻ��̶���һ�У���Ȩ�޹̶���
	//3.m_ColBegin���ⲿ��ֵ��
	if (!m_Plate)
		return;
	//��ʼ������
	m_ColChg = true;
	m_ColArrayCount = 0;
	memset(m_ColOrder, 0, sizeof(m_ColOrder));

	cx -= VSCROLL_WIDTH;

	//�ڻ�����Ȩ���촦��
	int i(0);
	int width(0);

	if (IsOption())
	{
		if(m_bStrategyGraphy)
		    cx = (cx - OPTION_MIDDLE_WIDTH- RCONTRACT_GRAPH_WIDTH) / 2;
		else
			cx = (cx - OPTION_MIDDLE_WIDTH) / 2;
	}
	else
	{
		for (; i < m_Plate->PlateColCount; i++)
		{
			TPlateCol& col = m_Plate->PlateCols[i];
			if (col.Visible)
			{
				m_ColArray[m_ColArrayCount++] = col;
				m_ColOrder[col.Field] = (SFidMeanType)m_ColArrayCount;
				width += col.Width;
				i++;
				break;
			}
		}
	}

	//������
	int begin(m_ColBegin);
	for (; i < m_Plate->PlateColCount; i++)
	{
		if ((int)m_ColArrayCount >= MAX_SHOW_COL)
			break;

		TPlateCol& col = m_Plate->PlateCols[i];
		if (!col.Visible)
			continue;

		if (begin > 0)				//����Scrollλ��
		{
			begin--;
			continue;
		}

		if (width > cx)	//����������
			break;

		m_ColArray[m_ColArrayCount++] = col;
		m_ColOrder[col.Field] = (SFidMeanType)m_ColArrayCount;
		width += col.Width;
	}
}

void TGridControl::Load_Rows(int cy, std::set<std::string>& SubConts, std::set<std::string>& UnsubConts, std::string&  UnsubTarget)
{
	//1.beginΪ��ʼ��
	//2.�����ڻ�����Ȩ�ڽ��沼���ϵĲ����Ȩ�б����ʾ������������Դ��ͬ��һ��ȡ��PlateRows��һ��ȡ��PlateOption
	//3.m_RowBegin���ⲿ��ֵ��
	//4.ִ�к�Լ���ĺ��˶�
	if (!m_Plate)
		return;
	//��ȡ�˶���Լ
	for (int i = 0; i < (int)m_RowArrayCount; i++)
	{
		TGridRow& row = m_RowArray[i];
		if (NULL != row.Contract && !row.IsSpread)
			UnsubConts.insert(row.Contract->ContractNo);
		else
			UnsubConts.insert(row.SpreadRow.ContractNo);
		if (NULL != row.Contract2 && !row.IsSpread)
			UnsubConts.insert(row.Contract2->ContractNo);
	}

	//��ʼ������
	m_RowChg = true;
	m_RowArrayCount = 0;
	m_RowOrder.clear();
	cy -= HEAD_HEIGHT;

	//��Ȩ���ڻ����촦��
	//TODO:��Ȩ��ĵĶ��ĺ�ȡ��
	//TPlateRow* SrcRows(NULL);
	//int SrcRowCount(0);
	bool bResetTarget = false;
	if (IsOption())
	{
		if (m_bZCEUse)
			cy -= RCONTRACT_HEIGHT;
		else
		    cy -= RCONTRACT_HEIGHT+ RCONTRACT_STRATEGY;
		if (NULL != m_OptionSeries)
		{
			if (NULL != m_Plate->OptionSeries && m_Plate->OptionSeries != m_OptionSeries)
			{
				UnsubConts.insert(m_OptionSeries->TargetContract->ContractNo);
				UnsubTarget = m_OptionSeries->TargetContract->ContractNo;
			}
			else
			{
				if (!m_Plate->OptionSeries||m_OptStrategy.IsOptionSeriesNull())
					bResetTarget = true;
				m_Plate->OptionSeries = m_OptionSeries;
			}

			if (m_Plate->OptionSeries != m_OptionSeries)
			{
				m_OptionSeries = m_Plate->OptionSeries;
				if (NULL != m_OptionSeries)
				{
					SubConts.insert(m_OptionSeries->TargetContract->ContractNo);
					bResetTarget = true;
				}
			}
			m_TargetChg = true;
		}
	}
	/*else
	{
		if (NULL != m_OptionSeries)
			UnsubConts.insert(m_OptionSeries->RelateContract);
		m_OptionSeries = NULL;
	}*/
	//������
	unsigned short height(0);

	if (IsOption())
	{
		SOptionContractPair* pairs[MAX_SHOW_ROW];
		int cnt = G_StarApi->GetOptionContractPairData((NULL != m_OptionSeries ? m_OptionSeries->SeriesNo : NULL), m_RowBegin, pairs, sizeof(pairs) / sizeof(SOptionContractPair*));
		for (int i = 0; i < cnt; i++)
		{
			//�������߶�
			if (height + ROW_HEIGHT > cy)
				break;
			SOptionContractPair* cp = pairs[i];
			size_t pos = m_RowArrayCount++;
			TGridRow& row = m_RowArray[pos];
			row.RowIndex = m_RowBegin + pos;
			row.Contract = cp->Contract1;
			row.Contract2 = cp->Contract2;
			row.IsSpread = false;
			strncpy_s(row.StrikePrice, cp->StrikePrice, sizeof(row.StrikePrice) - 1);
			row.StrikePriceValue = atof(row.StrikePrice) * row.Contract2->Commodity->PriceMultiple;

			m_RowOrder.insert(TGridRowOrderMapType::value_type(row.Contract->ContractNo, (unsigned short)pos));
			if (UnsubConts.find(row.Contract->ContractNo) != UnsubConts.end())
				UnsubConts.erase(row.Contract->ContractNo);
			else
				SubConts.insert(row.Contract->ContractNo);

			m_RowOrder.insert(TGridRowOrderMapType::value_type(row.Contract2->ContractNo, (unsigned short)(pos + MAX_SHOW_ROW)));
			if (UnsubConts.find(row.Contract2->ContractNo) != UnsubConts.end())
				UnsubConts.erase(row.Contract2->ContractNo);
			else
				SubConts.insert(row.Contract2->ContractNo);

			height += ROW_HEIGHT;
		}
		if (m_OptionSeries)
			m_Plate->OptionCallCount = G_StarApi->GetOptionContractPairCount(m_OptionSeries->SeriesNo);
		SStrikePriceType price;
		SContract* pCon = GetSelectContract(price);
		if (pCon)
			m_OptStrategy.SetOptionContract(pCon, price);
		if(bResetTarget)
		   m_OptStrategy.SetOptionSeries(m_OptionSeries);
	}
	else
	{
		for (int i = m_RowBegin; i < (int)m_Plate->PlateRows.size(); i++)
		{
			//���������ʾ����
			if ((int)m_RowArrayCount >= MAX_SHOW_ROW)
				break;

			//�������߶�
			if (height + ROW_HEIGHT > cy)
				break;

			TPlateRow& pr = m_Plate->PlateRows[i];

			size_t pos = m_RowArrayCount++;
			TGridRow& row = m_RowArray[pos];
			row.RowIndex = m_RowBegin + pos;
			if (pr.IsSpread)
			{
				strcpy_s(row.SpreadRow.ContractNo, pr.ContractNo);
				if (!G_QuoteUtils.GetSpreadContract(pr.ContractNo, row.SpreadRow.SpreadContract))
				{
					TPlateRowVectorType rows(m_Plate->PlateRows);
					m_Plate->PlateRows.clear();
					rows.erase(rows.begin() + i);

					for (size_t j = 0; j < rows.size(); j++)
					{
						TPlateRow& r = rows[j];
						r.RowIndex = j;
						m_Plate->PlateRows.push_back(r);
					}

					if (m_RowSelectIndex >= m_Plate->PlateRows.size())
						m_RowSelectIndex = m_Plate->PlateRows.size() - 1;

					m_Plate->SaveRows();
					i--;
					m_RowArrayCount--;
					continue;
				}
				row.Contract2 = NULL;
				row.StrikePrice[0] = '\0';
				row.IsSpread = true;
				m_RowOrder.insert(TGridRowOrderMapType::value_type(row.SpreadRow.ContractNo, (unsigned short)pos));

				if (UnsubConts.find(row.SpreadRow.ContractNo) != UnsubConts.end())
					UnsubConts.erase(row.SpreadRow.ContractNo);
				else
					SubConts.insert(row.SpreadRow.ContractNo);
			}
			else
			{
				row.Contract = pr.Contract;
				row.Contract2 = NULL;
				row.StrikePrice[0] = '\0';
				row.IsSpread = false;
				m_RowOrder.insert(TGridRowOrderMapType::value_type(row.Contract->ContractNo, (unsigned short)pos));

				if (UnsubConts.find(row.Contract->ContractNo) != UnsubConts.end())
					UnsubConts.erase(row.Contract->ContractNo);
				else
					SubConts.insert(row.Contract->ContractNo);
			}
			height += ROW_HEIGHT;
		}
		m_OptStrategy.DelALLRectTool();
	}

}

void TGridControl::Set_SpreadCell(int r, int c)
{
	TGridRow& row = m_RowArray[r];
	if (!row.IsSpread)
		return;
	SSpreadContract con = row.SpreadRow.SpreadContract;
	if (con.SnapShot == NULL)
		return;
	TGridCol& col = m_ColArray[c];
	TQuoteDataCell& cell = m_Data[GL][r][c];
	cell.Chg = QUOTE_CHG_RESUME;
	SQuoteSnapShot* q(con.SnapShot);
	//1.�����ֶ�  ���������������ַ�
	if (col.Field < S_FID_MEAN_COUNT)
	{
		//��ȥԭʼֵ
		cell.Field = q->Data[col.Field];
	}
}
void TGridControl::Set_DataCell(GLR_TYPE glr, int r, int c, QUOTE_CHG_TYPE chg)
{
	TGridRow& row = m_RowArray[r];
	if (row.IsSpread)
	{
		Set_SpreadCell(r, c);
		return;
	}
	SContract* cont = (GL == glr) ? row.Contract : row.Contract2;
	if (NULL == cont || NULL == cont->SnapShot)
		return;

	TGridCol& col = m_ColArray[c];
	TQuoteDataCell& cell = m_Data[glr][r][c];

	//���ñ�־
	cell.Chg = chg;
	SQuoteSnapShot* q(cont->SnapShot);

	//1.�����ֶ�  ���������������ַ�
	if (col.Field < S_FID_MEAN_COUNT)
	{
		//��ȥԭʼֵ
		cell.Field = q->Data[col.Field];

		switch (col.Field)
		{
		case S_FID_BESTBIDPRICE:
		case S_FID_BESTBIDQTY:
		case S_FID_BESTASKPRICE:
		case S_FID_BESTASKQTY:
		{
			SQuoteField field;
			field.FidAttr = S_FIDTYPE_NONE;
			bool ret = G_StarApi->GetImpliedField(cont, col.Field, &field);
			if (ret)
				cell.Field = field;
		}
		break;
		default:
			break;
		}
	}
}

void TGridControl::Load_Datas()
{
	bool isoption = IsOption();
	memset(m_Data, 0, sizeof(m_Data));

	for (size_t r = 0; r < m_RowArrayCount; r++)
	{
		for (size_t c = 0; c < m_ColArrayCount; c++)
		{
			Set_DataCell(GL, r, c, QUOTE_CHG_RESUME);
			if (isoption)
				Set_DataCell(GR, r, c, QUOTE_CHG_RESUME);
		}
	}
}

void TGridControl::LinkageCurrContract(const char* action)
{
	SContract* cont = GetSelectContract();
	if (NULL == cont)
		return;

	LinkageSetContract(action, cont);
}

void TGridControl::OptionOrderPanelSync(const char* Content)
{
	m_OptStrategy.OptionOrderPanelSync(Content);
}
//ҵ����--------------------------------------------------------------------------------------------------------------------
void TGridControl::Refresh_Data()
{
	m_ColChg = true;
	m_RowChg = true;
	m_TargetChg = true;
}

bool TGridControl::IsNeed_Resume()
{
	TCriticalSection::Lock lock(m_Crit);
	return m_NeedResume;
}

bool TGridControl::Update_SpreadQuote(const SSpreadContract* scont)
{
	//�������
	TCriticalSection::Lock lock(m_Crit);
	SContractNoType cno;
	G_QuoteUtils.GetSpreadContractNo(scont, cno);
	TGridRowOrderMapType::iterator iter = m_RowOrder.find(cno);
	if (iter == m_RowOrder.end())
		return false;
	unsigned short rindex = iter->second;
	int r = rindex % MAX_SHOW_ROW;
	TGridRow& row = m_RowArray[r];
	SQuoteSnapShot*	quote = scont->SnapShot;
	if (!quote)
		return false;
	row.SpreadRow.SpreadContract.SnapShot = quote;
	for (int i = 0; i < S_FID_MEAN_COUNT; i++)
	{
		const SQuoteField* field = &quote->Data[i];
		SFidAttrType fid = field->FidAttr;
		int c = m_ColOrder[i] - 1;
		if (c >= 0)
			Set_SpreadCell(r, c);
	}
	return true;
}

bool TGridControl::Update_Quote(const SContract* cont, const SQuoteUpdate* quote)
{
	//�������
	TCriticalSection::Lock lock(m_Crit);

	//�ж���Ȩ���
	if (IsOption()&& NULL != m_OptionSeries && m_OptionSeries->TargetContract == cont)
	{
		m_TargetChg = true;
		m_OptStrategy.UpdateXuShiValue();
		return true;
	}

	//������
	TGridRowOrderMapType::iterator iter = m_RowOrder.find(cont->ContractNo);
	if (iter == m_RowOrder.end())
		return false;
	if (IsOption() && m_OptStrategy.IsCheckedContect(cont->ContractNo))
		m_OptStrategy.FreshStrategyGraph();
	unsigned short rindex = iter->second;
	GLR_TYPE glr = (GLR_TYPE)(rindex / MAX_SHOW_ROW);
	int r = rindex % MAX_SHOW_ROW;
	TGridRow& row = m_RowArray[r];

	//ʱ����仯
	int c = m_ColOrder[S_FID_DATETIME] - 1;
	if (c >= 0)
		Set_DataCell(glr, r, c, QUOTE_CHG_RESUME);

	//�����仯�ֶθ�������
	//�����۸��ֶα仯��ת��Ϊ�����ֶεı仯
	//�����۸��ֶα仯�����ᵼ�»������ֶεı仯
	for (int i = 0; i < quote->Count; i++)
	{
		const SQuoteField* field = &quote->Field[i];
		SFidMeanType fid = field->FidMean;
		switch (fid)
		{
		case S_FID_IMPLIEDBIDPRICE:
			fid = S_FID_BESTBIDQTY;
			c = m_ColOrder[fid] - 1;
			if (c >= 0)
				Set_DataCell(glr, r, c, QUOTE_CHG_CHANGE);
			fid = S_FID_BESTBIDPRICE;
			break;
		case S_FID_IMPLIEDBIDQTY:
			fid = S_FID_BESTBIDQTY;
			break;
		case S_FID_IMPLIEDASKPRICE:
			fid = S_FID_BESTASKQTY;
			c = m_ColOrder[fid] - 1;
			if (c >= 0)
				Set_DataCell(glr, r, c, QUOTE_CHG_CHANGE);
			fid = S_FID_BESTASKPRICE;
			break;
		case S_FID_IMPLIEDASKQTY:
			fid = S_FID_BESTASKQTY;
			break;
		case S_FID_LASTPRICE:
		case S_FID_PRESETTLEPRICE:
			c = m_ColOrder[S_FID_UPDOWN] - 1;
			if (c >= 0)
				Set_DataCell(glr, r, c, QUOTE_CHG_CHANGE);
			c = m_ColOrder[S_FID_GROWTH] - 1;
			if (c >= 0)
				Set_DataCell(glr, r, c, QUOTE_CHG_CHANGE);
			break;
		case S_FID_LASTQTY:
		case S_FID_PREPOSITIONQTY:
		case S_FID_POSITIONQTY:
			c = m_ColOrder[S_FID_NOWINTERST] - 1;
			if (c >= 0)
				Set_DataCell(glr, r, c, QUOTE_CHG_CHANGE);
			c = m_ColOrder[S_FID_TURNRATE] - 1;
			if (c >= 0)
				Set_DataCell(glr, r, c, QUOTE_CHG_CHANGE);
			break;
		default:
			break;
		}
		c = m_ColOrder[fid] - 1;
		if (c >= 0)
			Set_DataCell(glr, r, c, QUOTE_CHG_CHANGE);
	}

	for (size_t c = 0; c < m_ColArrayCount; c++)
	{
		TGridCol* col = &m_ColArray[c];
		if (QUOTE_FIELD_COLOR[col->Field])
		{
			TQuoteDataCell& d = m_Data[glr][r][c];

			if (QUOTE_CHG_INCEPTION == d.Chg)
				d.Chg = QUOTE_CHG_RESUME;
		}
	}

	return true;
}

void TGridControl::Switch_Plate(TPlatePage* plate)
{
	//���ð�顢��������ѡ������
	m_Plate = plate;
	m_ColBegin = 0;
	m_RowBegin = 0;
	m_RowSelectIndex = 0;
	m_RowSelectRight = false;

	//�������С���������
	Reload_ColsAndRows();
}

bool TGridControl::Update_HisQuote(const SContractNoType contractno)
{
	//TCriticalSection::Lock lock(m_Crit);
	if (!IsOption())
		return false;
	//�ж���Ȩ���
	if (NULL != m_OptionSeries && 0 == strncmp(m_OptionSeries->TargetContract->ContractNo, contractno, sizeof(SContractNoType) - 1))
	{
		m_OptStrategy.CalProfitExpectVariance();
		return true;
	}
	return false;
}
void TGridControl::Reload_ColsAndRows()
{
	RECT cr;
	GetRect(cr);
	cr.right -= cr.left;
	cr.bottom -= cr.top;

	std::set<std::string> SubConts;
	std::set<std::string> UnsubConts;
	std::string  UnsubTarget;
	//�����С������С���������
	{
		TCriticalSection::Lock lock(m_Crit);
		Load_Cols(cr.right);
		Load_Rows(cr.bottom, SubConts, UnsubConts, UnsubTarget);
		Load_Datas();
	}
	//
	if (!UnsubTarget.empty())
	{
		SContract* pCon = G_StarApi->GetContractUnderlay(UnsubTarget.c_str());
		if(pCon)
		    G_QuoteCenter.Unsub_HisQuote(pCon->ContractNo, this);
		if (G_QuoteCenter.Sub_HisQuote(m_OptionSeries->TargetContract->ContractNo, S_KLINE_DAY, 1, 100, this))
		{
			G_QuoteCenter.OnHisQuote(m_OptionSeries->TargetContract->ContractNo, S_KLINE_DAY, 0);
		}
	}
	//ִ�����鶩���˶�
	for (std::set<std::string>::iterator iter = SubConts.begin(); iter != SubConts.end(); iter++)
		G_QuoteCenter.Sub_Quote(iter->c_str());

	for (std::set<std::string>::iterator iter = UnsubConts.begin(); iter != UnsubConts.end(); iter++)
		G_QuoteCenter.Unsub_Quote(iter->c_str());
}

void TGridControl::Reload_Rows()
{
	RECT cr;
	GetRect(cr);
	cr.right -= cr.left;
	cr.bottom -= cr.top;

	std::set<std::string> SubConts;
	std::set<std::string> UnsubConts;
	std::string  UnsubTarget;
	//�����С������С���������
	{
		TCriticalSection::Lock lock(m_Crit);
		Load_Rows(cr.bottom, SubConts, UnsubConts, UnsubTarget);
		Load_Datas();
	}
	if (!UnsubTarget.empty())
	{
		SContract* pCon = G_StarApi->GetContractUnderlay(UnsubTarget.c_str());
		if (pCon)
		    G_QuoteCenter.Unsub_HisQuote(pCon->ContractNo, this);
		G_QuoteCenter.Sub_HisQuote(m_OptionSeries->TargetContract->ContractNo, S_KLINE_DAY, 1, 100, this);
	}
	//ִ�����鶩���˶�
	for (std::set<std::string>::iterator iter = SubConts.begin(); iter != SubConts.end(); iter++)
		G_QuoteCenter.Sub_Quote(iter->c_str());

	for (std::set<std::string>::iterator iter = UnsubConts.begin(); iter != UnsubConts.end(); iter++)
		G_QuoteCenter.Unsub_Quote(iter->c_str());
}

bool TGridControl::SelectUp()
{
	if (NULL != m_Plate && m_RowSelectIndex > 0 && m_RowSelectIndex < (size_t)m_Plate->GetRowScrollCount())
	{
		m_RowSelectIndex--;
		if ((int)m_RowSelectIndex < m_RowBegin)
		{
			m_RowBegin--;
			Reload_Rows();
		}
		else
			Refresh_Data();
		return true;
	}
	return false;
}

bool TGridControl::SelectDown()
{
	if (NULL != m_Plate && m_RowSelectIndex >= 0 && m_RowSelectIndex < (size_t)m_Plate->GetRowScrollCount() - 1)
	{
		m_RowSelectIndex++;
		if (m_RowSelectIndex >= m_RowBegin + m_RowArrayCount)
		{
			m_RowBegin++;
			Reload_Rows();
		}
		else
			Refresh_Data();
		return true;
	}
	return false;
}

bool TGridControl::SetContract(SContract* contract)
{
	if (NULL == m_Plate)
		return false;

	for (size_t i = 0; i < m_Plate->PlateRows.size(); i++)
	{
		TPlateRow& row = m_Plate->PlateRows[i];
		if (row.Contract == contract)
		{
			SetRowBegin(row.RowIndex);
			SetSelectRow(row.RowIndex);
			Reload_Rows();
			Redraw(NULL);
			return true;
		}
	}

	return false;
}

void TGridControl::AutoAdjustWidth()
{
	if (NULL == m_Plate)
		return;

	HDC hdc = GetDC(NULL);

	SIZE size;

	//������Ļ��-------------------------------------------------------------------------------------
	for (int c = 0; c < m_Plate->PlateColCount; c++)
	{
		TGridCol& pcol = m_Plate->PlateCols[c];
		if (!pcol.Visible)
			continue;
		int cindex = m_ColOrder[pcol.Field] - 1;
		if (cindex < 0)
			continue;

		GetTextExtentPoint(hdc, pcol.Name, wcslen(pcol.Name), &size);
		TPlateColWidthType width((TPlateColWidthType)size.cx);

		TPlateCol& col = m_ColArray[cindex];
		for (size_t r = 0; r < m_RowArrayCount; r++)
		{
			TGridRow& row = m_RowArray[r];
			TQuoteDataCell& cell = m_Draw[GL][r][cindex];
			SelectObject(hdc, FONT_FUTURE_CONTENT);	//��ͨ����
			wchar_t wtext[101] = L"----";

			switch (S_FIDTYPE_ARRAY[col.Field])
			{
			case S_FIDTYPE_QTY:
				if (row.IsSpread || cell.Field.FidAttr == S_FIDATTR_VALID)
				{
					_i64tow_s(cell.Field.Qty, wtext, sizeof(wtext) / sizeof(wchar_t), 10);
				}
				else if (cell.Field.FidAttr == S_FIDATTR_IMPLIED)
				{
					wtext[0] = L'*';
					_i64tow_s(cell.Field.Qty, &wtext[1], sizeof(wtext) / sizeof(wchar_t) - 1, 10);
				}
				break;
			case S_FIDTYPE_PRICE:
			case S_FIDTYPE_GREEK:
			{
				switch (col.Field)
				{
				case S_FID_UPDOWN:
					if (row.IsSpread)
					{
						SSpreadContract contract = row.SpreadRow.SpreadContract;
						SCommodityPrecType Prec = contract.PricePrec;
						FormatPrice(G_StarApi, cell.Field.Price, Prec, 1, wtext, true);
					}
					else
					{
						SContract* contract = row.Contract;
						if (cell.Field.FidAttr == S_FIDATTR_VALID)
						{
							FormatPrice(G_StarApi, cell.Field.Price, contract->Commodity, wtext, true);
						}
						else if (cell.Field.FidAttr == S_FIDATTR_IMPLIED)
						{
							wtext[0] = L'*';
							FormatPrice(G_StarApi, cell.Field.Price, contract->Commodity, &wtext[1], true);
						}
					}
					break;
				case S_FID_GROWTH:
				case S_FID_RATIO:
					FormatPrice(G_StarApi, cell.Field.Price, 2, 1, wtext, false);
					wcsncat_s(wtext, L"%", 1);
					break;
				case S_FID_TOTALTURNOVER:
					swprintf_s(wtext, L"%.0f", cell.Field.Price);
					break;
				case S_FID_DELTA:
				case S_FID_GAMMA:
				case S_FID_THETA:
				case S_FID_VEGA:
				case S_FID_RHO:
				{
					if (cell.Field.FidAttr == S_FIDATTR_VALID)
						FormatPrice(G_StarApi, cell.Field.Price, 4, 1, wtext, true);
				}
				break;
				default:
					if (row.IsSpread)
					{
						SSpreadContract contract = row.SpreadRow.SpreadContract;
						SCommodityPrecType Prec =contract.PricePrec;
						FormatPrice(G_StarApi, cell.Field.Price, Prec, 1, wtext, true);
					}
					else
					{
						SContract* contract = row.Contract;
						if (cell.Field.FidAttr == S_FIDATTR_VALID)
						{
							FormatPrice(G_StarApi, cell.Field.Price, contract->Commodity, wtext, true);
						}
						else if (cell.Field.FidAttr == S_FIDATTR_IMPLIED)
						{
							wtext[0] = L'*';
							FormatPrice(G_StarApi, cell.Field.Price, contract->Commodity, &wtext[1], true);
						}
					}
					break;
				}
			}
			break;
			case S_FIDTYPE_DATETIME:
			{
				unsigned int t(cell.Field.DateTime % 1000000000);
				swprintf_s(wtext, L"%02d:%02d:%02d %03d", t / 10000000, t / 100000 % 100, t / 1000 % 100, t % 1000);
			}
			break;
			case S_FIDTYPE_STR:
				if (S_FID_CODE == pcol.Field)
				{
					if (row.IsSpread)
					{
						TSpreadRow sRow = row.SpreadRow;
						if (!GetContractCode(G_StarApi, sRow.ContractNo, wtext))
						{
							MultiByteToWideChar(1252, 0, sRow.ContractNo, -1, wtext, sizeof(wtext) / sizeof(wchar_t));
						}
					}
					else
					{
						SContract* contract = row.Contract;
						if (!GetContractCode(G_StarApi, contract->ContractNo, wtext))
						{
							MultiByteToWideChar(1252, 0, contract->ContractNo, -1, wtext, sizeof(wtext) / sizeof(wchar_t));
						}
					}
				}
				else if (S_FID_SRCCODE == col.Field)
				{
					if (row.IsSpread)
					{
						SContractNoType srccno;
						G_StarApi->GetContractSrc(row.SpreadRow.ContractNo, srccno);
						MultiByteToWideChar(1252, 0, srccno, -1, wtext, sizeof(wtext) / sizeof(wchar_t));
					}
					else
					{
						SContract* contract = row.Contract;
						SContractNoType srccno;
						G_StarApi->GetContractSrc(contract->ContractNo, srccno);
						MultiByteToWideChar(1252, 0, srccno, -1, wtext, sizeof(wtext) / sizeof(wchar_t));
					}
				}
				else if (S_FID_NAME == pcol.Field)
				{
					SelectObject(hdc, FONT_FUTURE_CHS);//��������
					if (row.IsSpread)
					{
						TSpreadRow sRow = row.SpreadRow;
						if(!GetContractName(G_StarApi,sRow.ContractNo, wtext))
						{
							MultiByteToWideChar(1252, 0, sRow.ContractNo, -1, wtext, sizeof(wtext) / sizeof(wchar_t));
						}
						wcsncat_s(wtext, G_LANG->LangText(TLI_CUSTOM_TYPE), wcslen(G_LANG->LangText(TLI_CUSTOM_TYPE)));
					}
					else
					{
						SContract* contract = row.Contract;
						if(!GetContractName(G_StarApi, contract->ContractNo, wtext))
						{
							MultiByteToWideChar(1252, 0, contract->ContractNo, -1, wtext, sizeof(wtext) / sizeof(wchar_t));
						}
						/*if ((contract->Commodity->CommodityType == S_COMMODITYTYPE_SPDMON || contract->Commodity->CommodityType == S_COMMODITYTYPE_SPDCOM))
						{
							wcsncat_s(wtext, G_LANG->LangText(TLI_SYSTEM_TYPE), wcslen(G_LANG->LangText(TLI_SYSTEM_TYPE)));
						}*/
					}
				}
				else if (S_FID_SPREADRATIO == col.Field)
				{
					bool bShow = false;
					SContractNoType cno;
					if (row.IsSpread)
					{
						strcpy_s(cno, row.SpreadRow.ContractNo);
						bShow = true;
					}
					else
					{
						SContract* contract =  row.Contract;
						if ((contract->Commodity->CommodityType == S_COMMODITYTYPE_SPDMON || contract->Commodity->CommodityType == S_COMMODITYTYPE_SPDCOM))
						{
							strcpy_s(cno, contract->ContractNo);
							bShow = true;
						}
					}
					if (bShow)
					{
						GetSpreadRatio(cno, wtext, sizeof(wtext) / sizeof(wchar_t));
					}
				}
				break;
			default:
				return;
			}

			GetTextExtentPoint(hdc, wtext, wcslen(wtext), &size);

			if (size.cx > width)
				width = (TPlateColWidthType)size.cx;
			bool isoption = IsOption();
			if (isoption)
			{
				TQuoteDataCell& cell2 = m_Draw[GR][r][cindex];
				wchar_t wtext[101] = L"----";

				switch (S_FIDTYPE_ARRAY[col.Field])
				{
				case S_FIDTYPE_QTY:
					if (cell2.Field.FidAttr == S_FIDATTR_VALID)
					{
						_i64tow_s(cell2.Field.Qty, wtext, sizeof(wtext) / sizeof(wchar_t), 10);
					}
					else if (cell2.Field.FidAttr == S_FIDATTR_IMPLIED)
					{
						wtext[0] = L'*';
						_i64tow_s(cell2.Field.Qty, &wtext[1], sizeof(wtext) / sizeof(wchar_t) - 1, 10);
					}
					break;
				case S_FIDTYPE_PRICE:
				{
					SContract* contract2 = row.Contract2;
					switch (col.Field)
					{
					case S_FID_UPDOWN:
						if (cell2.Field.FidAttr == S_FIDATTR_VALID)
						{
							FormatPrice(G_StarApi, cell2.Field.Price, contract2->Commodity, wtext, true);
						}
						else if (cell2.Field.FidAttr == S_FIDATTR_IMPLIED)
						{
							wtext[0] = L'*';
							FormatPrice(G_StarApi, cell2.Field.Price, contract2->Commodity, &wtext[1], true);
						}
						break;
					case S_FID_GROWTH:
						FormatPrice(G_StarApi, cell2.Field.Price, 2, 1, wtext, false);
						wcsncat_s(wtext, L"%", 1);
						break;
					case S_FID_TOTALTURNOVER:
						swprintf_s(wtext, L"%.0f", cell2.Field.Price);
						break;
					case S_FID_DELTA:
					case S_FID_GAMMA:
					case S_FID_THETA:
					case S_FID_VEGA:
					case S_FID_RHO:
					{
						if (cell2.Field.FidAttr == S_FIDATTR_VALID)
							FormatPrice(G_StarApi, cell2.Field.Price, 4, 1, wtext, true);
					}
					break;
					default:
						if (cell2.Field.FidAttr == S_FIDATTR_VALID)
						{
							FormatPrice(G_StarApi, cell2.Field.Price, contract2->Commodity, wtext, true);
						}
						else if (cell2.Field.FidAttr == S_FIDATTR_IMPLIED)
						{
							wtext[0] = L'*';
							FormatPrice(G_StarApi, cell2.Field.Price, contract2->Commodity, &wtext[1], true);
						}
						break;
					}
				}
				break;
				}
				SIZE size2;
				GetTextExtentPoint(hdc, wtext, wcslen(wtext), &size2);
				if (size2.cx > width)
					width = (TPlateColWidthType)size2.cx;
			}
		}
		pcol.Width = width + 2 * DRAW_CELL_PADDING;
	}

	//�����к����ݣ��ػ����-----------------------------------------------------------------
	Reload_ColsAndRows();
	m_Plate->SaveCols();
	Redraw(NULL);

	DeleteDC(hdc);
}

bool TGridControl::DelSelectedContract()
{
	if (NULL == m_Plate || !m_Plate->IsSelf)
		return false;

	if (m_RowSelectIndex >= 0 && m_RowSelectIndex < m_Plate->PlateRows.size())
	{
		TPlateRowVectorType rows(m_Plate->PlateRows);
		m_Plate->PlateRows.clear();
		rows.erase(rows.begin() + m_RowSelectIndex);

		for (size_t i = 0; i < rows.size(); i++)
		{
			TPlateRow& r = rows[i];
			r.RowIndex = i;
			m_Plate->PlateRows.push_back(r);
		}

		if (m_RowSelectIndex >= m_Plate->PlateRows.size())
			m_RowSelectIndex = m_Plate->PlateRows.size() - 1;

		m_Plate->SaveRows();
		Reload_Rows();
		Redraw(NULL);
		((TQuoteFrame*)GetWindow())->SetPanelContract();
		return true;
	}

	return false;
}

void TGridControl::JumpToAtTheMoney()
{
	bool caloption = (IsOption() && NULL != m_OptionSeries);

	SQuoteSnapShot* rq(NULL);
	SQuoteField* rf(NULL);
	if (caloption)
	{
		rq = m_OptionSeries->TargetContract->SnapShot;
		if (rq)
			rf = &rq->Data[S_FID_LASTPRICE];
	}
	int nFindIndex = 0;
	SOptionContractPair* pairs[MAX_SHOW_ROW];
	int cnt = G_StarApi->GetOptionContractPairData((NULL != m_OptionSeries ? m_OptionSeries->SeriesNo : NULL), 0, pairs, sizeof(pairs) / sizeof(SOptionContractPair*));
	for (int i = 0; i < cnt; i++)
	{
		SOptionContractPair* cp = pairs[i];
		if (cp)
		{
			SPriceType	StrikePrice = atof(cp->StrikePrice) * cp->Contract2->Commodity->PriceMultiple;
			if ((NULL != rf && S_FIDTYPE_NONE != rf->FidAttr && rf->Price >= StrikePrice) || NULL == rf)
				nFindIndex++;
		}
	}
	m_RowBegin = max(0,nFindIndex-(int)m_RowArrayCount/2);

	Reload_Rows();
	Redraw(NULL);

}

void TGridControl::OpenOptioncalu()
{
	if (!m_OptionSeries)
		return;
	wchar_t strParam[1024] = L"";
	wchar_t strTargetPrice[51] = L"0.0001";
	if (m_OptionSeries&&m_OptionSeries->TargetContract)
	{
		SCommodity* comm(m_OptionSeries->TargetContract->Commodity);
		SQuoteSnapShot* q(m_OptionSeries->TargetContract->SnapShot);
		if (NULL != comm && NULL != q)
		{
			SQuoteField& ud = q->Data[S_FID_LASTPRICE];
			double dPrice = 0.001;
			if (S_FIDATTR_NONE != ud.FidAttr)
				dPrice = ud.Price;
			if (dPrice == 0.0)
			{
				ud = q->Data[S_FID_PRESETTLEPRICE];
				if (ud.FidAttr != S_FIDATTR_NONE)
				{
					dPrice = ud.Price;
				}
			}
			FormatPrice(G_StarApi, dPrice, comm, strTargetPrice, true);
		}
	}
	SStrikePriceType price;
	wchar_t strStrikePrice[51] = L"";
	SContract* pCon = GetSelectContract(price);
	SPriceType dStrikePrice = atof(price);
	if (pCon)
	{
		dStrikePrice *= pCon->Commodity->PriceMultiple;
		FormatPrice(G_StarApi, dStrikePrice, pCon->Commodity, strStrikePrice, true);
	}
	
	int nAllDay = m_OptionSeries->ExpiryDays;//(int)(::_time64(NULL) / 3600 * 24);

	//if (nAllDay>7) nAllDay = nAllDay * 5 / 7;  //��ȥ��ĩʱ��
	//if (nAllDay<1) nAllDay = 1;
	double dcall = 10.0, dPut = 10.0;
	GetSelectOptionPrice(dcall, dPut);
	wchar_t strcallPrice[51] = L"", strputPrice[51] = L"";
	FormatPrice(G_StarApi, dcall, m_OptionSeries->Commodity, strcallPrice, true);
	FormatPrice(G_StarApi, dPut, m_OptionSeries->Commodity, strputPrice, true);
	swprintf_s(strParam, L"F 1 1 %s %s %d 3 %d %d %s %s", strTargetPrice, strStrikePrice, nAllDay,20,50, strcallPrice, strputPrice);
	wchar_t currpath[2048];
	CurrPath(currpath, sizeof(currpath)/sizeof(wchar_t)-1);
	wchar_t filename[2048];
	memset(filename, 0, sizeof(filename));

	swprintf_s(filename, L"%s\\OptionCalc.exe", currpath);

	HINSTANCE hinst = ShellExecute(NULL, L"OPEN", filename, strParam, currpath, SW_NORMAL);
}
void TGridControl::SetUpDownRefType(UpDownRefType type)
{
	m_updwonType = type;
	Redraw(NULL);
}
void TGridControl::SetColumnMirror(bool bMirror)
{ 
	m_bColMirror = bMirror; 
	m_ColChg = true;
	m_RowChg = true;
	Redraw(NULL);
}
void TGridControl::SetIsEnterTLine(bool bTLnie)
{
	m_bEnterTLine = bTLnie;
}
void TGridControl::SetIsZceUse(bool bZce)
{ 
	m_bZCEUse = bZce;
	m_bStrategyGraphy = bZce?false:true;
}
void TGridControl::SetTargetAddCol(char* pCol)
{
	m_vAddTargetCol.clear();
	const char * split = ",";
	char * p;
	char *next_token = NULL;
	p = strtok_s(pCol, split,&next_token);
	while (p != NULL)
	{
		int ncol = atoi(p);
		m_vAddTargetCol.push_back(ncol);
		p = strtok_s(NULL, split,&next_token);
	}
}
void TGridControl::PrepareRects(RECT& cr)
{
	bool isoption = IsOption();
	if (m_bZCEUse)
		OPTION_MIDDLE_WIDTH = 140;
	//���� Target �� Grid ������----------------------------------------------------------------------------------------
	RECT& grid_r(m_Rects[GRID]);
	grid_r = cr;
	if (isoption)
	{
		int nHigth;
		if (m_bZCEUse)
			nHigth = RCONTRACT_HEIGHT;
		else
			nHigth = RCONTRACT_HEIGHT + RCONTRACT_STRATEGY;
		if (grid_r.bottom - grid_r.top > nHigth)
			grid_r.top = grid_r.top+ nHigth;
		else
			grid_r.top = grid_r.bottom;
		if (m_bStrategyGraphy)
			grid_r.right = grid_r.right - RCONTRACT_GRAPH_WIDTH;
	}
	
	RECT& target_r(m_Rects[TARGET]);
	target_r = cr;
	if (isoption)
		target_r.bottom = cr.top + RCONTRACT_HEIGHT;
	else
	    target_r.bottom = cr.top;
	target_r.right = grid_r.right;

	RECT& graph_r(m_Rects[TACTIC_GRAPH]);
	graph_r = cr;
	graph_r.left = grid_r.right;
	graph_r.top = cr.top;

	//���� Target �ڲ�����----------------------------------------------------------------------------------------------
	RECT& target_series_r(m_Rects[TARGET_SERIES]);
	target_series_r = target_r;
	if (target_series_r.right - target_series_r.left > RCONTRACT_NAME_WIDTH)
		target_series_r.right = target_series_r.left + RCONTRACT_NAME_WIDTH;
	int ncommidity = 140;
	RECT& target_commidity_r(m_Rects[TARGET_COMMIDITY]);
	target_commidity_r = target_series_r;
	target_commidity_r.right = target_series_r.left + ncommidity;

	RECT& target_contract_r(m_Rects[TARGET_CONTRACT]);
	target_contract_r = target_series_r;
	target_contract_r.left = target_commidity_r.right;

	RECT& target_target_r(m_Rects[TARGET_TARGET]);
	target_target_r = target_r;
	target_target_r.left = target_series_r.right;
	if (target_target_r.right - target_target_r.left > RCONTRACT_TARGET_NAME_WIDTH)
		target_target_r.right = target_target_r.left + RCONTRACT_TARGET_NAME_WIDTH;

	RECT& target_others_r(m_Rects[TARGET_OTHERS]);
	target_others_r = target_r;
	target_others_r.left = target_target_r.right;
	//��Ȩ��������
	RECT& strategy_r(m_Rects[STRATEGY_ITEM]);
	strategy_r.top = target_r.bottom;
	strategy_r.bottom = grid_r.top;
	strategy_r.right = grid_r.right;
	//���� Grid �ڲ�����------------------------------------------------------------------------------------------------
	RECT& grid_header_r(m_Rects[GRID_HEADER]);
	grid_header_r = grid_r;
	if (grid_header_r.bottom - grid_header_r.top > HEAD_HEIGHT)
		grid_header_r.bottom = grid_header_r.top + HEAD_HEIGHT;

	RECT& grid_content_r(m_Rects[GRID_CONTENT]);
	grid_content_r = grid_r;
	grid_content_r.top = grid_header_r.bottom;

	//���� Grid Header �ڲ�����-----------------------------------------------------------------------------------------
	RECT& grid_header_middle_r(m_Rects[GRID_HEADER_MIDDLE]);
	grid_header_middle_r = grid_header_r;
	grid_header_middle_r.left = grid_header_r.right;
	if (isoption && grid_header_r.right - grid_header_r.left > OPTION_MIDDLE_WIDTH)
	{
		grid_header_middle_r.left = grid_header_r.left + (grid_header_r.right - grid_header_r.left - OPTION_MIDDLE_WIDTH) / 2;
		grid_header_middle_r.right = grid_header_middle_r.left + OPTION_MIDDLE_WIDTH;
	}

	RECT& grid_header_left_r(m_Rects[GRID_HEADER_LEFT]);
	grid_header_left_r = grid_header_r;
	grid_header_left_r.right = grid_header_middle_r.left;

	RECT& grid_header_right_r(m_Rects[GRID_HEADER_RIGHT]);
	grid_header_right_r = grid_header_r;
	grid_header_right_r.left = grid_header_middle_r.right;

	//���� Grid Content �ڲ�����----------------------------------------------------------------------------------------
	RECT& grid_content_left_r(m_Rects[GRID_CONTENT_LEFT]);
	grid_content_left_r.top = grid_content_r.top;
	grid_content_left_r.bottom = grid_content_r.bottom;
	grid_content_left_r.left = grid_header_left_r.left;
	if (isoption)
		grid_content_left_r.right = grid_header_left_r.right;
	else
		grid_content_left_r.right = grid_header_left_r.right - VSCROLL_WIDTH - 1;

	RECT& grid_content_middle_r(m_Rects[GRID_CONTENT_MIDDLE]);
	grid_content_middle_r.top = grid_content_r.top;
	grid_content_middle_r.bottom = grid_content_r.bottom;
	grid_content_middle_r.left = grid_header_middle_r.left;
	grid_content_middle_r.right = grid_header_middle_r.right;

	RECT& grid_content_right_r(m_Rects[GRID_CONTENT_RIGHT]);
	grid_content_right_r.top = grid_content_r.top;
	grid_content_right_r.bottom = grid_content_r.bottom;
	grid_content_right_r.left = grid_header_right_r.left;
	grid_content_right_r.right = grid_header_right_r.right - VSCROLL_WIDTH - 1;
}

void TGridControl::Load_DrawData()
{
	//�Ƿ�ִ��Resume����
	bool exec_resume(false);
	DWORD currtick(GetTickCount());
	if (currtick - m_LastTick > 200)
	{
		m_LastTick = currtick;
		exec_resume = true;
	}
	bool isoption = IsOption();
	//�������ݵ���ͼ����
	TCriticalSection::Lock lock(m_Crit);
	for (size_t r = 0; r < m_RowArrayCount; r++)
	{
		TGridRow& row = m_RowArray[r];
		for (size_t c = 0; c < m_ColArrayCount; c++)
		{
			TPlateCol& col = m_ColArray[c];
			TQuoteDataCell& cell = m_Data[GL][r][c];
			if ((QUOTE_CHG_CHANGE == cell.Chg&&S_FIDTYPE_ARRAY[col.Field] == S_FIDTYPE_PRICE) || (row.IsSpread&&S_FIDTYPE_ARRAY[col.Field] == S_FIDTYPE_PRICE))
			{
				if (cell.Field.Price != m_Draw[GL][r][c].Field.Price)
				{
					if (col.Field == S_FID_BESTBIDPRICE)
						m_PreBidPrice[GL][r] = m_Draw[GL][r][c];
					else if (col.Field == S_FID_BESTASKPRICE)
						m_PreAskPrice[GL][r] = m_Draw[GL][r][c];
				}
			}
			if (isoption)
			{
				TQuoteDataCell& cell2 = m_Data[GR][r][c];
				if (QUOTE_CHG_CHANGE == cell2.Chg&&S_FIDTYPE_ARRAY[col.Field] == S_FIDTYPE_PRICE)
				{
					if (cell2.Field.Price != m_Draw[GR][r][c].Field.Price)
					{
						if (col.Field == S_FID_BESTBIDPRICE)
							m_PreBidPrice[GR][r] = m_Draw[GR][r][c];
						else if (col.Field == S_FID_BESTASKPRICE)
							m_PreAskPrice[GR][r] = m_Draw[GR][r][c];
					}
				}
			}
		}
	}
	memcpy_s(m_Draw, sizeof(m_Draw), m_Data, sizeof(m_Data));

	m_NeedResume = false;


	//�޸ı��������ݵı仯ֵ
	for (size_t r = 0; r < m_RowArrayCount; r++)
	{
		for (size_t c = 0; c < m_ColArrayCount; c++)
		{
			TPlateCol& col = m_ColArray[c];
			TQuoteDataCell& cell = m_Data[GL][r][c];

			if (QUOTE_CHG_CHANGE == cell.Chg && QUOTE_FIELD_RESUME[col.Field])
			{
				if (exec_resume)					//�˿��Ʒ������ܻ����cpuռ����
					cell.Chg = QUOTE_CHG_RESUME;
				m_NeedResume = true;
			}
			else if (QUOTE_CHG_INCEPTION != cell.Chg)
			{
				cell.Chg = QUOTE_CHG_INCEPTION;
			}

			if (isoption)
			{
				TQuoteDataCell& cell2 = m_Data[GR][r][c];

				if (QUOTE_CHG_CHANGE == cell2.Chg && QUOTE_FIELD_RESUME[col.Field])
				{
					if (exec_resume)					//�˿��Ʒ������ܻ����cpuռ����
						cell2.Chg = QUOTE_CHG_RESUME;
					m_NeedResume = true;
				}
				else if (QUOTE_CHG_INCEPTION != cell2.Chg)
				{
					cell2.Chg = QUOTE_CHG_INCEPTION;
				}
			}
		}
	}
}

void TGridControl::Cal_Color()
{
	bool caloption = (IsOption() && NULL != m_OptionSeries);

	SQuoteSnapShot* rq(NULL);
	SQuoteField* rf(NULL);
	if (caloption)
	{
		rq = m_OptionSeries->TargetContract->SnapShot;
		if (rq)
			rf = &rq->Data[S_FID_LASTPRICE];
	}

	for (size_t r = 0; r < m_RowArrayCount; r++)
	{
		TGridRow& row = m_RowArray[r];

		SQuoteSnapShot* q(NULL);
		if (NULL != row.Contract && !row.IsSpread)
			q = row.Contract->SnapShot;
		else
			q = row.SpreadRow.SpreadContract.SnapShot;

		SQuoteField* ud(NULL);
		if (NULL != q)
			ud = &q->Data[S_FID_UPDOWN];

		COLORREF color_chg = COLOR_FUTURE_EQUAL;;

		for (size_t c = 0; c < m_ColArrayCount; c++)
		{
			//��ͨ���������ǵ�ɫ---------------------------------------------------------
			COLORREF& color_cf = m_Color[GL][r][c];
			if (m_updwonType == TYPE_LASTSETTLE)
			{
				if (NULL != row.Contract && row.IsSpread)
				{
					SQuoteField* udLastSettle(NULL);
					SQuoteField* udLastPrice(NULL);
					if (NULL != q)
					{
						udLastSettle = &q->Data[S_FID_PRESETTLEPRICE];
						udLastPrice = &q->Data[S_FID_LASTPRICE];
						if (NULL != udLastSettle && S_FIDTYPE_NONE != udLastSettle && 0 != udLastSettle->Price&&udLastPrice != NULL&&udLastPrice != S_FIDTYPE_NONE&&udLastPrice->Price != 0)
							color_chg = (udLastPrice->Price - udLastSettle->Price > 0) ? COLOR_FUTURE_UP : COLOR_FUTURE_DOWN;
						else
							color_chg = COLOR_FUTURE_EQUAL;
					}
				}
				else
				{
					if (NULL != ud && S_FIDTYPE_NONE != ud && 0 != ud->Price)
						color_chg = (ud->Price > 0) ? COLOR_FUTURE_UP : COLOR_FUTURE_DOWN;
					else
						color_chg = COLOR_FUTURE_EQUAL;
				}

			}
			else if (m_updwonType == TYPE_LASTPRICE)
			{
				TGridCol& col = m_ColArray[c];
				TQuoteDataCell& cell = m_Draw[GL][r][c];
				if (S_FIDTYPE_ARRAY[col.Field] == S_FIDTYPE_PRICE)
				{
					if (col.Field == S_FID_BESTBIDPRICE)
					{
						if (cell.Field.Price - m_PreBidPrice[GL][r].Field.Price > 0)
							color_chg = COLOR_FUTURE_UP;
						else if (cell.Field.Price - m_PreBidPrice[GL][r].Field.Price < 0)
							color_chg = COLOR_FUTURE_DOWN;
					}
					else if (col.Field == S_FID_BESTASKPRICE)
					{
						if (cell.Field.Price - m_PreAskPrice[GL][r].Field.Price > 0)
							color_chg = COLOR_FUTURE_UP;
						else if (cell.Field.Price - m_PreAskPrice[GL][r].Field.Price < 0)
							color_chg = COLOR_FUTURE_DOWN;
					}
					else
					{
						if (NULL != row.Contract && row.IsSpread)
						{
							SQuoteField* udLastSettle(NULL);
							SQuoteField* udLastPrice(NULL);
							if (NULL != q)
							{
								udLastSettle = &q->Data[S_FID_PRESETTLEPRICE];
								udLastPrice = &q->Data[S_FID_LASTPRICE];
								if (NULL != udLastSettle && S_FIDTYPE_NONE != udLastSettle && 0 != udLastSettle->Price&&udLastPrice != NULL&&udLastPrice != S_FIDTYPE_NONE&&udLastPrice->Price != 0)
									color_chg = (udLastPrice->Price - udLastSettle->Price > 0) ? COLOR_FUTURE_UP : COLOR_FUTURE_DOWN;
							}
						}
						else
						{
							if (NULL != ud && S_FIDTYPE_NONE != ud && 0 != ud->Price)
								color_chg = (ud->Price > 0) ? COLOR_FUTURE_UP : COLOR_FUTURE_DOWN;
						}
					}

				}
			}

			//���ǵ�ɫ�仯��Ӱ��۸��ֶ���ɫ����Ҫ�����ֶα仯��־-----------------------
			if (color_cf != color_chg)
			{
				color_cf = color_chg;
				TGridCol& col = m_ColArray[c];
				if (QUOTE_FIELD_COLOR[col.Field])
				{
					TQuoteDataCell& cell = m_Draw[GL][r][c];
					if (QUOTE_CHG_INCEPTION == cell.Chg)
						cell.Chg = QUOTE_CHG_RESUME;
				}
			}
		}

		//����Ȩ����Ч�ĵڶ���Լ-----------------------------------------------------
		if (!caloption || NULL == row.Contract2)
			continue;

		SQuoteSnapShot* q2(NULL);
		if (NULL != row.Contract2)
			q2 = row.Contract2->SnapShot;

		SQuoteField* ud2(NULL);
		if (NULL != q2)
			ud2 = &q2->Data[S_FID_UPDOWN];

		//���ǵ�ɫ�仯��Ӱ��۸��ֶ���ɫ����Ҫ�����ֶα仯��־-----------------------
		for (size_t c = 0; c < m_ColArrayCount; c++)
		{
			//��Ȩ���ڶ���Լ�ǵ�ɫ����
			COLORREF& color_cf2 = m_Color[GR][r][c];
			if (m_updwonType == TYPE_LASTSETTLE)
			{
				if (NULL != ud2 && S_FIDTYPE_NONE != ud2 && 0 != ud2->Price)
					color_chg = (ud2->Price > 0) ? COLOR_FUTURE_UP : COLOR_FUTURE_DOWN;
				else
					color_chg = COLOR_FUTURE_EQUAL;
			}
			else if (m_updwonType == TYPE_LASTPRICE)
			{
				TGridCol& col = m_ColArray[c];
				TQuoteDataCell& cell = m_Draw[GR][r][c];
				if (S_FIDTYPE_ARRAY[col.Field] == S_FIDTYPE_PRICE&&NULL != ud2 && S_FIDTYPE_NONE != ud2 && 0 != ud2->Price)
				{
					if (col.Field == S_FID_BESTBIDPRICE)
					{
						if (cell.Field.Price - m_PreBidPrice[GR][r].Field.Price > 0)
							color_chg = COLOR_FUTURE_UP;
						else if (cell.Field.Price - m_PreBidPrice[GR][r].Field.Price < 0)
							color_chg = COLOR_FUTURE_DOWN;
					}
					else if (col.Field == S_FID_BESTASKPRICE)
					{
						if (cell.Field.Price - m_PreAskPrice[GR][r].Field.Price > 0)
							color_chg = COLOR_FUTURE_UP;
						else if (cell.Field.Price - m_PreAskPrice[GR][r].Field.Price < 0)
							color_chg = COLOR_FUTURE_DOWN;
					}
					else
						color_chg = (ud2->Price > 0) ? COLOR_FUTURE_UP : COLOR_FUTURE_DOWN;

				}
			}
			if (color_cf2 != color_chg)
			{
				color_cf2 = color_chg;
				TGridCol& col = m_ColArray[c];
				if (QUOTE_FIELD_COLOR[col.Field])
				{
					TQuoteDataCell& cell = m_Draw[GR][r][c];
					if (QUOTE_CHG_INCEPTION == cell.Chg)
						cell.Chg = QUOTE_CHG_RESUME;
				}
			}
		}

		//��Ȩ����ɫ�ļ���
		HBRUSH bl_chg(BRUSH_INMONEY_BACKGROUND);
		HBRUSH br_chg(BRUSH_OUTMONEY_BACKGROUND);
		if ((NULL != rf && S_FIDTYPE_NONE != rf->FidAttr && rf->Price < m_RowArray[r].StrikePriceValue) || NULL == rf)
		{
			bl_chg = BRUSH_OUTMONEY_BACKGROUND;
			br_chg = BRUSH_INMONEY_BACKGROUND;
		}

		HBRUSH& bl = m_Brush[GL][r];
		HBRUSH& br = m_Brush[GR][r];
		if (bl != bl_chg || br != br_chg)
		{
			bl = bl_chg;
			br = br_chg;

			for (size_t c = 0; c < m_ColArrayCount; c++)
			{
				TQuoteDataCell& d1 = m_Draw[GL][r][c];
				if (QUOTE_CHG_INCEPTION == d1.Chg)
					d1.Chg = QUOTE_CHG_RESUME;
				TQuoteDataCell& d2 = m_Draw[GR][r][c];
				if (QUOTE_CHG_INCEPTION == d2.Chg)
					d2.Chg = QUOTE_CHG_RESUME;
			}
		}
	}
}

void TGridControl::AskOptionPrice()
{
	SContract* selcont = GetSelectContract();
	if (G_CommonApi&&selcont)
	{
		TSendOrder order;
		DefaultSendOrder(order);
		QOptionContractNoTypeToTradeOptionContract(selcont->ContractNo, order);
		order.OrderType = otEnquiry;
		ErrorReflectInfo eError;
		CM_PARAM pm;
		memset(&pm,0, sizeof(CM_PARAM));
		pm.cmParam = CM_ENQUIRY;
		MyVecInt vOrderIds;
		if (!G_CommonApi->InsertOrder(order, eError, vOrderIds,&pm))
		{
			if (eError.nErrorLevel == EL_Error)
				MessageBox(GetWindow()->GetHwnd(), eError.error_text, L"", MB_ICONERROR);
		}
	}
}
bool TGridControl::SeriesNo2Date(SOptionSeriesNoType Sno, wchar_t* date,int nchar)
{
	const char* pos1(strrchr(Sno, '|'));
	if (pos1)
	{
		MultiByteToWideChar(1252, 0, &pos1[1], -1, date,nchar);
		return true;
	}
	return false;
}
void TGridControl::Draw_Target(HDC hdc, RECT& wr, HDC mdc, RECT& cr)
{
	if (!m_TargetChg)
		return;
	RECT target_r = m_Rects[TARGET];
	if (target_r.top >= target_r.bottom)
		return;
	if (NULL == m_OptionSeries || NULL == m_OptionSeries->TargetContract)
	{
		FillRect(mdc, &target_r, BRUSH_FUTURE_ROW_BACKGROUND);
		BitBlt(hdc, wr.left, wr.top, target_r.right - target_r.left, target_r.bottom - target_r.top, mdc, 0, 0, SRCCOPY);
		return;
	}
	//�׳��磬�ü�����begin
	HRGN rgn = CreateRectRgnIndirect(&target_r);
	int retr = SelectClipRgn(mdc, rgn);
	DeleteObject(rgn);
	int nBlock = 20;
	m_TargetChg = false;
	
	SetTextColor(mdc, COLOR_FUTURE_STR);
	SelectObject(mdc, FONT_FUTURE_TITLE);
	int nPriceWidth = m_OptionSeries->TargetContract->Commodity->PriceDeno > 1? RCONTRACT_FRACTION_PRICE_WIDTH:RCONTRACT_PRICE_WIDTH;
	//����--------------------------------------------------
	RECT r(m_Rects[TARGET_SERIES]);
	SelectObject(mdc, PEN_OPTION_SERIES);
	MoveToEx(mdc, r.left, r.top, 0);
	LineTo(mdc, r.left, r.bottom);
	MoveToEx(mdc, r.right, r.top, 0);
	LineTo(mdc, r.right, r.bottom);
	r.bottom = r.top + (r.bottom - r.top) / 2;
	InflateRect(&r, -2, -5);
	r.left += 10;
	wchar_t textCName[51];
	MByteToWChar(m_OptionSeries->Commodity->Exchange->ExchangeName, textCName, sizeof(textCName) / sizeof(wchar_t));
	DrawText(mdc, textCName, wcslen(textCName), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	
	SelectObject(mdc, PEN_OPTION_STRIKE_LINE);
	RECT r_Arraw(m_Rects[TARGET_SERIES]);
	r_Arraw.bottom = r_Arraw.top + (r_Arraw.bottom - r_Arraw.top) / 2;
	r_Arraw.left = r_Arraw.right - nBlock;
	r_Arraw.right = r_Arraw.left + (r_Arraw.bottom - r_Arraw.top);
	Draw_Arraw(mdc, r_Arraw, D_DOWN);

	InflateRect(&r, 2, 5);

	SetTextColor(mdc, COLOR_FUTURE_TITLE);
	RECT rr;
	SIZE size;
	if (!IsDomesticExchange(m_OptionSeries->Commodity->Exchange->ExchangeNo))
	{
		r = m_Rects[TARGET_TARGET];
		r.bottom = r.top + (r.bottom - r.top) / 2;
		DrawText(mdc, G_LANG->LangText(TLI_FUTURE_TARGET), wcslen(G_LANG->LangText(TLI_FUTURE_TARGET)), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

		/*GetTextExtentPoint(mdc, G_LANG->LangText(TLI_FUTURE_TARGET), wcslen(G_LANG->LangText(TLI_FUTURE_TARGET)), &size);

		SelectObject(mdc, PEN_OPTION_TITLE_LINE);
		rr = r;
		rr.left += (rr.right - rr.left - size.cx) / 2 + size.cx;
		rr.right = rr.left + (rr.bottom - rr.top);
		Draw_Arraw(mdc, rr, D_DOWN);*/
	}

	r.left = r.right;
	r.right = r.left + nPriceWidth;
	DrawText(mdc, G_LANG->LangText(TLI_NEW_TEXT), wcslen(G_LANG->LangText(TLI_NEW_TEXT)), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

	r.left = r.right;
	r.right = r.left + nPriceWidth;
	DrawText(mdc, G_LANG->LangText(TLI_UPDOWN_TEXT), wcslen(G_LANG->LangText(TLI_UPDOWN_TEXT)), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

	r.left = r.right;
	r.right = r.left + nPriceWidth;
	DrawText(mdc, G_LANG->LangText(TLI_UPRATE_TEXT), wcslen(G_LANG->LangText(TLI_UPRATE_TEXT)), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

	r.left = r.right;
	r.right = r.left + nPriceWidth;
	DrawText(mdc, G_LANG->LangText(TLI_VOL_TEXT), wcslen(G_LANG->LangText(TLI_VOL_TEXT)), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

	r.left = r.right;
	r.right = r.left + nPriceWidth;
	DrawText(mdc, G_LANG->LangText(TLI_POSITION_TEXT), wcslen(G_LANG->LangText(TLI_POSITION_TEXT)), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

	r.left = r.right;
	r.right = r.left + nPriceWidth;
	DrawText(mdc, G_LANG->LangText(TLI_OPENING_TEXT), wcslen(G_LANG->LangText(TLI_OPENING_TEXT)), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

	r.left = r.right;
	r.right = r.left + nPriceWidth;
	DrawText(mdc, G_LANG->LangText(TLI_HIGH_TEXT), wcslen(G_LANG->LangText(TLI_HIGH_TEXT)), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

	r.left = r.right;
	r.right = r.left + nPriceWidth;
	DrawText(mdc, G_LANG->LangText(TLI_LOW_TEXT), wcslen(G_LANG->LangText(TLI_LOW_TEXT)), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

	r.left = r.right;
	r.right = r.left + nPriceWidth;
	DrawText(mdc, G_LANG->LangText(TLI_PRESETTLE_TEXT), wcslen(G_LANG->LangText(TLI_PRESETTLE_TEXT)), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

	//���Ƹ�����
	for (size_t i = 0; i < m_vAddTargetCol.size(); i++)
	{
		int nfied = m_vAddTargetCol[i];
		if (nfied < MAX_PLATECOL_COUNT)
		{
			TPlateCol* pcol = G_QuoteUtils.PlateColsMap[nfied];
			if (pcol)
			{
				r.left = r.right;
				r.right = r.left + nPriceWidth;
				DrawText(mdc, pcol->Name, wcslen(pcol->Name), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
			}
		}
	}

	//����--------------------------------------------------
	wchar_t text[101];
	SelectObject(mdc, FONT_FUTURE_TITLE);

	r.top = r.bottom;
	r.bottom = target_r.bottom;

	r.left = target_r.left;
	r.right = r.left + RCONTRACT_NAME_WIDTH;
	SelectObject(mdc, PEN_OPTION_SERIES);
	MoveToEx(mdc, r.left, r.top, 0);
	LineTo(mdc, r.right, r.top);
	rr = m_Rects[TARGET_COMMIDITY];
	rr.top = r.top;
	InflateRect(&rr, -2, -5);
	SetTextColor(mdc, COLOR_FUTURE_STR);
	rr.left += 10;
	MByteToWChar(m_OptionSeries->Commodity->CommodityName, textCName, sizeof(textCName) / sizeof(wchar_t));
	DrawText(mdc, textCName, wcslen(textCName), &rr, DT_LEFT | DT_SINGLELINE | DT_VCENTER);

	SelectObject(mdc, PEN_OPTION_STRIKE_LINE);
	r_Arraw = m_Rects[TARGET_COMMIDITY];
	r_Arraw.top = r.top;
	r_Arraw.left = r_Arraw.right - nBlock;
	r_Arraw.right = r_Arraw.left + (r_Arraw.bottom - r_Arraw.top);
	Draw_Arraw(mdc, r_Arraw, D_DOWN);
	
	SelectObject(mdc, PEN_OPTION_SERIES);
	rr = m_Rects[TARGET_CONTRACT];
	rr.top = r.top;
	MoveToEx(mdc, rr.left, rr.top, 0);
	LineTo(mdc, rr.left, rr.bottom);
	InflateRect(&rr, -2, -5);
	rr.left += 5;
	text[0] = L'\0';
	if (SeriesNo2Date(m_OptionSeries->SeriesNo, text, sizeof(text) / sizeof(wchar_t)))
	DrawText(mdc, text, wcslen(text), &rr, DT_LEFT | DT_SINGLELINE | DT_VCENTER);

	SelectObject(mdc, PEN_OPTION_STRIKE_LINE);
	r_Arraw = m_Rects[TARGET_CONTRACT];
	r_Arraw.top = r.top;
	r_Arraw.left = r_Arraw.right - nBlock;
	r_Arraw.right = r_Arraw.left + (r_Arraw.bottom - r_Arraw.top);
	Draw_Arraw(mdc, r_Arraw, D_DOWN);

	r.top -= 2;
	if (!IsDomesticExchange(m_OptionSeries->Commodity->Exchange->ExchangeNo))
	{
		r.left = r.right;
		r.right = r.left + RCONTRACT_TARGET_NAME_WIDTH;
		SetTextColor(mdc, COLOR_FUTURE_STR);
		if (GetContractName(G_StarApi, m_OptionSeries->TargetContract->ContractNo, text))
			DrawText(mdc, text, wcslen(text), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
	}
	SelectObject(mdc, FONT_FUTURE_CONTENT);

	SCommodity* comm(m_OptionSeries->TargetContract->Commodity);
	SQuoteSnapShot* q(m_OptionSeries->TargetContract->SnapShot);
	if (NULL != comm && NULL != q)
	{
		SQuoteField& ud = q->Data[S_FID_UPDOWN];

		COLORREF ud_color(COLOR_FUTURE_EQUAL);
		if (S_FIDTYPE_NONE != ud.FidAttr && 0 != ud.Price)
			ud_color = (ud.Price > 0) ? COLOR_FUTURE_UP : COLOR_FUTURE_DOWN;

		SQuoteField* fid(NULL);

		r.left = r.right;
		r.right = r.left + nPriceWidth;
		SetTextColor(mdc, ud_color);
		fid = &q->Data[S_FID_LASTPRICE];
		if (S_FIDTYPE_NONE != fid->FidAttr && FormatPrice(G_StarApi, fid->Price, comm, text, true))
			DrawText(mdc, text, wcslen(text), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

		r.left = r.right;
		r.right = r.left + nPriceWidth;
		if (S_FIDTYPE_NONE != ud.FidAttr && FormatPrice(G_StarApi, ud.Price, comm, text, true))
			DrawText(mdc, text, wcslen(text), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

		r.left = r.right;
		r.right = r.left + nPriceWidth;
		fid = &q->Data[S_FID_GROWTH];
		if (S_FIDTYPE_NONE != fid->FidAttr && FormatPrice(G_StarApi, fid->Price, 2, 1, text, true))
		{
			wcsncat_s(text, L"%", 1);
			DrawText(mdc, text, wcslen(text), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
		}

		r.left = r.right;
		r.right = r.left + nPriceWidth;
		SetTextColor(mdc, COLOR_FUTURE_STR);
		fid = &q->Data[S_FID_TOTALQTY];
		if (S_FIDTYPE_NONE != fid->FidAttr)
		{
			_itow_s((int)fid->Qty, text, 10);
			DrawText(mdc, text, wcslen(text), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
		}

		r.left = r.right;
		r.right = r.left + nPriceWidth;
		SetTextColor(mdc, COLOR_FUTURE_STR);
		fid = &q->Data[S_FID_POSITIONQTY];
		if (S_FIDTYPE_NONE != fid->FidAttr)
		{
			_itow_s((int)fid->Qty, text, 10);
			DrawText(mdc, text, wcslen(text), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
		}

		r.left = r.right;
		r.right = r.left + nPriceWidth;
		SetTextColor(mdc, COLOR_FUTURE_EQUAL);
		fid = &q->Data[S_FID_OPENINGPRICE];
		if (S_FIDTYPE_NONE != fid->FidAttr && FormatPrice(G_StarApi, fid->Price, comm, text, true))
			DrawText(mdc, text, wcslen(text), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

		r.left = r.right;
		r.right = r.left + nPriceWidth;
		SetTextColor(mdc, COLOR_FUTURE_UP);
		fid = &q->Data[S_FID_HIGHPRICE];
		if (S_FIDTYPE_NONE != fid->FidAttr && FormatPrice(G_StarApi, fid->Price, comm, text, true))
			DrawText(mdc, text, wcslen(text), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

		r.left = r.right;
		r.right = r.left + nPriceWidth;
		SetTextColor(mdc, COLOR_FUTURE_DOWN);
		fid = &q->Data[S_FID_LOWPRICE];
		if (S_FIDTYPE_NONE != fid->FidAttr && FormatPrice(G_StarApi, fid->Price, comm, text, true))
			DrawText(mdc, text, wcslen(text), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

		r.left = r.right;
		r.right = r.left + nPriceWidth;
		SetTextColor(mdc, COLOR_FUTURE_EQUAL);
		fid = &q->Data[S_FID_PRESETTLEPRICE];
		if (S_FIDTYPE_NONE != fid->FidAttr && FormatPrice(G_StarApi, fid->Price, comm, text, true))
			DrawText(mdc, text, wcslen(text), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

		//���Ƹ�����
		for (size_t i = 0; i < m_vAddTargetCol.size(); i++)
		{
			int nfied = m_vAddTargetCol[i];
			if (nfied < MAX_PLATECOL_COUNT)
			{
				r.left = r.right;
				r.right = r.left + nPriceWidth;
				fid = &q->Data[nfied];
				switch (S_FIDTYPE_ARRAY[nfied])
				{
				case S_FIDTYPE_QTY:	//�����ֶ� ��ɫ
				{
					SetTextColor(mdc, COLOR_FUTURE_STR);
					if (S_FIDTYPE_NONE != fid->FidAttr)
					{
						_itow_s((int)fid->Qty, text, 10);
						DrawText(mdc, text, wcslen(text), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
					}
				}
				break;
				case S_FIDTYPE_PRICE:	//�۸��ֶΣ�QUOTE_FIELD_COLOR Ϊ false �� ��ɫ��Ϊ true �� �����ǵ��ж� ��ɫ �� ��ɫ
				{
					SetTextColor(mdc, ud_color);
					if (S_FIDTYPE_NONE != fid->FidAttr && FormatPrice(G_StarApi, fid->Price, comm, text, true))
						DrawText(mdc, text, wcslen(text), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
				}	
				break;
				case S_FIDTYPE_TIME:	//ʱ���ֶ� ��ɫ
				{
					SetTextColor(mdc, COLOR_FUTURE_STR);
					unsigned int t(fid->DateTime % 1000000000);
					swprintf_s(text, L"%02d:%02d:%02d %03d", t / 10000000, t / 100000 % 100, t / 1000 % 100, t % 1000);
					DrawText(mdc, text, wcslen(text), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
				}
				break;
				}
			}
		}
	}
	//�ײ�����----------------------------------------------
	SelectObject(mdc, PEN_FUTURE_TITLELINE);
	MoveToEx(mdc, target_r.left + 2, target_r.bottom - 1, 0);
	LineTo(mdc, target_r.right - 2, target_r.bottom - 1);
	//�ָ��ü�����
	SelectClipRgn(mdc, NULL);
	BitBlt(hdc, wr.left, wr.top, target_r.right - target_r.left, target_r.bottom - target_r.top, mdc, 0, 0, SRCCOPY);
}

void TGridControl::Draw_Cols(HDC hdc, RECT& wr, HDC mdc, RECT& cr)
{
	if (!m_ColChg)
		return;

	RECT grid_header_r(m_Rects[GRID_HEADER]);
	RECT grid_header_left_r(m_Rects[GRID_HEADER_LEFT]);
	RECT grid_header_middle_r(m_Rects[GRID_HEADER_MIDDLE]);
	RECT grid_header_right_r(m_Rects[GRID_HEADER_RIGHT]);

	FillRect(mdc, &grid_header_r, BRUSH_FUTURE_HEAD_BACKGROUND);
	SelectObject(mdc, FONT_FUTURE_TITLE);
	SetTextColor(mdc, COLOR_FUTURE_TITLE);

	//�ڻ�����Ȩ���ֱ���
	//�׳��磬�ü�����begin
	HRGN rgn = CreateRectRgnIndirect(&grid_header_left_r);
	int retr = SelectClipRgn(mdc, rgn);
	DeleteObject(rgn);
	RECT r(grid_header_left_r);
	if(m_bColMirror&&IsOption())
		r.left = r.right;
	else
	    r.right = r.left;
	for (size_t i = 0; i < m_ColArrayCount; i++)
	{
		TGridCol* col = &m_ColArray[i];
		if (m_bColMirror&&IsOption())
		{
			r.right = r.left;
			r.left = r.right - col->Width;
		}
		else
		{
			r.left = r.right;
			r.right = r.left + col->Width;
		}

		RECT dr(r);
		if (dr.left + DRAW_CELL_PADDING <= dr.right)
			dr.left += DRAW_CELL_PADDING;
		if (dr.left <= dr.right - DRAW_CELL_PADDING)
			dr.right -= DRAW_CELL_PADDING;
		TPlateColAlignType		tAlign = col->Align;
		if (m_bColMirror&&IsOption())
		{
			if(col->Align == DT_LEFT)
				tAlign = DT_RIGHT;
			else if(col->Align == DT_RIGHT)
				tAlign = DT_LEFT;
		}
		SIZE tSize;
		GetTextExtentPoint(hdc, col->Name, wcslen(col->Name), &tSize);
		if (dr.right - dr.left <= tSize.cx)
		{
			if (m_bColMirror&&IsOption())
				dr.right= dr.left + tSize.cx;
			else
				dr.left = dr.right - tSize.cx;
		}
		DrawText(mdc, col->Name, wcslen(col->Name), &dr, tAlign | DT_SINGLELINE | DT_VCENTER);
	}
	//�ָ��ü�����
	SelectClipRgn(mdc, NULL);
	r = grid_header_middle_r;
	if (r.right > r.left&&m_OptionSeries)
	{   
		wchar_t title[201] = L"";
		if(m_bZCEUse)
			wcscpy_s(title, G_LANG->LangText(TLI_OPTIONSTRIKEPRICE));
		else if (m_OptionSeries->ExpiryDays > 360)
		{
			swprintf_s(title, G_LANG->LangText(TLI_STRIKEPRICE_TITLE), 0);
		}
		else
		{
			swprintf_s(title, G_LANG->LangText(TLI_STRIKEPRICE_TITLE), m_OptionSeries->ExpiryDays);
		}
		DrawText(mdc, title, wcslen(title), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
	}
	r = grid_header_right_r;
	if (r.right > r.left)
	{
		rgn = CreateRectRgnIndirect(&grid_header_right_r);
		SelectClipRgn(mdc, rgn);
		DeleteObject(rgn);
		r.right = r.left;

		for (size_t i = 0; i < m_ColArrayCount; i++)
		{
			TGridCol* col = &m_ColArray[i];
			r.left = r.right;
			r.right = r.left + col->Width;

			RECT dr(r);
			if (dr.left + DRAW_CELL_PADDING <= dr.right)
				dr.left += DRAW_CELL_PADDING;
			if (dr.left <= dr.right - DRAW_CELL_PADDING)
				dr.right -= DRAW_CELL_PADDING;
			SIZE tSize;
			GetTextExtentPoint(hdc, col->Name, wcslen(col->Name), &tSize);
			if (dr.right - dr.left <= tSize.cx)
				dr.left = dr.right - tSize.cx;
			DrawText(mdc, col->Name, wcslen(col->Name), &dr, col->Align | DT_SINGLELINE | DT_VCENTER);
		}
		//�ָ��ü�����
		SelectClipRgn(mdc, NULL);
	}
	SelectObject(mdc, PEN_FUTURE_TITLELINE);
	MoveToEx(mdc, grid_header_r.left, grid_header_r.bottom - 1, 0);
	LineTo(mdc, grid_header_r.right, grid_header_r.bottom - 1);
	BitBlt(hdc, wr.left+ grid_header_r.left, wr.top + r.top, grid_header_r.right - grid_header_r.left, grid_header_r.bottom - grid_header_r.top, mdc, grid_header_r.left, r.top, SRCCOPY);
}
void GetTotalTurnoverText(wchar_t* pText, size_t nSize,SPriceType pice)
{
	if (G_LANG->LangId() == ENU)
	{
		if (pice / 1000000000.0> 1.0)
		{
			swprintf_s(pText, nSize, L"%.1f%s", pice / 1000000000.0, G_LANG->LangText(TLI_BILLION));
		}
		else if (pice / 1000000 > 1.0)
		{
			swprintf_s(pText, nSize, L"%.1f%s", pice / 1000000.0,G_LANG->LangText(TLI_MILLION));
		}
		else if (pice / 10000 > 1.0)
		{
			swprintf_s(pText, nSize, L"%.0f%s", pice / 1000.0, G_LANG->LangText(TLI_THOUSAND));
		}
		else
		{
			swprintf_s(pText, nSize, L"%.0f", pice);
		}
	}
	else
	{
		if (pice / 1000000000000.0> 1.0)
		{
			swprintf_s(pText, nSize, L"%.1f%s", pice / 1000000000000.0, G_LANG->LangText(TLI_BILLION));
		}
		else if (pice / 100000000 > 1.0)
		{
			swprintf_s(pText, nSize, L"%.1f%s", pice / 100000000.0, G_LANG->LangText(TLI_MILLION));
		}
		else if (pice / 100000 > 1.0)
		{
			swprintf_s(pText, nSize, L"%.0f%s", pice / 10000.0, G_LANG->LangText(TLI_THOUSAND));
		}
		else
		{
			swprintf_s(pText, nSize, L"%.0f", pice);
		}
	}
	
}
void TGridControl::Draw_Cell(HDC hdc, RECT& r, GLR_TYPE glr, size_t ri, size_t ci)
{
	SelectObject(hdc, FONT_FUTURE_CONTENT);
	TGridCol& col = m_ColArray[ci];
	TGridRow& row = m_RowArray[ri];
	TQuoteDataCell& cell = m_Draw[glr][ri][ci];
	wchar_t wtext[101] = L"----";

	switch (S_FIDTYPE_ARRAY[col.Field])
	{
	case S_FIDTYPE_QTY:	//�����ֶ� ��ɫ
		SetTextColor(hdc, COLOR_FUTURE_STR);
		if ((row.IsSpread&&cell.Field.FidAttr != S_FIDTYPE_NONE) || (!row.IsSpread&&cell.Field.FidAttr == S_FIDATTR_VALID))
		{
			_i64tow_s(cell.Field.Qty, wtext, sizeof(wtext) / sizeof(wchar_t), 10);
		}
		else if (cell.Field.FidAttr == S_FIDATTR_IMPLIED)
		{
			wtext[0] = L'*';
			_i64tow_s(cell.Field.Qty, &wtext[1], sizeof(wtext) / sizeof(wchar_t) - 1, 10);
		}
		break;
	case S_FIDTYPE_PRICE:	//�۸��ֶΣ�QUOTE_FIELD_COLOR Ϊ false �� ��ɫ��Ϊ true �� �����ǵ��ж� ��ɫ �� ��ɫ
	case S_FIDTYPE_GREEK:
	{
		if (QUOTE_CHG_CHANGE == cell.Chg && QUOTE_FIELD_RESUME[col.Field])
			SetTextColor(hdc, COLOR_FUTURE_CHANGED);
		else
			SetTextColor(hdc, m_Color[glr][ri][ci]);

		switch (col.Field)
		{
		case S_FID_GROWTH:
			if (cell.Field.FidAttr == S_FIDATTR_VALID)
			{
				FormatPrice(G_StarApi, cell.Field.Price, 2, 1, wtext, false);
				wcsncat_s(wtext, L"%", 1);
			}
			break;
		case S_FID_RATIO:
			FormatPrice(G_StarApi, cell.Field.Price*100, 2, 1, wtext, false);
			wcsncat_s(wtext, L"%", 1);
			break;
		case S_FID_TOTALTURNOVER:
			GetTotalTurnoverText(wtext, sizeof(wtext) / sizeof(wchar_t),cell.Field.Price);
			break;
		case S_FID_DELTA:
		case S_FID_GAMMA:
		case S_FID_THETA:
		case S_FID_VEGA:
		case S_FID_RHO:
		{
			if (cell.Field.FidAttr == S_FIDATTR_VALID)
				FormatGreek(cell.Field.Greek, 4, wtext);
		}
		break;
		default:
			if (row.IsSpread)
			{
				if (cell.Field.FidAttr != S_FIDTYPE_NONE)
				{
					SSpreadContract contract = row.SpreadRow.SpreadContract;
					SCommodityPrecType Prec = contract.PricePrec;
					FormatPrice(G_StarApi, cell.Field.Price, Prec, 1, wtext, true);
				}
			}
			else
			{
				SContract* contract = (GL == glr) ? row.Contract : row.Contract2;
				if (cell.Field.FidAttr == S_FIDATTR_VALID)
				{
					FormatPrice(G_StarApi, cell.Field.Price, contract->Commodity, wtext, true);
				}
				else if (cell.Field.FidAttr == S_FIDATTR_IMPLIED)
				{
					wtext[0] = L'*';
					FormatPrice(G_StarApi, cell.Field.Price, contract->Commodity, &wtext[1], true);
				}
			}
			break;
		}
	}
	break;
	case S_FIDTYPE_DATETIME:	//ʱ���ֶ� ��ɫ
	{
		SetTextColor(hdc, COLOR_FUTURE_STR);
		unsigned int t(cell.Field.DateTime % 1000000000);
		swprintf_s(wtext, L"%02d:%02d:%02d %03d", t / 10000000, t / 100000 % 100, t / 1000 % 100, t % 1000);
	}
	break;
	case S_FIDTYPE_STR:	//�����ֶ� ��ɫ
		if (S_FID_CODE == col.Field)
		{
			if (m_RowSelectIndex == m_RowArray[ri].RowIndex)
				SetTextColor(hdc, COLOR_FUTURE_SEL_TEXT);
			else
			    SetTextColor(hdc, COLOR_FUTURE_STR);
			if (row.IsSpread)
			{
				if (!GetContractCode(G_StarApi, row.SpreadRow.ContractNo, wtext))
				{
					MultiByteToWideChar(1252, 0, row.SpreadRow.ContractNo, -1, wtext, sizeof(wtext) / sizeof(wchar_t));
				}
			}
			else
			{
				SContract* contract = (GL == glr) ? row.Contract : row.Contract2;
				if (!GetContractCode(G_StarApi, contract->ContractNo, wtext))
				{
					MultiByteToWideChar(1252, 0, contract->ContractNo, -1, wtext, sizeof(wtext) / sizeof(wchar_t));
				}
			}
		}
		else if (S_FID_SRCCODE == col.Field)
		{
			if (m_RowSelectIndex == m_RowArray[ri].RowIndex)
				SetTextColor(hdc, COLOR_FUTURE_SEL_TEXT);
			else
				SetTextColor(hdc, COLOR_FUTURE_STR);
			if (row.IsSpread)
			{
				SContractNoType srccno;
				G_StarApi->GetContractSrc(row.SpreadRow.ContractNo, srccno);
				MultiByteToWideChar(1252, 0, srccno, -1, wtext, sizeof(wtext) / sizeof(wchar_t));
			}
			else
			{
				SContract* contract = (GL == glr) ? row.Contract : row.Contract2;
				SContractNoType srccno;
				G_StarApi->GetContractSrc(contract->ContractNo, srccno);
				MultiByteToWideChar(1252, 0, srccno, -1, wtext, sizeof(wtext) / sizeof(wchar_t));
			}
		}
		else if (S_FID_NAME == col.Field)
		{
			SelectObject(hdc, FONT_FUTURE_CHS);//��������
			if (m_RowSelectIndex == m_RowArray[ri].RowIndex)
				SetTextColor(hdc, COLOR_FUTURE_SEL_TEXT);
			else
			    SetTextColor(hdc, COLOR_FUTURE_STR);
			if (row.IsSpread)
			{
				if (!GetContractName(G_StarApi, row.SpreadRow.ContractNo, wtext))
				{
					MultiByteToWideChar(1252, 0, row.SpreadRow.ContractNo, -1, wtext, sizeof(wtext) / sizeof(wchar_t));
				}
				wcsncat_s(wtext, G_LANG->LangText(TLI_CUSTOM_TYPE), wcslen(G_LANG->LangText(TLI_CUSTOM_TYPE)));
			}
			else
			{
				SContract* contract = (GL == glr) ? row.Contract : row.Contract2;
				if(!GetContractName(G_StarApi, contract->ContractNo, wtext))
				{
					MultiByteToWideChar(1252, 0, contract->ContractNo, -1, wtext, sizeof(wtext) / sizeof(wchar_t));
				}
				/*if ((contract->Commodity->CommodityType == S_COMMODITYTYPE_SPDMON || contract->Commodity->CommodityType == S_COMMODITYTYPE_SPDCOM))
				{
					wcsncat_s(wtext, G_LANG->LangText(TLI_SYSTEM_TYPE), wcslen(G_LANG->LangText(TLI_SYSTEM_TYPE)));
				}*/
			}
		}
		else if (S_FID_SPREADRATIO == col.Field)
		{
			if (m_RowSelectIndex == m_RowArray[ri].RowIndex)
				SetTextColor(hdc, COLOR_FUTURE_SEL_TEXT);
			else
				SetTextColor(hdc, COLOR_FUTURE_STR);
			bool bShow = false;
			SContractNoType cno;
			if (row.IsSpread)
			{
				strcpy_s(cno, row.SpreadRow.ContractNo);
				bShow = true;
			}
			else
			{
				SContract* contract = (GL == glr) ? row.Contract : row.Contract2;
				if ((contract->Commodity->CommodityType == S_COMMODITYTYPE_SPDMON || contract->Commodity->CommodityType == S_COMMODITYTYPE_SPDCOM))
				{
					strcpy_s(cno, contract->ContractNo);
					bShow = true;
				}
			}
			if (bShow)
			{
				GetSpreadRatio(cno, wtext, sizeof(wtext) / sizeof(wchar_t));
			}		
		}
		break;
	default:
		return;
	}

	RECT dr(r);
	if (dr.left + DRAW_CELL_PADDING <= dr.right)
		dr.left += DRAW_CELL_PADDING;
	if (dr.left <= dr.right - DRAW_CELL_PADDING)
		dr.right -= DRAW_CELL_PADDING;
	TPlateColAlignType		tAlign = col.Align;
	if (m_bColMirror&&IsOption()&& GL == glr)
	{
		if (col.Align == DT_LEFT)
			tAlign = DT_RIGHT;
		else if (col.Align == DT_RIGHT)
			tAlign = DT_LEFT;
	}
	SIZE tSize;
	GetTextExtentPoint(hdc, wtext, wcslen(wtext),&tSize);
	if (dr.right - dr.left <= tSize.cx)
	{
		if (m_bColMirror&&IsOption() && GL == glr)
			dr.right = dr.left + tSize.cx;
		else
			dr.left = dr.right - tSize.cx;
	}
	DrawText(hdc, wtext, wcsnlen_s(wtext, sizeof(wtext) / sizeof(wchar_t) - 1), &dr, DT_NOPREFIX | DT_SINGLELINE | DT_VCENTER | tAlign);
}

void TGridControl::Draw_VScroll(HDC hdc, RECT& wr, HDC mdc, RECT& cr)
{
	RECT sr;
	if (!GetScrollRect(sr))
		return;
	FillRect(mdc, &sr, BRUSH_FUTURE_VSCROLL);
}

void TGridControl::Draw_Rows(HDC hdc, RECT& wr, HDC mdc, RECT& cr)
{
	RECT grid_content_r(m_Rects[GRID_CONTENT]);
	RECT grid_content_left_r(m_Rects[GRID_CONTENT_LEFT]);
	RECT grid_content_middle_r(m_Rects[GRID_CONTENT_MIDDLE]);
	RECT grid_content_right_r(m_Rects[GRID_CONTENT_RIGHT]);

	FillRect(mdc, &grid_content_r, BRUSH_FUTURE_ROW_BACKGROUND);
	bool drawoption(grid_content_middle_r.right > grid_content_middle_r.left);

	//SelectObject(mdc, FONT_FUTURE_CONTENT);
	LONG row_width = grid_content_left_r.right - grid_content_left_r.left;

	//�׳��磬�ü�����begin
	HRGN rgn = CreateRectRgnIndirect(&grid_content_left_r);
	int retr = SelectClipRgn(mdc, rgn);
	DeleteObject(rgn);
	RECT r(grid_content_left_r);
	r.bottom = r.top;
	{
		//�ڻ�---------------------------------------------------------------------------------------------------------------------------
		for (size_t ri = 0; ri < m_RowArrayCount; ri++)
		{
			r.top = r.bottom;
			r.bottom = r.top + ROW_HEIGHT;
			if (m_bColMirror&&IsOption())
			{
				r.right = grid_content_left_r.right;
				r.left = r.right;
			}
			else
			{
				r.left = grid_content_left_r.left;
				r.right = r.left;
			}

			//����Ȩ����ɫ
			if (drawoption&&!m_bZCEUse)
			{
				RECT rr(r);
				rr.left = grid_content_left_r.left;
				rr.right = rr.left + row_width;
				FillRect(mdc, &rr, m_Brush[GL][ri]);
			}
			else if (!m_RowSelectRight && m_RowSelectIndex == m_RowArray[ri].RowIndex)
			{
				RECT rr(r);
				rr.left = grid_content_left_r.left;
				rr.right = rr.left + row_width;
				FillRect(mdc, &rr, BRUSH_FUTURE_SEL_BACKGROUND);
			}
			bool rchg(false);

			for (size_t ci = 0; ci < m_ColArrayCount; ci++)
			{
				if (m_bColMirror&&IsOption())
				{
					r.right = r.left;
					r.left = r.right - m_ColArray[ci].Width;
				}
				else
				{
					r.left = r.right;
					r.right = r.left + m_ColArray[ci].Width;
				}

				if (!m_RowChg && QUOTE_CHG_INCEPTION == m_Draw[GL][ri][ci].Chg)
					continue;

				rchg = true;	//�����б仯
				Draw_Cell(mdc, r, GL, ri, ci);
			}

			if (!rchg)
				continue;

			//��ѡ����
			if (!m_RowSelectRight && m_RowSelectIndex == m_RowArray[ri].RowIndex)
			{
				RECT rr(r);
				rr.left = grid_content_left_r.left;
				rr.right = rr.left + row_width;
				FrameRect(mdc, &rr, BRUSH_FUTURE_SEL);
			}

			if (m_RowChg)
				continue;

			//������ͼ
			if (m_bColMirror&&IsOption())
			{
				r.right = grid_content_left_r.right;
				r.left = r.right;
			}
			else
			{
				r.left = grid_content_left_r.left;
				r.right = r.left;
			}
			for (size_t ci = 0; ci < m_ColArrayCount; ci++)
			{
				TGridCol* col = &m_ColArray[ci];
				TQuoteDataCell* cell = &m_Draw[GL][ri][ci];

				//����
				if (QUOTE_CHG_INCEPTION == cell->Chg)
				{
					if (r.right > r.left)
						BitBlt(hdc, wr.left + r.left, wr.top + r.top, min(r.right, grid_content_left_r.right - VSCROLL_WIDTH) - r.left, min(r.bottom, cr.bottom) - r.top, mdc, r.left, r.top, SRCCOPY);
					if (m_bColMirror&&IsOption())
					{
						r.left -= col->Width;
						r.right = r.left;
					}
					else
					{
						r.right += col->Width;
						r.left = r.right;
					}
					continue;
				}

				//�仯
				if (m_bColMirror&&IsOption())
					r.left -= col->Width;
				else
				    r.right += col->Width;
			}
			if (r.left < 0)
				r.left = 0;
			if (r.right > r.left) //���һ����ͼ����β ����vscroll���򣬱�֤��Ȩ����ɫ
				BitBlt(hdc, wr.left + r.left, wr.top + r.top, min(r.right, grid_content_left_r.right) - r.left, min(r.bottom, cr.bottom) - r.top, mdc, r.left, r.top, SRCCOPY);
		}
	}
	//�ָ��ü�����
	SelectClipRgn(mdc, NULL);
	//��Ȩ---------------------------------------------------------------------------------------------------------------------------
	if (drawoption)
	{
		//�׳��磬�ü�����begin
		rgn = CreateRectRgnIndirect(&grid_content_right_r);
		SelectClipRgn(mdc, rgn);
		DeleteObject(rgn);
		row_width = grid_content_right_r.right - grid_content_right_r.left;
		r = grid_content_right_r;
		r.bottom = r.top;

		for (size_t ri = 0; ri < m_RowArrayCount; ri++)
		{
			r.top = r.bottom;
			r.bottom = r.top + ROW_HEIGHT;
			r.left = grid_content_right_r.left;
			r.right = r.left;

			//����Ȩ����ɫ
			if (drawoption && !m_bZCEUse)
			{
				RECT rr(r);
				rr.left = grid_content_right_r.left;
				rr.right = rr.left + row_width;
				FillRect(mdc, &rr, m_Brush[GR][ri]);
			}
			else if (m_RowSelectRight && m_RowSelectIndex == m_RowArray[ri].RowIndex)
			{
				RECT rr(r);
				rr.left = grid_content_right_r.left;
				rr.right = rr.left + row_width;
				FillRect(mdc, &rr, BRUSH_FUTURE_SEL_BACKGROUND);
			}
			bool rchg(false);

			for (size_t ci = 0; ci < m_ColArrayCount; ci++)
			{
				r.left = r.right;
				r.right = r.left + m_ColArray[ci].Width;

				if (!m_RowChg && QUOTE_CHG_INCEPTION == m_Draw[GR][ri][ci].Chg)
					continue;

				rchg = true;	//�����б仯
				Draw_Cell(mdc, r, GR, ri, ci);
			}

			if (!rchg)
				continue;

			//��ѡ����
			if (m_RowSelectRight && m_RowSelectIndex == m_RowArray[ri].RowIndex)
			{
				RECT rr(r);
				rr.left = grid_content_right_r.left;;
				rr.right = rr.left + row_width;
				FrameRect(mdc, &rr, BRUSH_FUTURE_SEL);
			}

			if (m_RowChg)
				continue;

			//������ͼ
			r.left = grid_content_right_r.left;
			r.right = r.left;
			for (size_t ci = 0; ci < m_ColArrayCount; ci++)
			{
				TGridCol* col = &m_ColArray[ci];
				TQuoteDataCell* cell = &m_Draw[GR][ri][ci];

				//����
				if (QUOTE_CHG_INCEPTION == cell->Chg)
				{
					if (r.right > r.left)
						BitBlt(hdc, wr.left + r.left, wr.top + r.top, min(r.right, grid_content_right_r.right) - r.left, min(r.bottom, cr.bottom) - r.top, mdc, r.left, r.top, SRCCOPY);

					r.right += col->Width;
					r.left = r.right;
					continue;
				}

				//�仯
				r.right += col->Width;
			}

			if (r.right > r.left)	//���һ����ͼ����β ����vscroll���򣬱�֤��Ȩ����ɫ
				BitBlt(hdc, wr.left + r.left, wr.top + r.top, grid_content_right_r.right - r.left, min(r.bottom, cr.bottom) - r.top, mdc, r.left, r.top, SRCCOPY);
		}
		//�ָ��ü�����
		SelectClipRgn(mdc, NULL);
	}

	//�б仯��ͼ
	if (m_RowChg)
	{
		//��������
		Draw_VScroll(hdc, wr, mdc, cr);

		r = grid_content_r;
		BitBlt(hdc, wr.left + r.left, wr.top + r.top, r.right - r.left, r.bottom - r.top, mdc, r.left, r.top, SRCCOPY);
	}
}

//----------------------------------------------------------------------------------------------------------------------
bool TGridControl::GetScrollRect(RECT& r)
{
	//�ް�飬��������ݣ���ʾ�����ݣ�������ʾ������
	if (NULL == m_Plate)
		return false;

	if (m_Plate->GetRowScrollCount() <= 0)
		return false;

	if (m_RowArrayCount >= (size_t)m_Plate->GetRowScrollCount())
		return false;

	//�߶ȺͿ��Ȳ���������ʾ������
	int nHigth = m_bZCEUse ? RCONTRACT_HEIGHT: RCONTRACT_HEIGHT + RCONTRACT_STRATEGY;
	LONG top_height = IsOption() ? HEAD_HEIGHT + nHigth : HEAD_HEIGHT;

	RECT cr(m_Rects[GRID_CONTENT]);
	if (cr.right <= VSCROLL_WIDTH || cr.bottom <= top_height)
		return false;

	//����r
	r.right = cr.right - 1;
	r.left = cr.right - VSCROLL_WIDTH;

	LONG all_height = (cr.bottom - top_height);
	size_t pos = m_RowBegin;
	size_t page = m_RowArrayCount;
	size_t count = m_Plate->GetRowScrollCount();
	if (pos >= count)
		pos = count - 1;
	if (page > count)
		page = count;

	r.top = top_height + (LONG)(1.0 * pos * all_height / count);
	r.bottom = r.top + (LONG)(1.0 * page * all_height / count);
	return true;
}

int TGridControl::FindColEdge(short x)
{
	RECT grid_content_left_r(m_Rects[GRID_CONTENT_LEFT]);
	int width(0);
	if (m_bColMirror&&IsOption())
		width = grid_content_left_r.right;
	for (int i = 0; i < (int)m_ColArrayCount; i++)
	{
		if (!m_ColArray[i].Visible)
			continue;
		if (m_bColMirror&&IsOption())
			width -= m_ColArray[i].Width;
		else
		    width += m_ColArray[i].Width;
		if (x >= width - 5 && x <= width + 5)
			return i;
	}

	return -1;
}

int TGridControl::FindColIndex(short x)
{
	if (!m_Plate)
		return -1;
	RECT cr;
	GetRect(cr);
	cr.right -= cr.left;
	if(m_bStrategyGraphy)
	    cr.right = (cr.right - OPTION_MIDDLE_WIDTH - VSCROLL_WIDTH- RCONTRACT_GRAPH_WIDTH) / 2;
	else
		cr.right = (cr.right - OPTION_MIDDLE_WIDTH - VSCROLL_WIDTH) / 2;

	int width(0);
	if (IsOption() && x >= cr.right + OPTION_MIDDLE_WIDTH)
		width += cr.right + OPTION_MIDDLE_WIDTH;
	else if(m_bColMirror&&IsOption())
		width = cr.right;
	for (int i = 0; i < (int)m_ColArrayCount; i++)
	{
		if (!m_ColArray[i].Visible)
			continue;
		if (m_bColMirror&&IsOption() && x <= cr.right)
		{
			if (x <= width && x > width - m_ColArray[i].Width)
				return i;
			width -= m_ColArray[i].Width;
		}
		else
		{
			if (IsOption() && x > cr.right&&x < cr.right + OPTION_MIDDLE_WIDTH)
				return -1;
			if (x >= width && x < width + m_ColArray[i].Width)
				return i;
			width += m_ColArray[i].Width;
		}
	}

	return -1;
}

void TGridControl::ClickGridNotice(const char* action, POINTS& pts)
{
	if (!m_Plate)
		return;
	int nHigth = m_bZCEUse ? RCONTRACT_HEIGHT : RCONTRACT_HEIGHT + RCONTRACT_STRATEGY;
	int r = (pts.y - HEAD_HEIGHT - (IsOption() ? nHigth : 0)) / ROW_HEIGHT;
	int c = FindColIndex(pts.x);
	POINT pt;
	POINTSTOPOINT(pt, pts);
	RECT target_r(m_Rects[TARGET]);
	if (IsOption() && PtInRect(&target_r, pt)&& m_OptionSeries)
	{
		SContract* contract = m_OptionSeries->TargetContract;

		if (NULL != contract)
		{
			char content[128];
			sprintf_s(content, "contractid=%s;field=%d;src=grid", contract->ContractNo, 0);
			PolestarQuoteLinkage(GetWindow()->GetHwnd(), action, content);
		}
	}
	else if (r >= 0 && r < (int)m_RowArrayCount && c >= 0 && c < (int)m_ColArrayCount)
	{
		TGridRow& row = m_RowArray[r];
		TPlateCol& col = m_ColArray[c];
		if (row.IsSpread)
		{
			char content[128];
			sprintf_s(content, "contractid=%s;field=%d;src=grid", row.SpreadRow.ContractNo, col.Field);
			PolestarQuoteLinkage(GetWindow()->GetHwnd(), action, content);
		}
		else
		{
			RECT cr;
			GetRect(cr);
			cr.right -= cr.left;
			int nWidth = 0;
			if (m_bStrategyGraphy)
				nWidth = VSCROLL_WIDTH + OPTION_MIDDLE_WIDTH + RCONTRACT_GRAPH_WIDTH;
			else
				nWidth = VSCROLL_WIDTH + OPTION_MIDDLE_WIDTH;
			bool sright = (IsOption() && pts.x > (cr.right - nWidth) / 2 + OPTION_MIDDLE_WIDTH);

			SContract* contract = sright ? row.Contract2 : row.Contract;

			if (NULL != contract)
			{
				char content[128];
				sprintf_s(content, "contractid=%s;field=%d;src=grid", contract->ContractNo, col.Field);
				PolestarQuoteLinkage(GetWindow()->GetHwnd(), action, content);
			}
		}
	}
}

void TGridControl::LinkageSetContract(const char* action, SContract* contract)
{
	char content[128];
	if (NULL == contract)
	{
		SContractNoType sno;
		if (GetSpreadNo(sno))
		{
			sprintf_s(content, "contractid=%s;field=126;src=grid", sno);
		}
		return;
	}
	else
	{
		sprintf_s(content, "contractid=%s;field=126;src=grid", contract->ContractNo);
	}
	PolestarQuoteLinkage(GetWindow()->GetHwnd(), action, content);
}
void TGridControl::LinkageQuickMacro(const char* action, WPARAM vk)
{
	char content[11];
	sprintf_s(content, "%u", vk);
	PolestarQuoteLinkage(GetWindow()->GetHwnd(), action, content);
}
SContract* TGridControl::GetTargetContract()
{
	if(!m_OptionSeries)
		return NULL;
	return m_OptionSeries->TargetContract;
}
SContract* TGridControl::GetSelectContract(SStrikePriceType price)
{
	if (NULL == m_Plate)
		return NULL;

	if (IsOption())
	{
		if (m_RowSelectIndex >= 0 && m_RowSelectIndex < m_Plate->GetRowScrollCount())
		{
			SOptionContractPair* pairs[1] = {NULL};
			G_StarApi->GetOptionContractPairData((NULL != m_OptionSeries ? m_OptionSeries->SeriesNo : NULL), m_RowSelectIndex, pairs, 1);
			if (price)
				strncpy_s(price, sizeof(SStrikePriceType), pairs[0]->StrikePrice, sizeof(SStrikePriceType));
			return m_RowSelectRight ? pairs[0]->Contract2 : pairs[0]->Contract1;
		}
	}
	else
	{
		if (m_RowSelectIndex >= 0 && m_RowSelectIndex < m_Plate->PlateRows.size())
		{
			if (!m_Plate->PlateRows[m_RowSelectIndex].IsSpread)
				return m_Plate->PlateRows[m_RowSelectIndex].Contract;
		}
	}

	return NULL;
}

bool TGridControl::GetSelectOptionPrice(double &Callprice, double &Putprice)
{
	if (NULL == m_Plate)
		return false;

	if (IsOption())
	{
		if (m_RowSelectIndex >= 0 && m_RowSelectIndex < m_Plate->GetRowScrollCount())
		{
			SOptionContractPair* pairs[1] = { NULL };
			G_StarApi->GetOptionContractPairData((NULL != m_OptionSeries ? m_OptionSeries->SeriesNo : NULL), m_RowSelectIndex, pairs, 1);
			if (pairs[0]->Contract1)
			{
				SQuoteSnapShot* q = pairs[0]->Contract1->SnapShot;
				if (q)
				{
					SQuoteField field = q->Data[S_FID_LASTPRICE];
					if (field.FidAttr != S_FIDTYPE_NONE)
					{
						Callprice = field.Price;
					}
					if( Callprice== 0.0)
					{
						field = q->Data[S_FID_PRESETTLEPRICE];
						if (field.FidAttr != S_FIDTYPE_NONE)
						{
							Callprice = field.Price;
						}
					}
				}
			}
			if (pairs[0]->Contract2)
			{
				SQuoteSnapShot* q = pairs[0]->Contract2->SnapShot;
				if (q)
				{
					SQuoteField field = q->Data[S_FID_LASTPRICE];
					if (field.FidAttr != S_FIDTYPE_NONE)
					{
						Putprice = field.Price;
					}
					if (Putprice == 0.0)
					{
						field = q->Data[S_FID_PRESETTLEPRICE];
						if (field.FidAttr != S_FIDTYPE_NONE)
						{
							Putprice = field.Price;
						}
					}
				}
			}
			return true;
		}
	}
	return false;
}

bool TGridControl::GetSpreadNo(SContractNoType& sno)
{
	if (IsOption()|| !m_Plate)
		return false;
	if (m_RowSelectIndex >= 0 && m_RowSelectIndex < m_Plate->PlateRows.size())
	{
		if (m_Plate->PlateRows[m_RowSelectIndex].IsSpread)
		{
			strcpy_s(sno, m_Plate->PlateRows[m_RowSelectIndex].ContractNo);
			return true;
		}
	}
	return false;
}
//1.�������ˢ�·�Ϊ�����仯�����ݱ仯
//2.�����仯����ȫ��ˢ�£����ݱ仯���в���ˢ�£���ʹ��ur������ÿ�ζ���ȫur���ͣ���ur == cr
//3.�����仯���� ʹ��ͬ���ػ棬�ȸ������ݻ��棨������������״̬����Ȼ��ǿ���ػ�
//4.���ݱ仯���� ʹ���첽�ػ棬�������ݻ��棬��֪ͨ��Ϣ�ػ�
//5.�����仯���б仯���б仯��ѡ�б仯���Ϸű仯����С�仯
//6.���ݱ仯���������ݱ仯
//7.���棺״̬���桢���ݻ���
//8.״̬���棺ѡ����Ϸ��������߳̿ؼ��࣬������
//9.���ݻ��棺�С��С����ݡ��Ƿ�仯��������������ģ����ݱ䶯����
//10.���ݻ����������ڣ��ؼ�����ʱ��������������ʱ֪ͨ���٣��������ڳ��ڿؼ�
//11.OnDrawȫ������false�������ڲ���ͼ
bool TGridControl::OnDraw(HDC hdc, HDC mdc, RECT& cr, RECT& ur, bool follow)
{
	//�����з�
	PrepareRects(cr);

	//����ϵͳ��������Ŀ�ˢ�£���Ҫ��������
	if (follow)
		Refresh_Data();

	//��ȡ��ͼ����
	Load_DrawData();

	//��������ɫ����Ȩ����ɫ
	Cal_Color();

	//����ɫ
	FillRect(mdc, &cr, BRUSH_FUTURE_BACKGROUND);

	RECT wr;
	GetRect(wr);

	//����ĺ�Լ��
	Draw_Target(hdc, wr, mdc, cr);

	//������
	Draw_Cols(hdc, wr, mdc, cr);

	//������
	Draw_Rows(hdc, wr, mdc, cr);

	//����Ȩ����
	if(IsOption())
	   m_OptStrategy.Draw_OptionStrategy(hdc, wr, mdc, cr);

	//��������
	m_ColChg = false;
	m_RowChg = false;
	return false;
}

void TGridControl::OnMouseMove(WORD btn, POINTS& pts)
{
	if (!m_Plate)
		return;
	switch (m_MouseMoveType)
	{
	case MOUSEMOVE_VSCROLL:
	{
		RECT cr;
		GetRect(cr);
		cr.bottom -= cr.top;

		POINT p;
		GetCursorPos(&p);
		int nHigth = m_bZCEUse ? RCONTRACT_HEIGHT : RCONTRACT_HEIGHT + RCONTRACT_STRATEGY;
		int movepos = (LONG)(1.0 * (p.y - m_VScrollBegin.y) * m_Plate->GetRowScrollCount() / (cr.bottom - HEAD_HEIGHT - (IsOption() ? nHigth : 0)));
		if (0 != movepos && m_RowBegin + movepos >= 0 && m_RowBegin + movepos <= (int)(m_Plate->GetRowScrollCount() - m_RowArrayCount))
		{
			m_RowBegin += movepos;

			m_VScrollBegin = p;
			Reload_Rows();
			Redraw(NULL);
		}
	}
	return;
	case MOUSEMOVE_WIDTH:
	{
		if (NULL == m_AdjustCol)
			return;

		if (CURSOR_WE != GetCursor())
			SetCursor(CURSOR_WE);

		RECT cr;
		GetRect(cr);
		cr.bottom -= cr.top;
		cr.right -= cr.left;

		POINT p;
		GetCursorPos(&p);

		int adjust = p.x - m_AdjustWidthBegin.x;
		if (m_bColMirror&&IsOption())
			adjust =  m_AdjustWidthBegin.x-p.x;
		if (0 != adjust && m_AdjustCol->Width + adjust >= MIN_COL_WIDTH && m_AdjustCol->Width + adjust <= MAX_COL_WIDTH)
		{
			m_AdjustWidthBegin = p;
			m_AdjustCol->Width += adjust;
			Reload_ColsAndRows();
			m_Plate->SaveCols();
			Redraw(NULL);
		}
	}
	return;
	default:
		break;
	}
	RECT item_r(m_Rects[STRATEGY_ITEM]);
	RECT graph_r(m_Rects[TACTIC_GRAPH]);
	POINT pt;
	POINTSTOPOINT(pt, pts);
	int nHigth = m_bZCEUse ? RCONTRACT_HEIGHT : RCONTRACT_HEIGHT + RCONTRACT_STRATEGY;
	long top_height = IsOption() ? nHigth : 0;
	if (pts.y >= top_height && pts.y < top_height + HEAD_HEIGHT && FindColEdge(pts.x) >= 0)
	{
		if (CURSOR_WE != GetCursor())
			SetCursor(CURSOR_WE);
	}
	else if (IsOption() && (PtInRect(&item_r, pt) || PtInRect(&graph_r, pt)))//����ѡ������
	{
		m_OptStrategy.OnMouseMove(pt);
		m_bOutFresh = true;
		Redraw(NULL);
		TrackMouseLeave();
	}
	if (IsOption() && !PtInRect(&graph_r, pt))
	{
		m_OptStrategy.OnMouseLeave();
		if (m_bOutFresh&&!PtInRect(&item_r, pt))
		{
			Redraw(NULL);
			m_bOutFresh = false;
		}
	}
}
bool TGridControl::IsDomesticExchange(SExchangeNoType	exchangeNo)
{
	if (strcmp(exchangeNo, "ZCE") == 0 || strcmp(exchangeNo, "DCE") == 0 || strcmp(exchangeNo, "SHFE") == 0 || strcmp(exchangeNo, "INE") == 0 || strcmp(exchangeNo, "CFFEX") == 0)
		return true;
	return false;
}
int TGridControl::GetAllOptionExchange(SExchange* out[], int len)
{
	//�Ƚ�����������
	std::set<std::string> exchanges;
	const char* exc_arry[] = {
		"ZCE", "DCE", "SHFE", "CFFEX", "SSE", "SZSE", "ESUNNY", "SGE",
		"CBOT", "CME", "COMEX", "NYMEX",
		"ICUS", "ICEU", "HKEX", "LME",
		"EUREX", "SGX", "TOCOM"
	};
	int count = 0;
	for (int i = 0; i < sizeof(exc_arry) / sizeof(char*); i++)
	{
		SExchange* e;
		if (G_StarApi->GetOptionExchangeData(exc_arry[i], &e, 1, false) <= 0)
			continue;
		exchanges.insert(exc_arry[i]);
		out[count] = e;
		count++;
	}
	//���Զ�������
	SExchange* array[128];
	int cnt = G_StarApi->GetOptionExchangeData(NULL, array, sizeof(array) / sizeof(SExchange*), true);
	for (int i = 0; i < cnt; i++)
	{
		SExchange* e = array[i];
		if (exchanges.end() == exchanges.find(e->ExchangeNo))
		{
			out[count] = e;
			count++;
		}
	}
	return count;
}
int TGridControl::GetAllOptionCommidity(SCommodity* out[], int len)
{
	//��ȡ֣����Ʒ��
	int cntzce = G_StarApi->GetOptionCommodityData("ZCE", NULL, &out[0], len, true);
	int cntdce = G_StarApi->GetOptionCommodityData("DCE", NULL, &out[cntzce], len, true);
	int cntshfe = G_StarApi->GetOptionCommodityData("SHFE", NULL, &out[cntzce+ cntdce], len, true);
	int cntcffex = G_StarApi->GetOptionCommodityData("CFFEX", NULL, &out[cntzce + cntdce+ cntshfe], len, true);
	int nCount = cntzce + cntdce + cntshfe + cntcffex;
	SExchange* excArray[128];
	int count = G_StarApi->GetOptionExchangeData(NULL, excArray, sizeof(excArray) / sizeof(SExchange*), true);
	for (int i = 0; i < count; i++)
	{
		if (nCount >= len)
			break;
		SExchange* eno = excArray[i];
		if (strcmp(eno->ExchangeNo, "ZCE")!= 0 &&strcmp(eno->ExchangeNo, "DCE") != 0 && strcmp(eno->ExchangeNo, "SHFE") != 0 && strcmp(eno->ExchangeNo, "CFFEX") != 0)
		{
			SCommodity* array[1024];
			int cnt = G_StarApi->GetOptionCommodityData(eno->ExchangeNo, NULL, array, sizeof(array) / sizeof(SCommodity*), true);
			for (int j = 0; j < cnt; j++)
			{
				out[nCount] = array[j];
				nCount++;
			}
		}
	}
	return nCount;
}
void TGridControl::OnLButtonDown(WORD btn, POINTS& pts)
{
	if (!m_Plate)
		return;
	ClickGridNotice("LButtonDown", pts);
	SetFocus();
	((TQuoteFrame*)GetWindow())->CancalSelectField();
	m_OptStrategy.FreeListFocused();
	RECT cr(m_Rects[GRID_CONTENT]);
	RECT item_r(m_Rects[STRATEGY_ITEM]);
	RECT graph_r(m_Rects[TACTIC_GRAPH]);
	RECT target_r(m_Rects[TARGET]);
	POINT pt;
	POINTSTOPOINT(pt, pts);
	int nHigth = m_bZCEUse ? RCONTRACT_HEIGHT : RCONTRACT_HEIGHT + RCONTRACT_STRATEGY;
	LONG top_height = IsOption() ? HEAD_HEIGHT + nHigth : HEAD_HEIGHT;

	RECT sr;

	RECT relaterect = { 0, 0, 0, 0 };
	RECT exchange_r(m_Rects[TARGET_SERIES]);
	RECT commidity_r(m_Rects[TARGET_COMMIDITY]);
	RECT contract_r(m_Rects[TARGET_CONTRACT]);
	if (IsOption())
	{
		relaterect.left = RCONTRACT_NAME_WIDTH;
		relaterect.right = relaterect.left + RCONTRACT_TARGET_NAME_WIDTH;
		relaterect.bottom = RCONTRACT_HEIGHT / 2;
		target_r.top = target_r.top + (target_r.bottom - target_r.top) / 2;
		target_r.left = exchange_r.right;
		commidity_r.top = target_r.top;
		contract_r.top = target_r.top;
		exchange_r.bottom = RCONTRACT_HEIGHT / 2;
	}
	if (IsOption() && PtInRect(&exchange_r, pt))
	{
		TDuiPopMenuWindow pop;
		TDuiPopMenuItem item;
		memset(&item, 0, sizeof(TDuiPopMenuItem));
		SExchange* array[128];
		int cnt = GetAllOptionExchange(array, sizeof(array) / sizeof(SExchange*));
		for (int i = 0; i < cnt; i++)
		{
			SExchange* e = array[i];
			if (!e)
				continue;
			item.Index = 250 + i;
			item.IsChecked = (e == m_OptionSeries->Commodity->Exchange);
			wchar_t strText[51];
			MByteToWChar(e->ExchangeName, strText, sizeof(strText) / sizeof(wchar_t));
			wcsncpy_s(item.Text, strText, sizeof(item.Text) / sizeof(wchar_t) - 1);
			item.Value = (void*)e;

			pop.AddItem(item);
		}
		pop.SetSpi(this);

		RECT wr;
		GetWindow()->GetRect(wr);
		pop.SetWidth(exchange_r.right - exchange_r.left);
		pop.ShowPop(wr.left + exchange_r.left, wr.top + exchange_r.bottom, false, NULL);
	}
	else if (IsOption() && PtInRect(&commidity_r, pt))
	{
		TDuiPopMenuWindow pop;
		TDuiPopMenuItem item;
		memset(&item, 0, sizeof(TDuiPopMenuItem));
		SCommodity* array[1024];
		int cnt = G_StarApi->GetOptionCommodityData(m_OptionSeries->Commodity->Exchange->ExchangeNo, NULL, array, sizeof(array) / sizeof(SCommodity*), true);
		for (int i = 0; i < cnt; i++)
		{
			SCommodity* c = array[i];
			if (!c)
				continue;
			item.Index = 300 + i;
			item.IsChecked = (c == m_OptionSeries->Commodity);
			wchar_t strText[51];
			MByteToWChar(c->CommodityName, strText, sizeof(strText) / sizeof(wchar_t));
			wcsncpy_s(item.Text, strText, sizeof(item.Text) / sizeof(wchar_t) - 1);
			item.Value = (void*)c;

			pop.AddItem(item);
		}
		pop.SetSpi(this);

		RECT wr;
		GetWindow()->GetRect(wr);
		pop.SetWidth(commidity_r.right - commidity_r.left);
		pop.ShowPop(wr.left + commidity_r.left, wr.top + commidity_r.bottom, false, NULL);
	}
	else if (IsOption() && PtInRect(&contract_r, pt))
	{
		TDuiPopMenuWindow pop;
		TDuiPopMenuItem item;
		memset(&item, 0, sizeof(TDuiPopMenuItem));
		SContractNoType begin;
		begin[0] = '\0';
		SOptionSeries* array[1024];

		while (true)
		{
			int cnt = G_StarApi->GetOptionSeriesData(m_OptionSeries->Commodity->CommodityNo, begin, array, sizeof(array) / sizeof(SContract*), true);

			for (int i = 0; i < cnt; i++)
			{
				SOptionSeries* c = array[i];
				item.Index = 350 + i;
				item.IsChecked = (c == m_OptionSeries);
				SeriesNo2Date(c->SeriesNo, item.Text,sizeof(item.Text)/sizeof(wchar_t));
				item.Value = (void*)c;

				pop.AddItem(item);
			}

			if (cnt < sizeof(array) / sizeof(SContract*))
				break;
			strcpy_s(begin, array[cnt - 1]->SeriesNo);
		}
		pop.SetSpi(this);

		RECT wr;
		GetWindow()->GetRect(wr);
		pop.SetWidth(contract_r.right - contract_r.left);
		pop.ShowPop(wr.left + contract_r.left, wr.top + contract_r.bottom, false, NULL);
	}
	else if (IsOption() && (PtInRect(&item_r,pt)|| PtInRect(&graph_r, pt)))//����ѡ������
	{
		m_OptStrategy.OnLButtonDown(pt);
		Redraw(NULL);
	}
	else if (pts.x >= cr.left && pts.x < cr.right - VSCROLL_WIDTH && pts.y >= top_height && pts.y < cr.bottom)			//����ѡ����
	{
		size_t sindex = (pts.y - top_height) / ROW_HEIGHT + m_RowBegin;
		bool sright = (IsOption() && pts.x > (cr.right - VSCROLL_WIDTH - OPTION_MIDDLE_WIDTH) / 2 + OPTION_MIDDLE_WIDTH);
		bool isMiddle = !sright && (IsOption() && pts.x > (cr.right - VSCROLL_WIDTH - OPTION_MIDDLE_WIDTH) / 2);
		if (m_bZCEUse&&NULL != m_Plate && sindex >= (size_t)m_Plate->GetRowScrollCount())
		{
			m_RowSelectIndex = -1;
			Refresh_Data();
			Redraw(NULL);
		}
		if (NULL != m_Plate && sindex < (size_t)m_Plate->GetRowScrollCount() && !isMiddle)
		{
			m_RowSelectIndex = sindex;
			m_RowSelectRight = sright;
			if (IsOption())
			{
				SStrikePriceType price = "";
				SContract* pCon = GetSelectContract(price);
				if(pCon)
				    m_OptStrategy.SetOptionContract(pCon, price);
			}
			Refresh_Data();
			((TQuoteFrame*)GetWindow())->SetPanelContract();
			Redraw(NULL);
		}
		else if (NULL != m_Plate && sindex < (size_t)m_Plate->GetRowScrollCount() && isMiddle)
		{
			m_OptStrategy.HitStrikeRect(sindex, pt);
			Redraw(NULL);
		}
		return;
	}
	else if (pts.y >= top_height - HEAD_HEIGHT && pts.y < top_height && NULL != m_Plate)													//�����п�
	{
		m_AdjustCol = NULL;
		int cindex = FindColEdge(pts.x);
		if (cindex >= 0)
		{
			for (short i = 0; i < m_Plate->PlateColCount; i++)
			{
				TPlateCol& pc = m_Plate->PlateCols[i];
				if (pc.Field == m_ColArray[cindex].Field)
				{
					m_AdjustCol = &pc;
					break;
				}
			}

			if (NULL != m_AdjustCol)
			{
				CatchMouse();
				GetCursorPos(&m_AdjustWidthBegin);
				m_MouseMoveType = MOUSEMOVE_WIDTH;
			}
		}
		return;

	}
	else if (GetScrollRect(sr) && pts.x >= sr.left && pts.x < sr.right && pts.y >= sr.top && pts.y < sr.bottom)
	{
		CatchMouse();
		GetCursorPos(&m_VScrollBegin);
		m_MouseMoveType = MOUSEMOVE_VSCROLL;
		return;
	}
}

void TGridControl::OnLButtonUp(WORD btn, POINTS& pts)
{
	m_MouseMoveType = MOUSEMOVE_NONE;
	m_AdjustCol = NULL;
	m_OptStrategy.OnLButtonUp(pts);
	if (HasMouse())
		ReleaseMouse();
}
void TGridControl::OnMouseLeave()
{
	m_OptStrategy.OnMouseLeave();
	Redraw(NULL);
}
void TGridControl::OnLButtonDbClk(WORD btn, POINTS& pts)
{
	SetFocus();

	/*if (IsOption())
		return;
*/
	RECT cr(m_Rects[GRID_CONTENT]);
	RECT target_r(m_Rects[TARGET_OTHERS]);
	int nHigth = m_bZCEUse ? RCONTRACT_HEIGHT : RCONTRACT_HEIGHT + RCONTRACT_STRATEGY;
	LONG top_height = IsOption() ? HEAD_HEIGHT + nHigth : HEAD_HEIGHT;
	POINT pt;
	POINTSTOPOINT(pt, pts);
	target_r.top = target_r.top + (target_r.bottom - target_r.top) / 2;
	if (IsOption() && PtInRect(&target_r, pt))//����ѡ������
	{
		if (m_bEnterTLine)
			((TQuoteFrame*)GetWindow())->SwitchToTargetTLine();
		else
		    ((TQuoteFrame*)GetWindow())->SwitchToTargetKLine();
		m_OptStrategy.DelALLRectTool();
		return;
	}
	else if (pts.x >= cr.left && pts.x < cr.right - VSCROLL_WIDTH && pts.y >= top_height && pts.y < cr.bottom)			//����ѡ����
	{
		size_t sindex = (pts.y - top_height) / ROW_HEIGHT + m_RowBegin;
		int c = FindColIndex(pts.x);
		if (NULL != m_Plate && sindex < (size_t)m_Plate->GetRowScrollCount() && c >= 0 && c < (int)m_ColArrayCount)
		{
			TPlateCol& col = m_ColArray[c];
			if (IsOption() || col.Field == S_FID_CODE || col.Field == S_FID_NAME)
			{
				if(m_bEnterTLine)
					((TQuoteFrame*)GetWindow())->SwitchToTLine();
				else
				    ((TQuoteFrame*)GetWindow())->SwitchToKLine();
				m_OptStrategy.DelALLRectTool();
				return;
			}
		}
		
	}
	ClickGridNotice("LButtonDbClk", pts);
}
void TGridControl::OnKeyDown(WPARAM vk, LPARAM lParam)
{
	switch (vk)
	{
	case VK_UP:
		if (SelectUp())
		{
			Redraw(NULL);
			((TQuoteFrame*)GetWindow())->SetPanelContract();
			LinkageSetContract("VK_UP", GetSelectContract());
		}

		break;
	case VK_DOWN:
		if (SelectDown())
		{
			Redraw(NULL);
			((TQuoteFrame*)GetWindow())->SetPanelContract();
			LinkageSetContract("VK_DOWN", GetSelectContract());
		}
		break;
	case VK_PRIOR:			//pageup
		if (NULL != m_Plate && m_RowBegin > 0)
		{
			RECT cr;
			GetRect(cr);
			cr.right -= cr.left;
			cr.bottom -= cr.top;
			int nHigth = m_bZCEUse ? RCONTRACT_HEIGHT : RCONTRACT_HEIGHT + RCONTRACT_STRATEGY;
			size_t page = (cr.bottom - HEAD_HEIGHT - (IsOption() ? nHigth : 0)) / ROW_HEIGHT;
			m_RowBegin -= page;
			if (m_RowBegin < 0)
				m_RowBegin = 0;

			Reload_Rows();

			Redraw(NULL);
			return;
		}
		break;
	case VK_NEXT:			//pagedown
		if (NULL != m_Plate && m_RowBegin + m_RowArrayCount < (size_t)m_Plate->GetRowScrollCount())
		{
			RECT cr;
			GetRect(cr);
			cr.right -= cr.left;
			cr.bottom -= cr.top;
			int nHigth = m_bZCEUse ? RCONTRACT_HEIGHT : RCONTRACT_HEIGHT + RCONTRACT_STRATEGY;
			size_t page = (cr.bottom - HEAD_HEIGHT - (IsOption() ? nHigth : 0)) / ROW_HEIGHT;
			m_RowBegin += page;
			if (m_RowBegin >= (int)(m_Plate->GetRowScrollCount() - page))
				m_RowBegin = m_Plate->GetRowScrollCount() - page;

			Reload_Rows();

			Redraw(NULL);
			return;
		}
		break;
	case VK_LEFT:
		((TQuoteFrame*)GetWindow())->FutureScrollLeft();
		break;
	case VK_RIGHT:
		((TQuoteFrame*)GetWindow())->FutureScrollRight();
		break;
	case VK_ESCAPE:			//esc
		break;
	case VK_RETURN:			//enter
		/*if (IsOption())
			return;*/
		((TQuoteFrame*)GetWindow())->SwitchToTLine();
		break;
	case VK_F3:
		((TQuoteFrame*)GetWindow())->KeyF3();
		break;
	case VK_F4:
		((TQuoteFrame*)GetWindow())->KeyF4();
		break;
	case VK_F5:
		break;
	case VK_F6:
		((TQuoteFrame*)GetWindow())->KeyF6();
		break;
	case VK_F8:
		((TQuoteFrame*)GetWindow())->SwitchToKLine();
		break;
	default:
	{
		if (G_CommonApi && !G_CommonApi->GetFastOrderWorkState())
			LinkageQuickMacro("OnKeyDown", vk);
		break;
	}
	}
}

void TGridControl::OnMouseWheel(short rot, WORD btn, POINTS& pts)
{
	if (0 == rot)
		return;
	if (!m_Plate)
		return;
	if (rot > 0)
		rot = max(rot, WHEEL_DELTA);
	else
		rot = min(rot, -1 * WHEEL_DELTA);

	int done = -1 * (int)ceil(rot / WHEEL_DELTA);
	if (m_OptStrategy.OnMouseWheel(done))
		return;
	RECT sr;
	if (!GetScrollRect(sr))
		return;

	if (done + m_RowBegin >= 0 && done + m_RowBegin <= m_Plate->GetRowScrollCount() - (int)m_RowArrayCount)
	{
		m_RowBegin += done;
		Reload_Rows();
		Redraw(NULL);
	}
}

void TGridControl::OnPopMenuClick(TDuiPopMenuItem* obj)
{
    if (obj->Index >= 200&& obj->Index < 250) // ��Ȩ����
	{
		Tactic* tac = (Tactic*)obj->Value;
		m_OptStrategy.SetTacticType(*tac);
		Redraw(NULL);
	}
	else if (obj->Index >= 250 && obj->Index < 300) // ��Ȩ������
	{
		SExchange* e = (SExchange*)obj->Value;
		SCommodity* c_arr[1024];
		int c_arrCount = G_StarApi->GetOptionCommodityData(e->ExchangeNo, NULL, c_arr, sizeof(c_arr) / sizeof(SCommodity*), true);
		for (int j = 0; j < c_arrCount; j++)
		{
			SOptionSeries* pSeri = NULL;
			G_StarApi->GetOptionSeriesData(c_arr[j]->CommodityNo, NULL, &pSeri, 1, false);
			if (pSeri)
			{
				m_Plate->OptionSeries = pSeri;
				m_Plate->SaveOptionTarget();
				SetRowBegin(0);
				SetSelectRow(0);
				Refresh_Data();
				Reload_Rows();
				((TQuoteFrame*)GetWindow())->SetPanelContract();
				Redraw(NULL);
				break;
			}
		}
	}
	else if (obj->Index >= 300 && obj->Index < 350) // ��ȨƷ��
	{
		SCommodity* c = (SCommodity*)obj->Value;
		if (c)
		{
			SOptionSeries* pSeri = NULL;
			G_StarApi->GetOptionSeriesData(c->CommodityNo, NULL, &pSeri, 1, false);
			if (pSeri)
			{
				m_Plate->OptionSeries = pSeri;
				m_Plate->SaveOptionTarget();
				SetRowBegin(0);
				SetSelectRow(0);
				Refresh_Data();
				Reload_Rows();
				((TQuoteFrame*)GetWindow())->SetPanelContract();
				Redraw(NULL);
			}
		}
	}
	else if (obj->Index >= 350 && obj->Index < 400) // ��Ȩ��Լ
	{
		SOptionSeries* pSeri = (SOptionSeries*)obj->Value;
		if (pSeri)
		{
			m_Plate->OptionSeries = pSeri;
			m_Plate->SaveOptionTarget();
			SetRowBegin(0);
			SetSelectRow(0);
			Refresh_Data();
			Reload_Rows();
			((TQuoteFrame*)GetWindow())->SetPanelContract();
			Redraw(NULL);
		}
	}
	else if (obj->Index >= 31 && obj->Index <= 35)
	{
		((TQuoteFrame*)GetWindow())->OpenClosePanel(obj->Index);
	}
	else
	{
		switch (obj->Index)
		{
		case 0:
		{
			SContract* selcont(GetSelectContract());
			TPlatePage* p = (TPlatePage*)obj->Value;
			if (!p)
				break;
			bool can(true);
			for (size_t i = 0; i < p->PlateRows.size(); i++)
			{
				TPlateRow& r = p->PlateRows[i];
				if (r.Contract == selcont)
				{
					can = false;
					break;
				}
			}
			if (can)
			{
				TPlateRow row;
				memset(&row, 0, sizeof(TPlateRow));
				row.Contract = selcont;
				row.RowIndex = p->PlateRows.size();
				row.IsSpread = false;
				p->PlateRows.push_back(row);
				p->SaveRows();
			}
		}
		break;
		case 1:
			((TQuoteFrame*)GetWindow())->SwitchToTLine();
			break;
		case 2:
			((TQuoteFrame*)GetWindow())->SwitchToKLine();
			break;
		case 4:
			((TQuoteFrame*)GetWindow())->SelectContract();
			break;
		case 41:
			DelSelectedContract();
			break;
		case 5:
			m_bStrategyGraphy = !m_bStrategyGraphy;
			Reload_ColsAndRows();
			Redraw(NULL);
			((TQuoteFrame*)GetWindow())->SaveCfg();
			break;
		case 51:
			OpenOptioncalu();
			break;
		case 52:
			JumpToAtTheMoney();
			break;
		case 6:
			((TQuoteFrame*)GetWindow())->ConfigColumn();
			break;
		case 7:
			AutoAdjustWidth();
			break;
		case 8:
			AskOptionPrice();
			break;
		case 9:
			G_MainFrame->SwitchTitleBarShow();
			break;
		case 10:
			((TQuoteFrame*)GetWindow())->PriceAlertLinkage();
			break;
		default:
			break;
		}

	}

	SetFocus();
}

void TGridControl::OnRButtonDown(WORD btn, POINTS& pts)
{
	TDuiPopMenuWindow pop;

	TDuiPopMenuItem item;
	memset(&item, 0, sizeof(TDuiPopMenuItem));

	//ѯ��
	if (IsOption())
	{
		item.Index = 8;
		item.Begin = false;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_ASKPRICE), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddItem(item);
	}

	//������ѡ
	if (NULL != m_Plate && !m_Plate->IsSelf && NULL != GetSelectContract())
	{
		item.Index = 0;
		item.Begin = true;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_ADD_SELF_Plate), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddItem(item);
		for (TPlatePageVectorType::iterator iter = G_QuoteUtils.PlatePages.begin(); iter != G_QuoteUtils.PlatePages.end(); iter++)
		{
			TPlatePage* p = *iter;
			if (p->ChildPages.empty())
			{
				if (p->IsSelf)
				{
					//wcsncpy_s(item.Text, G_LANG->LangText(TLI_ADD_SELF), sizeof(item.Text) / sizeof(wchar_t) - 1);
					wcsncpy_s(item.Text, p->PlateName, sizeof(item.Text) / sizeof(wchar_t) - 1 - wcslen(item.Text));
					item.Value = p;
					pop.AddSubItem(item);
					item.Begin = false;
				}
			}
			else
			{
				for (TPlatePageVectorType::iterator citer = p->ChildPages.begin(); citer != p->ChildPages.end(); citer++)
				{
					TPlatePage* pp = *citer;
					if (pp->IsSelf)
					{
						//wcsncpy_s(item.Text, G_LANG->LangText(TLI_ADD_SELF), sizeof(item.Text) / sizeof(wchar_t) - 1);
						wcsncpy_s(item.Text, pp->PlateName, sizeof(item.Text) / sizeof(wchar_t) - 1 - wcslen(item.Text));
						item.Value = pp;
						pop.AddSubItem(item);
						item.Begin = false;
					}
				}
			}
		}
		item.Begin = false;
	}

	//�۸�Ԥ��
	item.Index = 10;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_PRICE_ALERT), sizeof(item.Text) / sizeof(wchar_t) - 1);
	pop.AddItem(item);

	//�л�ͼ��
	if (NULL != m_Plate && !m_Plate->IsOption)
	{
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_ENTERANALYSISCHART), sizeof(item.Text) / sizeof(wchar_t) - 1);
		item.Index = -1;
		pop.AddItem(item);

		item.Index = 1;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_SWITCH_TLINE), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddSubItem(item);
		item.Index = 2;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_SWITCH_KLINE), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddSubItem(item);
	}

	//�����̿�
	item.Index = 3;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_OPEN_PANEL), sizeof(item.Text) / sizeof(wchar_t) - 1);
	pop.AddItem(item);
	item.Index = 31;
    wcsncpy_s(item.Text, G_LANG->LangText(TLI_CLOSE_PANEL), sizeof(item.Text) / sizeof(wchar_t) - 1);
	item.IsChecked = !((TQuoteFrame*)GetWindow())->IsPanelVisible();
	pop.AddSubItem(item);
	item.Index = 32;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_PANEL_QUOTE1), sizeof(item.Text) / sizeof(wchar_t) - 1);
	item.IsChecked = ((TQuoteFrame*)GetWindow())->GetPanelLevel() == PANEL_LEVEL_ONE;
	pop.AddSubItem(item);
	item.Index = 33;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_PANEL_QUOTE5), sizeof(item.Text) / sizeof(wchar_t) - 1);
	item.IsChecked = ((TQuoteFrame*)GetWindow())->GetPanelLevel() == PANEL_LEVEL_FIVE;
	pop.AddSubItem(item);
	item.Index = 34;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_PANEL_QUOTE10), sizeof(item.Text) / sizeof(wchar_t) - 1);
	item.IsChecked = ((TQuoteFrame*)GetWindow())->GetPanelLevel() == PANEL_LEVEL_TEN;
	pop.AddSubItem(item);
	item.Index = 35;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_SMALLPANEL), sizeof(item.Text) / sizeof(wchar_t) - 1);
	item.IsChecked = ((TQuoteFrame*)GetWindow())->IsPanelSmall();
	pop.AddSubItem(item);


	item.Begin = true;
	item.IsChecked = false;

	//ѡ���Լ ɾ����Լ
	if (NULL != m_Plate && m_Plate->IsSelf)
	{
		item.Index = 4;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_SELECT_CONTRACT), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddItem(item);
		item.Begin = false;

		item.Index = 41;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_DELETE_CONTRACT), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddItem(item);
		item.Begin = false;

		/*item.Index = 42;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_LOCAL_SPREAD), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddItem(item);
		item.Begin = false;*/
	}

	//ѡ����Ȩ
	if (IsOption())
	{
		item.Begin = false;
		item.Index = 5;
		if(m_bStrategyGraphy)
		    wcsncpy_s(item.Text, G_LANG->LangText(TLI_ClOSESTRATEGYGRAPHY), sizeof(item.Text) / sizeof(wchar_t) - 1);
		else
		    wcsncpy_s(item.Text, G_LANG->LangText(TLI_OPENSTRATEGYGRAPHY), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddItem(item);
	   
		item.Begin = true;
		item.Index = 51;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_OPTIONCALCULATOR), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddItem(item);
		item.Begin = false;
		item.Index = 52;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_JUMP_ATTHEMONEY), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddItem(item);
	}

	//������ͷ
	item.Index = 6;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_CONFIG_COLUMN), sizeof(item.Text) / sizeof(wchar_t) - 1);
	pop.AddItem(item);

	//����Ӧ�п�
	item.Index = 7;
	item.Begin = true;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_AUTO_ADJUST_COL_WIDTH), sizeof(item.Text) / sizeof(wchar_t) - 1);
	pop.AddItem(item);

	//ȫ��/�ָ�
	if (IsShowFullScreenMenu())
	{
		item.Index = 9;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_FULLSCREENREATORE), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddItem(item);
	}

	pop.SetSpi(this);

	POINT p;
	GetCursorPos(&p);
	pop.SetWidth(180);
	pop.ShowPop(p.x, p.y, true, GetWindow()->GetHwnd());
}
bool TGridControl::IsShowFullScreenMenu()
{
	HWND Hwnd = ((TQuoteFrame*)GetWindow())->GetHwnd();
	while (::GetParent(Hwnd))
		Hwnd = ::GetParent(Hwnd);
	wchar_t name[MAX_PATH];
	GetClassName(Hwnd, name, sizeof(name));
	if (wcscmp(L"class TMainFrame", name) == 0)
		return true;
	return false;
}
#pragma once
class TKLineChart
{
public:
	TKLineChart();
	~TKLineChart();
public:
	bool						Visible;					//�Ƿ���ʾ		��һ��ͼ�α�����ʾ
	int							Height;						//ͼ�θ߶�		����������ͼ��ʱ�����ձ������µ����߶�
	RECT						LeftRect;					//�����������
	RECT						RightRect;					//�ұ���������
	RECT						CenterRect;					//�����ͼ����
	RECT						CenterTopRect;				//��������
	RECT						CenterSpecRect;				//ͼ��ָ���ǩ����
	RECT						CenterChartRect;			//ͼ������
	RECT						CenterBottomRect;			//�ײ�����
	TKLineAxisY					LeftAxisY;					//���Y��
	TKLineAxisY					RightAxisY;					//�Ҳ�Y��
	TKChartSpec                 KChartSpec[2];               //ͼ��������ָ����Ϣ
	KLINE_STYLE                 Style;                    //��ͼ����
public:
	void                        SetKLineCtl(TKLineControl* pCtl) { m_pKLineCtl = pCtl; }
	double                      YAxis_Pix2Price(int pix);
	int                         YAxis_Price2Pix(double value);
	void                        CalcAllIndicators(bool bMain,bool bTLine);
	void	                    CalcIndicatorIndex(int nIndex);
	void                        RecalcAxisY(bool bMain,bool bTLine);
	void                        DrawChart(HDC mdc, bool bMain,bool bTLine);
	void                        DrawLegend(HDC mdc);
	//===============================================================================================================================
	//ָ����ƺ���
	//===============================================================================================================================
	//��ͼ
	void KLine_CalcIndi(int index);
	void TLine_CalcIndi(int index);
	void Tick_CalcIndi(int index);
	void Spread_CalcIndi(int index);
	void SubContract_CalcIndi(int index);
	void SubContract_DrawChart(HDC mdc, int index);

	void MA_CalcIndi(int index);

	void SAR_CalcIndi(int index);

	void EMA_CalcIndi(int index);

	void BOLL_CalcIndi(int index);

	void BBI_CalcIndi(int index);
	//��ͼ
	void VOL_CalcIndi(int index);

	void MACD_CalcIndi(int index);

	void KDJ_CalcIndi(int index);

	void RSI_CalcIndi(int index);

	void WR_CalcIndi(int index);

	void BIAS_CalcIndi(int index);
	
	void DMI_CalcIndi(int index);

	void OBV_CalcIndi(int index);

	void TRIX_CalcIndi(int index);

	void CR_CalcIndi(int index);

	void MTM_CalcIndi(int index);

	void PSY_CalcIndi(int index);

	void CCI_CalcIndi(int index);

	void VR_CalcIndi(int index);

	//��Ȩ
	void TP_CalcIndi(int index);
	void IV_CalcIndi(int index);
	void Delta_CalcIndi(int index);
	void Gamma_CalcIndi(int index);
	void Vega_CalcIndi(int index);
	void Theta_CalcIndi(int index);
	void Rho_CalcIndi(int index);
	//ָ�꺯��
	double SPEC_HIGH(int curr);
	double SPEC_LOW(int curr);
	double SPEC_CLOSE(int curr);
	double SPEC_SettlePrice(int curr);
	long long SPEC_VOL(int curr);
	double SPEC_Lowest(double input[],int curr, int n);
	double SPEC_Highest(double input[],int curr, int n);
	double SPEC_MA(double input[], int curr, int n);
	double   SPEC_SMA(double input[], int curr, int n, int m);
	double   SPEC_EMA(double input[], int curr, int n);
	double SPCE_VariancePS(double input[], int curr, int n);
	double SPCE_STD(double input[], int curr, int n);
	bool   SPEC_SAR(double afStep, double AfLimit);
	double SPEC_SUM(double input[], int curr, int n);
	int    SPEC_COUNT(bool Condition[], int curr, int n);
	double SPEC_MAX(double v1, double v2);
	double SPEC_IIF(bool con, double trueValue, double falseValue);
	double SPEC_REF(double input[], int curr, int n);
	double SPEC_AVEDEV(double input[], int curr, int n);
private:
	enum TagLineType
	{
		LineType_VOL = 0,
		LineType_Data,
	    LineType_ZERO,
	};
	enum  TCHART_TYPE
	{
		TLINE_TYPE = 0,
		TICK_TYPE,
		KLINE_TYPE,
	};
	void   GetParamText(wchar_t *ptext, int nLegth, TKChartSpec& pSpace);
	void   AddSeries(TKChartSpec& spec,TChartSeries* pSeries, int penid, wchar_t* name,int nPre,bool bPow,bool bLeftAxisY);
	void   CalLeftAxisYMaxMinValue(double Data[MAX_SHOW_KLINE_X],bool rCal,bool bPow);
	void   CalRightAxisYMaxMinValue(double Data[MAX_SHOW_KLINE_X]);
	void   CalSubTagLine(TagLineType type, int nPre = 2);
private:
	
	TKLineControl*                    m_pKLineCtl;
	double						      m_Cache[7][MAX_SHOW_KLINE_X];				//���ݻ���	
};


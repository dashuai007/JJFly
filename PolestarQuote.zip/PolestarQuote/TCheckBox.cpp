#include "PreInclude.h"



TCheckBox::TCheckBox()
{
	m_colorBK = RGB(255, 255, 255);
	m_color = RGB(0, 0, 0);
	m_strText[0] = '/0';
	m_bChecked = false;
	m_bInRect = false;
}


TCheckBox::~TCheckBox()
{
}

LRESULT TCheckBox::WndProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_PAINT:
		OnPaint();
		break;
	case WM_LBUTTONDOWN:
		m_bInRect = true;
		break;
	case WM_LBUTTONDBLCLK:
		m_bInRect = false;
		{
			long x = LOWORD(lParam);
			long y = HIWORD(lParam);
			RECT rect;
			GetClientRect(m_Hwnd, &rect);
			if (x >= rect.left&&x <= rect.right&&y >= rect.top&&y <= rect.bottom)
				SetCheck(GetCheck()? false : true);
		}
		break;
	case WM_LBUTTONUP:
		if (m_bInRect)
		{
			long x = LOWORD(lParam);
			long y = HIWORD(lParam);
			RECT rect;
			GetClientRect(m_Hwnd, &rect);
			if (x >= rect.left&&x <= rect.right&&y >= rect.top&&y <= rect.bottom)
				SetCheck(GetCheck() ? false : true);
		}
		break;
	default:
		return NOT_PROCESSED;
    }
    return PROCESSED;
}
void TCheckBox::SetCheck(bool check)
{
	m_bChecked = check;
	PostMessage(GetParent(), SSWM_CHECKBOX_CHECK_CHANAGE, m_nindex, (LPARAM)m_Hwnd);
	InvalidateRect(GetHwnd(), NULL, TRUE);
}
bool TCheckBox::Create(HWND hwnd, int nindex)
{
	m_nindex = nindex;
	CreateFrm(_T("TCheckBox"), hwnd, WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN);
	return true;
}
void TCheckBox::MoveWindow(const int& x, const int& y, const int& cx, const int& cy)
{
	SetWindowPos(m_Hwnd, 0, x, y, cx, cy, SWP_NOZORDER);
	InvalidateRect(m_Hwnd, 0, true);
}
void TCheckBox::SetBkColor(COLORREF color)
{
	m_colorBK = color;
	InvalidateRect(GetHwnd(), NULL, TRUE);
}
void TCheckBox::SetColor(COLORREF color)
{
	m_color = color;
	InvalidateRect(GetHwnd(), NULL, TRUE);
}
void TCheckBox::SetText(const wchar_t* pText)
{
	wcsncpy_s(m_strText, pText, sizeof(m_strText)/sizeof(wchar_t)-1);
}
void TCheckBox::OnPaint()
{
	TMemDC memdc(m_Hwnd);
	RECT rect;
	GetClientRect(GetHwnd(), &rect);
	SetBkMode(memdc.GetHdc(), TRANSPARENT);
	HBRUSH hBkBrush = CreateSolidBrush(m_colorBK/*g_ColorRefData.GetColorBackground()*/);
	FillRect(memdc.GetHdc(), &rect, hBkBrush);

	RECT rcsel;
	rcsel.left = 0;
	rcsel.top = (rect.bottom - rect.top - m_selchecksize) / 2;
	rcsel.right = rcsel.left + m_selchecksize;
	rcsel.bottom = rcsel.top + m_selchecksize;
	HPEN pen = CreatePen(PS_USERSTYLE, 1, RGB(150, 150, 150));
	SelectObject(memdc.GetHdc(), pen);
	Rectangle(memdc.GetHdc(), rcsel.left, rcsel.top, rcsel.right, rcsel.bottom);

	if (!IsWindowEnabled(m_Hwnd))
	{
		HBRUSH hDisBrush = CreateSolidBrush(RGB(200, 200, 200));
		InflateRect(&rcsel, -1, -1);
		FillRect(memdc.GetHdc(), &rcsel, hDisBrush);
		DeleteObject(hDisBrush);
	}
	//����checkbox
	else if (m_bChecked)
	{
		HPEN hpen = CreatePen(PS_SOLID, 2, RGB(150, 150, 150));
		SelectObject(memdc.GetHdc(), hpen);
		InflateRect(&rcsel, -2, -2);

		POINT pp[3];
		pp[0].x = rcsel.left + 1;
		pp[0].y = rcsel.top + (rcsel.bottom - rcsel.top) / 2;
		pp[1].x = pp[0].x + 2;
		pp[1].y = rcsel.bottom - 2;
		pp[2].x = rcsel.right - 1;
		pp[2].y = rcsel.top + 2;

		MoveToEx(memdc.GetHdc(), pp[0].x, pp[0].y, NULL);
		LineTo(memdc.GetHdc(), pp[1].x, pp[1].y);
		MoveToEx(memdc.GetHdc(), pp[1].x, pp[1].y, NULL);
		LineTo(memdc.GetHdc(), pp[2].x, pp[2].y);

		InflateRect(&rcsel, 2, 2);
		DeleteObject(hpen);
	}
	HFONT hFont = CreateFont(12, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
		CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����"));
	SelectObject(memdc.GetHdc(), hFont);

	SetTextColor(memdc.GetHdc(), m_color);
	rcsel.left = rcsel.right + 4; rcsel.right = rect.right;
	rcsel.top = rect.top;
	rcsel.bottom = rect.bottom;
	DrawText(memdc.GetHdc(), m_strText, wcslen(m_strText), &rcsel, DT_SINGLELINE | DT_LEFT | DT_VCENTER);

	DeleteFont(hFont);
	DeleteObject(hBkBrush);
	DeleteObject(pen);
}
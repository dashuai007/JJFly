﻿#include "PreInclude.h"

TKLineControl::TKLineControl(TDuiWindow& window) : TDuiControl(window), m_ShowCrossDown(false), m_ShowCross(false), m_CrossX(100), m_CrossY(100), m_CanZoomOut(true), m_PreVK(0), m_MoveOrderId(0), m_pMoveStop(NULL), m_pMovePosition(NULL)
, m_nSelSub(0), m_TLineType(TLINE_SYMMETRIC_AXIS),m_nSelCustom(-1), m_bLinkage(true), m_bRegToolTip(false), m_bCalCross(false)
{
	IndexParams::GetInstance()->LoadModifyParamInfo();
	memset(m_Rects, 0, sizeof(m_Rects));

	m_Contract.Init(this);
	memset(&m_AxisX, 0, sizeof(m_AxisX));
	//memset(m_Chart, 0, sizeof(m_Chart));
	CIndexMgr::GetInstance()->InitAllIndex();
	
	INDEX_SPEC indArr[] = { KLINE_SPEC ,VOL_SPEC ,MACD_SPEC ,KDJ_SPEC,RSI_SPEC,WR_SPEC,BIAS_SPEC };
	for (size_t i = 0; i < sizeof(indArr) / sizeof(INDEX_SPEC); i++)
	{
		SetChartSpace(m_Chart[i].KChartSpec[0], CIndexMgr::GetInstance()->GetIndex(indArr[i]), true);
		if(i==0)
			SetChartSpace(m_Chart[i].KChartSpec[1], CIndexMgr::GetInstance()->GetIndex(MA_SPACE), true);
	}

	Assign_SubChart();

	memset(m_Orders, 0, sizeof(m_Orders));
	memset(m_Positions, 0, sizeof(m_Positions));
	memset(m_Stops, 0, sizeof(m_Stops));
	memset(m_OrderPixels, 0, sizeof(m_OrderPixels));
	G_QuoteCenter.Add_KLineControl(this);
	m_ShapeChart.SetKLineControl(this);
	m_hwTip = CreateWindowEx(WS_EX_TOPMOST, TOOLTIPS_CLASS, NULL, WS_POPUP | TTS_NOPREFIX |TTS_BALLOON, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, GetWindow()->GetHwnd(), NULL, GetModuleHandle(NULL), NULL);
	SetWindowPos(m_hwTip, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
}

TKLineControl::~TKLineControl()
{
	//退订合约
	m_Contract.UnsubContract();

	G_QuoteCenter.Del_KLineControl(this);
	ClearShapes();
}
void TKLineControl::SetChartSpace(TKChartSpec& chartSpace, CIndex* pIndex, bool bModify)
{
	if (!pIndex)
		return;
	chartSpace.m_pIndex = pIndex;
	std::vector<TKLineSpecParam> vParames;
	if(IndexParams::GetInstance()->GetParams(pIndex->GetIndexName(), vParames)&& bModify)
	{
		for (size_t i = 0; i < vParames.size(); i++)
		{
			chartSpace.Params[i]=vParames[i];
		}
	}
	else
	   memcpy_s(&chartSpace.Params, sizeof(chartSpace.Params), pIndex->GetParamAddr(), sizeof(chartSpace.Params));
	wcscpy_s(chartSpace.SpecName, pIndex->GetIndexName());
	chartSpace.Visible = pIndex->GetIsVisiable();
}
void TKLineControl::SetCfg(int index)
{
	m_Contract.SwitchByMenu(index);
	Switch_Spec();
}


void TKLineControl::SetMainCfg(char* pstr, int size)
{
	//新版本保存格式
	char* ptrStar = pstr;
	char* pos1 = NULL;
	for (int i = 0; i < sizeof(m_Chart) / sizeof(TKLineChart); i++)
	{
		TKLineChart& chart = m_Chart[i];
		pos1 = strstr(ptrStar, "{cno:");
		if (NULL != pos1)
		{
			if (pos1[6] == '{')
			{
				int ncno = atoi(&pos1[5]);
				if (i == ncno)
				{
					chart.Visible = true;
					for (int j = 0; j < sizeof(chart.KChartSpec) / sizeof(TKChartSpec); j++)
					{
						TKChartSpec& spec = chart.KChartSpec[j];
						if (i == 0)
							spec.Visible = true;
						char* pos2 = strstr(pos1, "{sno:");
						if (NULL != pos2)
						{
							if (pos2[6] == ',')
							{
								int nsno = atoi(&pos2[5]);
								if (j == nsno)
								{
									char sName[21] = { 0 };
									char* pos3 = strstr(pos2, "SName:");
									if (NULL != pos3)
									{
										char* pos4 = strchr(pos3, ',');
										int len = pos4 - &pos3[6];
										memcpy(sName, &pos3[6], len);
										sName[len + 1] = '\0';
									}
									if (i == 0 && j == 0 && strcmp(sName, "MA") == 0)
										continue;
									MultiByteToWideChar(1252, 0, sName, -1, spec.SpecName, sizeof(spec.SpecName) / sizeof(wchar_t));
									CIndex* pSpace = CIndexMgr::GetInstance()->GetIndexByName(spec.SpecName);
									SetChartSpace(spec, pSpace, false);
									spec.Visible = true;
									pos3 = strstr(pos2, "P1:");
									if (NULL != pos3)
									{
										if (pos3[4] == ',')
										spec.Params[0].Value = atoi(&pos3[3]);
									}
									pos3 = strstr(pos2, "P2:");
									if (NULL != pos3)
									{
										if (pos3[4] == ',')
										spec.Params[1].Value = atoi(&pos3[3]);
									}
									pos3 = strstr(pos2, "P3:");
									if (NULL != pos3)
									{
										if (pos3[4] == ',')
										spec.Params[2].Value = atoi(&pos3[3]);
									}
									pos3 = strstr(pos2, "P4:");
									if (NULL != pos3)
									{
										if (pos3[4] == ',')
										spec.Params[3].Value = atoi(&pos3[3]);
									}
									pos3 = strstr(pos2, "P5:");
									if (NULL != pos3)
									{
										if (pos3[4] == ',')
										spec.Params[4].Value = atoi(&pos3[3]);
									}
									pos3 = strstr(pos2, "P6:");
									if (NULL != pos3)
									{
										if (pos3[4] == '}')
										spec.Params[5].Value = atoi(&pos3[3]);
									}
									pos1 = pos3;
								}
							}
						}
					}
					ptrStar = strchr(pos1, '}');
				}

			}
			else if (pos1[6] == '}')
			{
				int ncno = atoi(&pos1[5]);
				if (i == ncno&&ncno==0)
				{
					chart.Visible = true;
					for (int j = 0; j < sizeof(chart.KChartSpec) / sizeof(TKChartSpec); j++)
					{
						TKChartSpec& spec = chart.KChartSpec[j];
						spec.Visible = false;
					}
				}
				ptrStar = strchr(pos1, '}');
			}
		}
	}
	pos1 = strstr(ptrStar, "(bLinkage:");
	if (NULL != pos1)
	{
		char* pos2 = strchr(pos1, ')');
		if (NULL != pos2)
		{
			pos2[0] = '\0';
			m_bLinkage = atoi(&pos1[10]);
			pos2[0] = ';';
		}
	}
	pos1 = strstr(ptrStar, "(KStyle:");
	if (NULL != pos1)
	{
		char* pos2 = strchr(pos1, ')');
		if (NULL != pos2)
		{
			pos2[0] = '\0';
			m_Chart[0].Style = (KLINE_STYLE)atoi(&pos1[8]);
			pos2[0] = ';';
		}
	}
}

void TKLineControl::GetMainCfg(char* pstr, int size)
{
	for (int i = 0; i < sizeof(m_Chart) / sizeof(TKLineChart); i++)
	{
		TKLineChart& chart = m_Chart[i];
		if (!chart.Visible&&i != 0)
			continue;
		char chartNo[21] = { 0 };
		sprintf_s(chartNo, "{cno:%d", i);
		strcat_s(pstr, size, chartNo);
		for (int j = 0; j < sizeof(chart.KChartSpec) / sizeof(TKChartSpec); j++)
		{
			TKChartSpec& spec = chart.KChartSpec[j];
			if (!spec.Visible)
				continue;
			char spaceNo[21] = { 0 };
			sprintf_s(spaceNo, "{sno:%d,", j);
			strcat_s(pstr, size, spaceNo);
			char SpaceName[21] = { 0 }, cSname[21] = { 0 };
			WideCharToMultiByte(936, 0, spec.SpecName, -1, SpaceName, sizeof(SpaceName), 0, 0);
			sprintf_s(cSname, "SName:%s,", SpaceName);
			strcat_s(pstr, size, cSname);
			char cItem[21] = { 0 };
			sprintf_s(cItem, "P1:%d,", spec.Params[0].Value);
			strcat_s(pstr, size, cItem);
			sprintf_s(cItem, "P2:%d,", spec.Params[1].Value);
			strcat_s(pstr, size, cItem);
			sprintf_s(cItem, "P3:%d,", spec.Params[2].Value);
			strcat_s(pstr, size, cItem);
			sprintf_s(cItem, "P4:%d,", spec.Params[3].Value);
			strcat_s(pstr, size, cItem);
			sprintf_s(cItem, "P5:%d,", spec.Params[4].Value);
			strcat_s(pstr, size, cItem);
			sprintf_s(cItem, "P6:%d}", spec.Params[5].Value);
			strcat_s(pstr, size, cItem);
		}
		strcat_s(pstr, size, "}");
	}
	char tmpTxt[21] = { 0 };
	sprintf_s(tmpTxt, "(bLinkage:%d)", m_bLinkage);
	strcat_s(pstr, size, tmpTxt);
	sprintf_s(tmpTxt, "(KStyle:%d)", m_Chart[0].Style);
	strcat_s(pstr, size, tmpTxt);
}
bool TKLineControl::GetSpreadNo(SContractNoType& sno)
{
	if (m_Contract.IsSpread)
	{
		strcpy_s(sno, m_Contract.SpreadNo);
		return true;
	}
	return false;
}
bool TKLineControl::CheckContract(const SContractNoType contractid)
{
	return m_Contract.CheckContract(contractid);
}

void TKLineControl::SwitchToTLine()
{
	EnterShapechartShapes();
	m_Contract.SwitchTLine();
	Switch_Spec();
	LeaveShapeChartShapes();
}

void TKLineControl::SwitchToKLine()
{
	EnterShapechartShapes();
	m_Contract.SwitchKLine();
	Switch_Spec();
	LeaveShapeChartShapes();
}
void TKLineControl::SwitchLineType(TLangIndex_PolestarQuote nType)
{
	EnterShapechartShapes();
	m_Contract.SwitchByMenu(nType);
	Switch_Spec();
	m_nSelCustom = -1;
	LeaveShapeChartShapes();
}
void TKLineControl::SwitchLineTypeAndRedow(TLangIndex_PolestarQuote nType)
{
	EnterShapechartShapes();
	m_Contract.SwitchByMenu(nType);
	Switch_Spec();
	m_Contract.SubAndReload();
	m_nSelCustom = -1;
	LeaveShapeChartShapes();
	CalculateRects();
	Redraw(NULL);
	SetFocus();
}
void TKLineControl::SwitchLineTypeByCustom(TKLinePeriod prd)
{
	EnterShapechartShapes();
	m_Contract.SwitchByCustom(prd);
	Switch_Spec();
	m_Contract.SubAndReload();
	LeaveShapeChartShapes();
	CalculateRects();
	Redraw(NULL);
	SetFocus();
}
void TKLineControl::SetContract(SContract* contract)
{
	EnterShapechartShapes();
	m_Contract.RegContract(contract);
	m_Contract.SubAndReload();
	LeaveShapeChartShapes();
	CalculateRects();
	//发通知
	if (NULL != contract)
	{
		char content[128];
		sprintf_s(content, "contractid=%s;field=126;src=kline", contract->ContractNo);
		PolestarQuoteLinkage(GetWindow()->GetHwnd(), "SetContract", content);
	}
}
void TKLineControl::SetSpreadContractLinkage(const SContractNoType cno)
{
	EnterShapechartShapes();
	m_Contract.RegSpreadContract(cno);
	m_Contract.SubAndReload();
	LeaveShapeChartShapes();
	char content[128];
	sprintf_s(content, "contractid=%s;field=126;src=kline", cno);
	PolestarQuoteLinkage(GetWindow()->GetHwnd(), "SetContract", content);
}
void TKLineControl::SetSubContract(const SContractNoType cno)
{
	SContract* cont =  NULL;
	if (!G_StarApi->GetContractData(NULL, cno, &cont, 1, false))
		return;
	m_SubContract.RegContract(cont);
	m_SubContract.SubAndReload();
}
bool TKLineControl::Reload_Data(const SContractNoType test_contract)
{
	if (!m_Contract.CheckContract(test_contract))
		return false;
	m_ShapeChart.ResetShape();
	bool ret = m_Contract.ReloadData();
	//TCriticalSection::Lock lock(m_Crit);
	////绘图准备
	//for (int i = 0; i < sizeof(m_Chart) / sizeof(TKLineChart); i++)
	//{
	//	TKLineChart& chart = m_Chart[i];
	//	if (!chart.Visible)
	//		continue;
	//	//计算指标信息
	//	chart.CalcAllIndicators(i == 0);
	//}
	return ret;
}

bool TKLineControl::Update_Data(const SContractNoType test_contract)
{
	if (!m_Contract.CheckContract(test_contract))
		return false;
	m_ShapeChart.ResetShape();
	bool ret = m_Contract.UpdateData();
	//TCriticalSection::Lock lock(m_Crit);
	////绘图准备
	//PrepareAxisX();
	//for (int i = 0; i < sizeof(m_Chart) / sizeof(TKLineChart); i++)
	//{
	//	TKLineChart& chart = m_Chart[i];
	//	if (!chart.Visible)
	//		continue;
	//	//计算指标信息
	//	chart.CalcAllIndicators(i == 0);
	//}
	return ret;
}
bool TKLineControl::Update_HisVolatilityData(const SContractNoType test_contract)
{
	if (!m_Contract.CheckContract(test_contract))
		return false;
	bool ret = m_Contract.UpdateHisVolatilityData();
	return ret;
}
bool TKLineControl::Reload_HisVolatilityData(const SContractNoType test_contract)
{
	if (!m_Contract.CheckContract(test_contract))
		return false;
	bool ret = m_Contract.ReloadHisVolatilityData();
	return ret;
}
bool TKLineControl::SetLineState(const char* action)
{
	if (NULL == G_LineOrderApi || NULL == action || '\0' == action[0])
		return false;

	//下单和删单操作开启时，需要关闭十字标线
	switch (action[0])
	{
	case LINE_ORDER_BEGIN:
		m_LineState = LINE_ORDER;
		m_ShowCross = false;
		TrackMouseLeave();
		break;
	case LINE_ORDER_DEL:
		m_LineState = LINE_DEL_ORDER;
		m_ShowCross = false;
		break;
	case LINE_ORDER_END:
		m_LineState = LINE_NONE;
		break;
	default:
		return false;
	}

	return true;
}

void TKLineControl::OnMoveAndSize(bool move, bool size)
{
	//第一次打开界面时，会先设置合约，造成CalculateRects一次没有执行过，故此处增加一次调用，或者在设置合约之前调用一次？？？？？？
	//主要考虑，订阅数据时，要根据界面尺寸计算，需要订阅的数据量，所以要保持界面的大小及中间尺寸计算正确

	//2016-06-22：应不再需要根据界面大小评估订阅数据量，所以此处不再需要试算分区域大小
	if (!size)
		return;

	//RECT cr;
	//GetRect(cr);
	//cr.bottom -= cr.top;

	//cr.right -= cr.left;
	//CalculateRects(cr);
	CalculateRects();
}

bool TKLineControl::OnDraw(HDC hdc, HDC mdc, RECT& cr, RECT& ur, bool follow)
{
	PrepareAxisX();
	PrepareAxisY();
	//开始绘图
	FillRect(mdc, &cr, BRUSH_KLINE_BACKGROUND);

	DrawTop(mdc, cr);
	DrawBottom(mdc, cr);
	DrawLeft(mdc, cr);
	DrawRight(mdc, cr);
	DrawCenter(mdc, cr);

	DrawChart(mdc, cr);
	DrawTrade(mdc, cr);
	DrawCross(mdc, cr);
	DrawIntervalAmplification(mdc, cr);
	DrawLineOrder(mdc, cr);

	return true;
}

void TKLineControl::OnMouseMove(WORD btn, POINTS& pts)
{
	if (g_pDrawTool&&IsWindow(g_pDrawTool->GetHwnd()) && g_pDrawTool->GetSelectedShape() != SHAPE_NONE)
	{
		if (MAIN_CHART_KLINE == m_Contract.MainChart)
		{
			RECT r(m_Rects[CENTER_CHART]);
			if (pts.x >= r.left && pts.x < r.right && pts.y >= r.top && pts.y < r.bottom)
			{
				SHAPE_TYPE type = g_pDrawTool->GetSelectedShape();
				m_ShapeChart.SelectDrawTool(type, &m_Chart[0], &m_AxisX);
				m_ShapeChart.OnMouseMove(pts);
			}
			else
			{
				if (g_pDrawTool)
					m_ShapeChart.DeleteShapePen();
			}
			RedrawLater(NULL);
			return;
		}
	}
	else if (m_bAmplification|| m_bStatistics) //区间放大 统计
	{
		RECT r(m_Rects[CENTER_CHART]);
		if (pts.x >= r.left && pts.x < r.right && pts.y >= r.top && pts.y < r.bottom)
		{
			SetCurrCursor(CURSOR_LINE);
			m_nEndX = pts.x;
			m_CrossX = pts.x;
		}
		RedrawLater(NULL);
		return;
	}
	else if (m_ShapeChart.OnMouseMove(pts))
	{	
		RedrawLater(NULL);
		return;
	}
	//获取需要移动的订单
	TLineOrder* order(NULL);
	if (pts.y >= 0 && pts.y < MAX_SHOW_KLINE_Y)
		order = m_OrderPixels[pts.y];
	//获得止盈止损关联持仓
	TLinePosition* position(NULL);
	if (NULL != G_LineOrderApi && (SWS_StopTrade &G_LineOrderApi->GetStartegyWorkState()) != SWS_NONE)
	{
		if (pts.y >= 0 && pts.y < MAX_SHOW_KLINE_Y)
			position = m_PositionPixels[pts.y];
	}
	//获得需要移动的止盈止损订单
	TLineStop* stop(NULL);
	if (NULL != G_LineOrderApi && (SWS_StopTrade &G_LineOrderApi->GetStartegyWorkState()) != SWS_NONE)
	{
		if (pts.y >= 0 && pts.y < MAX_SHOW_KLINE_Y)
			stop = m_StopPixels[pts.y];
	}

	if (LINE_ORDER == m_LineState)	//下单状态
	{
		SetCurrCursor(CURSOR_LINE);
		RECT r(m_Chart[0].CenterChartRect);
		m_LineY = 0;
		if (pts.x >= r.left && pts.x < r.right && pts.y >= r.top && pts.y < r.bottom)
			m_LineY = pts.y;

		RedrawLater(NULL);
		return;
	}
	else if (LINE_DEL_ORDER == m_LineState) //撤单状态
	{
		SetCurrCursor(CURSOR_DEL);
		return;
	}
	else if (m_ShowCross)	//十字标线
	{
		RECT r(m_Rects[CENTER_CHART]);
		if (pts.x >= r.left && pts.x < r.right && pts.y >= r.top && pts.y < r.bottom)
		{
			SetCurrCursor(NULL);
			m_CrossX = pts.x;
			m_CrossY = pts.y;
		}
		else
		{
			SetCurrCursor(CURSOR_ARROW);
			m_ShowCross = false;
		}

		RedrawLater(NULL);
		return;
	}
	else if (m_nSelSub != 0)
	{
		RECT r(m_Rects[CENTER_CHART]);
		if (pts.x < r.left || pts.x > r.right || pts.y < r.top || pts.y > r.bottom)
		{
			m_nSelSub = 0;
			RedrawLater(NULL);
			return;
		}
	}
	else if (m_MoveOrderId > 0)	//正在移动订单
	{
		SetCurrCursor(CURSOR_HAND_MOVE);
		RECT r(m_Chart[0].CenterChartRect);
		m_LineY = 0;
		if (pts.x >= r.left && pts.x < r.right && pts.y >= r.top && pts.y < r.bottom)
		{
			m_LineY = pts.y;
			TKLineChart& chart = m_Chart[0];
			double value = (chart.LeftAxisY.MaxValue - (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue) * (m_LineY - chart.LeftRect.top) / (chart.LeftRect.bottom - chart.LeftRect.top)) * 1.0 / chart.LeftAxisY.PrecPow;
			if (NULL != G_LineOrderApi)
			{
				
				    G_LineOrderApi->SyncModifyWnd(m_MoveOrderId, value, m_Contract.IsEpoleStarSpreadContract() ? DLT_Spread : DLT_Condition, true);
			}
		}

		RedrawLater(NULL);
		return;
	}
	else if (m_pMoveStop)
	{
		SetCurrCursor(CURSOR_HAND_MOVE);
		RECT r(m_Chart[0].CenterChartRect);
		m_LineY = 0;
		if (pts.x >= r.left && pts.x < r.right && pts.y >= r.top && pts.y < r.bottom)
		{
			m_LineY = pts.y;
			TKLineChart& chart = m_Chart[0];
			double value = (chart.LeftAxisY.MaxValue - (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue) * (m_LineY - chart.LeftRect.top) / (chart.LeftRect.bottom - chart.LeftRect.top)) * 1.0 / chart.LeftAxisY.PrecPow;
			if (NULL != G_LineOrderApi)
			{
				TModifyStopDraw modify;
				modify.dPrice = value;
				modify.nType = m_pMoveStop->Type == TYPE_LOSS ? stLoss : stProfit;
				modify.pPosition = m_pMoveStop->pPosition;
				modify.uLocalId = m_pMoveStop->LocalId;
				modify.uQty = m_pMoveStop->Qty;
				G_LineOrderApi->SyncStopModifyWnd(modify, true);
			}
		}

		RedrawLater(NULL);
		return;
	}
	else if (m_pMovePosition)
	{
		SetCurrCursor(CURSOR_HAND_MOVE);
		RECT r(m_Chart[0].CenterChartRect);
		m_LineY = 0;
		if (pts.x >= r.left && pts.x < r.right && pts.y >= r.top && pts.y < r.bottom)
		{
			m_LineY = pts.y;
		}

		RedrawLater(NULL);
		return;
	}
	else if (NULL != order || NULL != position || NULL != stop)	//触摸到订单或持仓
	{
		SetCurrCursor(CURSOR_HAND);
		return;
	}
	else if (!m_ShowCross && NULL != m_Contract.Cont && MAIN_CHART_KLINE == m_Contract.MainChart && btn == MK_LBUTTON && HasMouse()) //拖动K线
	{
		SetCurrCursor(CURSOR_WE);

		POINT cp;
		GetCursorPos(&cp);
		TKLineShapeType& kshape = G_QuoteUtils.KLineShapes[m_Contract.KLineShape];

		int movedatacount = cp.x > m_BeginPoint.x? ceil((cp.x - m_BeginPoint.x)*1.0 / kshape.AreaWidth):floor((cp.x - m_BeginPoint.x)*1.0 / kshape.AreaWidth);
		int hopetail = m_BeginTailIndex + movedatacount;
		if (hopetail < 0)
			hopetail = 0;
		if (hopetail == m_Contract.KLineTail)	//没动或最右边，不能再动
			return;
		if (!m_CanZoomOut && hopetail > m_Contract.KLineTail) //最左边，不能再动
			return;

		m_Contract.KLineTail = hopetail;
		m_Contract.SubAndReload();
		m_BeginMove = true;
		m_ShapeChart.ResetShape();
		Redraw(NULL);
		SetFocus();
		return;
	}

	SetCurrCursor(CURSOR_ARROW);
}

void TKLineControl::OnLButtonDown(WORD btn, POINTS& pts)
{
	if (!HasFocus())
	{
		SetFocus();
		//发通知
		if (NULL != m_Contract.Cont)
		{
			char content[128];
			sprintf_s(content, "contractid=%s;field=126;src=kline", m_Contract.Cont->ContractNo);
			PolestarQuoteLinkage(GetWindow()->GetHwnd(), "SetContract", content);
		}
	}
	((TQuoteFrame*)GetWindow())->CancalSelectField();
	m_nSelSub = 0;
	for (int i = 1; i < sizeof(m_Chart) / sizeof(TKLineChart); i++)
	{
		TKLineChart& chart = m_Chart[i];
		if (!chart.Visible)
			continue;
		if (pts.x >= chart.CenterRect.left&&pts.x <= chart.CenterRect.right && pts.y >= chart.CenterRect.top &&pts.y <= chart.CenterRect.bottom)
		{
			m_nSelSub = i;
		}
	}
	if (m_nSelSub == 0 && m_ShapeChart.OnLButtonDown(pts))
	{
		Redraw(NULL);
		return;
	}
	m_BeginMove = false;
	m_LButtonDown = true;
	m_ShowCrossDown = false;

	RECT kcr = m_Rects[TOP_KCYCLE];
	RECT ccr = m_Chart[0].CenterChartRect;
	RECT Link_r = m_Rects[TOP_LINKAGE];
	//获取需要移动的订单
	TLineOrder* order(NULL);
	if (pts.y >= 0 && pts.y < MAX_SHOW_KLINE_Y)
		order = m_OrderPixels[pts.y];

	//获得需要移动的持仓
	TLinePosition* position(NULL);
	if (NULL != G_LineOrderApi && (SWS_StopTrade &G_LineOrderApi->GetStartegyWorkState()) != SWS_NONE)
	{
		if (pts.y >= 0 && pts.y < MAX_SHOW_KLINE_Y)
			position = m_PositionPixels[pts.y];
	}

	//获得需要移动的止盈止损订单
	TLineStop* stop(NULL);
	if (NULL != G_LineOrderApi && (SWS_StopTrade &G_LineOrderApi->GetStartegyWorkState()) != SWS_NONE)
	{
		if (pts.y >= 0 && pts.y < MAX_SHOW_KLINE_Y)
			stop = m_StopPixels[pts.y];
	}

	if (LINE_ORDER == m_LineState)
	{
		TKLineChart& chart = m_Chart[0];
		RECT r(chart.CenterChartRect);
		if (pts.x >= r.left && pts.x < r.right && pts.y >= r.top && pts.y < r.bottom)
		{
			double value = (chart.LeftAxisY.MaxValue - (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue) * (m_LineY - chart.LeftRect.top) / (chart.LeftRect.bottom - chart.LeftRect.top)) * 1.0 / chart.LeftAxisY.PrecPow;
			G_LineOrderApi->AddDrawLineStrategyOrder(m_Contract.IsSpread? m_Contract.SpreadNo:m_Contract.Cont->ContractNo, value, m_Contract.IsEpoleStarSpreadContract() ? DLT_Spread: DLT_Condition);
			G_LineOrderApi->CancelDrawLineOperation();

			//if (ret != 0) //失败提示
			//{
			//	MessageBox(GetWindow()->GetHwnd(), G_LANG->LangText(TLI_LINE_ORDER_FAIL), L"", MB_OK);
			//}
		}

		Redraw(NULL);
		return;
	}
	else if (LINE_DEL_ORDER == m_LineState)
	{
		if (pts.y >= 0 && pts.y < sizeof(m_OrderPixels) / sizeof(TLineOrder*))
		{
			TLineOrder* order = m_OrderPixels[pts.y];
			if (NULL != order && NULL != G_LineOrderApi)
			{
					G_LineOrderApi->MoveStrategyOrder(order->OrderId, m_Contract.IsEpoleStarSpreadContract() ? DLT_Spread : DLT_Condition);
			}
			else if (NULL != stop&& NULL != G_LineOrderApi)
			{		
					TDeleteStopDraw delstop;
					delstop.pPosition = stop->pPosition;
					delstop.uLocalId = stop->LocalId;
					G_LineOrderApi->DeleteDrawStopRecord(delstop);	
			}
			else
			{
				m_LineState = LINE_NONE;
				SetCurrCursor(CURSOR_ARROW);
				Redraw(NULL);
				if (NULL != G_LineOrderApi)
				{
					G_LineOrderApi->CancelDrawLineOperation();
				}
			}
		}
		return;
	}
	else if (NULL != order) //开始移动订单
	{
		if (NULL != G_LineOrderApi)
		{
			SetCurrCursor(CURSOR_HAND_MOVE);
			G_LineOrderApi->SuspendStrategyOrder(order->OrderId, m_Contract.IsEpoleStarSpreadContract() ? DLT_Spread : DLT_Condition);
			m_MoveOrderId = order->OrderId;
			m_LineY = order->Pixel;
			Redraw(NULL);
		}
		return;
	}
	else if (NULL != stop)
	{
		if (NULL != G_LineOrderApi)
		{
			SetCurrCursor(CURSOR_HAND_MOVE);
			G_LineOrderApi->SuspendDrawStopRecord(stop->pPosition);
			m_pMoveStop = stop;
			m_LineY = stop->Pixel;
			Redraw(NULL);
		}
	}
	else if (NULL != position)
	{
		if (NULL != G_LineOrderApi&&NULL != position->pPosition)
		{
			SetCurrCursor(CURSOR_HAND_MOVE);
			m_pMovePosition = position;
			m_LineY = position->Pixel;
			Redraw(NULL);
		}
	}
	else if (pts.x >= kcr.left && pts.x < kcr.right && pts.y >= kcr.top && pts.y < kcr.bottom)	//周期切换菜单
	{
		TDuiPopMenuWindow pop;
		TDuiPopMenuItem item;
		memset(&item, 0, sizeof(TDuiPopMenuItem));

		//分时图
		item.Index = TLI_KLINE_TIME;
		wcsncpy_s(item.Text, G_LANG->LangText(item.Index), sizeof(item.Text) / sizeof(wchar_t) - 1);
		wcsncpy_s(item.RightText, L"0 Enter", sizeof(item.RightText) / sizeof(wchar_t) - 1);
		item.Begin = false;
		pop.AddItem(item);

		//闪电图
		item.Index = TLI_KLINE_TICK;
		wcsncpy_s(item.Text, G_LANG->LangText(item.Index), sizeof(item.Text) / sizeof(wchar_t) - 1);
		item.RightText[0] = L'\0';
		item.Begin = false;
		pop.AddItem(item);

		//秒线
		item.Index = TLI_KLINE_SEC5;
		wcsncpy_s(item.Text, G_LANG->LangText(item.Index), sizeof(item.Text) / sizeof(wchar_t) - 1);
		item.RightText[0] = L'\0';
		item.Begin = true;
		pop.AddItem(item);

		item.Index = TLI_KLINE_SEC10;
		wcsncpy_s(item.Text, G_LANG->LangText(item.Index), sizeof(item.Text) / sizeof(wchar_t) - 1);
		item.RightText[0] = L'\0';
		item.Begin = false;
		pop.AddItem(item);

		item.Index = TLI_KLINE_SEC15;
		wcsncpy_s(item.Text, G_LANG->LangText(item.Index), sizeof(item.Text) / sizeof(wchar_t) - 1);
		item.RightText[0] = L'\0';
		item.Begin = false;
		pop.AddItem(item);

		item.Index = TLI_KLINE_SEC30;
		wcsncpy_s(item.Text, G_LANG->LangText(item.Index), sizeof(item.Text) / sizeof(wchar_t) - 1);
		item.RightText[0] = L'\0';
		item.Begin = false;
		pop.AddItem(item);

		//分钟
		item.Index = TLI_KLINE_MIN1;
		wcsncpy_s(item.Text, G_LANG->LangText(item.Index), sizeof(item.Text) / sizeof(wchar_t) - 1);
		wcsncpy_s(item.RightText, L"1 Enter", sizeof(item.RightText) / sizeof(wchar_t) - 1);
		item.Begin = true;
		pop.AddItem(item);

		item.Index = TLI_KLINE_MIN3;
		wcsncpy_s(item.Text, G_LANG->LangText(item.Index), sizeof(item.Text) / sizeof(wchar_t) - 1);
		wcsncpy_s(item.RightText, L"2 Enter", sizeof(item.RightText) / sizeof(wchar_t) - 1);
		item.Begin = false;
		pop.AddItem(item);

		item.Index = TLI_KLINE_MIN5;
		wcsncpy_s(item.Text, G_LANG->LangText(item.Index), sizeof(item.Text) / sizeof(wchar_t) - 1);
		wcsncpy_s(item.RightText, L"3 Enter", sizeof(item.RightText) / sizeof(wchar_t) - 1);
		item.Begin = false;
		pop.AddItem(item);

		item.Index = TLI_KLINE_MIN10;
		wcsncpy_s(item.Text, G_LANG->LangText(item.Index), sizeof(item.Text) / sizeof(wchar_t) - 1);
		wcsncpy_s(item.RightText, L"4 Enter", sizeof(item.RightText) / sizeof(wchar_t) - 1);
		item.Begin = false;
		pop.AddItem(item);

		item.Index = TLI_KLINE_MIN15;
		wcsncpy_s(item.Text, G_LANG->LangText(item.Index), sizeof(item.Text) / sizeof(wchar_t) - 1);
		wcsncpy_s(item.RightText, L"5 Enter", sizeof(item.RightText) / sizeof(wchar_t) - 1);
		item.Begin = false;
		pop.AddItem(item);

		item.Index = TLI_KLINE_MIN30;
		wcsncpy_s(item.Text, G_LANG->LangText(item.Index), sizeof(item.Text) / sizeof(wchar_t) - 1);
		wcsncpy_s(item.RightText, L"6 Enter", sizeof(item.RightText) / sizeof(wchar_t) - 1);
		item.Begin = false;
		pop.AddItem(item);

		item.Index = TLI_KLINE_HOUR1;
		wcsncpy_s(item.Text, G_LANG->LangText(item.Index), sizeof(item.Text) / sizeof(wchar_t) - 1);
		wcsncpy_s(item.RightText, L"7 Enter", sizeof(item.RightText) / sizeof(wchar_t) - 1);
		item.Begin = false;
		pop.AddItem(item);

		//日线
		item.Index = TLI_KLINE_DAY1;
		wcsncpy_s(item.Text, G_LANG->LangText(item.Index), sizeof(item.Text) / sizeof(wchar_t) - 1);
		wcsncpy_s(item.RightText, L"9 Enter", sizeof(item.RightText) / sizeof(wchar_t) - 1);
		item.Begin = true;
		pop.AddItem(item);

		item.Index = TLI_KLINE_WEEK1;
		wcsncpy_s(item.Text, G_LANG->LangText(item.Index), sizeof(item.Text) / sizeof(wchar_t) - 1);
		item.RightText[0] = L'\0';
		item.Begin = false;
		pop.AddItem(item);

		item.Index = TLI_KLINE_MONTH1;
		wcsncpy_s(item.Text, G_LANG->LangText(item.Index), sizeof(item.Text) / sizeof(wchar_t) - 1);
		item.RightText[0] = L'\0';
		item.Begin = false;
		pop.AddItem(item);

		item.Index = TLI_KLINE_YEAR1;
		wcsncpy_s(item.Text, G_LANG->LangText(item.Index), sizeof(item.Text) / sizeof(wchar_t) - 1);
		item.RightText[0] = L'\0';
		item.Begin = false;
		pop.AddItem(item);

		item.Index = TLI_CUSTOM;
		wcsncpy_s(item.Text, G_LANG->LangText(item.Index), sizeof(item.Text) / sizeof(wchar_t) - 1);
		item.RightText[0] = L'\0';
		pop.AddItem(item);

		for (size_t i = 0; i < m_arrUserPeriod.size(); i++)
		{
			TKLinePeriod period = m_arrUserPeriod[i];
			item.Index = TLI_CUSTOM_BEGIN+i;
			swprintf_s(item.Text, L"%d%s", period.multi, G_LANG->LangText(TLI_CUSTOM_END + period.kind));
			item.RightText[0] = L'\0';
			pop.AddSubItem(item);
		}

		item.Index = TLI_MANAGE;
		wcsncpy_s(item.Text, G_LANG->LangText(item.Index), sizeof(item.Text) / sizeof(wchar_t) - 1);
		item.RightText[0] = L'\0';
		pop.AddSubItem(item);

		pop.SetSpi(this);

		RECT wr;
		GetWindow()->GetRect(wr);
		pop.SetWidth(kcr.right - kcr.left + 80);
		pop.ShowPop(wr.left + kcr.left - 80, wr.top + kcr.bottom, false, NULL);
		m_LButtonDown = false;
		return;
	}
	else if (pts.x >= Link_r.left && pts.x < Link_r.right && pts.y >= Link_r.top && pts.y < Link_r.bottom)
	{
		m_bLinkage = !m_bLinkage;
		if (m_bLinkage)
		{
			SendMessage(m_hwTip, TTM_ACTIVATE, 1, 0);
			UpadteRectTipText(0, Link_r, (LPWSTR)G_LANG->LangText(TLI_LINKAGE_WINDOW));
		}
		else
		{
			SendMessage(m_hwTip, TTM_ACTIVATE,1, 0);
			UpadteRectTipText(0, Link_r, (LPWSTR)G_LANG->LangText(TLI_UNLINKAGE_WINDOW));
		}
		Redraw(NULL);
		((TQuoteFrame*)GetWindow())->SaveCfg();
	}
	else if (!m_ShowCross)
	{
		//图形菜单打开
		for (int i = 0; i < sizeof(m_Chart) / sizeof(TKLineChart); i++)
		{
			TKLineChart& chart = m_Chart[i];
			if (!chart.Visible)
				continue;
			if (pts.x >= chart.CenterRect.left&&pts.x <= chart.CenterRect.right && pts.y >= chart.CenterRect.top &&pts.y <= chart.CenterRect.bottom)
			{
				if (0 == i)
					m_ShowCrossDown = true;
			}
			RECT r = chart.CenterSpecRect;

			if (pts.x >= r.left && pts.x < r.right && pts.y >= r.top && pts.y < r.bottom)
			{
				TDuiPopMenuWindow pop;
				TDuiPopMenuItem item;
				memset(&item, 0, sizeof(TDuiPopMenuItem));
				int nWidth = SPEC_NAME_WIDTH + 30;
				if (0 == i)   //主图菜单
				{
					if (MAIN_CHART_KLINE != m_Contract.MainChart)
						continue;
					int nCount = 0;
					for (int j = 3; j < CIndexMgr::GetInstance()->GetMainIndexCount(); j++)
					{
						CIndex* pIndex = CIndexMgr::GetInstance()->GetIndex((INDEX_SPEC)j);
						if (pIndex)
						{
							item.Index = 1000 + nCount;
							item.IsChecked = ((pIndex == m_Chart[0].KChartSpec[1].m_pIndex && m_Chart[0].KChartSpec[1].Visible) || (pIndex == m_Chart[0].KChartSpec[0].m_pIndex && m_Chart[0].KChartSpec[0].Visible));
							wcsncpy_s(item.Text, pIndex->GetIndexName(), sizeof(item.Text) / sizeof(wchar_t) - 1);
							pop.AddItem(item);
							nCount++;
						}
					}
					item.Index = 1000 + nCount;
					item.Begin = true;
					item.IsChecked = false;
					wcsncpy_s(item.Text, G_LANG->LangText(TLI_MODIFY_PARAM), sizeof(item.Text) / sizeof(wchar_t) - 1);
					pop.AddItem(item);
					item.Index = 1000 + nCount + 1;
					item.Begin = false;
					item.IsChecked = false;
					wcsncpy_s(item.Text, G_LANG->LangText(TLI_CLOASE_TARGET), sizeof(item.Text) / sizeof(wchar_t) - 1);
					pop.AddItem(item);

				}
				else   //副图菜单
				{
					wcsncpy_s(item.Text, G_LANG->LangText(TLI_SWING_ANALYSIS), sizeof(item.Text) / sizeof(wchar_t) - 1);
					pop.AddItem(item);
					item.Value = &chart;	
					for (int j = 0; j < CIndexMgr::GetInstance()->GetSubIndexCount(); j++)
					{
						int nId = j + CIndexMgr::GetInstance()->GetMainIndexCount();
						CIndex* pIndex = CIndexMgr::GetInstance()->GetIndex((INDEX_SPEC)nId);
						if (!pIndex|| pIndex->GetIndexType() != SWING_TYPE)
							continue;
						item.Index = 2000 + j;
						wcsncpy_s(item.Text, pIndex->GetIndexName(), sizeof(item.Text) / sizeof(wchar_t) - 1);
						item.IsChecked = (pIndex == chart.KChartSpec[0].m_pIndex && chart.KChartSpec[0].Visible);
						pop.AddSubItem(item);
					}
					wcsncpy_s(item.Text, G_LANG->LangText(TLI_VOLUME_ANALYSIS), sizeof(item.Text) / sizeof(wchar_t) - 1);
					item.IsChecked = false;
					pop.AddItem(item);
					for (int j = 0; j < CIndexMgr::GetInstance()->GetSubIndexCount(); j++)
					{
						int nId = j + CIndexMgr::GetInstance()->GetMainIndexCount();
						CIndex* pIndex = CIndexMgr::GetInstance()->GetIndex((INDEX_SPEC)nId);
						if (!pIndex || pIndex->GetIndexType() != VOLUME_TYPE)
							continue;
						item.Index = 2000 + j;
						wcsncpy_s(item.Text, pIndex->GetIndexName(), sizeof(item.Text) / sizeof(wchar_t) - 1);
						item.IsChecked = (pIndex == chart.KChartSpec[0].m_pIndex && chart.KChartSpec[0].Visible);
						pop.AddSubItem(item);
					}
					wcsncpy_s(item.Text, G_LANG->LangText(TLI_OPTION_ANALYSIS), sizeof(item.Text) / sizeof(wchar_t) - 1);
					pop.AddItem(item);
					for (int j = 0; j < CIndexMgr::GetInstance()->GetSubIndexCount(); j++)
					{
						int nId = j + CIndexMgr::GetInstance()->GetMainIndexCount();
						CIndex* pIndex = CIndexMgr::GetInstance()->GetIndex((INDEX_SPEC)nId);
						if (!pIndex || pIndex->GetIndexType() != OPTION_TYPE)
							continue;
						item.Index = 2000 + j;
						wcsncpy_s(item.Text, pIndex->GetIndexName(), sizeof(item.Text) / sizeof(wchar_t) - 1);
						item.IsChecked = (pIndex == chart.KChartSpec[0].m_pIndex && chart.KChartSpec[0].Visible);
						pop.AddSubItem(item);
					}
					item.Index = 2000 + CIndexMgr::GetInstance()->GetSubIndexCount();
					wcsncpy_s(item.Text, G_LANG->LangText(TLI_MODIFY_PARAM), sizeof(item.Text) / sizeof(wchar_t) - 1);
					item.IsChecked = false;
					pop.AddItem(item);
					if(G_LANG->LangId()==ENU)
					   nWidth += 30;
				}

				pop.SetSpi(this);

				RECT wr;
				GetWindow()->GetRect(wr);
				pop.SetWidth(nWidth);
				pop.ShowPop(wr.left + r.left, wr.top + r.bottom, false, NULL);
				return;
			}
		}

		//拖动K线图
		if ((MAIN_CHART_KLINE == m_Contract.MainChart && pts.x >= ccr.left && pts.x < ccr.right && pts.y >= ccr.top && pts.y < ccr.bottom)||m_bStatistics)
		{
			CatchMouse();

			m_BeginTailIndex = m_Contract.KLineTail;
			GetCursorPos(&m_BeginPoint);
			if (!m_bStatistics&&!m_bAmplification)
				SetCurrCursor(CURSOR_WE);
			else
				m_BeginPoint.x = pts.x;
		}
	}
}

void TKLineControl::OnRButtonDown(WORD btn, POINTS& pts)
{
	if (m_ShapeChart.OnRButtonDown(pts))
	{
		TDuiPopMenuWindow pop;
		TDuiPopMenuItem item;
		memset(&item, 0, sizeof(TDuiPopMenuItem));

		//删除
		item.Index = MENU_DEL_SINGLE_SHAPE;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_DEL_SINGLE_SHAPE), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddItem(item);
		//全部删除
		item.Index = MENU_DEL_ALL_SHAPES;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_DEL_ALL_SHAPES), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddItem(item);
		pop.SetSpi(this);

		POINT p;
		GetCursorPos(&p);
		pop.SetWidth(150);
		pop.ShowPop(p.x, p.y, true, GetWindow()->GetHwnd());
		return;
	}
	//取消画线下单状态
	if (LINE_NONE != m_LineState)
	{
		m_LineState = LINE_NONE;
		SetCurrCursor(CURSOR_ARROW);
		Redraw(NULL);
		if (NULL != G_LineOrderApi)
		{
			G_LineOrderApi->CancelDrawLineOperation();
		}
		return;
	}

	if (m_ShowCross)
	{
		m_ShowCross = false;
		SetCurrCursor(CURSOR_ARROW);
		Redraw(NULL);
	}

	//执行右键菜单操作
	TDuiPopMenuWindow pop;

	TDuiPopMenuItem item;
	memset(&item, 0, sizeof(TDuiPopMenuItem));

	//加入自选板块
	item.Index = MENU_ADD_SELF_PLATE;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_ADD_SELF_Plate), sizeof(item.Text) / sizeof(wchar_t) - 1);
	pop.AddItem(item);
	for (TPlatePageVectorType::iterator iter = G_QuoteUtils.PlatePages.begin(); iter != G_QuoteUtils.PlatePages.end(); iter++)
	{
		TPlatePage* p = *iter;
		if (p->ChildPages.empty())
		{
			if (p->IsSelf)
			{
				//wcsncpy_s(item.Text, G_LANG->LangText(TLI_ADD_SELF), sizeof(item.Text) / sizeof(wchar_t) - 1);
				wcsncpy_s(item.Text, p->PlateName, sizeof(item.Text) / sizeof(wchar_t) - 1 - wcslen(item.Text));
				item.Value = p;
				pop.AddSubItem(item);
				item.Begin = false;
			}
		}
		else
		{
			for (TPlatePageVectorType::iterator citer = p->ChildPages.begin(); citer != p->ChildPages.end(); citer++)
			{
				TPlatePage* pp = *citer;
				if (pp->IsSelf)
				{
					//wcsncpy_s(item.Text, G_LANG->LangText(TLI_ADD_SELF), sizeof(item.Text) / sizeof(wchar_t) - 1);
					wcsncpy_s(item.Text, pp->PlateName, sizeof(item.Text) / sizeof(wchar_t) - 1 - wcslen(item.Text));
					item.Value = pp;
					pop.AddSubItem(item);
					item.Begin = false;
				}
			}
		}
	}
	//价格预警
	item.Index = MENU_PRICE_ALERT;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_PRICE_ALERT), sizeof(item.Text) / sizeof(wchar_t) - 1);
	pop.AddItem(item);

	//切换到行情报价
	item.Index = MENU_SWITCH_GRID;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_SWITCH_GRID), sizeof(item.Text) / sizeof(wchar_t) - 1);
	pop.AddItem(item);

	//打开关闭盘口
	item.Index = -1;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_OPEN_PANEL), sizeof(item.Text) / sizeof(wchar_t) - 1);
	pop.AddItem(item);
	item.Index = 31;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_CLOSE_PANEL), sizeof(item.Text) / sizeof(wchar_t) - 1);
	item.IsChecked = !((TQuoteFrame*)GetWindow())->IsPanelVisible();
	pop.AddSubItem(item);
	item.Index = 32;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_PANEL_QUOTE1), sizeof(item.Text) / sizeof(wchar_t) - 1);
	item.IsChecked = ((TQuoteFrame*)GetWindow())->GetPanelLevel() == PANEL_LEVEL_ONE;
	pop.AddSubItem(item);
	item.Index = 33;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_PANEL_QUOTE5), sizeof(item.Text) / sizeof(wchar_t) - 1);
	item.IsChecked = ((TQuoteFrame*)GetWindow())->GetPanelLevel() == PANEL_LEVEL_FIVE;
	pop.AddSubItem(item);
	item.Index = 34;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_PANEL_QUOTE10), sizeof(item.Text) / sizeof(wchar_t) - 1);
	item.IsChecked = ((TQuoteFrame*)GetWindow())->GetPanelLevel() == PANEL_LEVEL_TEN;
	pop.AddSubItem(item);
	item.Index = 35;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_SMALLPANEL), sizeof(item.Text) / sizeof(wchar_t) - 1);
	item.IsChecked = ((TQuoteFrame*)GetWindow())->IsPanelSmall();
	pop.AddSubItem(item);

	item.IsChecked = false;
	//重新载入数据
	item.Index = MUNU_RELOAD_HISQUOTE;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_RELOAD_HISQUOTE), sizeof(item.Text) / sizeof(wchar_t) - 1);
	pop.AddItem(item);

	//分时图增加坐标范围
	if (MAIN_CHART_TLINE == m_Contract.MainChart)
	{
		item.Index = MUNU_AXIS_RANGE;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_AXIS_RANGE), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddItem(item);
		item.Index = MUNU_SYMMETRIC_AXIS;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_SYMMETRIC_AXIS), sizeof(item.Text) / sizeof(wchar_t) - 1);
		item.IsChecked = m_TLineType == TLINE_SYMMETRIC_AXIS;
		pop.AddSubItem(item);
		item.Index = MUNU_LIMIT_AXIS;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_LIMIT_AXIS), sizeof(item.Text) / sizeof(wchar_t) - 1);
		item.IsChecked = m_TLineType == TLINE_LIMIT_AXIS;
		pop.AddSubItem(item);
		item.Index = MUNU_FULL_AXIS;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_FULL_AXIS), sizeof(item.Text) / sizeof(wchar_t) - 1);
		item.IsChecked = m_TLineType == TLINE_FULL_AXIS;
		pop.AddSubItem(item);
		item.IsChecked = false;
	}
	//主图类型
	if (MAIN_CHART_KLINE == m_Contract.MainChart)
	{
		item.Index = MENU_BAR_STYLE;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_BAR_STYLE), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddItem(item);
		item.Index = MENU_CANDDLE_STYLE;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_KLINE), sizeof(item.Text) / sizeof(wchar_t) - 1);
		item.IsChecked = m_Chart[0].Style == csK;
		pop.AddSubItem(item);
		item.Index = MENU_BAR_CHART;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_BAR_CHART), sizeof(item.Text) / sizeof(wchar_t) - 1);
		item.IsChecked = m_Chart[0].Style == csUSA;
		pop.AddSubItem(item);
		item.Index = MENU_CLOSE_LINE;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_CLOSE_LINE), sizeof(item.Text) / sizeof(wchar_t) - 1);
		item.IsChecked = m_Chart[0].Style == csPRICE;
		pop.AddSubItem(item);
		item.Index = MENU_TOWER_LINE;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_TOWER_LINE), sizeof(item.Text) / sizeof(wchar_t) - 1);
		item.IsChecked = m_Chart[0].Style == csTWR;
		pop.AddSubItem(item);
		item.IsChecked = false;
	}
	//绘图工具
	item.Index = MUNU_DWAW_LINE;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_DRAWLINE), sizeof(item.Text) / sizeof(wchar_t) - 1);
	item.Begin = true;
	pop.AddItem(item);

	//画线下单
	if (NULL != G_LineOrderApi && (SWS_DrawLine &G_LineOrderApi->GetStartegyWorkState()) != SWS_NONE)
	{
		item.Index = MUNU_LINE_ORDER;
		item.Begin = false;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_LINE_ORDER), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddItem(item);
	}

	//增加删除副图
	item.Begin = true;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_SUB_GRAPH_ADD), sizeof(item.Text) / sizeof(wchar_t) - 1);
	item.Index = MENU_SUB_GRAPH_ADD;
	pop.AddItem(item);
	item.Begin = false;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_SUB_GRAPH_DEL), sizeof(item.Text) / sizeof(wchar_t) - 1);
	item.Index = MENU_SUB_GRAPH_DEL;
	pop.AddItem(item);
    //联动窗口
	item.Begin = false;
	item.Index = MENU_LINKAGE_WINDOW;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_LINKAGE_WINDOW), sizeof(item.Text) / sizeof(wchar_t) - 1);
	item.IsChecked = m_bLinkage;
	pop.AddItem(item);
	item.IsChecked = false;
	//区间放大
	if (MAIN_CHART_TLINE != m_Contract.MainChart&&!m_Contract.IsSpread)
	{
		item.Index = MENU_INTERVAL_AMPLIFICATION;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_INTERVAL_AMPLIFICATION), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddItem(item);
		item.Index = MENU_INTERVAL_STATISTICS;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_INTERVAL_STATISTICS), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddItem(item);
	}
	//叠加合約
	/*item.Index = MENU_OVERLAP_CONTRACT;
	wcsncpy_s(item.Text, G_LANG->LangText(TLI_OVERLAP_CONTRACT), sizeof(item.Text) / sizeof(wchar_t) - 1);
	pop.AddItem(item);*/
	//全屏/恢复
	if (IsShowFullScreenMenu())
	{
		item.Index = MENU_FULLSCREEN_RESTORE;
		wcsncpy_s(item.Text, G_LANG->LangText(TLI_FULLSCREENREATORE), sizeof(item.Text) / sizeof(wchar_t) - 1);
		pop.AddItem(item);
	}


	pop.SetSpi(this);

	POINT p;
	GetCursorPos(&p);
	pop.SetWidth(150);
	pop.ShowPop(p.x, p.y, true, GetWindow()->GetHwnd());
}

void TKLineControl::OnLButtonUp(WORD btn, POINTS& pts)
{
	ReleaseMouse();

	TKLineChart& chart = m_Chart[0];
	RECT r(m_Rects[CENTER_CHART]);
	if (m_bAmplification) //区间放大
	{
		int nStar = m_AxisX.PixelData[m_BeginPoint.x - r.left];
		int nEnd = m_AxisX.PixelData[pts.x - r.left];
		IntervalAmplification(nStar, nEnd);
		Redraw(NULL);
	}
	else if (m_bStatistics)  //区间统计
	{
		int nStar = m_AxisX.PixelData[m_BeginPoint.x - r.left];
		int nEnd = m_AxisX.PixelData[pts.x - r.left];
		IntervalStatistics(nStar, nEnd);
		Redraw(NULL);
	}
	else if (m_MoveOrderId > 0)
	{
		if (pts.x >= r.left && pts.x < r.right && pts.y >= r.top && pts.y < r.bottom)
		{
			double value = (chart.LeftAxisY.MaxValue - (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue) * (m_LineY - chart.LeftRect.top) / (chart.LeftRect.bottom - chart.LeftRect.top)) * 1.0 / chart.LeftAxisY.PrecPow;
			G_LineOrderApi->ModifyDrawLinePice(m_MoveOrderId, value, m_Contract.IsEpoleStarSpreadContract() ? DLT_Spread: DLT_Condition);
			G_LineOrderApi->ResumeStrategyOrder(m_MoveOrderId, m_Contract.IsEpoleStarSpreadContract() ? DLT_Spread : DLT_Condition);
			G_LineOrderApi->SyncModifyWnd(m_MoveOrderId, value, true);
			G_LineOrderApi->CancelDrawLineOperation();
		}
		m_MoveOrderId = 0;
		m_LineY = 0;
		SetCurrCursor(CURSOR_ARROW);
		Redraw(NULL);
	}
	else if (m_pMoveStop)
	{
		if (pts.x >= r.left && pts.x < r.right && pts.y >= r.top && pts.y < r.bottom)
		{
			double value = (chart.LeftAxisY.MaxValue - (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue) * (m_LineY - chart.LeftRect.top) / (chart.LeftRect.bottom - chart.LeftRect.top)) * 1.0 / chart.LeftAxisY.PrecPow;
			if (NULL != G_LineOrderApi)
			{
				TModifyStopDraw modify;
				modify.dPrice = value;
				modify.nType = m_pMoveStop->Type == TYPE_LOSS ? stLoss : stProfit;
				modify.pPosition = m_pMoveStop->pPosition;
				modify.uLocalId = m_pMoveStop->LocalId;
				modify.uQty = m_pMoveStop->Qty;
				G_LineOrderApi->ModifyDrawStopRecord(modify);
				G_LineOrderApi->ResumeDrawStopRecord(m_pMoveStop->pPosition);
				G_LineOrderApi->SyncStopModifyWnd(modify, true);

			}
		}
		m_pMoveStop = NULL;
		SetCurrCursor(CURSOR_ARROW);
		Redraw(NULL);
	}
	else if (m_pMovePosition)
	{
		if (pts.x >= r.left && pts.x < r.right && pts.y >= r.top && pts.y < r.bottom)
		{
			double value = (chart.LeftAxisY.MaxValue - (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue) * (m_LineY - chart.LeftRect.top) / (chart.LeftRect.bottom - chart.LeftRect.top)) * 1.0 / chart.LeftAxisY.PrecPow;
			if (NULL != G_LineOrderApi)
			{
				G_LineOrderApi->SuspendDrawStopRecord(m_pMovePosition->pPosition);
				TAddStopDraw order;
				order.pPosition = m_pMovePosition->pPosition;
				order.dPrice = value;
				G_LineOrderApi->AddDrawStopRecord(order);
			}
		}
		m_pMovePosition = NULL;
		SetCurrCursor(CURSOR_ARROW);
		Redraw(NULL);
	}
	else if (m_ShowCross)
	{
		m_ShowCross = false;
		SetCurrCursor(CURSOR_ARROW);
		Redraw(NULL);
	}
	else if (!m_BeginMove && m_ShowCrossDown && pts.x >= r.left && pts.x < r.right && pts.y >= r.top && pts.y < r.bottom) //
	{
		m_ShowCross = true;
		SetCurrCursor(NULL);
		m_CrossX = pts.x;
		m_CrossY = pts.y;
		TrackMouseLeave();
		Redraw(NULL);
	}
	else if (!m_BeginMove &&m_nSelSub != 0 && pts.x >= r.left && pts.x < r.right && pts.y >= r.top && pts.y < r.bottom)
	{
		Redraw(NULL);
	}
	m_LButtonDown = false;
	m_ShowCrossDown = false;
}

void TKLineControl::OnLButtonDbClk(WORD btn, POINTS& pts)
{

}

void TKLineControl::OnMouseLeave()
{
	m_ShowCross = false;
	m_LineY = 0;
	m_MoveOrderId = 0;
	m_nSelSub = 0;
	m_pMoveStop = NULL;
	m_pMovePosition = NULL;
	SetCurrCursor(CURSOR_ARROW);
	if (g_pDrawTool)
	{
		m_ShapeChart.DeleteShapePen();
	}
	Redraw(NULL);
}

void TKLineControl::OnKeyDown(WPARAM vk, LPARAM lParam)
{
	switch (vk)
	{
	case VK_UP:
		KeyUp();
		break;
	case VK_DOWN:
		KeyDown();
		break;
	case VK_LEFT:
		KeyLeft();
		break;
	case VK_RIGHT:
		KeyRight();
		break;
	case VK_PRIOR://pageup
		((TQuoteFrame*)GetWindow())->ChangeKLineContractUp();
		break;
	case VK_NEXT://pagedown
		((TQuoteFrame*)GetWindow())->ChangeKLineContractDown();
		break;
	case VK_ESCAPE:
		KeyEsc();
		break;
	case VK_RETURN:
		KeyReturn();
		break;
	case VK_F3:
		((TQuoteFrame*)GetWindow())->KeyF3();
		break;
	case VK_F4:
		((TQuoteFrame*)GetWindow())->KeyF4();
		break;
	case VK_F5:
		KeyF5();
		break;
	case VK_F6:
		((TQuoteFrame*)GetWindow())->KeyF6();
		break;
	case VK_F8:
		KeyF8();
		break;
	default:
	{
		if (G_CommonApi && !G_CommonApi->GetFastOrderWorkState())
			LinkageQuickMacro("OnKeyDown", vk);
		break;
	}
	}

	m_PreVK = vk;

}

void TKLineControl::OnMouseWheel(short rot, WORD btn, POINTS& pts)
{
	if (0 == rot)
		return;

	if (rot > 0)
		rot = max(rot, WHEEL_DELTA);
	else
		rot = min(rot, -1 * WHEEL_DELTA);

	int done = -1 * (int)ceil(rot / WHEEL_DELTA);

	if (done < 0)
	{
		if (btn == MK_CONTROL)
			KeyUp();
		else
			((TQuoteFrame*)GetWindow())->ChangeKLineContractUp();
	}
	else if (done > 0)
	{
		if (btn == MK_CONTROL)
			KeyDown();
		else
			((TQuoteFrame*)GetWindow())->ChangeKLineContractDown();
	}
}

void TKLineControl::OnPopMenuClick(TDuiPopMenuItem* obj)
{
	if (NULL == obj)
		return;

	if (obj->Index >= TLI_KLINE_TIME && obj->Index <= TLI_KLINE_YEAR1)	//周期切换
	{
		SwitchLineTypeAndRedow((TLangIndex_PolestarQuote)obj->Index);
	}
	else if (obj->Index >= TLI_CUSTOM_BEGIN&&obj->Index <= TLI_CUSTOM_END)
	{
		int arrIdx = obj->Index - TLI_CUSTOM_BEGIN;
		m_nSelCustom = arrIdx;
		TKLinePeriod prd = m_arrUserPeriod[arrIdx];
		SwitchLineTypeByCustom(prd);
	}
	else if (obj->Index == TLI_MANAGE)
	{
		((TQuoteFrame*)GetWindow())->OpenCustomPeriodDlg();
	}
	else if (obj->Index >= 111 && obj->Index <= 112)	//打开关闭副图
	{
		if (obj->Index == MENU_SUB_GRAPH_ADD)
		{
			for (int i = 1; i < sizeof(m_Chart) / sizeof(TKLineChart); i++)
			{
				if (!m_Chart[i].Visible)
				{
					m_Chart[i].Visible = true;
					break;
				}
				if (i >= 6)
				{
					MessageBox(GetWindow()->GetHwnd(), G_LANG->LangText(TLI_ADDSUBGRAPHYTIP), G_LANG->LangText(TLI_TIPINFO), MB_ICONINFORMATION);
				}
			}
		}
		else if (obj->Index == MENU_SUB_GRAPH_DEL)
		{
			bool bDeleate = false;
			if (m_nSelSub < sizeof(m_Chart) / sizeof(TKLineChart) && m_nSelSub>0 && m_Chart[m_nSelSub].Visible)
			{
				m_Chart[m_nSelSub].Visible = false;
				bDeleate = true;
			}
			for (int i = sizeof(m_Chart) / sizeof(TKLineChart) - 1; i > 0; i--)
			{
				if (m_Chart[i].Visible)
				{
					if (bDeleate)
						m_nSelSub = i;
					else
						m_Chart[i].Visible = false;
					break;
				}
			}
		}
		Assign_SubChart();
		CalculateRects();
		Redraw(NULL);
		SetFocus();
	}
	else if (obj->Index >= 2000 && obj->Index < 2000 + CIndexMgr::GetInstance()->GetSubIndexCount())	//副图指标切换
	{
		int nId =  CIndexMgr::GetInstance()->GetMainIndexCount();
		CIndex* pIndex = CIndexMgr::GetInstance()->GetIndex((INDEX_SPEC)(obj->Index+ nId - 2000));
		if (pIndex)
		{
			SetChartSpace(((TKLineChart*)obj->Value)->KChartSpec[0], pIndex, true);
			Redraw(NULL);
			SetFocus();
		}		
	}
	else if (obj->Index == 2000 + CIndexMgr::GetInstance()->GetSubIndexCount())
	{
		ModifySubParam((TKLineChart*)obj->Value);
	}
	else if (obj->Index >= 1000 && obj->Index < 1000 + CIndexMgr::GetInstance()->GetMainIndexCount()) //主图指标切换
	{
		if (obj->Index >= 1000 && obj->Index < 997 + CIndexMgr::GetInstance()->GetMainIndexCount())
		{
			CIndex* pIndex = CIndexMgr::GetInstance()->GetIndex((INDEX_SPEC)(obj->Index - 997));
			if (pIndex)
			{
				m_Chart[0].KChartSpec[0].Visible = true;
				m_Chart[0].KChartSpec[1].Visible = false;
				if (MAIN_CHART_KLINE == m_Contract.MainChart)
				{
					SetChartSpace(m_Chart[0].KChartSpec[1], pIndex, true);
					m_Chart[0].KChartSpec[1].Visible = true;
				}
				Redraw(NULL);
				SetFocus();
			}
		}
		/*else if (obj->Index > 1000&& obj->Index < 997+ CIndexMgr::GetInstance()->GetMainIndexCount())
		{
			CIndex* pIndex = CIndexMgr::GetInstance()->GetIndex((INDEX_SPEC)(obj->Index - 997));
			if (pIndex)
			{
				m_Chart[0].KChartSpec[0].Visible = false;
				SetChartSpace(m_Chart[0].KChartSpec[1], pIndex, true);
				m_Chart[0].KChartSpec[1].Visible = true;
				Redraw(NULL);
				SetFocus();
			}
		}*/
		else if (obj->Index == 997 + CIndexMgr::GetInstance()->GetMainIndexCount())
		{
			ModifyMaParam();
		}
		else if (obj->Index == 998 + CIndexMgr::GetInstance()->GetMainIndexCount())
		{
			m_Chart[0].KChartSpec[0].Visible = false;
			m_Chart[0].KChartSpec[1].Visible = false;
			Redraw(NULL);
			SetFocus();
		}
	}
	else if (obj->Index >= 31 && obj->Index <= 35)
	{
		((TQuoteFrame*)GetWindow())->OpenClosePanel(obj->Index);
		SetFocus();
	}
	else if (obj->Index >= MENU_CANDDLE_STYLE && obj->Index <= MENU_TOWER_LINE)
	{
		m_Chart[0].Style = (KLINE_STYLE)(obj->Index - MENU_CANDDLE_STYLE);
		Redraw(NULL);
	}
	else //右键菜单
	{
		switch (obj->Index)
		{
		case MENU_ADD_SELF_PLATE:
			AddSelfPlate(obj);
			break;
		case MENU_SWITCH_GRID:
			((TQuoteFrame*)GetWindow())->SwitchToGrid();
			break;
		case MUNU_RELOAD_HISQUOTE:		//重载数据
		{
			if (NULL != m_Contract.Cont)
			{
				SSessionIdType sid;
				G_StarApi->ReloadHisQuote(m_Contract.Cont->ContractNo, m_Contract.KLineType, sid);
			}
		}
		break;
		case MUNU_SYMMETRIC_AXIS:
			m_TLineType = TLINE_SYMMETRIC_AXIS;
			Redraw(NULL);
			break;
		case MUNU_LIMIT_AXIS:
			m_TLineType = TLINE_LIMIT_AXIS;
			Redraw(NULL);
			break;
		case MUNU_FULL_AXIS:
			m_TLineType = TLINE_FULL_AXIS;
			Redraw(NULL);
			break;
		case MUNU_DWAW_LINE:
			((TQuoteFrame*)GetWindow())->OpenDrawToolDlg();
			break;
		case MUNU_LINE_ORDER:
			if (NULL != G_LineOrderApi)
			{
				G_LineOrderApi->PopupDrawlineWnd();
			}
			break;
		case MENU_DEL_SINGLE_SHAPE:
			m_ShapeChart.DeleteSingleShape();
			Redraw(NULL);
			break;
		case MENU_DEL_ALL_SHAPES:
			m_ShapeChart.DeleteAlleShape();
			Redraw(NULL);
			break;
		case MENU_FULLSCREEN_RESTORE:
			G_MainFrame->SwitchTitleBarShow();
			break;
		case MENU_LINKAGE_WINDOW:
			m_bLinkage = !m_bLinkage;
			Redraw(NULL);
			break;
		case MENU_OVERLAP_CONTRACT:
			OnOverlapContract();
			break;
		case MENU_INTERVAL_AMPLIFICATION:
			m_bAmplification = true;
			break;
		case MENU_INTERVAL_STATISTICS:
			m_bStatistics = true;
			break;
		case MENU_PRICE_ALERT:
			((TQuoteFrame*)GetWindow())->PriceAlertLinkage();
			break;
		default:
			break;
		}

	}

	((TQuoteFrame*)GetWindow())->SaveCfg();
}




void TKLineControl::CalculateRects()
{
	//------------------------------------------------------------------------------------------------------------------------------------------------------------
	//划分五大区域，优先级	top、bottom、left、right、center
	//------------------------------------------------------------------------------------------------------------------------------------------------------------
	RECT cr;
	GetRect(cr);
		//TOP							//包含 左上角和右上角	
	RECT& top_r(m_Rects[TOP]);
	top_r = cr;
	top_r.bottom = (top_r.top + TOP_HEIGHT <= cr.bottom) ? (top_r.top + TOP_HEIGHT) : top_r.top;	//固定高度 TOP_HEIGHT 或者 0

	//BOTTOM						//包含 左下角和右下角
	RECT& bottom_r(m_Rects[BOTTOM]);
	bottom_r = cr;
	bottom_r.top = (bottom_r.bottom - BOTTOM_HEIGHT >= top_r.bottom) ? bottom_r.bottom - BOTTOM_HEIGHT : bottom_r.bottom;	//固定高度 BOTTOM_HEIGHT 或者 0	

	//LEFT							//不含 左上角和左下角
	RECT& left_r(m_Rects[LEFT]);
	left_r.top = top_r.bottom;
	left_r.bottom = bottom_r.top;
	left_r.left = cr.left;
	int left_width = (m_Contract.Deno > 1) ? LEFT_WIDTH + WIDTH_EX : LEFT_WIDTH;
	left_r.right = (left_r.left + left_width <= cr.right) ? (left_r.left + left_width) : left_r.left;	//固定宽度 LEFT_WIDTH + LEFT_WIDTH_EX 或者 0

	//RIGHT							//不含 右上角和右下角	
	RECT& right_r(m_Rects[RIGHT]);
	right_r.top = top_r.bottom;
	right_r.bottom = bottom_r.top;
	right_r.right = cr.right;
	right_r.left = cr.right;
	int right_width = (m_Contract.Deno > 1) ? RIGHT_WIDTH + WIDTH_EX : RIGHT_WIDTH;
	if (MAIN_CHART_TLINE == m_Contract.MainChart)	//仅分时图有此区域
		right_r.left = (right_r.right - right_width >= left_r.right) ? right_r.right - right_width : right_r.right;

	//CENTER						//中间区域
	RECT& center_r(m_Rects[CENTER]);
	center_r.left = left_r.right;
	center_r.right = right_r.left;
	center_r.top = top_r.bottom;
	center_r.bottom = bottom_r.top;

	//------------------------------------------------------------------------------------------------------------------------------------------------------------
	//五大区域内部划分
	//------------------------------------------------------------------------------------------------------------------------------------------------------------
	//TOP_LINKAGE
	RECT& top_linkage_r(m_Rects[TOP_LINKAGE]);
	top_linkage_r = m_Rects[TOP];
	if (top_linkage_r.top < top_linkage_r.bottom)
		top_linkage_r.bottom -= LINE_WIDTH;
	if (top_linkage_r.right - top_linkage_r.left >= TOP_LINKAGE_WIDTH)
		top_linkage_r.right = top_linkage_r.left + TOP_LINKAGE_WIDTH;
		//TOP_CONTRACT
	RECT& top_contract_r(m_Rects[TOP_CONTRACT]);
	top_contract_r = m_Rects[TOP];
	if (top_contract_r.top < top_contract_r.bottom)
		top_contract_r.bottom -= LINE_WIDTH;
	top_contract_r.left = top_linkage_r.right;
	if (top_contract_r.right - top_contract_r.left >= TOP_CONTRACT_WIDTH)
		top_contract_r.right = top_contract_r.left + TOP_CONTRACT_WIDTH;

	//TOP_KCYCLE
	RECT& top_kcycle_r(m_Rects[TOP_KCYCLE]);
	top_kcycle_r = m_Rects[TOP];
	if (top_kcycle_r.top < top_kcycle_r.bottom)
		top_kcycle_r.bottom -= LINE_WIDTH;
	//if (top_kcycle_r.right - TOP_KCYCLE_WIDTH >= top_contract_r.right)
		top_kcycle_r.left = top_kcycle_r.right - TOP_KCYCLE_WIDTH;
	//else
	//	top_kcycle_r.left = top_kcycle_r.right;

	//LEFT CHART					  //不含右侧红线
	RECT& left_chart_r(m_Rects[LEFT_CHART]);
	left_chart_r = left_r;
	if (left_chart_r.left < left_chart_r.right - LINE_WIDTH)
		left_chart_r.right -= LINE_WIDTH;

	//RIGHT CHART					//不含右侧红线，不含副图高度
	RECT& right_chart_r(m_Rects[RIGHT_CHART]);
	right_chart_r = right_r;
	if (right_chart_r.left + LINE_WIDTH < right_chart_r.right)
		right_chart_r.left += LINE_WIDTH;

	//CENTER CHART
	RECT& center_chart_r(m_Rects[CENTER_CHART]);
	center_chart_r = center_r;

	//------------------------------------------------------------------------------------------------------------------------------------------------------------
	//副图区域计算，重新按比例分配大小
	//------------------------------------------------------------------------------------------------------------------------------------------------------------
	m_Chart[0].Visible = true;

	int all_height(0);
	int act_height(center_chart_r.bottom - center_chart_r.top);
	if (act_height == 0)
		return;
	//统计总高度
	for (int i = 0; i < sizeof(m_Chart) / sizeof(TKLineChart); i++)
	{
		TKLineChart& c = m_Chart[i];
		c.Height = max(c.Height, 1);
		if (c.Visible)
			all_height += c.Height;
	}

	//重新分配高度
	int rest_height(act_height);
	for (int i = sizeof(m_Chart) / sizeof(TKLineChart) - 1; i > 0; i--)
	{
		TKLineChart& c = m_Chart[i];
		if (!c.Visible)
			continue;

		c.Height = c.Height * act_height / all_height;
		rest_height -= (c.Height + LINE_WIDTH);
	}
	m_Chart[0].Height = rest_height;

	//计算绘图区域
	int curr_height(0);
	for (int i = 0; i < sizeof(m_Chart) / sizeof(TKLineChart); i++)
	{
		TKLineChart& c = m_Chart[i];
		if (!c.Visible)
			continue;

		c.CenterRect = center_chart_r;
		c.LeftRect = left_chart_r;
		c.RightRect = right_chart_r;

		c.CenterRect.top += curr_height;
		c.CenterRect.bottom = c.CenterRect.top + c.Height;

		c.CenterChartRect = c.CenterRect;
		if (c.CenterChartRect.top + CHART_TEXT_HEIGHT <= c.CenterChartRect.bottom)
			c.CenterChartRect.top += CHART_TEXT_HEIGHT;

		if (0 == i)	//第一个图预留底部文字区域
		{
			if (c.CenterChartRect.top <= c.CenterChartRect.bottom - CHART_TEXT_HEIGHT)
				c.CenterChartRect.bottom -= CHART_TEXT_HEIGHT;
		}

		c.CenterTopRect = c.CenterRect;
		c.CenterTopRect.bottom = c.CenterChartRect.top;
		
		c.CenterSpecRect = c.CenterTopRect;
		c.CenterSpecRect.right = c.CenterSpecRect.left + (c.CenterTopRect.bottom- c.CenterTopRect.top);

		c.CenterTopRect.left = c.CenterSpecRect.right;

		c.CenterBottomRect = c.CenterRect;
		c.CenterBottomRect.top = c.CenterChartRect.bottom;

		if (0 == i)	//留白
		{
			if (c.CenterChartRect.top + CHART_TEXT_HEIGHT <= c.CenterChartRect.bottom)
				c.CenterChartRect.top += CHART_TEXT_HEIGHT;
			if (c.CenterChartRect.top <= c.CenterChartRect.bottom - CHART_TEXT_HEIGHT)
				c.CenterChartRect.bottom -= CHART_TEXT_HEIGHT;
		}
		c.LeftRect.top = c.CenterChartRect.top;
		c.LeftRect.bottom = c.CenterChartRect.bottom;

		c.RightRect.top = c.CenterChartRect.top;
		c.RightRect.bottom = c.CenterChartRect.bottom;

		curr_height += c.Height + LINE_WIDTH;
	}
}

void TKLineControl::PrepareAxisX()
{
	m_CanZoomOut = false;

	//拷贝数据-----------------------------------------------------------------
	memset(&m_AxisX, 0, sizeof(m_AxisX));
	if (!m_Contract.CopyTo(m_AxisX.KData))
		return;
	m_AxisX.Begin = m_AxisX.KData.WriteIndex;

	RECT cc_r = m_Rects[CENTER_CHART];
	int pb = cc_r.left;									//绘图起始位置
	int pw = cc_r.right - cc_r.left;					//绘图整体宽度

	if (MAIN_CHART_TLINE == m_Contract.MainChart)//分时图
	{
		//定位起始索引，显示当前交易日数据------------------------------------------
		SContract* contract(m_Contract.Cont);
		if (NULL == contract)
			return;

		//分时图，在无成交量时，不画分时图
		SQuoteSnapShot* q(contract->SnapShot);
		if (q)
		{
			SQuoteField& field = q->Data[S_FID_TOTALQTY];
			/*if (FidAttr_None == field.FidAttr || field.Qty <= 0)
			return;*/

			if (!m_AxisX.KData.IsEmpty())
			{
				SHisQuoteData& d = m_AxisX.KData.Tail();
				//行情日期 小于等于 数据自然日或交易日
				SQuoteField& ut = q->Data[S_FID_DATETIME];
				if (ut.DateTime / 1000000000LL <= d.DateTimeStamp / 1000000000LL
					|| ut.DateTime / 1000000000LL <= d.TradeDate)	//处理集合竞价时 有成交量，但是还没开盘的问题
					m_AxisX.TradeDate = d.TradeDate;
			}
		}

		while (m_AxisX.Begin != m_AxisX.KData.ReadIndex)
		{
			int cindex = (m_AxisX.Begin - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
			SHisQuoteData& d = m_AxisX.KData.GetData(cindex);
			if (d.TradeDate != m_AxisX.TradeDate)
				break;
			m_AxisX.Begin = cindex;
		}

		//分时图根据KLineIndex生成虚拟数据-----------------------------------------
		TKLineData tmpdata;
		memcpy_s(&tmpdata, sizeof(TKLineData), &m_AxisX.KData, sizeof(TKLineData));
		tmpdata.ReadIndex = m_AxisX.Begin;

		memset(&m_AxisX.KData, 0, sizeof(TKLineData));
		int calcount = G_StarApi->GetCalTimeBucketCount(contract->Commodity->CommodityNo);
		if (calcount == 0)
			return;
		m_AxisX.KData.WriteIndex = calcount;
		m_AxisX.Begin = 0;
		m_AxisX.End = 0;

		int tmpbegin = tmpdata.ReadIndex;
		for (int i = 0; i < calcount; i++)	//计算模版最大值24*60，小于MAX_SHOW_KLINE_X，此处无需考虑越界
		{
			SHisQuoteTimeBucket* tb = G_StarApi->GetCalTimeBucketData(contract->Commodity->CommodityNo, i);
			SHisQuoteData& d = m_AxisX.KData.GetData(i);

			SHisQuoteData& s = tmpdata.GetData(tmpbegin);
			if (tmpbegin != tmpdata.WriteIndex)
			{
				//按时间判断，索引切换时间模板会错
				//if (tb->Index == s.KLineIndex)
				if (tb->EndTime == s.DateTimeStamp % 1000000000LL)
				{
					if (tmpbegin == tmpdata.ReadIndex)	//记录开头
						m_AxisX.Begin = i;

					d = s;
					tmpbegin = (tmpbegin + 1) % MAX_SHOW_KLINE_X;

					m_AxisX.End = i + 1;//if (tmpbegin == tmpdata.WriteIndex)	//记录结尾 2016-07-25修正	
				}
				else if (i > 0)
				{
					d = m_AxisX.KData.GetData(i - 1);
					d.QKLineQty = 0;
				}
			}

			d.KLineIndex = tb->Index;
			d.TradeDate = m_AxisX.TradeDate;
			d.DateTimeStamp = tb->EndTime;
		}

		//根据K线索引分配----------------------------------------------------------
		int pos(0);
		int curr = m_AxisX.KData.ReadIndex; //m_AxisX.Begin;

		while (curr != m_AxisX.KData.WriteIndex)
		{
			int i = (curr - m_AxisX.KData.ReadIndex /*- m_AxisX.Begin*/ + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
			SHisQuoteData& d = m_AxisX.KData.GetData(curr);
			int w = (d.KLineIndex + 1) * pw / calcount;

			m_AxisX.DataPos[i] = pos;

			if (w > pos)
			{
				m_AxisX.DataWidth[i] = (w - pos);
				pos = w;
			}
			else
			{
				m_AxisX.DataWidth[i] = 0;
			}

			curr = (curr + 1) % MAX_SHOW_KLINE_X;
		}

		//计算tagline--------------------------------------------------------------
		int tagindex(0);
		int basecount = G_StarApi->GetBaseTimeBucketCount(contract->Commodity->CommodityNo);
		for (int i = 0; i < basecount; i++)	//输出底边文字时 不跳过第一个
		{
			SHisQuoteTimeBucket* tb1 = G_StarApi->GetBaseTimeBucketData(contract->Commodity->CommodityNo, i);
			SHisQuoteTimeBucket* tb2 = G_StarApi->GetBaseTimeBucketData(contract->Commodity->CommodityNo, i + 1);
			int w = tb1->CalCount * pw / calcount;

			if (i >= sizeof(m_AxisX.TagLine) / sizeof(TKLineTagLine))
				break;
			TKLineTagLine& tag = m_AxisX.TagLine[tagindex++];
			tag.ShowText = true;
			tag.ShowDotLine = (i != 0 && i != basecount - 1);
			tag.Pixel = w;
			tag.BeginTime = tb1->BeginTime;

			if (NULL != tb2 && tb1->CalCount == tb2->CalCount)
			{
				tag.EndTime = tb2->BeginTime;
				i++;	//跳过下一条，不再输出标线
			}

		}
	}
	else//K线图
	{
		//定位起始索引，显示界面能容纳的数据---------------------------------------
		TKLineShapeType& ks = G_QuoteUtils.KLineShapes[m_Contract.KLineShape];
		int r_width = ((m_Contract.Deno > 1) ? RIGHT_WIDTH + WIDTH_EX : RIGHT_WIDTH);
		pw = (pw - r_width > 0) ? (pw - r_width) : 0;
		int kc = pw / ks.AreaWidth;
		int starIndex = m_AxisX.KData.ReadIndex;

		while ((m_AxisX.Begin != starIndex) && (kc > 0))
		{
			m_AxisX.Begin = (m_AxisX.Begin - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
			kc--;
		}
		m_AxisX.End = m_AxisX.KData.WriteIndex;

		m_CanZoomOut = (0 == kc);

		//根据固定宽度定位----------------------------------------------------------
		kc = 0;
		int pos(0);
		int curr = m_AxisX.Begin;
		while (curr != m_AxisX.End)
		{
			int i = (curr - m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
			m_AxisX.DataPos[i] = pos;
			m_AxisX.DataWidth[i] = ks.AreaWidth;
			pos += ks.AreaWidth;
			kc++;

			curr = (curr + 1) % MAX_SHOW_KLINE_X;
		}

		//计算tagline---------------------------------------------------------------
		int w = kc * ks.AreaWidth;
		int init_space(240);
		int curr_space(init_space);
		curr = m_AxisX.End;
		for (int i = 0; i < sizeof(m_AxisX.TagLine) / sizeof(TKLineTagLine); i++)
		{
			TKLineTagLine& tag = m_AxisX.TagLine[i];

			while (curr != m_AxisX.Begin)
			{
				curr = (curr - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
				SHisQuoteData& d = m_AxisX.KData.GetData(curr);
				curr_space += ks.AreaWidth;
				w -= ks.AreaWidth;
				if (curr_space > init_space)
				{
					tag.ShowText = true;
					tag.Pixel = w + ks.AreaWidth / 2 + 1;
					tag.BeginTime = d.DateTimeStamp;
					curr_space = 0;
					break;
				}
			}

			if (curr == m_AxisX.Begin)
				break;
		}
	}

	m_AxisX.Curr = m_AxisX.End;
	m_AxisX.Min = m_AxisX.End;
	m_AxisX.Max = m_AxisX.End;

	//计算像素值对应的数据-----------------------------------------------------------
	int pos(0);
	int curr = m_AxisX.Begin;
	if (MAIN_CHART_TLINE == m_Contract.MainChart)
		curr = m_AxisX.KData.ReadIndex;
	while (curr != m_AxisX.KData.WriteIndex)
	{
		int i = 0;
		if (MAIN_CHART_TLINE == m_Contract.MainChart)
			i = (curr - m_AxisX.KData.ReadIndex + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		else
			i = (curr - m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
		int w = m_AxisX.DataWidth[i];
		for (int j = pos; j < pos + w; j++)
		{
			m_AxisX.PixelData[j] = curr;
		}

		pos += w;

		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}

	//计算十字标线x轴----------------------------------------------------------------
	m_CrossTextX[0] = L'\0';
	m_CrossTextY[0] = L'\0';
	if (m_ShowCross|| m_bAmplification|| m_bStatistics)
	{
		//重置光标线
		if (m_bCalCross)
		{
			int curr = m_AxisX.Begin;
			while (curr != m_AxisX.End)
			{
				SHisQuoteData& d = m_AxisX.KData.GetData(curr);
				if (d.DateTimeStamp >= m_PreDateTime)
				{
					TKLineChart& chart = m_Chart[0];
					RECT r(chart.CenterChartRect);
					int i = (curr - m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
					int nMid = r.left + (r.right - r.left) / 2;
					int nXPos = r.left + m_AxisX.DataPos[i] + m_AxisX.DataWidth[i] / 2;
					/*if ((m_CrossX <= nMid&&nXPos >= nMid) || (m_CrossX >= nMid&&nXPos <= nMid))
					{
						int nMidInx = (m_AxisX.End - m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X / 2;
						int nMidPos = r.left + m_AxisX.DataPos[nMidInx] + m_AxisX.DataWidth[nMidInx] / 2;
						m_CrossX = nMidPos;
						m_CrossY = r.top + (int)((r.bottom - r.top) * (chart.LeftAxisY.MaxValue - d.QLastPrice * chart.LeftAxisY.PrecPow) / (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue));
					}
					else*/
					{
						m_AxisX.Curr = curr;
						m_CrossX = nXPos;
						m_CrossY = r.top + (int)((r.bottom - r.top) * (chart.LeftAxisY.MaxValue - d.QLastPrice * chart.LeftAxisY.PrecPow) / (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue));
					}	
					break;
				}
				curr = (curr + 1) % MAX_SHOW_KLINE_X;
			}
			m_bCalCross = false;
		}
		int data_index = 0;
		if (MAIN_CHART_TLINE == m_Contract.MainChart)
			data_index = (m_AxisX.KData.WriteIndex - m_AxisX.KData.ReadIndex + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X - 1;
		else
			data_index = (m_AxisX.End - m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X - 1;
		if (data_index >= 0)
		{
			int width = m_AxisX.DataPos[data_index] + m_AxisX.DataWidth[data_index];
			int cx_index = m_CrossX - cc_r.left;
			if (cx_index >= 0 && cx_index < width)
			{
				m_AxisX.Curr = m_AxisX.PixelData[cx_index];	//当前数据
				SHisQuoteData& d = m_AxisX.KData.GetData(m_AxisX.Curr);
				/*if (m_Contract.IsSpread)
					d = m_AxisX.SpreadKLineData.Data[m_AxisX.Curr];*/
				SDateType date = (SDateType)(d.DateTimeStamp / 1000000000LL);
				STimeType time = d.DateTimeStamp % 1000000000LL / 1000LL;

				if (date > 0 && time > 0)
				{
					swprintf_s(m_CrossTextX, L"%04d/%02d/%02d %02d:%02d:%02d", date / 10000, date / 100 % 100, date % 100, time / 10000, time / 100 % 100, time % 100);
				}
				else if (date > 0)
				{
					if (date % 100 > 0)
						swprintf_s(m_CrossTextX, L"%04d/%02d/%02d", date / 10000, date / 100 % 100, date % 100);
					else if (date % 10000 > 0)
						swprintf_s(m_CrossTextX, L"%04d/%02d", date / 10000, date / 100 % 100);
					else
						swprintf_s(m_CrossTextX, L"%04d", date / 10000);
				}
				else
				{
					swprintf_s(m_CrossTextX, L"%02d:%02d:%02d", time / 10000, time / 100 % 100, time % 100);
				}
			}
		}
	}

	//尾部索引当前值前移
	if (m_AxisX.Begin != m_AxisX.End && m_AxisX.Curr == m_AxisX.End)
		m_AxisX.Curr = (m_AxisX.Curr - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
}

void TKLineControl::PrepareAxisY()
{
	SContract* contract(m_Contract.Cont);

	//图形遍历
	for (int i = 0; i < sizeof(m_Chart) / sizeof(TKLineChart); i++)
	{
		TKLineChart& chart = m_Chart[i];
		if (!chart.Visible)
			continue;

		//初始化内存
		memset(&chart.LeftAxisY, 0, sizeof(TKLineAxisY));
		memset(&chart.RightAxisY, 0, sizeof(TKLineAxisY));
		if (NULL == contract)
			continue;

		//预设价格精度，最小变动价放大100倍
		if (m_Contract.Deno > 1)
			chart.LeftAxisY.PrecPow = (long long)(m_Contract.Deno * 100LL);
		else
		{
			//此两行合并，会造成double转long long时出现乱码
			SCommodityPrecType Prec = m_Contract.Prec;
			if (m_Contract.IsSpread)
				Prec = m_Contract.SpreadPrec;
			double pp = ::pow(10, Prec + 2);
			chart.LeftAxisY.PrecPow = (long long)pp;
		}

	}
}


void TKLineControl::DrawTop(HDC mdc, RECT& cr)
{
	RECT top_r(m_Rects[TOP]);
	if (top_r.left >= top_r.right || top_r.top >= top_r.bottom)
		return;

	//底部红线	
	SelectObject(mdc, PEN_KLINE_GRID_LINE);
	MoveToEx(mdc, top_r.left, top_r.bottom - 1, 0);
	LineTo(mdc, top_r.right, top_r.bottom - 1);

	//合约名称 及 选择标识
	if (NULL == m_Contract.Cont)
		return;

	SelectObject(mdc, FONT_KLINE_TEXT);
	SetTextColor(mdc, COLOR_KLINE_MENU_TEXT);

	RECT top_contract_r(m_Rects[TOP_CONTRACT]);
	RECT top_kcycle_r(m_Rects[TOP_KCYCLE]);
	RECT top_linkage_r(m_Rects[TOP_LINKAGE]);

	//绘制联动窗口图标
	DrawLinkageWindowIcon(mdc, top_linkage_r);

	SContractNoType conNo = { 0 };
	if (m_Contract.IsSpread)
		strcpy_s(conNo, m_Contract.SpreadNo);
	else
		strcpy_s(conNo, m_Contract.Cont->ContractNo);

	wchar_t con_name[101]=L"";
	if (top_contract_r.right > top_contract_r.left
		&& GetContractName(G_StarApi, conNo, con_name))
	{
		wcsncat_s(con_name, L" / ", 3);
		if (GetContractCode(G_StarApi, conNo, &con_name[wcslen(con_name)]))
		{
			RECT r(top_contract_r);
			r.left += 2 * PADDING_X;
			DrawText(mdc, con_name, wcslen(con_name), &r, DT_NOPREFIX | DT_LEFT | DT_SINGLELINE | DT_VCENTER);
		}
	}
	else
	{
		wcsncat_s(con_name, L" / ", 3);
		MultiByteToWideChar(1252, 0, conNo, -1, con_name, sizeof(con_name) / sizeof(wchar_t));
		RECT r(top_contract_r);
		r.left += 2 * PADDING_X;
		DrawText(mdc, con_name, wcslen(con_name), &r, DT_NOPREFIX | DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	}

	//K线周期 及 类型选择标识
	if (top_kcycle_r.right > top_kcycle_r.left)
	{
		RECT r(top_kcycle_r);
		r.right -= (r.bottom - r.top);
		if (m_nSelCustom == -1)
		{
			int li = GetCfg();
			DrawText(mdc, G_LANG->LangText(li), wcslen(G_LANG->LangText(li)), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
		}
		else
		{
			if (m_nSelCustom >= 0 && m_nSelCustom < m_arrUserPeriod.size())
			{
				TKLinePeriod period = m_arrUserPeriod[m_nSelCustom];
				wchar_t Tip[21];
				swprintf_s(Tip, L"%d%s", period.multi, G_LANG->LangText(TLI_CUSTOM_END + period.kind));
				DrawText(mdc, Tip, wcslen(Tip), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
			}
		}

		//下箭头
		SelectObject(mdc, PEN_KLINE_CYCLE);
		r = top_kcycle_r;
		r.left = r.right - (r.bottom - r.top);
		Draw_Arraw(mdc, r, D_DOWN);
	}
}
void TKLineControl::DrawLinkageWindowIcon(HDC mdc, RECT& cr)
{
	if (!m_bRegToolTip)
	{
		AddRectTool(0, cr, (LPWSTR)G_LANG->LangText(TLI_LINKAGE_WINDOW));
		m_bRegToolTip = true;
	}
	SelectObject(mdc, PEN_TLINE_PRICE);

	int L_Gap =9,T_Gap = 10,Pad = 2;
	int M_Pos = cr.left + (cr.right - cr.left+ L_Gap) / 2;
	MoveToEx(mdc, M_Pos- Pad, cr.top + T_Gap,0);
	LineTo(mdc, cr.left + L_Gap, cr.top + T_Gap);
	LineTo(mdc, cr.left + L_Gap, cr.bottom - T_Gap);
	LineTo(mdc, M_Pos- Pad, cr.bottom - T_Gap);

	MoveToEx(mdc, M_Pos+ Pad, cr.top + T_Gap, 0);
	LineTo(mdc,cr.right, cr.top + T_Gap);
	LineTo(mdc, cr.right, cr.bottom - T_Gap);
	LineTo(mdc, M_Pos+ Pad, cr.bottom - T_Gap);
	if (m_bLinkage)
	{
		MoveToEx(mdc, M_Pos - 3, (cr.top + cr.bottom) / 2, 0);
		LineTo(mdc, M_Pos + 3, (cr.top + cr.bottom) / 2);
	}
	else
	{
		MoveToEx(mdc, M_Pos - 3, cr.top + T_Gap -3, 0);
		LineTo(mdc, M_Pos + 3, cr.bottom -T_Gap + 3);
	}
}

void TKLineControl::DrawBottom(HDC mdc, RECT& cr)
{
	RECT bottom_r(m_Rects[BOTTOM]);
	if (bottom_r.left >= bottom_r.right || bottom_r.top >= bottom_r.bottom)
		return;

	//顶部红线
	SelectObject(mdc, PEN_KLINE_GRID_LINE);
	RECT center_r(m_Rects[CENTER]);
	if (center_r.left - 1 >= cr.left)
		center_r.left--;
	if (center_r.right + 1 <= cr.right)
		center_r.right++;
	MoveToEx(mdc, center_r.left, bottom_r.top, 0);
	LineTo(mdc, center_r.right, bottom_r.top);

	//判断合约
	if (NULL == m_Contract.Cont)
		return;

	//时间轴坐标
	SelectObject(mdc, FONT_KLINE_NUMBER);
	SetTextColor(mdc, COLOR_KLINE_GRID_TEXT);
	center_r = m_Rects[CENTER];

	wchar_t wtext[128];
	RECT r(bottom_r);
	r.top++;

	SIZE size;

	for (int i = 0; i < sizeof(m_AxisX.TagLine) / sizeof(TKLineTagLine); i++)
	{
		TKLineTagLine& tag = m_AxisX.TagLine[i];
		if (!tag.ShowText)
			break;

		SDateType date1 = (SDateType)(tag.BeginTime / 1000000000);
		STimeType time1 = tag.BeginTime % 1000000000;
		STimeType time2 = tag.EndTime % 1000000000;

		if (date1 > 0)
		{
			if (time1 > 0)
			{
				swprintf_s(wtext, L"%04d/%02d/%02d %02d:%02d:%02d", date1 / 10000, date1 / 100 % 100, date1 % 100,
					time1 / 10000000, time1 / 100000 % 100, time1 / 1000 % 100);
			}
			else
			{
				if (date1 % 100 > 0)
					swprintf_s(wtext, L"%04d/%02d/%02d", date1 / 10000, date1 / 100 % 100, date1 % 100);
				else if (date1 % 10000 > 0)
					swprintf_s(wtext, L"%04d/%02d", date1 / 10000, date1 / 100 % 100);
				else
					swprintf_s(wtext, L"%04d", date1 / 10000);
			}
		}
		else if (time2 > 0)
		{
			swprintf_s(wtext, L"%02d:%02d/%02d:%02d", time1 / 10000000, time1 / 100000 % 100, time2 / 10000000, time2 / 100000 % 100);
		}
		else
		{
			swprintf_s(wtext, L"%02d:%02d:%02d", time1 / 10000000, time1 / 100000 % 100, time1 / 1000 % 100);
		}

		GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
		r.left = center_r.left + tag.Pixel - size.cx / 2;
		r.right = r.left + size.cx;

		DrawText(mdc, wtext, wcslen(wtext), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
	}

}

void TKLineControl::DrawLeft(HDC mdc, RECT& cr)
{
	RECT left_r(m_Rects[LEFT]);
	if (left_r.left >= left_r.right || left_r.top >= left_r.bottom)
		return;

	//右侧红线
	SelectObject(mdc, PEN_KLINE_GRID_LINE);
	MoveToEx(mdc, left_r.right - 1, left_r.top, 0);
	LineTo(mdc, left_r.right - 1, left_r.bottom);

}

void TKLineControl::DrawRight(HDC mdc, RECT& cr)
{
	RECT right_r(m_Rects[RIGHT]);
	if (right_r.left >= right_r.right || right_r.top >= right_r.bottom)
		return;

	//左侧红线
	SelectObject(mdc, PEN_KLINE_GRID_LINE);
	MoveToEx(mdc, right_r.left, right_r.top, 0);
	LineTo(mdc, right_r.left, right_r.bottom);
}
void TKLineControl::DrawCenter(HDC mdc, RECT& cr)
{
	RECT center_r(m_Rects[CENTER]);
	if (center_r.left >= center_r.right || center_r.top >= center_r.bottom)
		return;
	//各个图形指标控制箭头
	SelectObject(mdc, PEN_KLINE_CYCLE);
	SelectObject(mdc, FONT_KLINE_NUMBER);
	SetTextColor(mdc, COLOR_KLINE_MENU_TEXT);
	
	for (int i = 0; i < sizeof(m_Chart) / sizeof(TKLineChart); i++)
	{
		TKLineChart& chart = m_Chart[i];
		if (!chart.Visible)
			continue;

		RECT csr(chart.CenterSpecRect);

		if (csr.left < csr.right && csr.top < csr.bottom)
		{
			RECT r(csr);
			r.right = r.left + (r.bottom - r.top);
			Draw_Arraw(mdc, r, D_DOWN);
		}
	}

	//横向图形分割线
	SelectObject(mdc, PEN_KLINE_GRID_LINE);
	for (int i = 1; i < sizeof(m_Chart) / sizeof(TKLineChart); i++)
	{
		TKLineChart& chart = m_Chart[i];
		if (!chart.Visible)
			continue;

		if (chart.CenterRect.left < chart.CenterRect.right && chart.CenterRect.top < chart.CenterRect.bottom)
		{
			MoveToEx(mdc, chart.CenterRect.left, chart.CenterRect.top - 1, 0);
			LineTo(mdc, chart.CenterRect.right, chart.CenterRect.top - 1);
			if (i == m_nSelSub)
			{
				FrameRect(mdc, &chart.CenterRect, BRUSH_KLINE_CROSS);
			}
		}
	}

	//纵向X轴数据背景线
	SelectObject(mdc, PEN_KLINE_GRID_DOTLINE);
	for (int i = 0; i < sizeof(m_AxisX.TagLine) / sizeof(TKLineTagLine); i++)
	{
		TKLineTagLine& tag = m_AxisX.TagLine[i];
		if (!tag.ShowText)
			break;

		if (tag.ShowDotLine)
		{
			int x = center_r.left + tag.Pixel;
			MoveToEx(mdc, x, center_r.top, 0);
			LineTo(mdc, x, center_r.bottom);
		}
	}
}

void TKLineControl::DrawTagLine(HDC mdc, TKLineChart& chart)
{
	SelectObject(mdc, FONT_KLINE_NUMBER);

	//left center
	RECT ccr(chart.CenterChartRect);
	RECT r(chart.LeftRect);
	r.right -= PADDING_X;

	for (int i = 0; i < sizeof(chart.LeftAxisY.TagLine) / sizeof(TKLineTagLine); i++)
	{
		TKLineTagLine& tag = chart.LeftAxisY.TagLine[i];
		if (!tag.ShowText)
			break;

		r.top = chart.LeftRect.top + tag.Pixel - MIN_ZONE_HEIGHT / 2;
		r.bottom = r.top + MIN_ZONE_HEIGHT;

		SetTextColor(mdc, tag.ValueColor);
		DrawText(mdc, tag.ValueText, wcslen(tag.ValueText), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

		if (tag.ShowSolidLine)
			SelectObject(mdc, PEN_KLINE_GRID_LINE);
		else if (tag.ShowDotLine)
			SelectObject(mdc, PEN_KLINE_GRID_DOTLINE);
		else
			continue;

		MoveToEx(mdc, ccr.left, ccr.top + tag.Pixel, 0);
		LineTo(mdc, ccr.right, ccr.top + tag.Pixel);
	}

	//right
	if (chart.RightRect.top >= chart.RightRect.bottom || chart.RightRect.left >= chart.RightRect.right)
		return;

	r = chart.RightRect;
	r.left += PADDING_X;

	for (int i = 0; i < sizeof(chart.RightAxisY.TagLine) / sizeof(TKLineTagLine); i++)
	{
		TKLineTagLine& tag = chart.RightAxisY.TagLine[i];
		if (!tag.ShowText)
			break;

		r.top = chart.RightRect.top + tag.Pixel - MIN_ZONE_HEIGHT / 2;
		r.bottom = r.top + MIN_ZONE_HEIGHT;

		SetTextColor(mdc, tag.ValueColor);
		DrawText(mdc, tag.ValueText, wcslen(tag.ValueText), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	}
}

void TKLineControl::DrawChart(HDC mdc, RECT& cr)
{
	//检查合约
	SContract* contract(m_Contract.Cont);
	if (NULL == contract)
		return;

	//绘制图形
	for (int i = 0; i < sizeof(m_Chart) / sizeof(TKLineChart); i++)
	{
		TKLineChart& chart = m_Chart[i];
		if (!chart.Visible)
			continue;
		//绘制区间统计
		if (i==0&&m_bStatistics&&m_bStatisticsShape)
		{
			RECT rc = chart.CenterChartRect;
			rc.left = m_BeginPoint.x;
			rc.right = m_nEndX;
			COLORREF colbk = RGB(30, 30, 30);
			COLORREF colline = RGB(220, 220, 10);
			if (G_STYLE == GRAY_STYLE)
			{
				colbk = RGB(246, 247, 236);
				colline = RGB(64, 128, 128);
			}
			HBRUSH hBrush = CreateSolidBrush(colbk);
			FillRect(mdc, &rc, hBrush);
			DeleteObject(hBrush);
			DotLine(mdc, m_BeginPoint.x, rc.top, m_BeginPoint.x, rc.bottom, colline);
			DotLine(mdc, m_nEndX, rc.top, m_nEndX, rc.bottom, colline);
		}
		//y轴绘图区域不满足
		if (chart.LeftRect.left >= chart.LeftRect.right || chart.LeftRect.top >= chart.LeftRect.bottom)
			continue;
		chart.CalcAllIndicators(i == 0, MAIN_CHART_TLINE == m_Contract.MainChart);
		//准备Y轴	
		chart.RecalcAxisY(i == 0, MAIN_CHART_TLINE == m_Contract.MainChart);

		//绘图区域不满足
		if (chart.CenterRect.left >= chart.CenterRect.right || chart.CenterRect.top >= chart.CenterRect.bottom)
			continue;

		//绘制tagline
		DrawTagLine(mdc, chart);

		//绘制图形
		chart.DrawChart(mdc,i==0, MAIN_CHART_TLINE == m_Contract.MainChart);

		//绘制指标参数
		chart.DrawLegend(mdc);
	}
	//绘制图形
	m_ShapeChart.DrawChart(mdc);
}

void TKLineControl::DrawTrade(HDC mdc, RECT& cr)
{
	//画线下单不存在
	if (NULL == G_LineOrderApi || NULL == m_Contract.Cont)
		return;

	TKLineChart& chart = m_Chart[0];
	RECT ccr = chart.CenterChartRect;
	if (chart.LeftAxisY.MaxValue <= chart.LeftAxisY.MinValue)
		return;

	//清数据
	memset(m_OrderPixels, 0, sizeof(m_OrderPixels));
	memset(m_PositionPixels, 0, sizeof(m_PositionPixels));
	memset(m_StopPixels, 0, sizeof(m_StopPixels));
	memset(m_Stops, 0, sizeof(m_Stops));
	memset(m_Positions, 0, sizeof(m_Positions));
	memset(m_Orders, 0, sizeof(m_Orders));
	m_Orders[0].OrderId = 0;
	m_Positions[0].PositionNo[0] = '\0';
	int oc(0);
	int pc(0);
	int sc(0);
	//获取数据----------------------------------------------------------------------------------------------------------------------------------------------
	//获取持仓
	TPosition* temp_position_data[MAX_TRADE_DATA_COUNT];
	int temp_position_count = G_LineOrderApi->GetPositionTotal(m_Contract.Cont->ContractNo, temp_position_data, MAX_TRADE_DATA_COUNT);
	for (int i = 0; i < temp_position_count; i++)
	{
		TPosition* d = temp_position_data[i];
		TLinePosition& p = m_Positions[pc++];
		strncpy_s(p.PositionNo, d->PositionNo, sizeof(p.PositionNo) - 1);
		p.Price = d->PositionPrice;
		p.Qty = d->PositionQty;
		p.Direct = d->Direct;
		p.pPosition = d;
		p.Pixel = 0;

		long long value = (long long)(p.Price * chart.LeftAxisY.PrecPow);
		if (value >= chart.LeftAxisY.MinValue && value <= chart.LeftAxisY.MaxValue)
		{
			p.Pixel = ccr.top + (int)((chart.LeftAxisY.MaxValue - value) * (ccr.bottom - ccr.top) / (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue));
			for (int j = 0; j < CHART_TEXT_HEIGHT; j++)
			{
				int pos = p.Pixel - CHART_TEXT_HEIGHT / 2 + j;
				if (pos >= ccr.top && pos < ccr.bottom)
					m_PositionPixels[pos] = &p;
			}
		}

		TPositionDraw Stops[MAX_TRADE_DATA_COUNT];              //止盈止损数据
		int temp_stop_count = G_LineOrderApi->GetPositionStopInfo(0, Stops, MAX_TRADE_DATA_COUNT, d);
		for (int j = 0; j < temp_stop_count; j++)
		{
			TPositionDraw stop = Stops[j];
			for (int k = 0; k < 2; k++)
			{
				if (k == 0 && (stop.nType & stLoss) == 0 || k == 1 && (stop.nType & stProfit) == 0)
				{
					continue;
				}
				TLineStop& s = m_Stops[sc++];
				s.Price = (k == 0 ? stop.dStopLossPrice : stop.dStopProfitPrice);
				s.LocalId = stop.uLocalId;
				s.pPosition = d;
				s.Type = (k == 0 ? TYPE_LOSS : TYPE_PROFIT);
				s.Qty = stop.uStopQty;
				s.Pixel = 0;
				s.PosPixel = p.Pixel;
				long long value = (long long)(s.Price * chart.LeftAxisY.PrecPow);
				if (value >= chart.LeftAxisY.MinValue && value <= chart.LeftAxisY.MaxValue)
				{
					s.Pixel = ccr.top + (int)((chart.LeftAxisY.MaxValue - value) * (ccr.bottom - ccr.top) / (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue));
					for (int m = 0; m < CHART_TEXT_HEIGHT; m++)
					{
						int pos = s.Pixel - CHART_TEXT_HEIGHT / 2 + m;
						if (pos >= ccr.top && pos < ccr.bottom)
							m_StopPixels[pos] = &s;
					}
				}
			}
		}
	}

	//获取委托
	if (m_Contract.IsEpoleStarSpreadContract())
	{
		TSpreadOrder* temp_order_data[MAX_TRADE_DATA_COUNT];
		int temp_order_count = G_LineOrderApi->GetTriggeringSpreadOrders(0, temp_order_data, MAX_TRADE_DATA_COUNT,m_Contract.IsSpread? m_Contract.SpreadNo: m_Contract.Cont->ContractNo);
		for (int i = 0; i < temp_order_count; i++)
		{
			TSpreadOrder* d = temp_order_data[i];
			TLineOrder& o = m_Orders[oc++];
			o.OrderId = d->OrderID;
			o.Price = d->sendorder.OrderPrice;
			o.Qty = d->sendorder.OrderQty;
			o.Direct = d->sendorder.Direct[0];
			o.Offset = d->sendorder.Offset[0];
			o.BackHand = false;
			o.Pixel = 0;

			long long value = (long long)(o.Price * chart.LeftAxisY.PrecPow);
			if (value >= chart.LeftAxisY.MinValue && value <= chart.LeftAxisY.MaxValue)
			{
				o.Pixel = ccr.top + (int)((chart.LeftAxisY.MaxValue - value) * (ccr.bottom - ccr.top) / (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue));

				for (int j = 0; j < CHART_TEXT_HEIGHT; j++)
				{
					int pos = o.Pixel - CHART_TEXT_HEIGHT / 2 + j;
					if (pos >= ccr.top && pos < ccr.bottom)
						m_OrderPixels[pos] = &o;
				}
			}
		}
	}
	else
	{
		TStrategyOrder* temp_order_data[MAX_TRADE_DATA_COUNT];
		int temp_order_count = G_LineOrderApi->GetStrategyOrdersByContractId(m_Contract.Cont->ContractNo, 0, temp_order_data, MAX_TRADE_DATA_COUNT);
		for (int i = 0; i < temp_order_count; i++)
		{
			TStrategyOrder* d = temp_order_data[i];
			TLineOrder& o = m_Orders[oc++];
			o.OrderId = d->StrategyOrderId;
			o.Price = d->TriggerPrice;
			o.Qty = d->OrderQty;
			o.Direct = d->tDirect;
			o.Offset = d->tOffset;
			o.BackHand = d->bBackHand;
			o.Pixel = 0;

			long long value = (long long)(o.Price * chart.LeftAxisY.PrecPow);
			if (value >= chart.LeftAxisY.MinValue && value <= chart.LeftAxisY.MaxValue)
			{
				o.Pixel = ccr.top + (int)((chart.LeftAxisY.MaxValue - value) * (ccr.bottom - ccr.top) / (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue));

				for (int j = 0; j < CHART_TEXT_HEIGHT; j++)
				{
					int pos = o.Pixel - CHART_TEXT_HEIGHT / 2 + j;
					if (pos >= ccr.top && pos < ccr.bottom)
						m_OrderPixels[pos] = &o;
				}
			}

		}
	}
	

	//绘图--------------------------------------------------------------------------------------------------------------------------------------------------

	RECT r = chart.LeftRect;
	wchar_t wtext[128];

	//绘制持仓
	for (int i = 0; i < pc; i++)
	{
		TLinePosition& d = m_Positions[i];
		if (d.Pixel <= 0)
			continue;

		r.top = d.Pixel - CHART_TEXT_HEIGHT;
		r.bottom = d.Pixel;
		
		SetTextColor(mdc, dBuy == d.Direct ? COLOR_LINE_POSITION_BUY: COLOR_LINE_POSITION_SELL);
		SelectObject(mdc, dBuy == d.Direct ? PEN_LINE_POSITION_BUY : PEN_LINE_POSITION_SELL);

		SelectObject(mdc, FONT_KLINE_TEXT);
		swprintf_s(wtext, L"%s%d%s", G_LANG->LangText(dBuy == d.Direct ? TLI_LINE_ORDER_POSITION_BUY : TLI_LINE_ORDER_POSITION_SELL), d.Qty, G_LANG->LangText(TLI_LINE_ORDER_HAND));
		DrawText(mdc, wtext, wcslen(wtext), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

		if (d.pPosition)
		{
			r.top = d.Pixel;
			r.bottom = d.Pixel + CHART_TEXT_HEIGHT;
			swprintf_s(wtext, L"%.2f", d.pPosition->FloatProfitTBT);
			DrawText(mdc, wtext, wcslen(wtext), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
		}

		int line_pos = ccr.left + PADDING_X * 2;
		MoveToEx(mdc, ccr.left, d.Pixel, 0);
		LineTo(mdc, line_pos, d.Pixel);

		RECT rr;
		rr.top = d.Pixel - CHART_TEXT_HEIGHT / 2;
		rr.bottom = rr.top + CHART_TEXT_HEIGHT;
		rr.left = r.right + PADDING_X * 2;
		rr.right = rr.left + (r.right - r.left);
		SelectObject(mdc, FONT_KLINE_NUMBER);
		FormatPrice(G_StarApi, d.Price, m_Contract.Prec + 2, m_Contract.Deno, wtext, true);
		DrawText(mdc, wtext, wcslen(wtext), &rr, DT_LEFT | DT_SINGLELINE | DT_VCENTER);

		SIZE size;
		GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
		line_pos += size.cx;
		if (ccr.right > line_pos)
		{
			MoveToEx(mdc, line_pos, d.Pixel, 0);
			LineTo(mdc, ccr.right, d.Pixel);
		}
	}
	//绘制止盈止损线
	for (int i = 0; i < sc; i++)
	{
		TLineStop& s = m_Stops[i];
		if (s.Pixel <= 0)
			continue;
		r.top = s.Pixel - CHART_TEXT_HEIGHT / 2;
		r.bottom = r.top + CHART_TEXT_HEIGHT;

		SetTextColor(mdc, s.Type == TYPE_LOSS ? COLOR_LINE_ORDER_LOSS : COLOR_LINE_ORDER_PROFIT);
		SelectObject(mdc, s.Type == TYPE_LOSS ? PEN_LINE_ORDER_LOSS : PEN_LINE_ORDER_PROFIT);

		SelectObject(mdc, FONT_KLINE_TEXT);
		swprintf_s(wtext, L"%s%d%s", G_LANG->LangText(s.Type == TYPE_LOSS ? TLI_LINE_STOP_LOSS : TLI_LINE_TAKE_PROFIT), s.Qty, G_LANG->LangText(TLI_LINE_ORDER_HAND));
		DrawText(mdc, wtext, wcslen(wtext), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
		int line_pos = ccr.left + PADDING_X * 2;
		if (m_pMoveStop == NULL || m_pMoveStop != &s)
		{
			MoveToEx(mdc, ccr.left, s.Pixel, 0);
			LineTo(mdc, line_pos, s.Pixel);
		}

		RECT rr(r);
		rr.left = r.right + PADDING_X * 2;
		rr.right = rr.left + (r.right - r.left);
		SelectObject(mdc, FONT_KLINE_NUMBER);
		FormatPrice(G_StarApi, s.Price, m_Contract.Prec, m_Contract.Deno, wtext, true);
		DrawText(mdc, wtext, wcslen(wtext), &rr, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
		SIZE size;
		GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
		line_pos += size.cx;
		if (ccr.right > line_pos)
		{
			if (m_pMoveStop == NULL || m_pMoveStop != &s)
			{
				MoveToEx(mdc, line_pos, s.Pixel, 0);
				LineTo(mdc, ccr.right, s.Pixel);
			}
		}
	}
	//绘制委托
	bool outside(false);
	for (int i = 0; i < oc; i++)
	{
		TLineOrder& d = m_Orders[i];
		if (d.Pixel <= 0)
		{
			outside = true;
			continue;
		}

		r.top = d.Pixel - CHART_TEXT_HEIGHT / 2;
		r.bottom = r.top + CHART_TEXT_HEIGHT;

		SelectObject(mdc, FONT_KLINE_TEXT);
		if (d.BackHand)
		{
			SetTextColor(mdc, COLOR_LINE_ORDER_BACK);
			SelectObject(mdc, PEN_LINE_ORDER_BACK);
			swprintf_s(wtext, L"%s%s%d%s", G_LANG->LangText(TLI_LINE_ORDER_BACK), G_LANG->LangText(dBuy == d.Direct ? TLI_LINE_ORDER_POSITION_BUY : TLI_LINE_ORDER_POSITION_SELL), d.Qty, G_LANG->LangText(TLI_LINE_ORDER_HAND));
		}
		else
		{
			if (oCover == d.Offset || oCoverT == d.Offset)
			{
				SetTextColor(mdc, COLOR_LINE_ORDER_COVER);
				SelectObject(mdc, PEN_LINE_ORDER_COVER);
				swprintf_s(wtext, L"%s%s%d%s", G_LANG->LangText(dBuy == d.Direct ? TLI_LINE_ORDER_BUY : TLI_LINE_ORDER_SELL), G_LANG->LangText(TLI_LINE_ORDER_OFFSET), d.Qty, G_LANG->LangText(TLI_LINE_ORDER_HAND));
			}
			else
			{
				SetTextColor(mdc, dBuy == d.Direct ? COLOR_LINE_ORDER_BUY: COLOR_LINE_ORDER_SELL);
				SelectObject(mdc, dBuy == d.Direct ? PEN_LINE_ORDER_BUY: PEN_LINE_ORDER_SELL);
				swprintf_s(wtext, L"%s%d%s", G_LANG->LangText(dBuy == d.Direct ? TLI_LINE_ORDER_BUY : TLI_LINE_ORDER_SELL), d.Qty, G_LANG->LangText(TLI_LINE_ORDER_HAND));
			}
		}
		DrawText(mdc, wtext, wcslen(wtext), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);

		int line_pos = ccr.left + PADDING_X * 2;
		if (0 == m_MoveOrderId || d.OrderId != m_MoveOrderId)
		{
			MoveToEx(mdc, ccr.left, d.Pixel, 0);
			LineTo(mdc, line_pos, d.Pixel);
		}


		RECT rr(r);
		rr.left = r.right + PADDING_X * 2;
		rr.right = rr.left + (r.right - r.left);
		SelectObject(mdc, FONT_KLINE_NUMBER);
		if(m_Contract.IsSpread)
			FormatPrice(G_StarApi, d.Price,m_Contract.SpreadPrec ,1, wtext, true);
		else
		    FormatPrice(G_StarApi, d.Price,m_Contract.Prec,m_Contract.Deno, wtext, true);
		DrawText(mdc, wtext, wcslen(wtext), &rr, DT_LEFT | DT_SINGLELINE | DT_VCENTER);

		SIZE size;
		GetTextExtentPoint(mdc, wtext, wcslen(wtext), &size);
		line_pos += size.cx;
		if (ccr.right > line_pos)
		{
			if (0 == m_MoveOrderId || d.OrderId != m_MoveOrderId)
			{
				MoveToEx(mdc, line_pos, d.Pixel, 0);
				LineTo(mdc, ccr.right, d.Pixel);
			}
		}
	}

	//提示界面外边有画线条件单
	if (outside)
	{
		RECT r = chart.CenterBottomRect;

		if (r.left < r.right && r.top < r.bottom)
		{
			SelectObject(mdc, FONT_KLINE_TEXT);
			SetTextColor(mdc, COLOR_KLINE_MENU_TEXT);

			DrawText(mdc, G_LANG->LangText(TLI_LINE_ORDER_HINT), wcslen(G_LANG->LangText(TLI_LINE_ORDER_HINT)), &r, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
		}
	}

}

void TKLineControl::DrawCross(HDC mdc, RECT& cr)
{
	if ((!m_ShowCross || LINE_NONE != m_LineState))
		return;

	RECT ccr = m_Rects[CENTER_CHART];

	//画十字标线
	{
		int old_rop = SetROP2(mdc, R2_NOT);

		SelectObject(mdc, PEN_KLINE_GRID_LINE);

		MoveToEx(mdc, ccr.left, m_CrossY, 0);
		LineTo(mdc, ccr.right, m_CrossY);
		MoveToEx(mdc, m_CrossX, ccr.top, 0);
		LineTo(mdc, m_CrossX, ccr.bottom);

		SetROP2(mdc, old_rop);
	}


	SelectObject(mdc, FONT_KLINE_NUMBER);
	SetTextColor(mdc, COLOR_KLINE_CROSS);


	//底部文字输出
	if (L'\0' != m_CrossTextX[0])
	{
		SIZE size;
		GetTextExtentPoint(mdc, m_CrossTextX, wcslen(m_CrossTextX), &size);
		size.cx += 2 * PADDING_X;

		RECT r = m_Rects[BOTTOM];
		if (m_CrossX + size.cx <= ccr.right)
		{
			r.left = m_CrossX;
			r.right = r.left + size.cx;
		}
		else
		{
			r.right = ccr.right;
			r.left = r.right - size.cx;
		}
		FillRect(mdc, &r, BRUSH_KLINE_BACKGROUND);
		FrameRect(mdc, &r, BRUSH_KLINE_CROSS);
		DrawText(mdc, m_CrossTextX, wcslen(m_CrossTextX), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
	}

	//右侧文字输出
	if (L'\0' != m_CrossTextY[0])
	{
		RECT r = m_Rects[RIGHT];
		if (r.left >= r.right)
		{
			r.right = ccr.right;
			r.left = r.right - ((m_Contract.Deno > 1) ? RIGHT_WIDTH + WIDTH_EX : RIGHT_WIDTH);
		}

		if (m_CrossY + 1 - CHART_TEXT_HEIGHT >= ccr.top)
		{
			r.bottom = m_CrossY + 1;
			r.top = r.bottom - CHART_TEXT_HEIGHT;
		}
		else
		{
			r.top = ccr.top;
			r.bottom = r.top + CHART_TEXT_HEIGHT;
		}
		FillRect(mdc, &r, BRUSH_KLINE_BACKGROUND);
		FrameRect(mdc, &r, BRUSH_KLINE_CROSS);
		DrawText(mdc, m_CrossTextY, wcslen(m_CrossTextY), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
	}
}
void TKLineControl::DrawIntervalAmplification(HDC mdc, RECT& cr)
{
	if (!m_bAmplification&&!m_bStatistics|| m_bStatisticsShape)
		return;
	RECT ccr = m_Rects[CENTER_CHART];
	if (m_LButtonDown)
	{
		DotLine(mdc, m_BeginPoint.x, ccr.top, m_BeginPoint.x, ccr.bottom, ColorReverse());

		DrawLine(mdc, m_nEndX, ccr.top, m_nEndX, ccr.bottom, ColorReverse());
	}
	else
	{
		DrawLine(mdc, m_nEndX, ccr.top, m_nEndX, ccr.bottom, ColorReverse());
	}
	SelectObject(mdc, FONT_KLINE_NUMBER);
	SetTextColor(mdc, COLOR_KLINE_CROSS);
	//底部文字输出
	if (L'\0' != m_CrossTextX[0])
	{
		SIZE size;
		GetTextExtentPoint(mdc, m_CrossTextX, wcslen(m_CrossTextX), &size);
		size.cx += 2 * PADDING_X;

		RECT r = m_Rects[BOTTOM];
		if (m_CrossX + size.cx <= ccr.right)
		{
			r.left = m_CrossX;
			r.right = r.left + size.cx;
		}
		else
		{
			r.right = ccr.right;
			r.left = r.right - size.cx;
		}
		FillRect(mdc, &r, BRUSH_KLINE_BACKGROUND);
		FrameRect(mdc, &r, BRUSH_KLINE_CROSS);
		DrawText(mdc, m_CrossTextX, wcslen(m_CrossTextX), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
	}
}

void TKLineControl::DrawLineOrder(HDC mdc, RECT& cr)
{
	//画线下单 或者 修改画线条件单
	if (LINE_ORDER != m_LineState && 0 == m_MoveOrderId&&m_pMoveStop == NULL&&m_pMovePosition == NULL)
		return;

	TKLineChart& chart = m_Chart[0];

	RECT ccr = chart.CenterChartRect;
	if (m_LineY < ccr.top || m_LineY >= ccr.bottom)
		return;

	//异或线
	{
		int old_rop = SetROP2(mdc, R2_NOT);

		//SelectObject(mdc, PEN_KLINE_GRID_LINE);

		MoveToEx(mdc, ccr.left, m_LineY, 0);
		LineTo(mdc, ccr.right, m_LineY);

		SetROP2(mdc, old_rop);
	}

	//右侧文字输出
	wchar_t wtext[128];
	double value = (chart.LeftAxisY.MaxValue - (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue) * (m_LineY - chart.LeftRect.top) / (chart.LeftRect.bottom - chart.LeftRect.top)) * 1.0 / chart.LeftAxisY.PrecPow;
	if (m_Contract.IsSpread)
		FormatPrice(G_StarApi, value, m_Contract.SpreadPrec, 1, wtext, true);
	else
	    FormatPrice(G_StarApi, value, m_Contract.Prec, m_Contract.Deno, wtext, true);

	RECT r = chart.RightRect;
	if (r.left >= r.right)
	{
		r.right = ccr.right;
		r.left = r.right - ((m_Contract.Deno > 1) ? RIGHT_WIDTH + WIDTH_EX : RIGHT_WIDTH);
	}

	if (m_LineY + 1 - CHART_TEXT_HEIGHT >= ccr.top)
	{
		r.bottom = m_LineY + 1;
		r.top = r.bottom - CHART_TEXT_HEIGHT;
	}
	else
	{
		r.top = ccr.top;
		r.bottom = r.top + CHART_TEXT_HEIGHT;
	}
	//绘制止盈止损
	if (m_pMoveStop || m_pMovePosition)
	{
		int nPosY = 0, nLineX = 0;
		double dPrice = 0;
		if (m_pMoveStop&&m_pMoveStop->pPosition)
		{
			dPrice = value - m_pMoveStop->pPosition->PositionPrice;
			nPosY = m_pMoveStop->PosPixel;
		}
		if (m_pMovePosition)
		{
			dPrice = value - m_pMovePosition->Price;
			nPosY = m_pMovePosition->Pixel;
		}
		nLineX = r.left + (r.right - r.left) / 2;
		int old_rop = SetROP2(mdc, R2_NOT);
		SelectObject(mdc, PEN_KLINE_GRID_LINE);
		MoveToEx(mdc, nLineX, m_LineY, 0);
		LineTo(mdc, nLineX, nPosY);
		SetROP2(mdc, old_rop);
		if (m_pMoveStop)
		{
			TLineStop* pStop = GetSameLocalIdLineStop(m_pMoveStop->LocalId);
			if (pStop)
			{
				int old_rop = SetROP2(mdc, R2_NOT);
				SelectObject(mdc, PEN_KLINE_GRID_DOTLINE);
				MoveToEx(mdc, nLineX - 20, pStop->Pixel, 0);
				LineTo(mdc, nLineX - 20, nPosY);
				SetROP2(mdc, old_rop);
			}
		}
		//绘制价差文字
		if ((dPrice > 0 && nPosY - m_LineY > CHART_TEXT_HEIGHT) || (dPrice < 0 && m_LineY - nPosY>2 * CHART_TEXT_HEIGHT))
		{
			wchar_t wPrice[128];
			FormatPrice(G_StarApi, dPrice, m_Contract.Prec, m_Contract.Deno, wPrice, true);
			RECT rr = r;
			if (dPrice > 0)
			{
				rr.top = r.bottom + (nPosY - m_LineY - CHART_TEXT_HEIGHT) / 2;
				rr.bottom = r.bottom + (nPosY - m_LineY + CHART_TEXT_HEIGHT) / 2;
			}
			else
			{
				rr.top = nPosY + (m_LineY - nPosY - 2 * CHART_TEXT_HEIGHT) / 2;
				rr.bottom = nPosY + (m_LineY - nPosY) / 2;
			}
			FillRect(mdc, &rr, BRUSH_KLINE_BACKGROUND);
			FrameRect(mdc, &rr, BRUSH_KLINE_CROSS);
			SelectObject(mdc, FONT_KLINE_NUMBER);
			SetTextColor(mdc, COLOR_KLINE_CROSS);
			DrawText(mdc, wPrice, wcslen(wPrice), &rr, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
		}
	}
	FillRect(mdc, &r, BRUSH_KLINE_BACKGROUND);
	FrameRect(mdc, &r, BRUSH_KLINE_CROSS);

	SelectObject(mdc, FONT_KLINE_NUMBER);
	SetTextColor(mdc, COLOR_KLINE_CROSS);
	DrawText(mdc, wtext, wcslen(wtext), &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
}
void TKLineControl::OnOverlapContract()
{
	((TQuoteFrame*)GetWindow())->SingleSelectContract();
}
void TKLineControl::KeyLeft()
{
	if (NULL == m_Contract.Cont)
		return;

	//无数据
	if (m_AxisX.Begin == m_AxisX.End)
		return;

	bool reload(false);
	if (!m_ShowCross)
	{
		m_AxisX.Curr = (m_AxisX.End - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	}
	else
	{
		//已经在最左边
		while (true)
		{
			if (m_AxisX.Curr != m_AxisX.Begin)
			{
				m_AxisX.Curr = (m_AxisX.Curr - 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
				if (m_AxisX.DataWidth[(m_AxisX.Curr - m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X] <= 0)
					continue;
			}
			else
			{
				if (m_AxisX.Curr == m_AxisX.KData.ReadIndex || MAIN_CHART_TLINE == m_Contract.MainChart)
					return;

				m_Contract.KLineTail++;
				reload = true;
			}
			break;
		}
	}

	SHisQuoteData& d = m_AxisX.KData.GetData(m_AxisX.Curr);
	int i = 0;
	if (MAIN_CHART_TLINE == m_Contract.MainChart)
		i = (m_AxisX.Curr - m_AxisX.KData.ReadIndex + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	else
		i = (m_AxisX.Curr - m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;

	TKLineChart& chart = m_Chart[0];
	//if (chart.LeftAxisY.MinValue <= 0 || chart.LeftAxisY.MaxValue <= 0 || chart.LeftAxisY.MinValue == chart.LeftAxisY.MaxValue)	//无最大最小值
	//	return;

	RECT r(chart.CenterChartRect);
	m_CrossX =  r.left + m_AxisX.DataPos[i] + m_AxisX.DataWidth[i] / 2;
	m_CrossY = r.top + (int)((r.bottom - r.top) * (chart.LeftAxisY.MaxValue - d.QLastPrice * chart.LeftAxisY.PrecPow) / (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue));

	//显示十字标线
	if (!m_ShowCross)
		m_ShowCross = true;
	SetCurrCursor(NULL);

	POINT cp;
	cp.x = m_CrossX;
	cp.y = m_CrossY;
	ClientToScreen(cp);
	SetCursorPos(cp.x, cp.y);

	if (reload)
	{
		m_Contract.SubAndReload();
	}
	m_ShapeChart.ResetShape();
	Redraw(NULL);
	SetFocus();
}

void TKLineControl::KeyRight()
{
	if (NULL == m_Contract.Cont)
		return;

	//无数据
	if (m_AxisX.Begin == m_AxisX.End)
		return;

	bool reload(false);
	if (!m_ShowCross)
	{
		m_AxisX.Curr = m_AxisX.Begin;
	}
	else
	{
		while (true)
		{
			int new_curr = (m_AxisX.Curr + 1) % MAX_SHOW_KLINE_X;
			if (m_AxisX.Curr == m_AxisX.End || new_curr == m_AxisX.End)	//分时线最后一根 此处会多次循环
			{
				if (m_Contract.KLineTail <= 0)
					return;
				m_Contract.KLineTail--;
				reload = true;
			}
			else
			{
				m_AxisX.Curr = new_curr;
				if (m_AxisX.DataWidth[(m_AxisX.Curr - m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X] <= 0)
					continue;
			}
			break;
		}

	}

	SHisQuoteData& d = m_AxisX.KData.GetData(m_AxisX.Curr);
	TKLineChart& chart = m_Chart[0];
	//if (chart.LeftAxisY.MinValue <= 0 || chart.LeftAxisY.MaxValue <= 0 || chart.LeftAxisY.MinValue == chart.LeftAxisY.MaxValue)	//无最大最小值
	//	return;

	RECT r(chart.CenterChartRect);
	int i = 0;
	if (MAIN_CHART_TLINE == m_Contract.MainChart)
		i = (m_AxisX.Curr - m_AxisX.KData.ReadIndex + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	else
		i = (m_AxisX.Curr - m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	m_CrossX = r.left + m_AxisX.DataPos[i] + m_AxisX.DataWidth[i] / 2;
	m_CrossY = r.top + (int)((r.bottom - r.top) * (chart.LeftAxisY.MaxValue - d.QLastPrice * chart.LeftAxisY.PrecPow) / (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue));

	//显示十字标线
	if (!m_ShowCross)
		m_ShowCross = true;
	SetCurrCursor(NULL);

	POINT cp;
	cp.x = m_CrossX;
	cp.y = m_CrossY;
	ClientToScreen(cp);
	SetCursorPos(cp.x, cp.y);

	if (reload)
	{
		m_Contract.SubAndReload();
	}
	m_ShapeChart.ResetShape();
	Redraw(NULL);
	SetFocus();
}

void TKLineControl::KeyUp()
{
	SHisQuoteData& d = m_AxisX.KData.GetData(m_AxisX.Curr);
	m_PreDateTime = d.DateTimeStamp;
	//先计算缩放前数据
	int nCurInx = (m_AxisX.Curr - m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	TKLineChart& chart = m_Chart[0];
	RECT r(chart.CenterChartRect);
	int nMidInx = (m_AxisX.End - m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X / 2;
	int nAllIndex = (m_AxisX.End - m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	int nTail = m_Contract.KLineTail;
	//缩放试算
	if (m_Contract.KLineShape < G_QuoteUtils.ShapSize - 1)
	{
		if (nCurInx < nMidInx)
		{
			TKLineShapeType& ks = G_QuoteUtils.KLineShapes[m_Contract.KLineShape + 1];
			int pw = r.right - r.left;
			int r_width = ((m_Contract.Deno > 1) ? RIGHT_WIDTH + WIDTH_EX : RIGHT_WIDTH);
			pw = (pw - r_width > 0) ? (pw - r_width) : 0;
			int nZoomAll = pw / ks.AreaWidth;
			int nAdd = nZoomAll - nAllIndex;
			int nZoomMid = nZoomAll / 2;
			if (nAdd < 0)
			{
				if (nCurInx > nZoomMid)
				{
					nTail += (abs(nAdd) - abs(nCurInx - nZoomMid));
					nCurInx = nZoomMid;
				}
				else
					nTail += abs(nAdd);
			}
			if (nTail <= 0)
			{
				m_bCalCross = true;
				nTail = 0;
			}
			else
			{
				m_CrossX = r.left + nCurInx*ks.AreaWidth + ks.AreaWidth / 2;
				m_CrossY = r.top + (int)((r.bottom - r.top) * (chart.LeftAxisY.MaxValue - d.QLastPrice * chart.LeftAxisY.PrecPow) / (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue));
			}
			
		}
		else if (nCurInx > nMidInx)
		{
			TKLineShapeType& ks = G_QuoteUtils.KLineShapes[m_Contract.KLineShape + 1];
			int pw = r.right - r.left;
			int r_width = ((m_Contract.Deno > 1) ? RIGHT_WIDTH + WIDTH_EX : RIGHT_WIDTH);
			pw = (pw - r_width > 0) ? (pw - r_width) : 0;
			int nZoomAll = pw / ks.AreaWidth;
			int nAdd = nZoomAll - nAllIndex;
			int nZoomCur = nCurInx + nAdd;
			if (nAdd < 0)
			{
				int nZoomMid = nZoomAll / 2;
				if (nZoomCur < nZoomMid)
				{
					nTail += abs(nZoomCur - nZoomMid);
					nZoomCur = nZoomMid;
				}
			}
			if (nTail<=0)
			{
				m_bCalCross = true;
				nTail = 0;
			}
			else
			{
				m_CrossX = r.left + nZoomCur*ks.AreaWidth + ks.AreaWidth / 2;
				m_CrossY = r.top + (int)((r.bottom - r.top) * (chart.LeftAxisY.MaxValue - d.QLastPrice * chart.LeftAxisY.PrecPow) / (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue));
			}
		}
		else
		{
			TKLineShapeType& ks = G_QuoteUtils.KLineShapes[m_Contract.KLineShape + 1];
			int pw = r.right - r.left;
			int r_width = ((m_Contract.Deno > 1) ? RIGHT_WIDTH + WIDTH_EX : RIGHT_WIDTH);
			pw = (pw - r_width > 0) ? (pw - r_width) : 0;
			int nZoomAll = pw / ks.AreaWidth;
			int nAdd = nZoomAll - nAllIndex;
			int nCurInx = nZoomAll / 2;
			if (nAdd < 0)
			{
				nTail += abs(abs(nAdd) - abs(nMidInx - nCurInx));
			}
			if (nTail<=0)
			{
				m_bCalCross = true;
				nTail = 0;
			}
			else
			{
				m_CrossX = r.left + nCurInx*ks.AreaWidth + ks.AreaWidth / 2;
				m_CrossY = r.top + (int)((r.bottom - r.top) * (chart.LeftAxisY.MaxValue - d.QLastPrice * chart.LeftAxisY.PrecPow) / (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue));
			}
		}
	}
	else
	{
		m_bCalCross = true;
	}
	if (m_Contract.KLineZoomIn(nTail))
	{
		m_ShapeChart.ResetShape();
		Redraw(NULL);
		SetFocus();
	}
}

void TKLineControl::KeyDown()
{
	if (!m_CanZoomOut)
		return;
	SHisQuoteData& d = m_AxisX.KData.GetData(m_AxisX.Curr);
	m_PreDateTime = d.DateTimeStamp;
	//先计算缩放前数据
	int nCurInx = (m_AxisX.Curr - m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	TKLineChart& chart = m_Chart[0];
	RECT r(chart.CenterChartRect);
	int nMidInx = (m_AxisX.End - m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X / 2;
	int nAllIndex = (m_AxisX.End - m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	int nTail = m_Contract.KLineTail;
	//缩放试算
	if (m_Contract.KLineShape > 0)
	{
		if (nCurInx < nMidInx)
		{
			TKLineShapeType& ks = G_QuoteUtils.KLineShapes[m_Contract.KLineShape - 1];
			int pw = r.right - r.left;
			int r_width = ((m_Contract.Deno > 1) ? RIGHT_WIDTH + WIDTH_EX : RIGHT_WIDTH);
			pw = (pw - r_width > 0) ? (pw - r_width) : 0;
			int nZoomAll = pw / ks.AreaWidth;
			int nAdd = nZoomAll - nAllIndex;
			int nZoomCur = nCurInx + nAdd;
			int nZoomMid = nZoomAll / 2;
			if (nZoomCur > nZoomMid)
			{
				nTail -= abs(nZoomCur - nZoomMid);
				nZoomCur = nZoomMid;
			}
			if (nTail<0)
			{
				m_bCalCross = true;
				nTail = 0;
			}
			else
			{
				m_CrossX = r.left + nZoomCur*ks.AreaWidth + ks.AreaWidth / 2;
				m_CrossY = r.top + (int)((r.bottom - r.top) * (chart.LeftAxisY.MaxValue - d.QLastPrice * chart.LeftAxisY.PrecPow) / (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue));
			}
		}
		else if (nCurInx > nMidInx)
		{
			TKLineShapeType& ks = G_QuoteUtils.KLineShapes[m_Contract.KLineShape - 1];
			int pw = r.right - r.left;
			int r_width = ((m_Contract.Deno > 1) ? RIGHT_WIDTH + WIDTH_EX : RIGHT_WIDTH);
			pw = (pw - r_width > 0) ? (pw - r_width) : 0;
			int nZoomAll = pw / ks.AreaWidth;
			int nAdd = nZoomAll - nAllIndex;
			int nZoomMid = nZoomAll / 2;
			if (nCurInx < nZoomMid)
			{
				nTail -= (abs(nAdd) - abs(nCurInx - nZoomMid));
				nCurInx = nZoomMid;
			}
			else
				nTail -= abs(nAdd);
			if (nTail<0)
			{
				m_bCalCross = true;
				nTail = 0;
			}
			else
			{
				m_CrossX = r.left + nCurInx*ks.AreaWidth + ks.AreaWidth / 2;
				m_CrossY = r.top + (int)((r.bottom - r.top) * (chart.LeftAxisY.MaxValue - d.QLastPrice * chart.LeftAxisY.PrecPow) / (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue));
			}
		}
		else
		{
			TKLineShapeType& ks = G_QuoteUtils.KLineShapes[m_Contract.KLineShape - 1];
			int pw = r.right - r.left;
			int r_width = ((m_Contract.Deno > 1) ? RIGHT_WIDTH + WIDTH_EX : RIGHT_WIDTH);
			pw = (pw - r_width > 0) ? (pw - r_width) : 0;
			int nZoomAll = pw / ks.AreaWidth;
			int nAdd = nZoomAll - nAllIndex;
			int nCurInx = nZoomAll / 2;
			nTail -= abs(abs(nAdd) - abs(nMidInx - nCurInx));
			if (nTail<0)
			{
				m_bCalCross = true;
				nTail = 0;
			}
			else
			{
				m_CrossX = r.left + nCurInx*ks.AreaWidth + ks.AreaWidth / 2;
				m_CrossY = r.top + (int)((r.bottom - r.top) * (chart.LeftAxisY.MaxValue - d.QLastPrice * chart.LeftAxisY.PrecPow) / (chart.LeftAxisY.MaxValue - chart.LeftAxisY.MinValue));
			}
		}
	}
	else
	{
		m_bCalCross = true;
	}
	if (m_Contract.KLineZoomOut(nTail))
	{
		m_ShapeChart.ResetShape();
		Redraw(NULL);
		SetFocus();
	}

}

void TKLineControl::KeyEsc()
{
	if (MAIN_CHART_TLINE == m_Contract.MainChart)
	{
		((TQuoteFrame*)GetWindow())->SwitchToGrid();
	}
	else
	{
		SwitchToTLine();
		m_Contract.SubAndReload();
		((TQuoteFrame*)GetWindow())->SaveCfg();
		CalculateRects();
		Redraw(NULL);
	}
}

void TKLineControl::KeyReturn()
{
	//K线周期切换快捷键
	//switch (m_PreVK)
	//{
	//case '0':
	//case VK_NUMPAD0:
	//	SwitchToTLine();
	//	break;
	//case '1':
	//case VK_NUMPAD1:
	//	m_Contract.SwitchByMenu(TLI_KLINE_MIN1);
	//	break;
	//case '2':
	//case VK_NUMPAD2:
	//	m_Contract.SwitchByMenu(TLI_KLINE_MIN3);
	//	break;
	//case '3':
	//case VK_NUMPAD3:
	//	m_Contract.SwitchByMenu(TLI_KLINE_MIN5);
	//	break;
	//case '4':
	//case VK_NUMPAD4:
	//	m_Contract.SwitchByMenu(TLI_KLINE_MIN10);
	//	break;
	//case '5':
	//case VK_NUMPAD5:
	//	m_Contract.SwitchByMenu(TLI_KLINE_MIN15);
	//	break;
	//case '6':
	//case VK_NUMPAD6:
	//	m_Contract.SwitchByMenu(TLI_KLINE_MIN30);
	//	break;
	//case '7':
	//case VK_NUMPAD7:
	//	m_Contract.SwitchByMenu(TLI_KLINE_HOUR1);
	//	break;
	//case '9':
	//case VK_NUMPAD9:
	//	m_Contract.SwitchByMenu(TLI_KLINE_DAY1);
	//	break;
	//default:
	if (MAIN_CHART_KLINE == m_Contract.MainChart)
	{
		((TQuoteFrame*)GetWindow())->SwitchToGrid();
		return;
	}
	else
	{
		SwitchToKLine();
	}
	//break;
//}

	m_Contract.SubAndReload();
	((TQuoteFrame*)GetWindow())->SaveCfg();
	CalculateRects();
	Redraw(NULL);
	SetFocus();
}
void TKLineControl::KeyF5()
{
	if (MAIN_CHART_KLINE == m_Contract.MainChart)
		SwitchToTLine();
	else
		SwitchToKLine();

	m_Contract.SubAndReload();
	((TQuoteFrame*)GetWindow())->SaveCfg();
	CalculateRects();
	Redraw(NULL);
	SetFocus();
}
void TKLineControl::KeyF8()
{
	int arrTypes[] = { TLI_KLINE_TIME ,TLI_KLINE_TICK ,TLI_KLINE_SEC5 ,TLI_KLINE_SEC10,TLI_KLINE_SEC15 ,TLI_KLINE_SEC30 ,TLI_KLINE_MIN1 ,
                                            TLI_KLINE_MIN3 ,TLI_KLINE_MIN5 ,TLI_KLINE_MIN10 ,TLI_KLINE_MIN15 ,TLI_KLINE_MIN30 ,TLI_KLINE_HOUR1 ,TLI_KLINE_DAY1 ,
		                                    TLI_KLINE_WEEK1,TLI_KLINE_MONTH1,TLI_KLINE_YEAR1 };
    //先确定下次显示的类型
	int curType = GetCfg();
	int NextIndex = 0;
	for (int i = 0; i < sizeof(arrTypes) / sizeof(int); i++)
	{
		if (curType == arrTypes[i])
		{
			NextIndex = (i + 1) % (sizeof(arrTypes) / sizeof(int));
			break;
		}
	}
	SwitchLineTypeAndRedow((TLangIndex_PolestarQuote)arrTypes[NextIndex]);

}
void TKLineControl::AddSelfPlate(TDuiPopMenuItem* obj)
{
	TPlatePage* pPage = (TPlatePage*)obj->Value;
	if (pPage)
	{
		bool can(true);
		for (size_t i = 0; i < pPage->PlateRows.size(); i++)
		{
			TPlateRow& r = pPage->PlateRows[i];
			if (r.Contract == m_Contract.Cont)
			{
				can = false;
				break;
			}
		}
		if (can)
		{
			TPlateRow row;
			memset(&row, 0, sizeof(TPlateRow));
			row.Contract = m_Contract.Cont;
			row.RowIndex = pPage->PlateRows.size();
			row.IsSpread = false;
			pPage->PlateRows.push_back(row);
			pPage->SaveRows();
		}
	}
}
void TKLineControl::SetIsShowDevision(bool bShow)
{
	m_bShowDevision = bShow;
	Redraw(NULL);
}
void TKLineControl::SetIsShowTimeLineRGBar(bool bShow)
{
	CIndex* pIndex = CIndexMgr::GetInstance()->GetIndex(TLINE_SPEC);
	if (pIndex)
	{
		pIndex->SetIsVisiable(bShow);
		if (MAIN_CHART_KLINE != m_Contract.MainChart)
			m_Chart[0].KChartSpec[0].Visible = bShow;
		Redraw(NULL);
	}
}
void TKLineControl::Switch_Spec()
{
	if (MAIN_CHART_KLINE == m_Contract.MainChart)
	{
		if (S_KLINE_TICK == m_Contract.KLineType && 0 == m_Contract.KLineSlice)
		{
			bool bVisibale1 = m_Chart[0].KChartSpec[1].Visible;
			CIndex* pIndex = CIndexMgr::GetInstance()->GetIndex(TICK_SPEC);
			if (pIndex)
				SetChartSpace(m_Chart[0].KChartSpec[0], pIndex, false);
			m_Chart[0].KChartSpec[0].Visible = bVisibale1 ? false : true;
			m_Chart[0].KChartSpec[1].Visible = bVisibale1;
		}
		else
		{
			bool bVisibale1 = m_Chart[0].KChartSpec[1].Visible;
			CIndex* pIndex = CIndexMgr::GetInstance()->GetIndex(KLINE_SPEC);
			if (pIndex)
			    SetChartSpace(m_Chart[0].KChartSpec[0], pIndex,false);
			m_Chart[0].KChartSpec[0].Visible = bVisibale1 ? false: true;
			m_Chart[0].KChartSpec[1].Visible = bVisibale1;
		}
	}
	else
	{
		CIndex* pIndex = CIndexMgr::GetInstance()->GetIndex(TLINE_SPEC);
		if (pIndex)
		    SetChartSpace(m_Chart[0].KChartSpec[0], pIndex,false);
	}
}

void TKLineControl::Assign_SubChart()
{
	m_Chart[0].Height = 3;
	m_Chart[0].SetKLineCtl(this);
	for (int i = 1; i < sizeof(m_Chart) / sizeof(TKLineChart); i++)
	{
		m_Chart[i].Height = 1;
		m_Chart[i].SetKLineCtl(this);
	}
}

void TKLineControl::ModifyMaParam()
{
	for (int i = 0; i < sizeof(m_Chart[0].KChartSpec) / sizeof(TKChartSpec); i++)
	{
		if (m_Chart[0].KChartSpec[i].Visible)
		{
			if (wcscmp(m_Chart[0].KChartSpec[i].SpecName, L"TICK") == 0|| wcscmp(m_Chart[0].KChartSpec[i].SpecName, L"KLINE") == 0)
				continue;
			TMaConfigWindow dlg(&m_Chart[0].KChartSpec[i]);
			if (dlg.ShowMaConfigWindow())
			{
				SaveParams(&m_Chart[0].KChartSpec[i]);
			}
			Redraw(NULL);
			SetFocus();
		}
	}
}
void TKLineControl::ModifySubParam(TKLineChart* pChart)
{
	TMaConfigWindow dlg(&pChart->KChartSpec[0]);
	if (dlg.ShowMaConfigWindow())
	{
		SaveParams(&pChart->KChartSpec[0]);
	}
	Redraw(NULL);
	SetFocus();
}
TLineStop* TKLineControl::GetSameLocalIdLineStop(uint id)
{
	for (int i = 0; i < MAX_TRADE_DATA_COUNT; i++)
	{
		if (&m_Stops[i] == NULL || &m_Stops[i] == m_pMoveStop)
			continue;
		if (m_Stops[i].LocalId == id)
			return &m_Stops[i];
	}
	return NULL;
}
void TKLineControl::LinkageQuickMacro(const char* action, WPARAM vk)
{
	char content[11];
	sprintf_s(content, "%u", vk);
	PolestarQuoteLinkage(GetWindow()->GetHwnd(), action, content);
}
void TKLineControl::ResetShapeRect()
{
	m_ShapeChart.ResetShape();
}
void TKLineControl::ClearShapes()
{
	auto pos = m_mapShape.begin();
	while (pos != m_mapShape.end())
	{
		pos->second.clear();
		pos++;
	}
	m_mapShape.clear();
}
void TKLineControl::EnterShapechartShapes()
{
	//先生成key
	if (NULL == m_Contract.Cont)
		return;
	char key[101];
	m_Contract.UniqueContract(key, sizeof(key));
	std::vector<TShape*> arr;
	m_ShapeChart.GetShapeArray(arr);
	AddArrayShape(key, arr);
}
void TKLineControl::LeaveShapeChartShapes()
{
	if (NULL == m_Contract.Cont)
		return;
	char key[101];
	m_Contract.UniqueContract(key, sizeof(key));
	if (m_mapShape.find(key) != m_mapShape.end())
	{
		auto iter = m_mapShape.find(key);
		std::vector<TShape*> vecShape = iter->second;
		m_ShapeChart.SetArrShape(vecShape);
	}
}
void TKLineControl::AddArrayShape(std::string key, std::vector<TShape*>& arr)
{
	auto iter = m_mapShape.find(key);
	if (iter != m_mapShape.end())
	{
		iter->second.clear();
		std::copy(arr.begin(), arr.end(), std::back_inserter(iter->second));
	}
	else
	{
		if (m_queShap.size() > 3)
		{
			std::string  strFirst = m_queShap.front();
			m_queShap.pop();
			auto iter = m_mapShape.find(strFirst);
			if (iter != m_mapShape.end())
			{
				for (size_t i = 0; i < iter->second.size(); i++)
				{
					delete iter->second[i];
					iter->second[i] = NULL;
				}
				iter->second.clear();
			}
			m_mapShape.erase(strFirst);
		}
		if (arr.size() > 0)
		{
			m_queShap.push(key);
			for (size_t i = 0; i < arr.size(); i++)
			{
				m_mapShape[key].push_back(arr[i]);
			}
		}

	}//
}
void TKLineControl::SaveChartObject()
{
	EnterShapechartShapes();
	char currpath[1024];
	CurrPath(currpath, sizeof(currpath));

	int nChartSize = m_mapShape.size();
	if (nChartSize <= 0)
		return;
	char filename[1024];
	sprintf_s(filename, "%s\\config\\PolestarQuote\\PolestarQuote.DrawObject.%x.pri", currpath, GetWindow()->GetHwnd());

	FILE* file(NULL);
	fopen_s(&file, filename, "wb");
	if (NULL == file)
		return;
	fwrite(&nChartSize, sizeof(int), 1, file);
	for (auto iter = m_mapShape.begin(); iter != m_mapShape.end(); iter++)
	{
		Chart_Header chart_hd;
		std::vector<TShape*> vShapes = iter->second;
		strcpy_s(chart_hd.Id, sizeof(chart_hd.Id), iter->first.data());
		chart_hd.Count = vShapes.size();
		fwrite(&chart_hd, sizeof(chart_hd), 1, file);
		for (size_t i = 0; i < vShapes.size(); i++)
		{
			int nLength = vShapes[i]->GetStoreSize();
			fwrite(&nLength, sizeof(int), 1, file);
			char* pc_Shape = new char[nLength];
			vShapes[i]->GetStoreinfo(pc_Shape, nLength);
			fwrite(pc_Shape, nLength, 1, file);
			delete pc_Shape;
		}
	}
	fclose(file);
}
void TKLineControl::LoadChartObject(HWND hwnd)
{
	char currpath[1024];
	CurrPath(currpath, sizeof(currpath));

	char filename[1024];
	sprintf_s(filename, "%s\\config\\PolestarQuote\\PolestarQuote.DrawObject.%x.pri", currpath, hwnd);

	FILE* file(NULL);
	fopen_s(&file, filename, "rb");
	if (NULL == file)
		return;
	int nChartSize = 0;
	fread_s(&nChartSize, sizeof(int), sizeof(int), 1, file);
	for (int i = 0; i < nChartSize; i++)
	{
		Chart_Header chart_hd = { 0 };
		fread_s(&chart_hd, sizeof(Chart_Header), sizeof(Chart_Header), 1, file);
		std::vector<TShape*> arrShape;
		for (int j = 0; j < chart_hd.Count; j++)
		{
			int nLength = 0;
			fread_s(&nLength, sizeof(int), sizeof(int), 1, file);
			char* pc_Shape = new char[nLength];
			fread_s(pc_Shape, nLength, nLength, 1, file);
			TShape shape;
			shape.SetStoreinfo(pc_Shape, nLength);
			delete pc_Shape;
			std::vector<ChartDot> arrGripher;
			shape.GetGripers(arrGripher);
			if (arrGripher.size() > 0)
			{
				TShape *pTmpShape = G_ShapeFactory()->CreateShape(shape.GetType(), &m_Chart[0], &m_AxisX, arrGripher, shape.GetColor(), shape.GetWidth());
				arrShape.push_back(pTmpShape);
			}
		}
		if (!arrShape.empty())
		{
			AddArrayShape(chart_hd.Id, arrShape);
		}
	}
	fclose(file);
}
void TKLineControl::GetChartObject(char* pstr, int size)
{
	EnterShapechartShapes();
	int nChartSize = m_mapShape.size();
	if (nChartSize <= 0)
		return;
	//先计算二进制数据块的大小
	int nSize = sizeof(int);
	for (auto it = m_mapShape.begin(); it != m_mapShape.end(); it++)
	{
		std::vector<TShape*> vShapes = it->second;
		nSize += sizeof(Chart_Header);
		for (size_t i = 0; i < vShapes.size(); i++)
		{
			nSize += sizeof(int);
			int nLength = vShapes[i]->GetStoreSize();
			nSize += nLength;
		}
	}
	char* binData = new char[nSize];
	memset(binData, 0, nSize);
	memcpy_s(binData, sizeof(int), &nChartSize, sizeof(int));
	int   nPos = sizeof(int);
	char* posPtr = binData + nPos;
	for (auto iter = m_mapShape.begin(); iter != m_mapShape.end(); iter++)
	{
		Chart_Header chart_hd;
		std::vector<TShape*> vShapes = iter->second;
		strcpy_s(chart_hd.Id, sizeof(chart_hd.Id), iter->first.data());
		chart_hd.Count = vShapes.size();
		memcpy_s(posPtr, sizeof(Chart_Header), &chart_hd, sizeof(Chart_Header));
		nPos += sizeof(Chart_Header);
		posPtr = binData + nPos;
		for (size_t i = 0; i < vShapes.size(); i++)
		{
			int nLength = vShapes[i]->GetStoreSize();
			memcpy_s(posPtr, sizeof(int), &nLength, sizeof(int));
			nPos += sizeof(int);
			posPtr = binData + nPos;
			char* pc_Shape = new char[nLength];
			vShapes[i]->GetStoreinfo(pc_Shape, nLength);
			memcpy_s(posPtr, nLength, pc_Shape, nLength);
			nPos += nLength;
			posPtr = binData + nPos;
			delete pc_Shape;
		}
	}
	BinToHex(binData, pstr, nSize);
	delete binData;
	LeaveShapeChartShapes();
}
void TKLineControl::SetChartObject(char* pstr, int size)
{
	char binData[3501];
	memset(binData, 0, sizeof(binData));
	HexToBin(pstr, binData, sizeof(binData));
	int nChartSize = 0;
	memcpy_s(&nChartSize, sizeof(int), binData, sizeof(int));
	int   nPos = sizeof(int);
	char* posPtr = binData + nPos;
	for (int i = 0; i < nChartSize; i++)
	{
		Chart_Header chart_hd = { 0 };
		memcpy_s(&chart_hd, sizeof(Chart_Header), posPtr, sizeof(Chart_Header));
		nPos += sizeof(Chart_Header);
		posPtr = binData + nPos;
		std::vector<TShape*> arrShape;
		for (int j = 0; j < chart_hd.Count; j++)
		{
			int nLength = 0;
			memcpy_s(&nLength, sizeof(int), posPtr, sizeof(int));
			nPos += sizeof(int);
			posPtr = binData + nPos;
			char* pc_Shape = new char[nLength];
			memcpy_s(pc_Shape, nLength, posPtr, nLength);
			nPos += nLength;
			posPtr = binData + nPos;
			TShape shape;
			shape.SetStoreinfo(pc_Shape, nLength);
			delete pc_Shape;
			std::vector<ChartDot> arrGripher;
			shape.GetGripers(arrGripher);
			if (arrGripher.size() > 0)
			{
				TShape *pTmpShape = G_ShapeFactory()->CreateShape(shape.GetType(), &m_Chart[0], &m_AxisX, arrGripher, shape.GetColor(), shape.GetWidth());
				arrShape.push_back(pTmpShape);
			}
		}
		if (!arrShape.empty())
		{
			AddArrayShape(chart_hd.Id, arrShape);
		}
	}
}
bool TKLineControl::IsShowFullScreenMenu()
{
	HWND Hwnd = ((TQuoteFrame*)GetWindow())->GetHwnd();
	while (::GetParent(Hwnd))
		Hwnd = ::GetParent(Hwnd);
	wchar_t name[MAX_PATH];
	GetClassName(Hwnd, name, sizeof(name));
	if (wcscmp(L"class TMainFrame", name) == 0)
		return true;
	return false;
}
void  TKLineControl::UpadteRectTipText(int id, RECT rect, LPWSTR szTipText)
{
	TOOLINFO  tti;

	//设置提示窗口的信息  
	memset(&tti, 0, sizeof(TOOLINFO));
	tti.cbSize = TTTOOLINFOA_V2_SIZE;
	tti.uFlags = TTF_SUBCLASS;
	tti.hwnd =GetWindow()->GetHwnd();
	tti.rect = rect;
	tti.uId = id;
	tti.lpszText = szTipText;
	//新增一个提示  
	SendMessage(m_hwTip, TTM_UPDATETIPTEXT, 0, (LPARAM)(LPTOOLINFO)&tti);
}
void   TKLineControl::AddRectTool(int id, RECT rect, LPWSTR szTipText)
{
	TOOLINFO  tti;

	//设置提示窗口的信息  
	memset(&tti, 0, sizeof(TOOLINFO));
	tti.cbSize = TTTOOLINFOA_V2_SIZE;
	tti.uFlags = TTF_SUBCLASS;
	tti.hwnd = GetWindow()->GetHwnd();
	tti.rect = rect;
	tti.uId = id;
	tti.lpszText = szTipText;
	//新增一个提示  
	SendMessage(m_hwTip, TTM_ADDTOOL, 0, (LPARAM)(LPTOOLINFO)&tti);
	SendMessage(m_hwTip, TTM_SETTIPBKCOLOR, COLORREF(RGB(220, 220, 220)), 0);
}
void TKLineControl::DelRectTool()
{
	if (!m_bRegToolTip)
		return;
	RECT rect = m_Rects[TOP_LINKAGE];
	TOOLINFO  tti;

	//设置提示窗口的信息  
	memset(&tti, 0, sizeof(TOOLINFO));
	tti.cbSize = TTTOOLINFOA_V2_SIZE;
	tti.uFlags = TTF_SUBCLASS;
	tti.hwnd = GetWindow()->GetHwnd();
	tti.rect = rect;
	tti.uId = 0;
	tti.lpszText = L"";
	//新增一个提示  
	SendMessage(m_hwTip, TTM_DELTOOL, 0, (LPARAM)(LPTOOLINFO)&tti);
	m_bRegToolTip = false;
}
void TKLineControl::IntervalAmplification(int nStar, int nEnd)
{
	m_bAmplification = false;
	int nTail = m_Contract.KLineTail;
	int nRate = m_Contract.KLineSRate;
	int nShape = m_Contract.KLineShape;
	RECT cc_r = m_Rects[CENTER_CHART];
	int nIndex = m_AxisX.PixelData[cc_r.right] == nEnd ? 0: m_AxisX.PixelData[cc_r.right] - nEnd - 1;
	nTail +=(nIndex + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	TKLineChart& chart = m_Chart[0];
	RECT r(chart.CenterChartRect);
	int pw = r.right - r.left;
	int r_width = ((m_Contract.Deno > 1) ? RIGHT_WIDTH + WIDTH_EX : RIGHT_WIDTH);
	pw = (pw - r_width > 0) ? (pw - r_width) : 0;
	int nWidth = pw / (nEnd - nStar + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	for (int i = G_QuoteUtils.ShapSize-1; i > 0; i--)
	{
		if (G_QuoteUtils.KLineShapes[i].AreaWidth <= nWidth)
		{
			nShape = i;
			break;
		}
	}
	if (m_Contract.Amplification(nTail, nRate, nShape))
	{
		m_ShapeChart.ResetShape();
		Redraw(NULL);
		SetFocus();
	}
}
void TKLineControl::SwitchKLineIndicate(wchar_t* pName)
{
	CIndex* pIndex = CIndexMgr::GetInstance()->GetIndexByName(pName);
	if (pIndex)
	{
		if (pIndex->GetIndexType() == TREND_TYPE)//主图指标
		{
			m_Chart[0].KChartSpec[0].Visible = true;
			m_Chart[0].KChartSpec[1].Visible = false;
			if (MAIN_CHART_KLINE == m_Contract.MainChart)
			{
				SetChartSpace(m_Chart[0].KChartSpec[1], pIndex, true);
				m_Chart[0].KChartSpec[1].Visible = true;
			}
		}
		else // 副图指标
		{
			TKLineChart* pChar =NULL;
			for (int i = 1; i < sizeof(m_Chart) / sizeof(TKLineChart); i++)
			{
				if (!m_Chart[i].Visible)
				{
					break;
				}
				pChar = &m_Chart[i];
			}
			if (!pChar)
			{
				m_Chart[1].Visible = true;
				pChar = &m_Chart[1];
			}
			SetChartSpace(pChar->KChartSpec[0], pIndex, true);
		}
		Redraw(NULL);
		SetFocus();
	}
}
bool TKLineControl::CalIntervalStatistics(int nStar, int nEnd)
{
	memset(&m_rsData, 0, sizeof(RSStruct));
	strcpy_s(m_rsData.cno, m_Contract.Cont->ContractNo);
	m_rsData.Precision = m_Contract.Cont->Commodity->PricePrec;
	m_rsData.CommodityDenominator = m_Contract.Cont->Commodity->PriceDeno;
	m_rsData.kind = m_Contract.KLineType;
	m_rsData.nStar = nStar;
	SHisQuoteData dStar = m_AxisX.KData.GetData(nStar);
	m_rsData.StarTime = dStar.DateTimeStamp;
	m_rsData.Star = dStar.QOpeningPrice;
	m_rsData.nEnd = nEnd;
	SHisQuoteData dEnd = m_AxisX.KData.GetData(nEnd);
	m_rsData.EndTime = dEnd.DateTimeStamp;
	m_rsData.End = dEnd.QLastPrice;
	m_rsData.nCount = (nEnd - nStar+1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	m_rsData.nAxisBegin = m_AxisX.Begin;
	m_rsData.nAxisEnd = m_AxisX.End;
	//计算最高价最低价
	double maxY = -10000000;
	double minY = 10000000;
	double tolVolPrice = 0.0;
	int curr(nStar);
	int nTmp = (nEnd + 1 + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	while (curr != nTmp)
	{
		SHisQuoteData d = m_AxisX.KData.GetData(curr);

		if (d.QHighPrice>maxY)
		{
			maxY = d.QHighPrice;
		}
		if (d.QLowPrice<minY)
		{
			minY = d.QLowPrice;
		}
		if (d.QLastPrice > d.QOpeningPrice)
			m_rsData.nUp++;
		else if (d.QLastPrice < d.QOpeningPrice)
			m_rsData.nDown++;
		else
			m_rsData.nEque++;

		m_rsData.Volume += d.QLastQty;
		tolVolPrice += (double)(d.QLastPrice*d.QLastQty);
		curr = (curr + 1) % MAX_SHOW_KLINE_X;
	}
	m_rsData.High = maxY;
	m_rsData.Low = minY;
	//仓差
	m_rsData.AmountDif = dEnd.QPositionQty - dStar.QPositionQty;
	//加权均价
	m_rsData.WeightAve = tolVolPrice / m_rsData.Volume;
	//涨幅
	m_rsData.rise = (m_rsData.End - m_rsData.Star) / m_rsData.Star;
	//振幅
	m_rsData.swing = (m_rsData.High - m_rsData.Low) / m_rsData.Star;
	TKLineChart& chart = m_Chart[0];
	RECT r(chart.CenterChartRect);
	int i = (nEnd - m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	m_nEndX = r.left + m_AxisX.DataPos[i] + m_AxisX.DataWidth[i] / 2;
	i = (nStar - m_AxisX.Begin + MAX_SHOW_KLINE_X) % MAX_SHOW_KLINE_X;
	m_BeginPoint.x = r.left + m_AxisX.DataPos[i] + m_AxisX.DataWidth[i] / 2;
	if (m_nEndX <= m_BeginPoint.x)
		return false;
	m_bStatisticsShape = true;
	Redraw(NULL);
	return true;
}
void TKLineControl::IntervalStatistics(int nStar, int nEnd)
{
	if(CalIntervalStatistics(nStar, nEnd))
	     ((TQuoteFrame*)GetWindow())->OpenIntervalStatisticsDlg(&m_rsData);
	m_bStatistics = false;
	m_bStatisticsShape = false;
}
void TKLineControl::SaveParams(TKChartSpec* linespace)
{
	if (!linespace)
		return;
	int nLength = sizeof(linespace->Params) / sizeof(TKLineSpecParam);
	std::vector<TKLineSpecParam> vParams;
	for (int j = 0; j < nLength; j++)
	{
		vParams.push_back(linespace->Params[j]);
	}
	IndexParams::GetInstance()->AddParams(linespace->SpecName, vParams);
	IndexParams::GetInstance()->SaveModifyParamInfo();
}
#pragma once
#include "LzhCompress.h"
//ָ����
typedef struct tagCODE
{
	DWORD nOperator;
	union {
		float fValue;
		int	  nValue;
		struct
		{
			BYTE byte1;
			BYTE byte2;
			BYTE byte3;
			BYTE byte4;
		};
	};
} CODE;

typedef struct tagREFRERNCE
{
	char strFmlName[21];
	char strVarName[21];
} REFRERNCE;

class CFormulaResultItem
{
public:
	CFormulaResultItem();
	virtual ~CFormulaResultItem();

	char		m_strName[21];
	WORD		m_nStyle;
	WORD		m_nLineThick;
	int			m_nColor;
	CDataArray*	m_pDataArray;
	int 		m_nDrawType;
	void*		m_pFncDrawItem;
};
#define COMPRESS_BUFFER_LEN	65536
static char CompressInBuffer[COMPRESS_BUFFER_LEN];
static char CompressOutBuffer[COMPRESS_BUFFER_LEN];
static CLzhCompress LzhCompress;
typedef std::vector<CFormulaResultItem*> FormulaResultItemsVector;
class CIndex
{
public:
	CIndex();
	~CIndex();
public:
	void                SetIndexName(wchar_t* pName) { wcscpy_s(m_wName, pName); }
	wchar_t*            GetIndexName() { return m_wName; }
	void                SetIsVisiable(bool bVisiable) { m_bVisible = bVisiable; }
	bool                GetIsVisiable() { return m_bVisible; }
	void                SetIndexType(INDEX_TYPE type) { m_Type = type; }
	INDEX_TYPE          GetIndexType() { return m_Type; }
	void                SetCalcIndeCallback(FuncCalcIndicator pCallback) { m_pCalcIndiCallback = pCallback; }
	FuncCalcIndicator   GetCalcIndeCallback() { return m_pCalcIndiCallback; }
	void                SetParam(int index, TKLineSpecParam& param);
	TKLineSpecParam&    GetParam(int index);
	TKLineSpecParam*    GetParamAddr() { return m_Params; }
	void                ClearArrays();
	void                Serialize(FILE* file,bool bLoad, int type);
private:
	uint                GetStringLength(FILE* file);
public:
	int			               m_nCodeSize;
	CODE*		               m_pCode;
	std::string                m_strFnc;                              //ָ��Դ��
	std::vector<REFRERNCE*>    m_References;
	FormulaResultItemsVector   m_ResultItems;
	std::string	               m_strVarNames;
	int                        m_nNumParam;
	std::string		           m_strParamWizard;	//
	std::string		           m_strNotes;			//
	std::string		           m_strGroup;			//
	std::string 	           m_strDescript;		//
	std::string           	   m_strDrawStrings;
	BOOL		               m_bSystem;

	WORD		                m_wProperty;

	WORD		                m_wForbidenPeriod;	//
	int			                m_nDefaultPeriod;
	BOOL                        m_bMainChart;
	std::vector <float>         m_Ticks;
	BOOL	                    m_bEnterSignal;
private:
	wchar_t						m_wName[21];					//ָ������
	bool						m_bVisible;					   //��ʾ
	INDEX_TYPE                  m_Type;                        //����
	FuncCalcIndicator			m_pCalcIndiCallback;           //ָ�����ص�
	TKLineSpecParam				m_Params[6];				   //����
															   //������ʽȨ�������ֶ�,����ʹ������,ʹ���û�,�Ƿ���������,�����ֶ�
	__time64_t m_lExpireTm;
	std::string   m_strLimitUser;
	BOOL m_bExport;
	BYTE m_Reserved[32];//�õ�һ���ֽڱ�ʾ�Ƿ����ָ��
};


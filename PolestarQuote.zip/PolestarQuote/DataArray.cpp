#include "PreInclude.h"


CDataArray::CDataArray()
	:m_nNumData(0), m_nStartIndex(0), m_pData(NULL)
{}

CDataArray::CDataArray(int nNumData, int nStartIndex)
	: m_nNumData(0), m_nStartIndex(0), m_pData(NULL)
{
	SetSize(nNumData, nStartIndex);
}

CDataArray::~CDataArray()
{
	if (m_pData) delete[] m_pData;
}

void CDataArray::SetAt(int nIndex, float fValue)
{
	if (nIndex >= m_nNumData)//���Ȳ����ˣ�Ҫ��̬����
	{
		int nOldNum = m_nNumData;
		m_nNumData = nIndex + 1;
		m_pData = (float *)realloc(m_pData, sizeof(float)*m_nNumData);
		//Ҫ��������Ŀռ丳��ʼֵ
		for (int i = nOldNum; i<m_nNumData; i++)
			m_pData[i] = 0;
	}
	m_pData[nIndex] = fValue;
}

void CDataArray::SetSize(int nNumData, int nStartIndex)
{
	if (m_pData && m_nNumData != nNumData)
	{
		delete[] m_pData;
		m_pData = NULL;
	}

	if (!m_pData && nNumData > 0)
	{
		m_pData = new float[nNumData];
		memset(m_pData, 0, sizeof(float)*nNumData);
	}

	m_nNumData = nNumData;
	m_nStartIndex = nStartIndex;
}

void CDataArray::CopyFrom(CDataArray *pSrc)
{
	SetSize(pSrc->m_nNumData, pSrc->m_nStartIndex);
	if (m_nNumData > 0)
	{
		if (m_nStartIndex < 0) return;
		float* ptr1 = m_pData + m_nStartIndex;
		float* ptr2 = pSrc->m_pData + m_nStartIndex;
		int nCount = m_nNumData - m_nStartIndex;
		memcpy(ptr1, ptr2, sizeof(float)*nCount);
	}
}

void CDataArray::CopyFrom(float fValue)
{
	if (m_nNumData > 0)
	{
		float* ptr = m_pData + m_nStartIndex;
		int nCount = m_nNumData - m_nStartIndex;
		while (nCount--)
		{
			*ptr++ = fValue;
		}
	}
}

BOOL CDataArray::GetMinMaxValue(float& fMinValue, float& fMaxValue, int nStartIndex, int nEndIndex)
{
	if ((nEndIndex - nStartIndex >= 0) &&
		(nStartIndex >= m_nStartIndex) &&
		(nEndIndex <= m_nNumData - 1))
	{
		float* pData = m_pData + nStartIndex;
		fMinValue = fMaxValue = *pData++;
		for (int i = nStartIndex + 1; i <= nEndIndex; i++)
		{
			if (*pData < fMinValue) fMinValue = *pData;
			if (*pData > fMaxValue) fMaxValue = *pData;
			pData++;
		}
		return TRUE;
	}
	return FALSE;
}

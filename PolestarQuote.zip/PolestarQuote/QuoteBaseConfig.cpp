#include "PreInclude.h"

const int RHigh = 20;
int CWidth = 100;
const int TEXTDIF = 5;
QuoteBaseConfig::QuoteBaseConfig() :m_nType(TYPE_LASTSETTLE),m_bShowDiv(true), m_bShowRGBar(true), m_bColMirror(true),
m_bLeftBid(true),m_bEnterTLine(false), m_bBidRAskG(false), m_bAccumulate(true)
{
	if(G_LANG->LangId()== ENU)
		CWidth = 135;
}
QuoteBaseConfig::~QuoteBaseConfig()
{

}

bool QuoteBaseConfig::Create(HWND hparent)
{
	CreateFrm(_T("TBaseWnd"), hparent, WS_CHILD /*| WS_VISIBLE */| WS_CLIPCHILDREN);
	SetWindowPos(m_Hwnd, 0, 0, 0, 500, 400, SWP_NOZORDER);
	CreateSubCtrls();
	return true;
}

void QuoteBaseConfig::CreateSubCtrls()
{
	LoadCfg();
	m_UpDownStd.Create(m_Hwnd, 0, false);
	m_UpDownStd.MoveWindow(CWidth, 0, 100, 18);
	m_UpDownStd.SetFont(FONT_CONTRL_QUOTE);
	m_UpDownStd.Clear();
	m_UpDownStd.AddString(G_LANG->LangText(TLI_LastSettle));
	m_UpDownStd.AddString(G_LANG->LangText(TLI_LastPrice));
	m_UpDownStd.ResizeData();
	m_UpDownStd.SetSelect(m_nType);

	m_DclickGrid.Create(m_Hwnd, 1, false);
	m_DclickGrid.MoveWindow(400 + 80, 0, 100, 18);
	m_DclickGrid.SetFont(FONT_CONTRL_QUOTE);
	m_DclickGrid.Clear();
	m_DclickGrid.AddString(G_LANG->LangText(TLI_ENTER_TLINE));
	m_DclickGrid.AddString(G_LANG->LangText(TLI_ENTER_KLINE));
	m_DclickGrid.ResizeData();
	m_DclickGrid.SetSelect(m_bEnterTLine?0:1);

	m_RGBar.Create(m_Hwnd);
	m_RGBar.MoveWindow(TEXTDIF, 30, 180, 27);
	m_RGBar.SetText(G_LANG->LangText(TLI_ShOWTIMERGBAR));
	m_RGBar.SetCheck(m_bShowRGBar);

	m_ChkDiv.Create(m_Hwnd);
	m_ChkDiv.MoveWindow(400, 30, 180, 27);
	m_ChkDiv.SetText(G_LANG->LangText(TLI_TODAY_YESTERDAY_DEVISION));
	m_ChkDiv.SetCheck(m_bShowDiv);

	m_LeftBid.Create(m_Hwnd);
	m_LeftBid.MoveWindow(TEXTDIF, 57, 260, 27);
	m_LeftBid.SetText(G_LANG->LangText(TLI_LEFT_BID_RIGHT_ASK));
	m_LeftBid.SetCheck(m_bLeftBid);

	m_Morror.Create(m_Hwnd);
	m_Morror.MoveWindow(400, 57, 180, 27);
	m_Morror.SetText(G_LANG->LangText(TLI_SHOWCOLUMNMORROR));
	m_Morror.SetCheck(m_bColMirror);

	m_BidRAskG.Create(m_Hwnd);
	m_BidRAskG.MoveWindow(TEXTDIF, 84, 180, 27);
	m_BidRAskG.SetText(G_LANG->LangText(TLI_PANEL_BID_RED_ASK_GREEN));
	m_BidRAskG.SetCheck(m_bBidRAskG);

	m_Accumulate.Create(m_Hwnd);
	m_Accumulate.MoveWindow(400, 84, 180, 27);
	m_Accumulate.SetText(G_LANG->LangText(TLI_SHOW_ACCUMULATION));
	m_Accumulate.SetCheck(m_bAccumulate);
}
void QuoteBaseConfig::RegistQuoteFrame(TQuoteFrame* pFrame)
{
	LoadCfg();
	m_vpQuoteFrame.push_back(pFrame);
	pFrame->SetUpDownRefType(m_nType);
	pFrame->SetIsShowDevision(m_bShowDiv);
	pFrame->SetIsShowTimeLineRGBar(m_bShowRGBar);
	pFrame->SetShowColumnMirror(m_bColMirror);
	pFrame->SetIsLeftBid(m_bLeftBid);
	pFrame->SetIsEnterTLine(m_bEnterTLine);
	pFrame->SetIsBidRedAskGreen(m_bBidRAskG);
	pFrame->SetIsShowAccumulate(m_bAccumulate);
}
void QuoteBaseConfig::UnRegistQuoteFrame(TQuoteFrame* pFrame)
{
	auto it = m_vpQuoteFrame.begin();
	while( it != m_vpQuoteFrame.end())
	{
		if (*it == pFrame)
			it = m_vpQuoteFrame.erase(it);
		else
			++it;
	}
}
LRESULT QuoteBaseConfig::WndProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_PAINT:
		OnPaint();
		break;
	case WM_DESTROY:
		OnDestory();
		break;
	default:
		return NOT_PROCESSED;
	}
   return PROCESSED;
}
void QuoteBaseConfig::OnPaint()
{
	TMemDC memdc(m_Hwnd);
	RECT rect;
	GetClientRect(m_Hwnd, &rect);
	FillRect(memdc.GetHdc(), &rect, BRUSH_BG_QUOTE);
	HFONT hFont = CreateFont(14, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
		CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("����"));
	RECT rctext = rect;
	rctext.top = TEXTDIF;
	rctext.left = TEXTDIF;
	rctext.right = rctext.left + CWidth;
	rctext.bottom = RHigh;
	SelectObject(memdc.GetHdc(), hFont);
	DrawText(memdc.GetHdc(), G_LANG->LangText(TLI_CHANGE_REFERENCE), wcslen(G_LANG->LangText(TLI_CHANGE_REFERENCE)), &rctext, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
	
	rctext.top = TEXTDIF;
	rctext.left = 400;
	rctext.right = rctext.left + 80;
	rctext.bottom = RHigh;
	SelectObject(memdc.GetHdc(), hFont);
	DrawText(memdc.GetHdc(), G_LANG->LangText(TLI_DCLICK_GRID), wcslen(G_LANG->LangText(TLI_DCLICK_GRID)), &rctext, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
	DeleteFont(hFont);
}
void QuoteBaseConfig::OnDestory()
{
	m_nType = (UpDownRefType)m_UpDownStd.GetSelect();
	m_bEnterTLine = m_DclickGrid.GetSelect() == 0 ? true:false;
	m_bShowDiv = m_ChkDiv.GetCheck();
	m_bShowRGBar = m_RGBar.GetCheck();
	m_bColMirror = m_Morror.GetCheck();
	m_bLeftBid = m_LeftBid.GetCheck();
	m_bBidRAskG = m_BidRAskG.GetCheck();
	m_bAccumulate = m_Accumulate.GetCheck();
	for (auto it = m_vpQuoteFrame.begin(); it != m_vpQuoteFrame.end(); it++)
	{
		TQuoteFrame* pFrame = *it;
		if (pFrame)
		{
			pFrame->SetUpDownRefType(m_nType);
			pFrame->SetIsShowDevision(m_bShowDiv);
			pFrame->SetIsShowTimeLineRGBar(m_bShowRGBar);
			pFrame->SetShowColumnMirror(m_bColMirror);
			pFrame->SetIsLeftBid(m_bLeftBid);
			pFrame->SetIsEnterTLine(m_bEnterTLine);
			pFrame->SetIsBidRedAskGreen(m_bBidRAskG);
			pFrame->SetIsShowAccumulate(m_bAccumulate);
		}
	}
	SaveCfg();
	m_UpDownStd.ReleaseComboxList();
	m_DclickGrid.ReleaseComboxList();
}
void QuoteBaseConfig::LoadCfg()
{
	wchar_t currpath[1024];
	CurrPath(currpath, sizeof(currpath) / sizeof(wchar_t));

	wchar_t filename[1024];
	wsprintf(filename, L"%s\\config\\PolestarQuote\\PolestarQuote.QuoteBaseConfig.%s.pri", currpath, G_LANG->LangName());
	std::ifstream icin;
	icin.open(filename);
	char temp[100];//����һ���ַ�����temp
	icin >> temp;
	m_nType = (UpDownRefType)atoi(temp);
	icin >> m_bShowDiv;
	icin >> m_bShowRGBar;
	icin >> m_bColMirror;
	icin >> m_bLeftBid;
	icin >> m_bEnterTLine;
	icin >> m_bBidRAskG;
	icin >> m_bAccumulate;
	icin.close();
}
void QuoteBaseConfig::SaveCfg()
{
	wchar_t currpath[1024];
	CurrPath(currpath, sizeof(currpath) / sizeof(wchar_t));

	wchar_t filename[1024];
	wsprintf(filename, L"%s\\config\\PolestarQuote\\PolestarQuote.QuoteBaseConfig.%s.pri", currpath, G_LANG->LangName());
	std::ofstream ocout;
	ocout.open(filename);
	ocout << (int)m_nType;
	ocout << " ";
	ocout << m_bShowDiv;
	ocout << " ";
	ocout << m_bShowRGBar;
	ocout << " ";
	ocout << m_bColMirror;
	ocout << " ";
	ocout << m_bLeftBid;
	ocout << " ";
	ocout << m_bEnterTLine;
	ocout << " ";
	ocout << m_bBidRAskG;
	ocout << " ";
	ocout << m_bAccumulate;
	ocout.close();
}
#ifndef _GLOBAL_
#define _GLOBAL_

//��������Դ����
const wchar_t LANG_POLESTARQUOTE[] = L"PolestarQuote";
enum TLangIndex_PolestarQuote
{
	TLI_INVALUE                        = -1,
	TLI_ALIGN_ALL						= 0,
	TLI_ALIGN_LEFT						= 1,
	TLI_ALIGN_MIDDLE					= 2,
	TLI_ALIGN_RIGHT						= 3,
	TLI_CONFIG_COLUMN					= 4,
	TLI_SELECT_CONTRACT					= 5,
	TLI_MOVEUP							= 6,
	TLI_MOVEDOWN						= 7,
	TLI_BTN_OK							= 8,
	TLI_BTN_CANCEL						= 9,
	TLI_COL_VISIBLE						= 10,
	TLI_COL_NAME						= 11,
	TLI_COL_ALIGN						= 12,
	TLI_EXCHANGE						= 13,
	TLI_COMMODITY						= 14,
	TLI_CONTRACT						= 15,
	TLI_SELECTED_CONTRACT				= 16,
	TLI_POLESTAR_QUOTE					= 17,
	TLI_SEL_FUTURES						= 18,
	TLI_SEL_OPTIONS						= 19,
	TLI_SEL_INDEX						= 20,
	TLI_SEL_SPREAD						= 21,
	TLI_SEL_SPREAD2						= 22,
	TLI_CONTRACT_INDEX					= 23,
	TLI_CONTRACT_MAIN					= 24,
	TLI_CONTRACT_NEARBY					= 25,
	TLI_SELL_TEXT						= 26,
	TLI_BUY_TEXT						= 27,
	TLI_SELL1_TEXT						= 28,
	TLI_SELL2_TEXT						= 29,
	TLI_SELL3_TEXT						= 30,
	TLI_SELL4_TEXT						= 31,
	TLI_SELL5_TEXT						= 32,
	TLI_SELL6_TEXT						= 33,
	TLI_SELL7_TEXT						= 34,
	TLI_SELL8_TEXT						= 35,
	TLI_SELL9_TEXT						= 36,
	TLI_SELL10_TEXT						= 37,
	TLI_BUY1_TEXT						= 38,
	TLI_BUY2_TEXT						= 39,
	TLI_BUY3_TEXT						= 40,
	TLI_BUY4_TEXT						= 41,
	TLI_BUY5_TEXT						= 42,
	TLI_BUY6_TEXT						= 43,
	TLI_BUY7_TEXT						= 44,
	TLI_BUY8_TEXT						= 45,
	TLI_BUY9_TEXT						= 46,
	TLI_BUY10_TEXT						= 47,
	TLI_NEW_TEXT						= 48,
	TLI_NEWVOL_TEXT						= 49,
	TLI_VOL_TEXT						= 50,
	TLI_POSITION_TEXT					= 51,
	TLI_OPENING_TEXT					= 52,
	TLI_PRESETTLE_TEXT					= 53,
	TLI_UPDOWN_TEXT						= 54,
	TLI_UPRATE_TEXT						= 55,
	TLI_HIGH_TEXT						= 56,
	TLI_LOW_TEXT						= 57,
	TLI_LIMITUP_TEXT					= 58,
	TLI_LIMITDOWN_TEXT					= 59,
	TLI_TICK_TIME						= 60,
	TLI_TICK_PRICE						= 61,
	TLI_TICK_HOLDCHG					= 62,
	TLI_TICK_OFFSET						= 63,
	TLI_PANEL_QUOTE1					= 64,
	TLI_PANEL_QUOTE5					= 65,
	TLI_PANEL_QUOTE10					= 66,
	TLI_PANEL_CHG						= 67,
	TLI_PANEL_BIDCHG					= 68,
	TLI_PANEL_ASKCHG					= 69,
	TLI_PANEL_OPEN						= 70,
	TLI_PANEL_BIDOPEN					= 71,
	TLI_PANEL_ASKOPEN					= 72,
	TLI_PANEL_OFFSET					= 73,
	TLI_PANEL_BIDOFF					= 74,
	TLI_PANEL_ASKOFF					= 75,
	TLI_PANEL_TOTALBID					= 76,
	TLI_PANEL_TOTALASK					= 77,
	TLI_STRIKEPRICE_TITLE				= 78,
	TLI_OPTION_SERIES					= 79,
	TLI_FUTURE_TARGET					= 80,
	TLI_SELECT_OPTION					= 81,
	TLI_DELETE_CONTRACT					= 82,
	TLI_SEL_SPOT						= 83,
	TLI_TRADING_DATE					= 84,
	TLI_KLINE_DATE_TIME					= 85,
	TLI_TLINE_PRICE						= 86,
	TLI_TLINE_AVG_PRICE					= 87,
	TLI_KLINE_OPENING					= 88,
	TLI_KLINE_HIGH						= 89,
	TLI_KLINE_LOW						= 90,
	TLI_KLINE_CLOSE						= 91,
	TLI_KLINE_VOL						= 92,
	TLI_KLINE_POSITION					= 93,
	TLI_SWITCH_TLINE					= 94,
	TLI_SWITCH_KLINE					= 95,
	TLI_SWITCH_GRID						= 96,
	TLI_OPEN_PANEL						= 97,
	TLI_CLOSE_PANEL						= 98,
	TLI_ADD_SELF						= 99,
	TLI_HIDE_RG_BAR						= 100,
	TLI_SHOW_RG_BAR						= 101,
	TLI_MA_CONFIG						= 102,
	TLI_BTN_CLEAR						= 103,
	TLI_RELOAD_HISQUOTE					= 104,
	TLI_AUTO_ADJUST_COL_WIDTH			= 105,
	TLI_SUB_GRAPH_ADD					= 106,
	TLI_SUB_GRAPH_DEL					= 107,

	TLI_LINE_ORDER						= 110,
	TLI_LINE_ORDER_FAIL					= 111,
	TLI_LINE_ORDER_BUY					= 112,
	TLI_LINE_ORDER_SELL					= 113,
	TLI_LINE_ORDER_POSITION_BUY			= 114,
	TLI_LINE_ORDER_POSITION_SELL		= 115,
	TLI_LINE_ORDER_BACK					= 116,
	TLI_LINE_ORDER_HAND					= 117,
	TLI_LINE_ORDER_HINT					= 118,
	TLI_LINE_ORDER_OFFSET				= 119,
    TLI_LINE_TAKE_PROFIT                = 120,
	TLI_LINE_STOP_LOSS					= 121,

	TLI_KLINE_TIME						= 201,				//��ʱͼ
	TLI_KLINE_TICK						= 202,				//����ͼ

	TLI_KLINE_SEC5						= 211,				//5��
	TLI_KLINE_SEC10						= 212,				//10��
	TLI_KLINE_SEC15						= 213,				//15��
	TLI_KLINE_SEC30						= 214,				//30��

	TLI_KLINE_MIN1						= 221,				//1����
	TLI_KLINE_MIN3						= 222,				//3����
	TLI_KLINE_MIN5						= 223,				//5����
	TLI_KLINE_MIN10						= 224,				//10����
	TLI_KLINE_MIN15						= 225,				//15����
	TLI_KLINE_MIN30						= 226,				//30����
	TLI_KLINE_HOUR1						= 227,				//1Сʱ
	
	TLI_KLINE_DAY1						= 231,				//1��
	TLI_KLINE_WEEK1						= 232,				//1��
	TLI_KLINE_MONTH1					= 233,				//1��
	TLI_KLINE_YEAR1						= 234,				//1��
	TLI_LOCAL_SPREAD					= 235,              //��������
	TLI_SELECT_LOCAL_SPREAD				= 236,              //ѡ�񱾵�����
	TLI_BASIC_SETTINGS					= 237,              //��������
	TLI_MODIFY_PARAM                    = 238,              //�����޸�
	TLI_OPEN_TARGET				        = 239,              //��ָ��
	TLI_CLOASE_TARGET					= 240,              //�ر�ָ��
	TLI_LastSettle						= 241,              //�����
	TLI_LastPrice						= 242,              //��һ��
	TLI_CHANGE_REFERENCE				= 243,              //�����ۺ���
	TLI_ADD_SELF_Plate					= 244,              //������ѡ 
	TLI_TODAY_YESTERDAY_DEVISION		= 245,              //����/����ָ���
    TLI_BUYSTRATEGY                     = 246,              //���뽨�ֲ��Է���
	TLI_SELLSTRATEGY					= 247,              //�������ֲ��Է���
	TLI_BUYOTMCOST                      = 248,              //������ֵ��Ȩ�ɱ�
	TLI_BUYITMCOST						= 249,              //����ʵֵ��Ȩ�ɱ�
	TLI_SELLCALLOTMCOST					= 250,              //����������ֵ��Ȩ�ɱ�
	TLI_SELLPUTOTMCOST                  = 251,              //����������ֵ��Ȩ�ɱ�
	TLI_BUYCALLPROFIT                   = 252,              //���뿴������
	TLI_BUYPUTPROFIT					= 253,              //���뿴������
	TLI_SELLCALLPROFIT					= 254,              //������������
	TLI_SELLPUTPROFIT					= 255,              //������������
	TLI_BUYCALLOTMEXPLAN                = 256,              //�����ǽ���
	TLI_BUYPUTOTMEXPLAN					= 257,              //���������
	TLI_BUYCALLITMEXPLAN				= 258,              //��С�ǽ���
	TLI_BUYPUTITMEXPLAN					= 259,              //��С������
	TLI_SELLOTMEXPLAN				    = 260,              //�����ǵ�����
	TLI_STRIKEPRICE						= 261,              //��Ȩ��
	TLI_BALANCEPOINT					= 262,              //����ƽ���
	TLI_TIMEVALUE						= 263,              //ʱ���ֵ
	TLI_LEVERAGERATIO					= 264,              //�ܸ˱���
	TLI_OPTIONCALCULATOR				= 265,              //��Ȩ������
	TLI_INTRINSICVALUE					= 266,              //���ڼ�ֵ
	TLI_PREMIUMRATIO					= 267,				//�����
	TLI_EFFECTIVEGEARING				= 268,				//��ʵ�ܸ���
	TLI_OPTIONSTARTDATE                 = 269,              //��Ȩ��ʼ��
	TLI_EXERCISERATE					= 270,              //��Ȩ����
	TLI_IMPLIEDVOLIATILITY				= 271,              //����������
	TLI_THEORETICALPRICE				= 272,				//���ۼ۸�
	TLI_EXERCISEDATE                    = 273,              //��Ȩ��
	TLI_LASTTRADINGDATE                 = 274,              //�������
	TLI_OPTIONTYPE						= 275,              //��Ȩ����
	TLI_OPTIONSTRIKEPRICE               = 276,
	TLI_AMERICAN						= 278,              //��ʽ
	TLI_EUROPEAN						= 279,              //ŷʽ
	TLI_DOMESTICCONTACT					= 280,              //���̺�Լ
	TLI_ABORDCCONTACT					= 281,              //���̺�Լ
    TLI_APPEARANCESETTINGS              = 282,              //��ɫ����
	TLI_COLUMN1                         = 283,              //��1
	TLI_COLUMN                          = 284,              //��
    TLI_LISTFONT                        = 285,              //�б�����
	TLI_ITEMSETTING                     = 286,              //��������
	TLI_ITEMSALL                        = 287,              //ȫ��
	TLI_ITEMHEAD                        = 288,              //��ͷ
	TLI_ITEMBODY                        = 289,              //����
	TLI_ITEMSELECTED                    = 290,              //ѡ��
	TLI_BACKCOLOR                       = 291,              //����ɫ
	TLI_TEXTCOLOR                       = 292,              //����ɫ
	TLI_ROWHEIGHT                       = 293,              //�б��и�
	TLI_UPCOLOR                         = 294,              //����ɫ
	TLI_DOWNCOLOR                       = 295,              //�µ�ɫ
	TLI_CHANGEDCOLOR                    = 296,              //�䶯ɫ
	TLI_CHANGETEXTHL                    = 297,              //�䶯���ָ���
	TLI_CHANGEBACKGROUNDHL              = 298,              //�䶯��ɫ����
	TLI_BUYSELLVOLHL                    = 299,              //������������
	TLI_APPLY                           = 300,              //Ӧ��
	TLI_CANCLE                          = 301,              //ȡ��
	TLI_BULLISH                         = 302,              //����  
	TLI_BEARISH                         = 303,              //���
	TLI_NOTRISE                         = 304,              //����
	TLI_NOTFALL                         = 305,              //����
	TLI_BREAK                           = 306,              //ͻ��
	TLI_DULL                            = 307,              //����
	TLI_BREAKSTRANGLE                   = 308,              //ͻ��(��)
	TLI_DULLSTRANGLE                    = 309,              //����(��)
	TLI_TEMPERATURERISE                 = 310,              //����
	TLI_TEMPERATURERISEPUT              = 311,              //������ׯ
	TLI_TEMPERATUREFALLCALL             = 312,              //�µ���ׯ
	TLI_TEMPERATUREFALL                 = 313,              //�µ�
	TLI_PROBABILITY                     = 314,              //����
	TLI_PROFITANDLOSS                   = 315,              //����
	TLI_NODIRECTPRICE                   = 316,              //��Լ��������
	TLI_FREESTYLE                       = 317,              //�������
	TLI_ShOWTIMERGBAR                   = 318,              //�Ƿ���ʾ��ʱͼ������
	TLI_OPENSTRATEGYGRAPHY              = 319,              //�򿪲���ͼ
	TLI_ClOSESTRATEGYGRAPHY             = 320,              //�رղ���ͼ
	TLI_SHOWCOLUMNMORROR                = 321,              //��ͷ������ʾ
	TLI_EXPIRATIONPRICE                 = 322,              //���ڼ�λ
	TLI_SMALLPANEL                      = 323,              //С�̿�
	TLI_TIPINFO                         = 324,              //��ʾ
	TLI_ADDSUBGRAPHYTIP                 = 325,              //���Ӹ�ͼ��ʾ
	TLI_ENTERANALYSISCHART              = 326,              //�������ͼ��
	TLI_ASKPRICE                        = 327,              //ѯ��
	TLI_DRAWLINE                        = 328,              //����
	TLI_HORIZONTAL_LINE                 = 329,              //ˮƽ��
	TLI_VERTICAL_LINE                   = 330,              //��ֱ��
	TLI_TREND_LINE                      = 331,              //������
	TLI_LINE_SEGMENT                    = 332,              //�߶�
	TLI_LEADER_LINE                     = 333,              //ָ����
	TLI_PARALLEL_LINE                   = 334,              //ƽ����
	TLI_TRIANGLE                        = 335,				//������
	TLI_RECTANGLE                       = 336,				//����
	TLI_GOLDEN_SECTION					= 337,				//�ƽ�ָ���
	TLI_PERCENTAGE_LINE					= 338,				//�ٷֱ���
	TLI_PERIODIC_LINE					= 339,				//������
	TLI_FIBONACCI_LINE					= 340,				//�Ѳ�������
	TLI_RESISTANCE_LINE					= 341,				//������
	TLI_GANN_LINE						= 342,				//������	
	TLI_REGRESSION_CHANNEL				= 343,			    //���Իع�ͨ��
	TLI_ARC_LINE						= 344,				//����
	TLI_SEMICIRCLE						= 345,				//��Բ��
	TLI_DEL_SINGLE_SHAPE                = 346,              //ɾ��
    TLI_DEL_ALL_SHAPES                  = 347,              //ȫ��ɾ��
    TLI_MAX_SHAPES_NUMBER               = 348,              //���ͼ������
	TLI_DRAW_LINE_TOOLS                 = 349,              //���߹���
	TLI_LEFT_BID_RIGHT_ASK              = 350,               //�̿ں�������������
	TLI_AXIS_RANGE                      = 351,               //���귶Χ
	TLI_SYMMETRIC_AXIS                  = 352,               //�Գ�����
	TLI_LIMIT_AXIS                      = 353,               //ͣ������
	TLI_FULL_AXIS                       = 354,               //��ռ����
	TLI_INCLUDEBUYTARGET                = 355,               //��������
	TLI_INCLUDESELLTARGET               = 356,               //���������
	TLI_FULLSCREENREATORE               = 357,               //ȫ����ʾ/�ָ�
	TLI_SWING_ANALYSIS                  = 358,               //�ڶ�����
	TLI_VOLUME_ANALYSIS                 = 359,               //���ַ���
	TLI_CUSTOM                          = 360,                //�Զ���
	TLI_CUSTOM_BEGIN                    = 361,
	TLI_CUSTOM_END                      = 460,
    TLI_SECOND                          = 461,                //��
	TLI_MINUTE                          = 462,                //����
	TLI_HOUR                            = 463,                //Сʱ
	TLI_DAY                             = 464,                //��
    TLI_MANAGE                          = 465,                //����
	TLI_TYPE                            = 466,                //����
	TLI_PERIOD_NUM                      = 467,                //������
	TLI_THOUSAND                        = 468,                //ǧ
	TLI_MILLION                         = 469,                //����
	TLI_BILLION                         = 470,                //ʮ��
	TLI_DCLICK_GRID                     = 471,                //˫������
	TLI_ENTER_TLINE                     = 472,                //���÷�ʱͼ
	TLI_ENTER_KLINE                     = 473,                //����K��ͼ
	TLI_FONT_CONFIG                     = 474,                 //��������
	TLI_GRID_FONT                       = 475,                //�б�����
	TLI_COLUMN_HEADER                   = 476,                //��ͷ����
	TLI_QUOTE_TEXT                      = 477,                //��������
	TLI_PANEL_FONT                      = 478,                //�̿�����
	TLI_FIRST_PRICE                     = 479,                //һ���ҵ�
	TLI_OTHER_PRICE                     = 480,                //�����ҵ�
    TLI_TICK_DETAIL                     = 481,                //�̿���ϸ
	TLI_SMALL_FONT                      = 482,                //С����
	TLI_MIDDLE_FONT                     = 483,                //������
	TLI_BIG_FONT                        = 484,                //������
	TLI_PERIOD_NUMBER_ERROR             = 485,                //����������
	TLI_ALEADY_EXISTS                   = 486,                //�Ѵ���
	TLI_MOST_SUPPER                     = 487,               //���֧��99
	TLI_PANEL_BID_RED_ASK_GREEN         = 488,                //�̿��������
	TLI_BULLISH_TIP                     = 489,               //������ʾ 
	TLI_BEARISH_TIP                     = 490,               //�����ʾ
	TLI_NOTRISE_TIP                     = 491,               //������ʾ
	TLI_NOTFALL_TIP                     = 492,              //������ʾ
	TLI_BREAK_TIP                       = 493,              //ͻ����ʾ
	TLI_DULL_TIP                        = 494,              //������ʾ
	TLI_BREAKSTRANGLE_TIP               = 495,              //ͻ��(��)��ʾ
	TLI_DULLSTRANGLE_TIP                = 496,              //����(��)��ʾ
	TLI_TEMPERATURERISE_TIP             = 497,              //������ʾ
	TLI_TEMPERATURERISEPUT_TIP          = 498,              //������ׯ��ʾ
	TLI_TEMPERATUREFALLCALL_TIP         = 499,              //�µ���ׯ��ʾ
	TLI_TEMPERATUREFALL_TIP             = 500,              //�µ���ʾ
	TLI_LINKAGE_WINDOW                  = 501,              //��������
	TLI_UNLINKAGE_WINDOW                = 502,              //����������
	TLI_CUSTOM_PERIOD                   = 503,               //�Զ�������
	TLI_ADD                             = 504,               //����
	TLI_DELETE                          = 505,               //ɾ��
	TLI_OVERLAP_CONTRACT                = 506,               //���Ӻϼs
	TLI_SELECTED_ALL                    = 507,               //ȫѡ
	TLI_CLEAR_ALL                       = 508,               //ȫ��
	TLI_DAY_PERIOD_NUMBER_ERROR         = 509,               //DAY����������
	TLI_OTHER_EXCHANGE                  = 510,               //����������
	TLI_STYLE_SETTING                   = 511,               //�������
	TLI_BLACK_STYLE                     = 512,               //��ɫ���
	TLI_GRAY_STYLE                      = 513,               //�Ұ׷��
	TLI_PANEL_TEXT                      = 514,               //�̿�����
	TLI_PANEL_TICK                      = 515,               //��ϸ
	TLI_OPTION_GRIDE                    = 516,               //T�ͱ���
	TLI_OPTION_INMONEY                  = 517,               //ʵֵ
	TLI_OPTION_OUTMONEY                 = 518,               //��ֵ
	TLI_QUOTE_GRIDE                     = 519,                //�����б�
	TLI_KLINE_GRAPH                     = 520,                //K��ͼ
	TLI_ESUNNY_INFORMATION              = 521,               //��ʢ��Ϣ����
	TLI_KLINE_BACKGROUND                = 522,               //ͼ�α���
	TLI_KLINE_TEXT                      = 523,               //ͼ������
	TLI_KLINE_UP                        = 524,               //����
	TLI_KLINE_DOWN                      = 525,                //����
	TLI_TLINE_PRICE_LINE                = 526,                //��ʱ�۸���
	TLI_TLINE_AVERAGE                   = 527,                //��ʱ������
	TLI__KLINE_INDEX                    = 528,                //ָ����
	TLI_PANEL_MUTIPLY                   = 529,                //�̿ڶ൵
	TLI_BID_QTY                         = 530,                //����
	TLI_ASK_QTY                         = 531,                //����
	TLI_SHOW_ACCUMULATION               = 532,                //�̿���ʾ�ۻ���
	TLI_INTERVAL_AMPLIFICATION          = 533,                //����Ŵ�
	TLI_OPTION_ANALYSIS                 = 534,               //��Ȩ����
	TLI_INTERVAL_STATISTICS             = 535,                //����ͳ��
	TLI_STAR_TIME                       = 536,                //��ʼʱ��
	TLI_END_TIME                        = 537,                //����ʱ��
	TLI_INITIAL_PRICE                   = 538,                //�ڳ���
	TLI_HIGHEST_PRICE                   = 539,                 //��߼�
	TLI_LOWEST_PRICE                    = 540,                //��ͼ�
	TLI_FINAL_PRICE                     = 541,                 //��ĩ��
	TLI_VOLUME                          = 542,                //�ɽ���
	TLI_HOLD_CHANGES                    = 543,                 //�ֲ�
	TLI_AVERAGE_PRICE                   = 544,                 //��Ȩ����
    TLI_INTERVAL_GROWTH                 = 545,                 //�����Ƿ�
	TLI_INTERVAL_SWING                  = 546,                 //�������
	TLI_PERIOD                          = 547,                 //����
	TLI_UP_NUM                          = 548,                 //����
	TLI_DOWN_NUM                        = 549,                 //����
	TLI_EQUAL_NUM                       = 550,                 //ƽ��
	TLI_RESTORE_DEFAULT_PARAM           = 551,                  //�ָ�Ĭ�ϲ���
	TLI_BUY_ORDER                       = 552,                  //���붩��
	TLI_SELL_ORDER                      = 553,                  //��������
	TLI_COVER_ORDER                     = 554,                  //ƽ�ֶ���
	TLI_BACKHAND_ORDER                  = 555,                  //���ֶ���
	TLI_STOP_LOSS                       = 556,                  //ֹ�𶩵�
	TLI_STOP_PROFIT                     = 557,                  //ֹӯ����
	TLI_BUY_POSITION                    = 558,                  //��ͷ�ֲ�
	TLI_SELL_POSITION                   = 559,                  //��ͷ�ֲ�
	TLI_EXTRA_LARGE_FONT                = 560,                  //�ش�����
	TLI_BAR_STYLE                       = 561,                  //��ͼ����
	TLI_KLINE                           = 562,                  //K��
	TLI_BAR_CHART                       = 563,                   //������
	TLI_CLOSE_LINE                      = 564,                  //��λ��
	TLI_TOWER_LINE                      = 565,                  //������
	TLI_SYSTEM_SPREAD                   = 566,                   //ϵͳ����
	TLI_PRICE_COEF                      = 567,                   //�۸�ϵ��
	TLI_CUSTOM_TYPE                     = 568,                   //(���裩
	TLI_SYSTEM_TYPE                     = 569,                   //(ϵͳ��
	TLI_MOVE_TOP                        = 570,                   //�ö�
    TLI_MOVE_BOTTOM                     = 571,                    //�õ�
	TLI_APPLIED_ALL_PLATES              = 572,                     //Ӧ�õ����а��
	TLI_JUMP_ATTHEMONEY                 = 573,                    //������ƽ
	TLI_SHORTCUT_KEY                    = 574,                    //��ݼ�����
	TLI_PLATE_NAME                      = 575,                    //�������
	TLI_SHORTCUT_NAME                   = 576,                      //��ݼ�
	TLI_MODIFY                          = 577,                       //�޸�
	TLI_MDSC_ERR_CODE_1                 = 578,                       //�޸Ŀ�ݼ�������1
	TLI_MDSC_ERR_CODE_2                 = 579,                       //�޸Ŀ�ݼ�������2
	TLI_MDSC_ERR_CODE_3                 = 580,                       //�޸Ŀ�ݼ�������3
	TLI_MDSC_ERR_CODE_4                 = 581,                       //�޸Ŀ�ݼ�������4
	TLI_MDSC_ERR_CODE_5                 = 582,                       //�޸Ŀ�ݼ�������5
	TLI_MENU_QUOTE_GRID                 = 583,                        //���鱨��
	TLI_MENU_TIME_LINE                  = 584,                        //��ʱͼ
	TLI_MENU_KLINE                      = 585,                        //K��ͼ
	TLI_MENU_TICK_LINE                  = 586,                        //TICK
	TLI_MENU_OPTION                     = 587,                        //��Ȩ
	TLI_MENU_DRAW_LINE                  = 588,                        //���߹���
	TLI_PRICE_ALERT                     = 589,                         //�۸�Ԥ��
};
enum UpDownRefType
{
	TYPE_LASTSETTLE						= 0,
	TYPE_LASTPRICE						= 1,
};
#define SSWM_TAB_SWITCH_FOCUS					WM_USER + 101
#define SSWM_COMBOX_SELECT						WM_USER + 102
#define SSWM_COMBOX_CHECK_CHANAGE				WM_USER + 103
#define SSWM_CHECKBOX_CHECK_CHANAGE				WM_USER + 104
#define SSWM_STATIC_BUTTON_CLICKDOWN			WM_USER + 105
#define SSWM_SET_EDIT_CLICKDOWN                 WM_USER + 106
#define SSWM_SET_LIST_CLICKDOWN                 WM_USER + 107
extern HCURSOR CURSOR_ARROW;
extern HCURSOR CURSOR_WE;		//����
extern HCURSOR CURSOR_NS;		//����
extern HCURSOR CURSOR_WSE;		//���Ϻ�����
extern HCURSOR CURSOR_ESW;		//���º�����
extern HCURSOR CURSOR_ALL;
//ȫ�ֶ���---------------------------------------------------------------------------------------------------------------------------------
extern IMainFrame* G_MainFrame;
extern ILanguageApi* G_LANG;
extern IStrategyTradeAPI* G_LineOrderApi;
extern IConfigFrame* G_ConfigFrame;
extern ICommonModule* G_CommonApi;
extern IStarApi* G_StarApi;
extern IQuickData* G_QuickData;
//���鴰��---------------------------------------------------------------------------------------------------------------------------------
//const COLORREF COLOR_QUOTEFRAME_BACKGROUND = RGB(29, 28, 36);
const COLORREF COLOR_QUOTEFRAME_BACKGROUND = RGB(15, 15, 15);//RGB(15, 15, 15);

extern HBRUSH BRUSH_QUOTEFRAME_BACKGROUND;

//���-------------------------------------------------------------------------------------------------------------------------------------
//const COLORREF COLOR_PLATE_BACKGROUND = RGB(39, 38, 46);
extern COLORREF COLOR_PLATE_BACKGROUND;
const COLORREF COLOR_PLATE_LINE = RGB(71, 69, 76);
extern COLORREF COLOR_PLATE_FONT;
extern COLORREF COLOR_PLATE_FONT2 ;
extern COLORREF COLOR_PLATE_FONT_HOT;
extern COLORREF COLOR_PLATE_FONT_HOT2 ;
const COLORREF COLOR_PLATE_MENU = COLOR_PLATE_FONT;
const COLORREF COLOR_PLATE_MENU_HOVER = COLOR_PLATE_FONT_HOT;

extern HBRUSH BRUSH_PLATE_BACKGROUND;

extern HPEN PEN_PLATE_LINE;
extern HPEN PEN_PLATE_MENU;
extern HPEN PEN_PLATE_MENU_HOVER;

extern HFONT FONT_PLATE;
extern HFONT FONT_BLOD_PLATE;
//������-----------------------------------------------------------------------------------------------------------------------------------
const COLORREF COLOR_SCROLL_BACKGROUND = RGB(125, 125, 125);						//��ť����
extern COLORREF COLOR_SCROLL_FOREGROUND ;							//����������
const COLORREF COLOR_SCROLL_BLOCK = COLOR_SCROLL_BACKGROUND;						//����
const COLORREF COLOR_SCROLL_GRAPH = COLOR_SCROLL_FOREGROUND;						//��ͷ

extern HBRUSH BRUSH_SCROLL_BACKGROUND;
extern HBRUSH BRUSH_SCROLL_FOREGROUND;
extern HBRUSH BRUSH_SCROLL_BLOCK;

extern HPEN PEN_SCROLL_GRAPH;

//�ڻ�����-----------------------------------------------------------------------------------------------------------------------------------
extern COLORREF COLOR_FUTURE_BACKGROUND;			   //����ɫ
extern COLORREF COLOR_FUTURE_HEAD_BACKGROUND ;		  //��ͷ����ɫ
extern COLORREF COLOR_FUTURE_ROW_BACKGROUND;		  //���ı���ɫ
extern COLORREF COLOR_FUTURE_SEL_BACKGROUND;		  //ѡ�б���ɫ
extern COLORREF COLOR_FUTURE_TITLE;                   //��ͷ����
extern COLORREF COLOR_FUTURE_STR;			          //�ַ����ֶ�
extern COLORREF COLOR_FUTURE_SEL_TEXT;               //ѡ������ɫ
extern COLORREF COLOR_FUTURE_UP;				     //�۸���
extern COLORREF COLOR_FUTURE_DOWN ;				     //�۸��
extern COLORREF COLOR_FUTURE_CHANGED;				 //�۸�䶯ɫ
extern COLORREF COLOR_OPTION_SERIES;
extern COLORREF COLOR_FUTURE_EQUAL;			         //�۸��ǲ���
extern COLORREF COLOR_FUTURE_SEL;			         //ѡ����
const COLORREF COLOR_FUTURE_TITLELINE = RGB(138, 0, 0);	
const COLORREF COLOR_FUTURE_VSCROLL = RGB(100, 100, 100);
extern COLORREF COLOR_INMONEY_BACKGROUND;//RGB(30, 0, 0);//RGB(35, 15, 15);		//ʵֵ��Ȩ����ɫ
extern COLORREF COLOR_OUTMONEY_BACKGROUND;//RGB(0, 30, 0);//RGB(20, 35, 20);		//��ֵ��Ȩ����ɫ
const COLORREF COLOR_OPTION_AXIS = RGB(255, 0, 0);
const COLORREF COLOR_OPTION_BENEFIT_LINE = RGB(255, 127, 0);
const COLORREF COLOR_OPTION_BENEFIT_BACKGROUND = RGB(13, 16, 18);
const COLORREF COLOR_OPTION_CHART_SCALE = RGB(128, 128, 128);

extern HBRUSH BRUSH_FUTURE_BACKGROUND;
extern HBRUSH BRUSH_FUTURE_HEAD_BACKGROUND;
extern HBRUSH BRUSH_FUTURE_ROW_BACKGROUND;
extern HBRUSH BRUSH_FUTURE_SEL_BACKGROUND;
extern HBRUSH BRUSH_FUTURE_SEL;
extern HBRUSH BRUSH_FUTURE_VSCROLL;
extern HBRUSH BRUSH_INMONEY_BACKGROUND;
extern HBRUSH BRUSH_OUTMONEY_BACKGROUND;
extern HBRUSH BRUSH_FUTURE_UP;
extern HBRUSH BRUSH_FUTURE_DOWN;
extern HBRUSH BRUSH_OPTION_BENEFIT_BACKGROUND;
extern HBRUSH BRUSH_OPTION_BENEFIT;

extern HPEN PEN_FUTURE_TITLELINE;
extern HPEN PEN_OPTION_TITLE_LINE;
extern HPEN PEN_OPTION_SERIES;

extern HFONT FONT_FUTURE_TITLE;
extern HFONT FONT_FUTURE_CHS;
extern HFONT FONT_FUTURE_CONTENT;

extern HPEN PEN_OPTION_AXIS;
extern HPEN PEN_OPTION_BENEFIT_LINE;
extern HPEN PEN_OPTION_BALANCE_LINE;
extern HPEN PEN_OPTION_STRIKE_LINE;
//���ô���-----------------------------------------------------------------------------------------------------------------------------------
extern COLORREF COLOR_CONFIGWINDOW_BACKGROUND;
const COLORREF COLOR_DUICONTROL_BACKGROUND = RGB(39, 38, 46);
const COLORREF COLOR_DRAW_TOOL_BACKGROUND =  RGB(240, 240, 240);
extern HBRUSH BRUSH_CONFIGWINDOW_BACKGROUND;
extern HBRUSH BRUSH_DUICONTROL_BACKGROUND;
extern HBRUSH BRUSH_DRAW_TOOL_BACKGROUND;
//�����̿�-----------------------------------------------------------------------------------------------------------------------------------
extern COLORREF COLOR_PANEL_BACKGROUND;
extern COLORREF COLOR_PANEL_LINE; //RGB(138, 0, 0);
extern COLORREF COLOR_PANEL_STR ;				//���ж��ǵ��� �䶯�ַ���
extern COLORREF COLOR_PANEL_PRICE_TEXT;
extern COLORREF COLOR_PANEL_TICK_TEXT;
extern COLORREF COLOR_PANEL_MULTI_BID;
extern COLORREF COLOR_PANEL_MULTI_ASK;

extern HBRUSH BRUSH_PANEL_BACKGROUND;
extern HBRUSH BRUSH_PANEL_LINE;

extern HPEN PEN_PANEL_LINE;
extern HPEN PEN_PANEL_DOT_LINE;
extern HPEN PEN_PANEL_ARROW;
extern HFONT FONT_PANEL_TEXT;
extern HFONT FONT_PANEL_CONTRACT;
extern HFONT FONT_PANEL_BIG_PRICE;
extern HFONT FONT_PANEL_SMALL_PRICE;
extern HFONT FONT_PANEL_TICK_PRICE;
extern HFONT FONT_PANEL_ONE_LEVEL;
extern HFONT FONT_PANEL_OTHER_LEVEL;

//K�ߴ���-------------------------------------------------------------------------------------------------------------------------------------
extern COLORREF COLOR_KLINE_BACKGROUND;
const COLORREF COLOR_KLINE_GRID_LINE = RGB(46, 46, 46);//RGB(138, 0, 0)
const COLORREF COLOR_KLINE_DOT_GRID_LINE = RGB(34, 34, 34);
const COLORREF COLOR_KLINE_GRID_TEXT = RGB(120, 120, 120);
extern COLORREF COLOR_KLINE_MENU_TEXT;//RGB(231, 231, 231);
extern COLORREF COLOR_TLINE_PRICE;
extern COLORREF COLOR_TLINE_AVG_PRICE;
const COLORREF COLOR_TLINE_RED_BAR = RGB(255, 60, 57);
const COLORREF COLOR_TLINE_GREEN_BAR = RGB(0, 220, 0);
extern COLORREF COLOR_KLINE_RED_BAR;
extern COLORREF COLOR_KLINE_GREEN_BAR;
extern COLORREF COLOR_KLINE_WHITE_BAR;
extern COLORREF COLOR_KLINE_CROSS;
const COLORREF COLOR_KLINE_DIVISION = RGB(60, 60, 60);

extern HBRUSH BRUSH_KLINE_BACKGROUND;
extern HBRUSH BRUSH_KLINE_RED_BAR;
extern HBRUSH BRUSH_KLINE_GREEN_BAR;
extern HBRUSH BRUSH_KLINE_CROSS;
extern HBRUSH BRUSH_KLINE_GRID_LINE;

extern HPEN PEN_KLINE_GRID_LINE;
extern HPEN PEN_KLINE_GRID_DOTLINE;
extern HPEN PEN_TLINE_PRICE;
extern HPEN PEN_TLINE_AVG_PRICE;
extern HPEN PEN_TLINE_RED_BAR;
extern HPEN PEN_TLINE_GREEN_BAR;
extern HPEN PEN_KLINE_RED_BAR;
extern HPEN PEN_KLINE_GREEN_BAR;
extern HPEN PEN_KLINE_WHITE_BAR;
extern HPEN PEN_KLINE_RED_BAR_DOT;
extern HPEN PEN_KLINE_GREEN_BAR_DOT;
extern HPEN PEN_KLINE_CYCLE;
extern HPEN PEN_KLINE_GRAY_DOT;

extern HFONT FONT_KLINE_TEXT;
extern HFONT FONT_KLINE_NUMBER;

extern COLORREF COLOR_SPEC_LINE[];
extern HPEN PEN_SPEC_LINE[];
extern HFONT FONT_TIP_TEXT;
//�����µ�------------------------------------------------------------------------------------------------------------------------------------
extern COLORREF COLOR_LINE_ORDER_BUY;     //��
extern HPEN PEN_LINE_ORDER_BUY;
extern COLORREF COLOR_LINE_ORDER_SELL;    //��
extern HPEN PEN_LINE_ORDER_SELL;
extern COLORREF COLOR_LINE_ORDER_COVER;   //ƽ
extern HPEN PEN_LINE_ORDER_COVER;
extern COLORREF COLOR_LINE_ORDER_BACK;     //��
extern HPEN PEN_LINE_ORDER_BACK;
extern COLORREF COLOR_LINE_ORDER_LOSS;     //��
extern HPEN PEN_LINE_ORDER_LOSS;
extern COLORREF COLOR_LINE_ORDER_PROFIT;   //Ӯ
extern HPEN PEN_LINE_ORDER_PROFIT;
extern COLORREF COLOR_LINE_POSITION_BUY;    //�ֲֶ�
extern HPEN PEN_LINE_POSITION_BUY;
extern COLORREF COLOR_LINE_POSITION_SELL;  //�ֲֿ�
extern HPEN PEN_LINE_POSITION_SELL;


extern HCURSOR CURSOR_HAND;
extern HCURSOR CURSOR_HAND_MOVE;
extern HCURSOR CURSOR_LINE;
extern HCURSOR CURSOR_DEL;
extern HCURSOR CURSOR_HAND_POINT;
//��������------------------------------------------------------------------------------------------------------------------------------------
const char POLESTAR_QUOTE_LINKAGE_SENDER[] = "PolestarQuote";
const char MOUSE_ORDER_LINKAGE_SENDER[] = "MouseOrder";
const char LINE_ORDER_LINKAGE_SENDER[] = "LineOrder";
const char AGRIDX_STRATEGY_LINKAGE_SENDER[] = "AgridxStrategy";
const char QUICK_MACRO_LINKAGE_SENDER[] = "QuickMacro";
const char TOOL_BAR_LINKAGE_SENDER[] = "TOOLBAR_SENDER";
const char SYSTEM_MENU_LINKAGE_SENDER[] = "SYSMENU_SENDER";

const char LINE_ORDER_BEGIN = 'B';
const char LINE_ORDER_END = 'E';
const char LINE_ORDER_DEL = 'D';

//ϵͳ���ÿؼ�
const COLORREF COLOR_IMAGE_GRAY = RGB(150, 150, 150);
const COLORREF g_color_white = RGB(231, 231, 231);
const COLORREF COLOR_QUOTE_CONFIG_BG = RGB(255, 255, 255);
const COLORREF COLOR_QUOTE_CONFIG_FONT = RGB(0, 0, 0);
const COLORREF COLOR_CONTRL_FOCUSE = RGB(126, 180, 234);
const COLORREF COLOR_DRAW_LINE_CLOSE = RGB(232, 17, 35);
extern HBRUSH BRUSH_IMAGE_GRAY;
extern HBRUSH g_brush_white;
extern HBRUSH BRUSH_BG_QUOTE;
extern HBRUSH BRUSH_CONTRL_FOCUSE;
extern HBRUSH BRUSH_CONTRL_FRAME;
extern HBRUSH BRUSH_DRAWLINE_CLOSE;
extern HFONT FONT_CONTRL_QUOTE;
//��Ȩ����
extern COLORREF COLOR_STRATEGY_LINE;
extern HBRUSH BRUSH_STRATEGY_LINE;
class QuoteBaseConfig;
class QuoteSkinConfig;
class QuoteFontConfig;
class QuoteShortcutConfig;
class DrawToolDlg;
class CustomPeriodDlg;
class IntervalStatisticsDlg;
class TQuoteFrame;

extern QuoteBaseConfig* g_BaseCfgDlg;
extern QuoteSkinConfig* g_SkinCfgDlg;
extern QuoteFontConfig* g_FontCfgDlg;
extern QuoteShortcutConfig* g_ShortcutCfgDlg;
extern DrawToolDlg*     g_pDrawTool;               //��ͼ����
extern std::vector<TQuoteFrame*> g_vFrames;

//ϵͳ���
extern SKIN_STYLE                  G_STYLE;
void __cdecl OnPolestarQuoteLinkage(HWND From, HWND To, const char* Sender, const char* Action, const char* Content);
void OnLineOrderLinkage(HWND From, HWND To, const char* Action);
void OnAgridxLinkage(HWND From, HWND To, const char* Action, const char* Content);
void OnQuickMacroLinkage(HWND From, HWND To, const char* Action, const char* Content);
void OnToolBarLinkage(HWND From, HWND To, const char* Action, const char* Content);
//����ϵͳ֪ͨ--------------------------------------------------------------------------------------------------------------------------------
bool PolestarQuoteLinkage(HWND hwnd, const char* action, const char* content);

//���в˵��ص�--------------------------------------------------------------------------------------------------------------------------------
void __cdecl PolestarQuoteMenuClick(const unsigned int MenuIndex, const HWND PastLife);
//����-����������
HWND __stdcall QuoteBaseConfigDlgCreatefunc(const wchar_t * sub_title, const HWND parent);
//����-���������
HWND __stdcall QuoteSkinConfigDlgCreatefunc(const wchar_t * sub_title, const HWND parent);
//����-����������
HWND __stdcall QuoteFontConfigDlgCreatefunc(const wchar_t * sub_title, const HWND parent);
//����-����ݼ�����
HWND __stdcall QuoteShortcutKeyConfigDlgCreatefunc(const wchar_t * sub_title, const HWND parent);
void DefaultSendOrder(TSendOrder&SendOrder);
std::vector<std::string> SplitString(const std::string & str, char cSplit);
void QOptionContractNoTypeToTradeOptionContract(const std::string &id, TContractKey &ContractKey);
void GetCurrScreenRect(RECT& r);
//ʮ������ת������
int HexToBin(const char * Text, char * Buffer, int BufSize);
//������תʮ������
void BinToHex(const char * Buffer, char * Text, int BufSize);
bool MByteToWChar(LPCSTR lpcszStr, LPWSTR lpwszStr, DWORD dwSize, UINT codepage = CP_UTF8);
bool WCharToMByte(LPCWSTR lpcwszStr, LPSTR lpszStr, DWORD dwSize, UINT codepage = CP_UTF8);
typedef wchar_t        W_Price_Type[21];
typedef wchar_t        W_Contract_Code_Type[101];
typedef wchar_t        W_Contract_Name_Type[101];
typedef wchar_t        W_Spread_Ratio_Type[101];
SRetType FormatPrice(IStarApi* pStarApi,const SPriceType price, const SCommodityPrecType prec, const SCommodityDenoType deno, W_Price_Type out, bool showdeno);
SRetType FormatPrice(IStarApi* pStarApi, const SPriceType price, const SCommodity* commodity, W_Price_Type out, bool showdeno);
SRetType FormatGreek(const SGreekType price, const SCommodityPrecType prec, W_Price_Type out);
bool GetContractCode(IStarApi* pStarApi, const SContractNoType contractno, W_Contract_Code_Type code);
bool GetContractName(IStarApi* pStarApi, const SContractNoType contractno, W_Contract_Name_Type name);
void GetSpreadRatio(SContractNoType cno, wchar_t* ratio, int nLen);
#endif
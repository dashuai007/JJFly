#pragma once
typedef struct tagDATAFILE_HEAD
{
	int		m_nType;			//�����ļ�����
	DWORD	m_dwVersion;		//�����ļ��汾��(V2.10 : 0x210)
}DATAFILE_HEAD;
#define dftFORMULA				-6
//ָ�������
class CIndexMgr
{
public:
	CIndexMgr();
	~CIndexMgr();
public:
	static CIndexMgr* GetInstance() { return &m_Instance; }
	void InitAllIndex();
	CIndex* GetIndex(INDEX_SPEC i);
	CIndex* GetIndexByName(wchar_t* name);
	int  GetMainIndexCount();
	int  GetSubIndexCount();
	int LoadFromFile(char* strFileName);
	int Load();
private:
	static CIndexMgr          m_Instance;
	std::vector<CIndex*>      m_vIndexs;
};


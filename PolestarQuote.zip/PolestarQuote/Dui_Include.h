#ifndef _DUI_INCLUDE_
#define _DUI_INCLUDE_

#pragma warning(disable : 4251)

#include "Dui_Type.h"
#include "Dui_Event.h"
#include "Dui_Basic.h"
#include "Dui_Extend.h"

#endif
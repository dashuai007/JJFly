﻿#include "PreInclude.h"

DrawToolDlg::DrawToolDlg()
{
	m_bhoverclose = false;
	m_btrack = false;
	m_bButtonDown = false;
	m_SelectShape = SHAPE_NONE;
	m_hImageList = ImageList_LoadImage(GetModuleHandle(L"PolestarQuote"), MAKEINTRESOURCE(IDB_BITMAP2), 16, 22, CLR_DEFAULT, IMAGE_BITMAP, LR_DEFAULTCOLOR);
}


DrawToolDlg::~DrawToolDlg()
{
	ImageList_Destroy(m_hImageList);
}
bool DrawToolDlg::Create(TQuoteFrame* pFrame)
{
	CreateFrm(_T("TToolWnd"), NULL, WS_POPUP | WS_VISIBLE | WS_CLIPCHILDREN| WS_BORDER, WS_EX_TOOLWINDOW | WS_EX_TOPMOST);
	m_hwTip = CreateWindowEx(WS_EX_TOPMOST,TOOLTIPS_CLASS,NULL,WS_POPUP| TTS_NOPREFIX| TTS_ALWAYSTIP,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,m_Hwnd,NULL, GetModuleHandle(NULL), NULL);
	SetWindowPos(m_hwTip,HWND_TOPMOST,0, 0, 0, 0,SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
	RECT r = { 0, 0, 0, 0 };
	if (pFrame)
		pFrame->GetRect(r);
	r.right -= r.left;
	r.bottom -= r.top;
	SetWindowPos(m_Hwnd,0, r.left + (r.right - WINDOW_WIDTH) / 2, r.top + (r.bottom - WINDOW_HEIGHT) / 2, WINDOW_WIDTH, WINDOW_HEIGHT, SWP_NOZORDER);
	InitShapeIcon();
	return true;
}
LRESULT DrawToolDlg::WndProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_PAINT:
		OnPaint();
		break;
	case WM_DESTROY:
		OnDestory();
		break;
	case WM_SIZE:
		OnSize();
		break;
	case WM_LBUTTONDOWN:
		OnLbuttonDown(wParam, lParam);
		break;
	case WM_LBUTTONUP:
		OnLbuttonUp(wParam, lParam);
		break;
	case WM_MOUSEMOVE:
		OnMouseMove();
		break;
	case WM_MOUSELEAVE:
		OnMouseLeave();
		break;
	default:
		return NOT_PROCESSED;
	}
	return PROCESSED;
}
void DrawToolDlg::OnPaint()
{
	TMemDC memdc(m_Hwnd);
	RECT rect;
	GetClientRect(m_Hwnd, &rect);
	FillRect(memdc.GetHdc(), &rect, BRUSH_DRAW_TOOL_BACKGROUND);
	FillRect(memdc.GetHdc(), &m_rctitle, BRUSH_BG_QUOTE);
	SelectObject(memdc.GetHdc(), FONT_CONTRL_QUOTE);
	RECT TitleTexRc = m_rctitle;
	TitleTexRc.left += 5;
	DrawText(memdc.GetHdc(), G_LANG->LangText(TLI_DRAW_LINE_TOOLS), wcslen(G_LANG->LangText(TLI_DRAW_LINE_TOOLS)), &TitleTexRc, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	//关闭按钮
	RECT rcclose = m_rctitle;
	rcclose.left = rcclose.right - CAPTION_HEIGHT;
	HPEN hpen;
	if (m_bhoverclose)
	{
		FillRect(memdc.GetHdc(), &rcclose, BRUSH_DRAWLINE_CLOSE);
		hpen = CreatePen(PS_SOLID, 1, COLOR_QUOTE_CONFIG_BG);
	}
	else
		hpen = CreatePen(PS_SOLID, 1, COLOR_KLINE_BACKGROUND);
	m_rcclose = rcclose;
	InflateRect(&rcclose, -8, -8);
	SelectObject(memdc.GetHdc(), hpen);
	MoveToEx(memdc.GetHdc(), rcclose.left, rcclose.top, 0);
	LineTo(memdc.GetHdc(), rcclose.right+1 , rcclose.bottom+1 );
	MoveToEx(memdc.GetHdc(), rcclose.left, rcclose.bottom, 0);
	LineTo(memdc.GetHdc(), rcclose.right+1, rcclose.top-1 );								
	DeleteObject(hpen);
	//绘制图标
	POINT pCur;
	GetCursorPos(&pCur);
	ScreenToClient(m_Hwnd, &pCur);
	for (int i = 0; i < m_VShapes.size(); i++)
	{
		SHAPE_ICON icon = m_VShapes[i];
		if (PtInRect(&icon.rect, pCur))
		{
			FillSolidRect(memdc.GetHdc(), &icon.rect, RGB(166,166,166));
		}
		POINT pt;
		if (m_SelectShape == icon.type&&m_bButtonDown)
		{
			pt.x = icon.rect.left + 6;
			pt.y = icon.rect.top + 6;
		}
		else
		{
			pt.x = icon.rect.left + 5;
			pt.y = icon.rect.top + 5;
		}
		ImageList_Draw(m_hImageList, icon.type, memdc.GetHdc(), pt.x, pt.y, ILD_NORMAL);
	}
}
void DrawToolDlg::OnDestory()
{
}
void DrawToolDlg::OnSize()
{
	RECT rect;
	GetClientRect(m_Hwnd, &rect);
	m_rctitle = rect;
	m_rctitle.bottom = CAPTION_HEIGHT;
}
void DrawToolDlg::OnLbuttonDown(WPARAM wParam, LPARAM lParam)
{
	m_bButtonDown = true;
	POINT pt;
	GetCursorPos(&pt);
	ScreenToClient(m_Hwnd, &pt);
	for (int i = 0; i < m_VShapes.size(); i++)
	{
		if (PtInRect(&m_VShapes[i].rect,pt))
		{
			m_SelectShape = m_VShapes[i].type;
		}
	}
	if (MK_LBUTTON == wParam&& PtInRect(&m_rctitle, pt) && !PtInRect(&m_rcclose, pt))
	{
		POINT pt;
		pt.x = LOWORD(lParam);
		pt.y = HIWORD(lParam);
		PostMessage(m_Hwnd, WM_NCLBUTTONDOWN, HTCAPTION, lParam/*MAKELPARAM(point.x, point.y)*/);
	}
	InvalidateRect(m_Hwnd, 0, true);
}
void DrawToolDlg::OnLbuttonUp(WPARAM wParam, LPARAM lParam)
{
	m_bButtonDown = false;
	POINT pt;
	GetCursorPos(&pt);
	ScreenToClient(m_Hwnd, &pt);
	if (PtInRect(&m_rcclose, pt))
	{
		DestroyWindow(m_Hwnd);
	}
	InvalidateRect(m_Hwnd, 0, true);
}
void DrawToolDlg::OnMouseMove()
{
	POINT pt;
	GetCursorPos(&pt);
	ScreenToClient(m_Hwnd, &pt);

	if (!m_btrack)
	{
		TRACKMOUSEEVENT tme;
		tme.cbSize = sizeof(tme);
		tme.dwFlags = TME_LEAVE;
		tme.hwndTrack = m_Hwnd;
		tme.dwHoverTime = 0;
		::TrackMouseEvent(&tme);
	}

	if (PtInRect(&m_rcclose, pt))
	{
		m_bhoverclose = true;
	}
	else
		m_bhoverclose = false;
	InvalidateRect(m_Hwnd, 0, false);
}
void DrawToolDlg::OnMouseLeave()
{
	m_btrack = false;
	m_bhoverclose = false;
	InvalidateRect(m_Hwnd, 0, false);
}
void DrawToolDlg::InitShapeIcon()
{
	m_VShapes.clear();
	RECT rect;
	GetClientRect(m_Hwnd, &rect);
	rect.top += CAPTION_HEIGHT;
	int span = 5;
	int nLeft = rect.left + span;
	int nTop = rect.top + span;
	for (int i = 0; i < SHAPE_COUNT; i++)
	{
		SHAPE_ICON icon;
		icon.type =(SHAPE_TYPE) i;
		icon.rect.left = nLeft;
		icon.rect.top = nTop;
		icon.rect.right = icon.rect.left + ICON_WIDTH;
		icon.rect.bottom = icon.rect.top + ICON_HIGTH;
		if (icon.rect.right + ICON_WIDTH > rect.right - span)
		{
			nLeft = rect.left + span;
			nTop = icon.rect.bottom ;
		}
		else
		{
			nLeft = icon.rect.right;
		}
		m_VShapes.push_back(icon);
		AddRectTool(i, icon.rect, (LPWSTR)G_LANG->LangText(TLI_HORIZONTAL_LINE+i));
	}
}
void  DrawToolDlg::AddRectTool(int id,RECT rect, LPWSTR szTipText)
{
	TOOLINFO  tti;

	//设置提示窗口的信息  
	memset(&tti, 0, sizeof(TOOLINFO));
	tti.cbSize  = TTTOOLINFOA_V2_SIZE;
	tti.uFlags  = TTF_SUBCLASS;
	tti.hwnd = m_Hwnd;
	tti.rect = rect;
	tti.uId = id;
	tti.lpszText=szTipText;
	//新增一个提示  
	SendMessage(m_hwTip, TTM_ADDTOOL, 0, (LPARAM)(LPTOOLINFO)&tti);
	SendMessage(m_hwTip, TTM_SETTIPBKCOLOR, COLORREF(RGB(220, 220, 220)),0);
}

